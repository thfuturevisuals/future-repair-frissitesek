"""Future Repair - damaged video / photo / audio file repair."""
__version__ = "1.5.5"

import time as _time

_LOADED_AT = _time.time()     # when this process loaded the package (see hotreload)
