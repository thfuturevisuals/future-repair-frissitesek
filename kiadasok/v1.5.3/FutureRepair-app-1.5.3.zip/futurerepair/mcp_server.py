"""Future Repair MCP server (stdio).

Lets Claude drive Future Repair on this computer: list and inspect media files, find a
healthy sample, run repairs as background jobs, verify results and look at frames.

Protocol: JSON-RPC 2.0, one message per line on stdin/stdout (MCP stdio transport).
Logs go to stderr only.
"""
from __future__ import annotations

import base64
import io
import json
import os
import re
import struct
import subprocess
import sys
import threading
import time
import traceback
import uuid
from concurrent.futures import ThreadPoolExecutor
from typing import Any, Callable, Dict, List, Optional

from . import __version__

PROTOCOLS = ["2025-06-18", "2025-03-26", "2024-11-05"]
SERVER_NAME = "future-repair"
MAX_WAIT = 50          # seconds a tool call may block while waiting for a job

INSTRUCTIONS = """Future Repair runs on the user's computer and repairs damaged media files
(MP4/MOV video, JPEG/RAW photos, WAV/MP3 audio). Paths are paths on that computer (network
shares like \\\\server\\share\\... work too). Originals are never modified; repaired copies get a
"_javitott" suffix next to the original unless `output` is given.

Typical video flow: inspect_file (is it broken? what codec?) -> find_reference (healthy sample from
the same camera, same resolution/fps/codec; scores how well it explains the broken data) ->
repair (returns a job; poll job_status) -> verify the output -> preview to look at frames.
Without a sample only the picture (and sometimes AAC audio) can be rebuilt, and only if the camera
wrote its codec headers into the stream. Messages from the engine are in Hungarian."""


def _log(*a) -> None:
    print("[future-repair]", *a, file=sys.stderr, flush=True)


# ---------------------------------------------------------------------------
# Jobs
# ---------------------------------------------------------------------------

class Job:
    def __init__(self, path: str, reference: Optional[str], output: Optional[str], fps: Optional[float]):
        self.id = uuid.uuid4().hex[:8]
        self.path = path
        self.reference = reference
        self.output = output
        self.fps = fps
        self.progress = 0.0
        self.step = "Várakozik"
        self.state = "queued"          # queued | running | done | cancelled | error
        self.result = None
        self.error = None
        self.started = time.time()
        self.finished: Optional[float] = None
        self.log: List[str] = []
        self.cancel_flag = False
        self.done_event = threading.Event()

    def as_dict(self, with_log: bool = False) -> dict:
        d = {
            "job_id": self.id,
            "path": self.path,
            "reference": self.reference,
            "state": self.state,
            "progress_percent": round(self.progress * 100, 1),
            "step": self.step,
            "elapsed_seconds": round((self.finished or time.time()) - self.started, 1),
        }
        if self.result is not None:
            r = self.result
            d["result"] = {
                "status": r.status,
                "message": r.message,
                "output": r.output,
                "warnings": r.warnings,
                "notes": r.notes,
                "details": {k: v for k, v in r.details.items() if k != "preview"},
            }
        if self.error:
            d["error"] = self.error
        if with_log:
            d["log"] = self.log[-150:]
        return d


class JobManager:
    def __init__(self):
        self.jobs: Dict[str, Job] = {}
        self.lock = threading.Lock()
        self.runner = ThreadPoolExecutor(max_workers=2, thread_name_prefix="repair")

    def start(self, path, reference, output, fps) -> Job:
        job = Job(path, reference, output, fps)
        with self.lock:
            self.jobs[job.id] = job
        self.runner.submit(self._run, job)
        return job

    def _run(self, job: Job) -> None:
        from .engine import repair
        from .result import Reporter
        job.state = "running"

        def on_step(s):
            job.step = s

        def on_log(s):
            job.log.append(s)

        try:
            rep = Reporter(on_step=on_step, on_log=on_log)
            res = repair(job.path, job.reference, job.output,
                         progress=lambda x: setattr(job, "progress", float(x)),
                         cancel=lambda: job.cancel_flag, reporter=rep, fps=job.fps)
            job.result = res
            job.state = "cancelled" if res.status == "cancelled" else "done"
            job.progress = 1.0
            job.step = "Kész"
        except Exception as e:  # noqa: BLE001
            job.error = "%s: %s" % (type(e).__name__, e)
            job.log.append(traceback.format_exc())
            job.state = "error"
        finally:
            job.finished = time.time()
            job.done_event.set()

    def get(self, job_id: str) -> Optional[Job]:
        with self.lock:
            return self.jobs.get(job_id)

    def all(self) -> List[Job]:
        with self.lock:
            return list(self.jobs.values())


JOBS = JobManager()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _norm(p: str) -> str:
    if not p:
        raise ValueError("Hiányzó útvonal.")
    p = os.path.expanduser(os.path.expandvars(p.strip().strip('"')))
    return os.path.normpath(p)


def _exists(p: str) -> str:
    p = _norm(p)
    if not os.path.exists(p):
        raise FileNotFoundError("Nem található: %s" % p)
    return p


def _human(n: float) -> str:
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if n < 1024 or unit == "TB":
            return ("%.0f %s" if unit in ("B", "KB") else "%.2f %s") % (n, unit)
        n /= 1024.0
    return str(n)


def _wait(job: Job, seconds: float, progress_cb: Optional[Callable[[Job], None]] = None) -> None:
    deadline = time.time() + max(0.0, min(float(seconds or 0), MAX_WAIT))
    while time.time() < deadline:
        if job.done_event.wait(timeout=min(2.0, max(0.05, deadline - time.time()))):
            return
        if progress_cb:
            progress_cb(job)


def _quick_status(path: str, kind: str) -> str:
    try:
        if kind == "video":
            from .video.analyze import read_layout
            lay = read_layout(path)
            if lay.moov is None or not any(t.sizes for t in lay.moov.tracks):
                return "sérült (nincs index)"
            for t in lay.moov.tracks:
                if t.sizes and t.offsets[-1] + t.sizes[-1] > lay.size:
                    return "sérült (csonka)"
            return "ép szerkezet"
        if kind == "photo":
            ext = os.path.splitext(path)[1].lower()
            if ext in (".jpg", ".jpeg", ".jpe", ".jfif"):
                from .photo.repair import parse_jpeg
                with open(path, "rb") as f:
                    data = f.read()
                if data[:3] != b"\xff\xd8\xff":
                    return "sérült (nincs JPEG fejléc)"
                info = parse_jpeg(data, 0)
                if info["end"] < 0:
                    return "sérült (csonka)"
                return "ép szerkezet"
            return "RAW (nincs gyorsellenőrzés)"
        if kind == "audio":
            if path.lower().endswith(".mp3"):
                return "MP3 (nincs gyorsellenőrzés)"
            size = os.path.getsize(path)
            with open(path, "rb") as f:
                head = f.read(1 << 16)
            if head[:4] not in (b"RIFF", b"RF64") or head[8:12] != b"WAVE":
                return "sérült (nincs WAV fejléc)"
            riff = struct.unpack("<I", head[4:8])[0]
            if head[:4] == b"RIFF" and riff + 8 != size and riff + 9 != size:
                return "gyanús (a fejléc szerinti méret eltér)"
            return "ép szerkezet"
    except Exception as e:  # noqa: BLE001
        return "hiba: %s" % e
    return "?"


# ---------------------------------------------------------------------------
# Tools
# ---------------------------------------------------------------------------

def tool_list_media(args: dict, ctx) -> dict:
    from .engine import classify, KIND_LABEL
    folder = _exists(args["folder"])
    recursive = bool(args.get("recursive", False))
    check = bool(args.get("check", True))
    limit = int(args.get("limit", 300))
    files = []
    walker = os.walk(folder) if recursive else [(folder, [], sorted(os.listdir(folder)))]
    for root, _dirs, names in walker:
        for n in sorted(names):
            p = os.path.join(root, n)
            if not os.path.isfile(p):
                continue
            kind = classify(p)
            if kind is None:
                continue
            item = {"path": p, "kind": kind, "kind_label": KIND_LABEL.get(kind, kind), "size": os.path.getsize(p)}
            if check:
                item["status"] = _quick_status(p, kind)
            files.append(item)
            if len(files) >= limit:
                break
        if len(files) >= limit:
            break
    lines = ["%d médiafájl itt: %s" % (len(files), folder)]
    for f in files:
        lines.append("- %s  [%s, %s]%s" % (os.path.relpath(f["path"], folder), f["kind_label"], _human(f["size"]),
                                         ("  → " + f["status"]) if "status" in f else ""))
    return {"text": "\n".join(lines), "data": {"folder": folder, "files": files}}


def tool_inspect_file(args: dict, ctx) -> dict:
    from .engine import classify
    path = _exists(args["path"])
    kind = classify(path)
    size = os.path.getsize(path)
    data: Dict[str, Any] = {"path": path, "kind": kind, "size": size}
    lines = ["%s (%s, %s)" % (path, kind or "ismeretlen", _human(size))]
    if kind == "video":
        from .video.analyze import read_layout
        lay = read_layout(path)
        data["top_level_boxes"] = [{"type": b.type.decode("latin-1"), "offset": b.start, "size": b.size,
                                    "truncated": b.truncated} for b in lay.top[:40]]
        data["mdat"] = {"start": lay.mdat_start, "end": lay.mdat_end, "declared_end": lay.mdat_declared_end}
        data["notes"] = lay.notes
        data["fragmented"] = lay.fragmented
        lines.append("Dobozok: " + ", ".join("%s@%d(%s)%s" % (b["type"], b["offset"], _human(b["size"]),
                                                             " CSONKA" if b["truncated"] else "")
                                            for b in data["top_level_boxes"][:12]))
        if lay.moov is None:
            data["index"] = "missing"
            lines.append("Index (moov): NINCS → a fájl megszakadt felvételnek tűnik; mintafájllal javítható.")
        else:
            tracks = []
            beyond = 0
            for t in lay.moov.tracks:
                n = len(t.sizes)
                dur = sum(t.durations) / float(t.timescale or 1)
                if t.sizes and t.offsets[-1] + t.sizes[-1] > lay.size:
                    beyond += 1
                tracks.append({"track_id": t.track_id, "handler": t.handler.decode("latin-1"),
                               "codec": t.codec.decode("latin-1"), "timescale": t.timescale, "samples": n,
                               "duration_seconds": round(dur, 2), "chunks": len(t.chunk_offsets),
                               "stsz_const": t.stsz_const})
            data["tracks"] = tracks
            data["index"] = "truncated" if beyond else "ok"
            for tr in tracks:
                lines.append("  sáv %s: %s/%s, %d minta, %.2f mp, %d chunk" % (
                    tr["track_id"], tr["handler"], tr["codec"], tr["samples"], tr["duration_seconds"], tr["chunks"]))
            lines.append("Index: " + ("rendben, minden adat a fájlban van" if not beyond else
                                      "megvan, de a fájl vége hiányzik (a saját indexéből javítható)"))
        if args.get("decode_check", True) and lay.moov is not None:
            from .video.verify import deep_verify
            v = deep_verify(path, points=4, frames_per_point=4)
            data["decode_check"] = v
            lines.append("Dekódolási próba: %s (%s)" % ("rendben" if v.get("ok") else "HIBÁS",
                                                       ", ".join("%.0f%%: %d kocka" % (c["position"] * 100, c["decoded"])
                                                                 for c in v.get("checks", []))))
    elif kind == "photo":
        with open(path, "rb") as f:
            blob = f.read()
        from .photo.repair import find_embedded_jpegs, parse_jpeg
        if blob[:3] == b"\xff\xd8\xff":
            info = parse_jpeg(blob, 0)
            data["jpeg"] = {k: v for k, v in info.items() if k != "segments"}
            data["jpeg"]["markers"] = ["%02X@%d" % (m, p) for m, p, _l in info["segments"][:40]]
            lines.append("JPEG %dx%d, fejléc vége: %d, EOI: %s" % (info["width"], info["height"], info["header_end"],
                                                                 "van" if info["end"] > 0 else "NINCS (csonka)"))
        emb = find_embedded_jpegs(blob)[:6]
        data["embedded_jpegs"] = [{"offset": s, "length": e - s, "width": w, "height": h} for s, e, w, h in emb]
        if emb:
            lines.append("Beágyazott JPEG-ek: " + ", ".join("%dx%d" % (w, h) for _s, _e, w, h in emb))
    elif kind == "audio":
        with open(path, "rb") as f:
            head = f.read(1 << 16)
        data["head_hex"] = head[:64].hex()
        if head[:4] in (b"RIFF", b"RF64"):
            from .audio.repair import _iter_riff_chunks
            chunks = [{"id": cid.decode("latin-1"), "offset": p, "size": sz} for cid, p, sz in _iter_riff_chunks(head)]
            data["riff_chunks"] = chunks
            lines.append("RIFF chunkok: " + ", ".join("%s(%d)" % (c["id"], c["size"]) for c in chunks))
    data["quick_status"] = _quick_status(path, kind) if kind else "ismeretlen típus"
    lines.append("Állapot: " + data["quick_status"])
    return {"text": "\n".join(lines), "data": data}


def tool_find_reference(args: dict, ctx) -> dict:
    from .suggest import match_score, suggest_reference
    path = _exists(args["path"])
    cand = args.get("candidate")
    if cand:
        cand = _exists(cand)
        sc = match_score(path, cand)
        verdict = "jó minta" if sc >= 0.9 else ("használható" if sc >= 0.5 else "NEM illik a sérült fájlhoz")
        return {"text": "A minta a sérült fájl elejének %.0f%%-át értelmezi → %s." % (sc * 100, verdict),
                "data": {"path": path, "candidate": cand, "score": round(sc, 3)}}
    ref = suggest_reference(path)
    if ref is None:
        return {"text": "Nem találtam megfelelő ép mintát a fájl mappájában. Adj meg egyet `candidate`-ként, "
                        "vagy keress egy ugyanazzal a kamerával, ugyanazzal a beállítással készült felvételt.",
                "data": {"path": path, "reference": None}}
    sc = match_score(path, ref)
    return {"text": "Javasolt minta: %s (illeszkedés: %.0f%%)" % (ref, sc * 100),
            "data": {"path": path, "reference": ref, "score": round(sc, 3)}}


def _job_text(job: Job, with_log: bool = False) -> str:
    d = job.as_dict()
    if job.state in ("queued", "running"):
        lines = ["Javítás folyamatban (job %s): %.0f%% – %s. Kérdezd le a job_status eszközzel." % (
            job.id, job.progress * 100, job.step)]
    elif job.state == "error":
        lines = ["A javítás hibával leállt (job %s): %s" % (job.id, job.error)]
    else:
        r = d.get("result", {})
        lines = ["Javítás vége (job %s): %s – %s" % (job.id, r.get("status"), r.get("message"))]
        if r.get("output"):
            lines.append("Kimenet: " + r["output"])
        for w in r.get("warnings") or []:
            lines.append("Figyelem: " + w)
        for n in r.get("notes") or []:
            lines.append("Megjegyzés: " + n)
        det = r.get("details") or {}
        if det:
            lines.append("Részletek: " + json.dumps(_jsonable(det), ensure_ascii=False))
    if with_log and job.log:
        lines.append("Napló:")
        lines.extend(job.log[-150:])
    return "\n".join(lines)


def tool_repair(args: dict, ctx) -> dict:
    path = _exists(args["path"])
    ref = _exists(args["reference"]) if args.get("reference") else None
    out = _norm(args["output"]) if args.get("output") else None
    if out and os.path.abspath(out) == os.path.abspath(path):
        raise ValueError("A kimenet nem lehet azonos az eredeti fájllal.")
    fps = float(args["fps"]) if args.get("fps") else None
    job = JOBS.start(path, ref, out, fps)
    _wait(job, args.get("wait_seconds", 40), ctx.progress_for(job))
    return {"text": _job_text(job), "data": job.as_dict()}


def tool_job_status(args: dict, ctx) -> dict:
    jid = args.get("job_id")
    if not jid:
        jobs = JOBS.all()
        if not jobs:
            return {"text": "Nincs futó vagy befejezett javítás ebben a munkamenetben.", "data": {"jobs": []}}
        return {"text": "\n".join(_job_text(j) for j in jobs), "data": {"jobs": [j.as_dict() for j in jobs]}}
    job = JOBS.get(jid)
    if job is None:
        raise ValueError("Ismeretlen job_id: %s" % jid)
    _wait(job, args.get("wait_seconds", 0), ctx.progress_for(job))
    with_log = bool(args.get("include_log", False))
    return {"text": _job_text(job, with_log), "data": job.as_dict(with_log=with_log)}


def tool_cancel_job(args: dict, ctx) -> dict:
    job = JOBS.get(args["job_id"])
    if job is None:
        raise ValueError("Ismeretlen job_id.")
    job.cancel_flag = True
    _wait(job, 10)
    return {"text": "Megszakítás kérve (job %s), állapot: %s" % (job.id, job.state), "data": job.as_dict()}


def tool_verify(args: dict, ctx) -> dict:
    from .engine import classify
    path = _exists(args["path"])
    kind = classify(path)
    if kind == "photo":
        from PIL import Image
        try:
            with Image.open(path) as im:
                im.load()
                return {"text": "A kép hibátlanul betölthető (%dx%d)." % im.size,
                        "data": {"ok": True, "width": im.width, "height": im.height}}
        except Exception as e:  # noqa: BLE001
            return {"text": "A kép nem tölthető be hibátlanul: %s" % e, "data": {"ok": False, "error": str(e)}}
    from .video.verify import deep_verify
    v = deep_verify(path, points=int(args.get("points", 8)), frames_per_point=6)
    lines = ["%s – %s, hossz: %.1f mp" % (path, "LEJÁTSZHATÓ" if v.get("ok") else "HIBÁKAT TALÁLTAM", v.get("duration", 0))]
    for c in v.get("checks", []):
        lines.append("  %3.0f%% (%.1f mp): %d kocka, %d hiba%s" % (c["position"] * 100, c["time"], c["decoded"], c["errors"],
                                                                 (" – " + c["error"]) if c.get("error") else ""))
    if "audio" in v:
        lines.append("  hang: %d keret dekódolva, %d hiba" % (v["audio"].get("audio_decoded", 0),
                                                              v["audio"].get("audio_errors", 0)))
    return {"text": "\n".join(lines), "data": v}


def tool_preview(args: dict, ctx) -> dict:
    from .engine import classify
    from PIL import Image
    path = _exists(args["path"])
    kind = classify(path)
    pos = float(args.get("position", 0.5))
    max_size = max(128, min(1600, int(args.get("max_size", 768))))
    img = None
    if kind == "video":
        from .video.verify import frame_at
        img = frame_at(path, pos)
    elif kind == "photo":
        from PIL import ImageFile
        ImageFile.LOAD_TRUNCATED_IMAGES = True
        try:
            img = Image.open(path)
            img.load()
        except Exception:  # noqa: BLE001
            from .photo.repair import find_embedded_jpegs
            with open(path, "rb") as f:
                blob = f.read()
            for s, e, _w, _h in find_embedded_jpegs(blob):
                try:
                    img = Image.open(io.BytesIO(blob[s:e]))
                    img.load()
                    break
                except Exception:  # noqa: BLE001
                    img = None
    if img is None:
        return {"text": "Ebből a fájlból nem tudtam képet kinyerni.", "data": {"ok": False}}
    img = img.convert("RGB")
    w, h = img.size
    img.thumbnail((max_size, max_size))
    buf = io.BytesIO()
    img.save(buf, "JPEG", quality=82)
    return {"text": "%s – képkocka %.0f%%-nál (eredeti méret %dx%d)" % (os.path.basename(path), pos * 100, w, h)
            if kind == "video" else "%s (%dx%d)" % (os.path.basename(path), w, h),
            "image": base64.b64encode(buf.getvalue()).decode("ascii"),
            "data": {"ok": True, "width": w, "height": h}}


def tool_open_app(args: dict, ctx) -> dict:
    from .paths import app_command
    paths = [_exists(p) for p in (args.get("paths") or [])]
    flags = 0
    if sys.platform.startswith("win"):
        flags = getattr(subprocess, "DETACHED_PROCESS", 0) | getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
    cmd = app_command(paths)          # through the installer's starter: the newest installed version opens
    subprocess.Popen(cmd, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                     close_fds=True, creationflags=flags)
    return {"text": "Future Repair elindítva%s." % ((" %d fájllal" % len(paths)) if paths else ""),
            "data": {"command": cmd}}


def tool_hex_dump(args: dict, ctx) -> dict:
    path = _exists(args["path"])
    off = int(args.get("offset", 0))
    ln = max(1, min(4096, int(args.get("length", 256))))
    size = os.path.getsize(path)
    if off < 0:
        off = max(0, size + off)
    with open(path, "rb") as f:
        f.seek(off)
        b = f.read(ln)
    rows = []
    for i in range(0, len(b), 16):
        chunk = b[i:i + 16]
        rows.append("%012x  %-47s  %s" % (off + i, " ".join("%02x" % c for c in chunk),
                                          "".join(chr(c) if 32 <= c < 127 else "." for c in chunk)))
    return {"text": "\n".join(rows) or "(üres)", "data": {"offset": off, "length": len(b), "file_size": size}}



# ---------------------------------------------------------------------------
# Disk recovery (reading a whole disk - needs administrator rights, runs as a separate process)
# ---------------------------------------------------------------------------

def _disk_status_path(output: str) -> str:
    from .disk.reassemble import DiskRecovery
    return os.path.join(output, DiskRecovery.STATUS)


def tool_disk_list(args: dict, ctx) -> dict:
    from .disk.raw import list_disks
    disks = list_disks()
    letters, sysd = {}, None
    if sys.platform.startswith("win"):
        from .disk import winsys
        letters = winsys.letters_by_disk()
        sysd = winsys.system_disk()
    lines = []
    for d in disks:
        d["letters"] = letters.get(d.get("number"), [])
        d["system"] = d.get("number") == sysd
        lines.append("- %s: %s, %.2f TB, %s%s%s" % (
            d["path"], d.get("model") or "?", (d.get("size") or 0) / 1e12, d.get("bus") or "",
            (", meghajtó: " + " ".join(d["letters"])) if d["letters"] else "",
            " (RENDSZERLEMEZ)" if d["system"] else ""))
    return {"text": "Lemezek:\n" + "\n".join(lines) if lines else "Nem találtam lemezt.", "data": {"disks": disks}}


def _resolve_disk(spec: str) -> str:
    spec = str(spec).strip()
    if sys.platform.startswith("win"):
        from .disk import winsys
        m = re.fullmatch(r"([A-Za-z]):?\\?", spec)
        if m:
            n = winsys.disk_number_of_letter(m.group(1))
            if n is None:
                raise ValueError("A %s: meghajtóhoz nem találok fizikai lemezt." % m.group(1).upper())
            spec = str(n)
        if spec.isdigit():
            n = int(spec)
            if n == winsys.system_disk():
                raise ValueError("Ez a rendszerlemez – ezt nem lehet kiválasztani.")
            return "\\\\.\\PhysicalDrive%d" % n
    return spec


def tool_disk_recover_start(args: dict, ctx) -> dict:
    device = _resolve_disk(args["disk"])
    output = _norm(args["output"])
    if sys.platform.startswith("win"):
        from .disk import winsys
        drv = os.path.splitdrive(os.path.abspath(output))[0]
        m = re.search(r"physicaldrive(\d+)", device.lower())
        if m and re.fullmatch(r"[A-Za-z]:", drv or "") and winsys.disk_number_of_letter(drv[0]) == int(m.group(1)):
            raise ValueError("A célmappa a helyreállítandó lemezen van – válassz másik meghajtót!")
    os.makedirs(output, exist_ok=True)
    sources = [_exists(p) for p in (args.get("sources") or [])]
    references = [_exists(p) for p in (args.get("references") or [])]
    job = {"device": device, "output": output, "sources": sources, "references": references,
           "only": args.get("only") or [], "protect": True}
    mode = (args.get("mode") or "auto").lower()
    if mode == "scan" or "#scan" in job["only"]:
        job["mode"] = "scan"
    elif mode == "survey" or "#survey" in job["only"]:
        job["mode"] = "survey"
    elif mode == "tree" or "#tree" in job["only"]:
        job["mode"] = "tree"
    elif mode == "entries" or "#entries" in job["only"]:
        job["mode"] = "entries"
    elif not sources:
        # no recovered files to start from: find the recordings on the disk itself
        if not references:
            raise ValueError("Lemezről kereséshez legalább egy ép mintavideó kell ('references').")
        job["mode"] = "carve"
    if args.get("max_files"):
        job["max_files"] = int(args["max_files"])
    if args.get("block_mb"):
        job["block"] = int(float(args["block_mb"]) * 1024 * 1024)
    stop = os.path.join(output, "futurerepair_lemez_STOP")
    if os.path.exists(stop):
        os.remove(stop)
    job_path = os.path.join(output, "futurerepair_lemez_feladat.json")
    with open(job_path, "w", encoding="utf-8") as f:
        json.dump(job, f, ensure_ascii=False, indent=1)
    app_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    script = os.path.join(app_dir, "FutureRepair.py")
    if sys.platform.startswith("win"):
        from .disk import winsys
        pyw = os.path.join(os.path.dirname(sys.executable), "pythonw.exe")
        exe = pyw if os.path.exists(pyw) else sys.executable
        rc = winsys.launch_elevated(exe, ["-E", "-s", script, "--disk-worker", job_path], cwd=app_dir)
        if rc <= 32:
            raise RuntimeError("A rendszergazdai indítás nem sikerült vagy el lett utasítva (kód: %d)." % rc)
        msg = ("Elindítottam a lemez-helyreállítást rendszergazdaként (a gépen jóvá kellett hagyni). "
               "Állapot: disk_recover_status, output=%s" % output)
    else:
        subprocess.Popen(["sudo", "-n", sys.executable, "-E", "-s", script, "--disk-worker", job_path],
                         stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        msg = "Elindítva (sudo). Állapot: disk_recover_status, output=%s" % output
    return {"text": msg, "data": {"job": job, "job_path": job_path}}


def tool_disk_protect(args: dict, ctx) -> dict:
    if not sys.platform.startswith("win"):
        raise ValueError("Csak Windows alatt használható.")
    device = _resolve_disk(args["disk"])
    m = re.search(r"physicaldrive(\d+)", device.lower())
    if not m:
        raise ValueError("Ismeretlen lemez: %s" % args["disk"])
    from .disk import winsys
    on = bool(args.get("readonly", True))
    import tempfile
    res = os.path.join(tempfile.gettempdir(), "futurerepair_readonly_%s.json" % uuid.uuid4().hex[:8])
    app_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    pyw = os.path.join(os.path.dirname(sys.executable), "pythonw.exe")
    exe = pyw if os.path.exists(pyw) else sys.executable
    rc = winsys.launch_elevated(exe, ["-E", "-s", os.path.join(app_dir, "FutureRepair.py"), "--disk-readonly",
                                      m.group(1), "on" if on else "off", res], cwd=app_dir)
    if rc <= 32:
        raise RuntimeError("A rendszergazdai indítás nem sikerült vagy el lett utasítva (kód: %d)." % rc)
    for _ in range(120):
        if os.path.exists(res):
            break
        time.sleep(0.5)
    if not os.path.exists(res):
        return {"text": "Elindult, de még nem jött válasz (jóvá kell hagyni a gépen).", "data": {}}
    with open(res, encoding="utf-8") as f:
        r = json.load(f)
    if not r.get("ok"):
        raise RuntimeError(r.get("error"))
    return {"text": "A %s. lemez írásvédettsége: %s" % (m.group(1), {True: "BE", False: "KI", None: "?"}[r.get("readonly")]),
            "data": r}


def tool_disk_recover_status(args: dict, ctx) -> dict:
    output = _norm(args["output"])
    p = _disk_status_path(output)
    if not os.path.exists(p):
        return {"text": "Még nincs állapotfájl (%s). Ha most indult, várj pár másodpercet; ha nem indult el, "
                        "lehet, hogy a rendszergazdai jóváhagyás elmaradt." % p, "data": {}}
    with open(p, encoding="utf-8") as f:
        st = json.load(f)
    age = time.time() - st.get("updated", 0)
    stale = st.get("state") in ("starting", "running") and age > 600
    lines = ["Állapot: %s – %s (%.1f%%)%s" % (st.get("state"), st.get("phase"), 100 * st.get("progress", 0),
                                               (" – %d perce nem frissült (lehet, hogy leállt)" % (age // 60)) if stale else "")]
    files = st.get("files", [])
    if files:
        cnt = {}
        for r in files:
            cnt[r.get("state")] = cnt.get(r.get("state"), 0) + 1
        lines.append("Fájlok: " + ", ".join("%s: %d" % kv for kv in sorted(cnt.items())))
        for r in files[-int(args.get("files", 20)):]:
            lines.append("- %s: %s%s" % (r.get("name"), r.get("state"),
                                         (" – " + r["message"]) if r.get("message") else ""))
    if st.get("error"):
        lines.append("HIBA: " + st["error"])
    n = int(args.get("log_lines", 15))
    if n:
        lines.append("Napló:")
        lines.extend(st.get("log", [])[-n:])
    small = {k: v for k, v in st.items() if k not in ("log", "files", "traceback")}
    small["files"] = [{k: v for k, v in r.items() if k != "cluster_list"} for r in files]
    return {"text": "\n".join(lines), "data": small}


def tool_disk_recover_stop(args: dict, ctx) -> dict:
    output = _norm(args["output"])
    with open(os.path.join(output, "futurerepair_lemez_STOP"), "w") as f:
        f.write("stop")
    return {"text": "Leállítást kértem; a futó lépés végén megáll (újraindítva onnan folytatja).", "data": {}}

def tool_app_update(args: dict, ctx) -> dict:
    from . import updater
    action = str(args.get("action") or "status").lower()
    r = None
    if action == "check":
        r = updater.check()
        r.pop("manifest", None)
    elif action == "install":
        r = updater.install()
    elif action == "rollback":
        r = updater.rollback()
    elif action in ("auto_on", "auto_off"):
        updater.set_auto(action == "auto_on")
    st = updater.status()
    lines = ["Ez a Claude-kapcsolat a %s verziót futtatja; a program következő indításakor a %s fut%s."
             % (st["running"], st["installed"], " (frissítve)" if st["restart_needed"] else ""),
             "Automatikus frissítés: %s." % ("be" if st["auto"] else "ki")]
    if st.get("latest"):
        lines.append("Legújabb kiadás: %s%s." % (st["latest"], " – telepíthető" if st["available"] else ""))
    elif st.get("unpublished"):
        lines.append("A frissítési csatornán még nincs kiadott verzió, így nincs mit letölteni.")
    if r is not None and r.get("error"):
        lines.append("Hiba: %s" % r["error"])
    if action == "install" and r and r.get("ok") and not r.get("already"):
        lines.append("Telepítve: %s. A Future Repair ablaka a következő megnyitáskor, a Claude-kapcsolat a Claude "
                     "újraindítása után használja; a most futó lemezfeladatok a saját verziójukkal futnak tovább."
                     % r["version"])
    if action == "rollback" and r and r.get("ok"):
        lines.append("Visszaállítva: a következő indításkor a %s fut." % r["version"])
    if st.get("notes") and st.get("available"):
        lines.append("Újdonságok:\n%s" % st["notes"])
    return {"text": "\n".join(lines), "data": {"result": r, "status": st}}


def tool_knowledge_base(args: dict, ctx) -> dict:
    from . import knowledge
    action = str(args.get("action") or "status").lower()
    lines = []
    if action == "sync":
        try:
            r = knowledge.sync()
            lines.append("Szinkron: %s" % ("%d minta elküldve, %d új letöltve, %d a közösben." % (
                r["sent"], r["got"], r["total"]) if r.get("ok") else r.get("error")))
        except Exception as e:  # noqa: BLE001
            lines.append("Szinkron nem sikerült: %s" % e)
    elif action == "learn":
        p = str(args.get("path") or "")
        if not os.path.isfile(p):
            return {"text": "Nincs ilyen fájl: %s" % p, "data": {}}
        tid = knowledge.learn(p, "kézi (Claude)")
        lines.append("Új minta: %s" % tid if tid else "Ebből a fajtából már van minta (vagy a fájl nem ép felvétel).")
    elif action in ("share_on", "share_off"):
        knowledge.set_sharing(action == "share_on")
    st = knowledge.status()
    lines.append("Minták ezen a gépen: %d (%d itt tanult, %d beküldésre vár). Megosztás: %s. Kulcs: %s." % (
        st["templates"], st["local"], st["pending"], "be" if st["share"] else "ki", "megvan" if st["key"] else "nincs"))
    if st.get("last_error"):
        lines.append("Utolsó hiba: %s" % st["last_error"])
    if st["labels"]:
        lines.append("Ismert felvételfajták: " + "; ".join(st["labels"][:20]))
    return {"text": "\n".join(lines), "data": st}


TOOLS = [
    {
        "name": "list_media",
        "title": "Médiafájlok listázása",
        "description": "List video/photo/audio files in a folder on the user's computer with a quick health check "
                       "(intact / broken index / truncated). Use it to find damaged files, e.g. on a memory card.",
        "inputSchema": {"type": "object", "properties": {
            "folder": {"type": "string", "description": "Folder path (local or network share)"},
            "recursive": {"type": "boolean", "default": False},
            "check": {"type": "boolean", "default": True, "description": "Run the quick health check"},
            "limit": {"type": "integer", "default": 300}},
            "required": ["folder"]},
        "annotations": {"readOnlyHint": True},
        "fn": tool_list_media,
    },
    {
        "name": "inspect_file",
        "title": "Fájl átvizsgálása",
        "description": "Detailed structure report of one media file: MP4/MOV boxes, index (moov) state, tracks and "
                       "codecs, decode check; JPEG markers / embedded previews; WAV chunks. Read-only.",
        "inputSchema": {"type": "object", "properties": {
            "path": {"type": "string"},
            "decode_check": {"type": "boolean", "default": True}},
            "required": ["path"]},
        "annotations": {"readOnlyHint": True},
        "fn": tool_inspect_file,
    },
    {
        "name": "find_reference",
        "title": "Mintafájl keresése",
        "description": "Find a healthy sample video in the broken file's folder (same camera/settings) and score how "
                       "much of the broken data it explains (0-1). With `candidate`, score that file instead.",
        "inputSchema": {"type": "object", "properties": {
            "path": {"type": "string", "description": "The damaged video"},
            "candidate": {"type": "string", "description": "Optional sample to score"}},
            "required": ["path"]},
        "annotations": {"readOnlyHint": True},
        "fn": tool_find_reference,
    },
    {
        "name": "repair",
        "title": "Javítás",
        "description": "Repair a damaged video/photo/audio file. Writes a new file (default: next to the original "
                       "with _javitott suffix); the original is never changed. Runs as a background job: returns "
                       "when done or after wait_seconds with a job_id to poll via job_status. Large videos take minutes.",
        "inputSchema": {"type": "object", "properties": {
            "path": {"type": "string", "description": "The damaged file"},
            "reference": {"type": "string", "description": "Healthy sample from the same device and settings "
                                                           "(strongly recommended for video)"},
            "output": {"type": "string", "description": "Optional output path"},
            "fps": {"type": "number", "description": "Frame rate for videos repaired without a sample"},
            "wait_seconds": {"type": "number", "default": 40, "maximum": MAX_WAIT}},
            "required": ["path"]},
        "annotations": {"readOnlyHint": False, "destructiveHint": False},
        "fn": tool_repair,
    },
    {
        "name": "job_status",
        "title": "Javítás állapota",
        "description": "Progress/result of a repair job (or all jobs if job_id is omitted). Can wait up to "
                       "wait_seconds for completion.",
        "inputSchema": {"type": "object", "properties": {
            "job_id": {"type": "string"},
            "wait_seconds": {"type": "number", "default": 0, "maximum": MAX_WAIT},
            "include_log": {"type": "boolean", "default": False}}},
        "annotations": {"readOnlyHint": True},
        "fn": tool_job_status,
    },
    {
        "name": "cancel_job",
        "title": "Javítás megszakítása",
        "description": "Cancel a running repair job.",
        "inputSchema": {"type": "object", "properties": {"job_id": {"type": "string"}}, "required": ["job_id"]},
        "fn": tool_cancel_job,
    },
    {
        "name": "verify",
        "title": "Ellenőrzés",
        "description": "Check that a (repaired) video plays: seeks to several points across the whole file and "
                       "decodes frames there, plus audio. For photos, fully decodes the image.",
        "inputSchema": {"type": "object", "properties": {
            "path": {"type": "string"},
            "points": {"type": "integer", "default": 8}},
            "required": ["path"]},
        "annotations": {"readOnlyHint": True},
        "fn": tool_verify,
    },
    {
        "name": "preview",
        "title": "Előnézet",
        "description": "Return a JPEG image of a video frame at a relative position (0..1), or of a photo "
                       "(falls back to the embedded preview of RAW/damaged files).",
        "inputSchema": {"type": "object", "properties": {
            "path": {"type": "string"},
            "position": {"type": "number", "default": 0.5, "minimum": 0, "maximum": 1},
            "max_size": {"type": "integer", "default": 768}},
            "required": ["path"]},
        "annotations": {"readOnlyHint": True},
        "fn": tool_preview,
    },
    {
        "name": "open_app",
        "title": "Future Repair megnyitása",
        "description": "Open the Future Repair desktop window on the user's computer, optionally with files loaded.",
        "inputSchema": {"type": "object", "properties": {
            "paths": {"type": "array", "items": {"type": "string"}}}},
        "fn": tool_open_app,
    },
    {
        "name": "hex_dump",
        "title": "Hex nézet",
        "description": "Read up to 4096 raw bytes of a file as hex (negative offset counts from the end). "
                       "For diagnosing unusual file structures.",
        "inputSchema": {"type": "object", "properties": {
            "path": {"type": "string"},
            "offset": {"type": "integer", "default": 0},
            "length": {"type": "integer", "default": 256, "maximum": 4096}},
            "required": ["path"]},
        "annotations": {"readOnlyHint": True},
        "fn": tool_hex_dump,
    },
    {
        "name": "disk_list",
        "title": "Lemezek listája",
        "description": "List the physical disks of the computer (size, model, bus, drive letters, system disk). "
                       "Use it to identify the disk a recovery should read from.",
        "inputSchema": {"type": "object", "properties": {}},
        "annotations": {"readOnlyHint": True},
        "fn": tool_disk_list,
    },
    {
        "name": "disk_recover_start",
        "title": "Lemezről helyreállítás indítása",
        "description": "Rebuild fragmented recordings directly from the disk they were stored on (e.g. a formatted "
                       "drive whose files a recovery tool brought back only partly). Reads the disk only (marks "
                       "it read-only first). With 'sources' it locates each recovered file on the disk; without "
                       "them it finds the recordings itself (video file starts) - name = recording date. Each "
                       "recording is followed cluster by cluster; complete files come back byte-identical. Needs administrator rights: "
                       "a UAC prompt appears on the computer and must be approved there. Runs for hours in the "
                       "background; poll disk_recover_status. Never use the system disk; the output must be on "
                       "another drive with enough free space.",
        "inputSchema": {"type": "object", "properties": {
            "disk": {"type": "string", "description": "Drive letter of the damaged disk (e.g. 'F:'), disk number, or device path"},
            "sources": {"type": "array", "items": {"type": "string"},
                        "description": "Folders (or files) of the recovered, damaged files. Leave empty to find "
                                       "the recordings on the disk itself (then 'references' is required)"},
            "output": {"type": "string", "description": "Folder for the rebuilt files (NOT on the damaged disk)"},
            "references": {"type": "array", "items": {"type": "string"},
                           "description": "Optional healthy sample videos from the same cameras"},
            "only": {"type": "array", "items": {"type": "string"}, "description": "Optional: only these file names"},
            "max_files": {"type": "integer", "description": "Optional: stop after this many rebuilt recordings (for a test run)"},
            "block_mb": {"type": "number", "description": "Optional allocation unit in MB if known (e.g. 32)"},
            "mode": {"type": "string", "enum": ["auto", "scan", "survey", "tree", "entries"], "default": "auto",
                     "description": "survey = a quick read-only look at what is left of the old file system "
                                    "(old folders, cluster size, allocation chains) - run it first on a "
                                    "formatted disk; takes a few minutes. scan = survey + complete listing in one job. "
                                    "tree = list everything the old folders describe "
                                    "(sources = the survey's JSON). entries = restore files listed by "
                                    "the survey (sources = the listing's futurerepair_lemez_bejegyzesek.json, "
                                    "only = file names or '#mappa:<folder path>')"}},
            "required": ["disk", "output"]},
        "fn": tool_disk_recover_start,
    },
    {
        "name": "disk_recover_status",
        "title": "Lemezről helyreállítás állapota",
        "description": "Progress and results of a disk recovery started with disk_recover_start.",
        "inputSchema": {"type": "object", "properties": {
            "output": {"type": "string"},
            "files": {"type": "integer", "default": 20, "description": "How many file results to list"},
            "log_lines": {"type": "integer", "default": 15}},
            "required": ["output"]},
        "annotations": {"readOnlyHint": True},
        "fn": tool_disk_recover_status,
    },
    {
        "name": "disk_protect",
        "title": "Lemez írásvédelme",
        "description": "Windows: turn the read-only flag of a whole disk on or off (UAC prompt on the computer). "
                       "disk_recover_start turns it on automatically; turn it off only when the user no longer "
                       "needs the damaged disk's data.",
        "inputSchema": {"type": "object", "properties": {
            "disk": {"type": "string", "description": "Drive letter (e.g. 'F:') or disk number"},
            "readonly": {"type": "boolean", "default": True}}, "required": ["disk"]},
        "fn": tool_disk_protect,
    },
    {
        "name": "disk_recover_stop",
        "title": "Lemezről helyreállítás leállítása",
        "description": "Ask a running disk recovery to stop; starting it again later continues where it stopped.",
        "inputSchema": {"type": "object", "properties": {"output": {"type": "string"}}, "required": ["output"]},
        "fn": tool_disk_recover_stop,
    },
    {
        "name": "app_update",
        "title": "Future Repair frissítése",
        "description": "Future Repair's own version and automatic updates on this computer. action: status "
                       "(default), check (look for a newer release now), install (download, test and activate the "
                       "newest release), rollback (back to the previous version), auto_on / auto_off. A new "
                       "version is used from the next start of the window and of this connection (after Claude "
                       "restarts); running jobs are never switched.",
        "inputSchema": {"type": "object", "properties": {
            "action": {"type": "string", "enum": ["status", "check", "install", "rollback", "auto_on", "auto_off"],
                       "default": "status"}}},
        "fn": tool_app_update,
    },
    {
        "name": "knowledge_base",
        "title": "Közös tudásbázis",
        "description": "Future Repair's shared knowledge: recording templates (a camera's file structure and "
                       "codec settings, no picture or sound) learnt on any of the studio's machines, used to "
                       "repair a broken recording without a sample file. action: status (default), sync (send "
                       "what this machine learnt, fetch the others'), learn (make a template from the playable "
                       "recording at `path`), share_on / share_off.",
        "inputSchema": {"type": "object", "properties": {
            "action": {"type": "string", "enum": ["status", "sync", "learn", "share_on", "share_off"],
                       "default": "status"},
            "path": {"type": "string", "description": "for learn: a playable recording of the camera"}}},
        "fn": tool_knowledge_base,
    },
]
TOOL_MAP = {t["name"]: t for t in TOOLS}


# ---------------------------------------------------------------------------
# JSON-RPC plumbing
# ---------------------------------------------------------------------------

class Server:
    def __init__(self, stdin=None, stdout=None):
        self.stdin = stdin or sys.stdin.buffer
        self.stdout = stdout or sys.stdout.buffer
        self.write_lock = threading.Lock()
        self.pool = ThreadPoolExecutor(max_workers=6, thread_name_prefix="tool")
        self.protocol = PROTOCOLS[0]

    def send(self, msg: dict) -> None:
        data = (json.dumps(msg, ensure_ascii=False, separators=(",", ":")) + "\n").encode("utf-8")
        with self.write_lock:
            self.stdout.write(data)
            self.stdout.flush()

    def respond(self, mid, result=None, error=None) -> None:
        msg = {"jsonrpc": "2.0", "id": mid}
        if error is not None:
            msg["error"] = error
        else:
            msg["result"] = result
        self.send(msg)

    # -- handlers ------------------------------------------------------------
    def handle(self, msg: dict) -> None:
        method = msg.get("method")
        mid = msg.get("id")
        params = msg.get("params") or {}
        if method is None:
            return                                   # a response to something we never send
        if mid is None:
            return                                   # notifications: initialized, cancelled, ...
        if method == "initialize":
            req = params.get("protocolVersion")
            self.protocol = req if req in PROTOCOLS else PROTOCOLS[0]
            self.respond(mid, {
                "protocolVersion": self.protocol,
                "capabilities": {"tools": {"listChanged": False}},
                "serverInfo": {"name": SERVER_NAME, "title": "Future Repair", "version": __version__},
                "instructions": INSTRUCTIONS,
            })
        elif method == "ping":
            self.respond(mid, {})
        elif method == "tools/list":
            tools = []
            for t in TOOLS:
                d = {k: v for k, v in t.items() if k != "fn"}
                if self.protocol == "2024-11-05":
                    d.pop("title", None)
                tools.append(d)
            self.respond(mid, {"tools": tools})
        elif method == "tools/call":
            self.pool.submit(self._call, mid, params)
        elif method in ("resources/list",):
            self.respond(mid, {"resources": []})
        elif method in ("resources/templates/list",):
            self.respond(mid, {"resourceTemplates": []})
        elif method in ("prompts/list",):
            self.respond(mid, {"prompts": []})
        elif method == "logging/setLevel":
            self.respond(mid, {})
        else:
            self.respond(mid, error={"code": -32601, "message": "Method not found: %s" % method})

    def _call(self, mid, params: dict) -> None:
        name = params.get("name")
        args = params.get("arguments") or {}
        token = (params.get("_meta") or {}).get("progressToken")
        tool = TOOL_MAP.get(name)
        if tool is None:
            self.respond(mid, error={"code": -32602, "message": "Unknown tool: %s" % name})
            return
        ctx = _Ctx(self, token)
        try:
            out = tool["fn"](args, ctx)
            content = [{"type": "text", "text": out.get("text", "")}]
            if out.get("image"):
                content.append({"type": "image", "data": out["image"], "mimeType": "image/jpeg"})
            result = {"content": content, "isError": False}
            if out.get("data") is not None and self.protocol != "2024-11-05":
                result["structuredContent"] = _jsonable(out["data"])
            self.respond(mid, result)
        except Exception as e:  # noqa: BLE001 - tool errors are reported to the model, not raised
            _log("tool error", name, traceback.format_exc())
            self.respond(mid, {"content": [{"type": "text", "text": "Hiba: %s" % e}], "isError": True})

    def serve(self) -> None:
        _log("ready, version", __version__)
        for raw in self.stdin:
            line = raw.strip()
            if not line:
                continue
            try:
                msg = json.loads(line.decode("utf-8"))
            except ValueError:
                self.send({"jsonrpc": "2.0", "id": None, "error": {"code": -32700, "message": "Parse error"}})
                continue
            msgs = msg if isinstance(msg, list) else [msg]
            for m in msgs:
                try:
                    self.handle(m)
                except Exception:  # noqa: BLE001
                    _log("handler error", traceback.format_exc())
        _log("stdin closed, exiting")


class _Ctx:
    def __init__(self, server: Server, token):
        self.server = server
        self.token = token

    def progress_for(self, job: Job):
        if self.token is None:
            return None

        def cb(j: Job):
            self.server.send({"jsonrpc": "2.0", "method": "notifications/progress",
                              "params": {"progressToken": self.token, "progress": round(j.progress * 100, 1),
                                         "total": 100, "message": j.step}})
        return cb


def _jsonable(o):
    try:
        json.dumps(o)
        return o
    except TypeError:
        return json.loads(json.dumps(o, default=str))


def main() -> int:
    from . import hotreload
    hotreload.enable()          # long-running: pick up updates made on disk
    # stdout carries the protocol: keep stray prints from libraries away from it
    real_stdout = sys.stdout.buffer
    sys.stdout = sys.stderr
    try:
        import av  # noqa: F401 - warm up FFmpeg and silence its logging
        av.logging.set_level(None)
    except Exception:  # noqa: BLE001
        pass
    try:
        from . import updater
        updater.start_background()
        from . import knowledge
        knowledge.start_background()     # automatic updates also when only Claude uses the program
    except Exception as e:  # noqa: BLE001
        _log("frissítés-ellenőrzés nem indult:", e)
    Server(stdout=real_stdout).serve()
    return 0


if __name__ == "__main__":
    sys.exit(main())
