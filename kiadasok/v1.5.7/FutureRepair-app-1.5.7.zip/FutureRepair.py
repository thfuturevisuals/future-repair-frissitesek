"""Starter: desktop app by default, MCP server with --mcp (used by Claude).

Installed updates live in frissitesek/<version>/ next to this file and frissitesek/aktiv.json names
the one in use (see futurerepair/updater.py). This starter picks that version before anything of the
program is imported; a running program never switches versions.
"""
import json
import multiprocessing
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))


def _version_of(code_dir):
    try:
        with open(os.path.join(code_dir, "futurerepair", "__init__.py"), encoding="utf-8") as f:
            m = re.search(r'^__version__\s*=\s*"([^"]+)"', f.read(), re.M)
        return m.group(1) if m else None
    except OSError:
        return None


def _vt(v):
    return tuple(int(x) for x in re.findall(r"\d+", v or "")[:4]) or (0,)


def _pick_code():
    """The folder whose code runs: the active installed update if it is usable, else this folder."""
    if os.path.basename(os.path.dirname(HERE)) == "frissitesek":
        return HERE                                   # started from an update folder
    if os.environ.get("FUTUREREPAIR_NO_UPDATE") == "1":
        return HERE
    if "--disk-worker" in sys.argv or "--disk-readonly" in sys.argv:
        return HERE                                   # a worker runs the code of the program that started it
    try:
        with open(os.path.join(HERE, "frissitesek", "aktiv.json"), encoding="utf-8") as f:
            ver = str(json.load(f).get("version") or "")
    except (OSError, ValueError, AttributeError):
        return HERE
    if not re.match(r"^\d+(\.\d+){1,3}$", ver):
        return HERE
    code = os.path.join(HERE, "frissitesek", ver)
    if _version_of(code) != ver or _vt(ver) <= _vt(_version_of(HERE)):
        return HERE
    return code


CODE = _pick_code()
if CODE != HERE:
    sys.path.insert(0, CODE)


def _load(module):
    """Import a module of the program; if an installed update does not even load, fall back to the
    code that came with the installer (and say so on stderr)."""
    import importlib
    try:
        return importlib.import_module(module)
    except Exception as e:  # noqa: BLE001
        if CODE == HERE:
            raise
        sys.stderr.write("Future Repair: a(z) %s frissítés nem töltődik be (%s), a telepített alapverzió "
                         "indul.\n" % (os.path.basename(CODE), e))
        for k in list(sys.modules):
            if k == "futurerepair" or k.startswith("futurerepair."):
                del sys.modules[k]
        while CODE in sys.path:
            sys.path.remove(CODE)
        return importlib.import_module(module)


if __name__ == "__main__":
    multiprocessing.freeze_support()
    argv = sys.argv[1:]
    if "--update-selftest" in argv:
        sys.exit(_load("futurerepair.updater").main(argv))
    _load("futurerepair.updater").hold()           # this version folder is in use while we run
    if "--disk-readonly" in argv:
        i = sys.argv.index("--disk-readonly")
        sys.exit(_load("futurerepair.disk.reassemble").main_readonly(sys.argv[i + 1], sys.argv[i + 2],
                                                                      sys.argv[i + 3]))
    if "--disk-worker" in argv:
        sys.exit(_load("futurerepair.disk.reassemble").main_worker(sys.argv[sys.argv.index("--disk-worker") + 1]))
    if any(a in argv for a in ("--claude-connect", "--claude-disconnect", "--claude-status", "--claude-selftest")):
        sys.exit(_load("futurerepair.claude_connect").main(argv))
    if any(a in argv for a in ("--update-status", "--update-check", "--update-install", "--update-rollback")):
        sys.exit(_load("futurerepair.updater").main(argv))
    if "--mcp" in argv:
        sys.exit(_load("futurerepair.mcp_server").main())
    sys.exit(_load("futurerepair.gui").main())
