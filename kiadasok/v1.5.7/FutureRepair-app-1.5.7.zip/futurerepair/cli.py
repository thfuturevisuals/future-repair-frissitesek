"""Command line interface: futurerepair <file> [--ref sample] [--out path]."""
from __future__ import annotations

import argparse
import sys

from .engine import repair
from .result import Reporter


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="futurerepair", description="Sérült videó/fotó/hang fájl javítása")
    ap.add_argument("file", help="a sérült fájl")
    ap.add_argument("--ref", "-r", help="ép mintafájl ugyanarról az eszközről")
    ap.add_argument("--out", "-o", help="kimeneti fájl (alapból <név>_javitott.<kiterjesztés>)")
    ap.add_argument("--fps", type=float, help="képkockaszám, ha nincs mintafájl")
    ap.add_argument("--verbose", "-v", action="store_true", help="részletes napló")
    a = ap.parse_args(argv)

    last = [-1]

    def progress(x):
        pct = int(x * 100)
        if pct != last[0] and pct % 5 == 0:
            last[0] = pct
            print("\r%3d%%" % pct, end="", file=sys.stderr, flush=True)

    rep = Reporter(on_step=lambda s: print("\n" + s, file=sys.stderr),
                   on_log=(lambda s: print(s, file=sys.stderr)) if a.verbose else None)
    res = repair(a.file, a.ref, a.out, progress=progress, reporter=rep, fps=a.fps)
    print(file=sys.stderr)
    print(res.message)
    for w in res.warnings:
        print("Figyelem:", w)
    if res.output:
        print("Kimenet:", res.output)
    return 0 if res.status in ("ok", "partial", "intact") else 1


if __name__ == "__main__":
    sys.exit(main())
