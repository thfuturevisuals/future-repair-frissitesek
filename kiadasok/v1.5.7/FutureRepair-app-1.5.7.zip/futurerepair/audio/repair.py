"""Audio repair: WAV/BWF/RF64 header rebuild and MP3 frame resync."""
from __future__ import annotations

import os
import struct
from typing import Optional, Tuple

from ..result import RepairResult, Reporter

WAV_EXT = {".wav", ".wave", ".bwf", ".rf64"}
MP3_EXT = {".mp3"}

DEFAULT_FMT = (1, 2, 48000, 24)   # PCM, stereo, 48 kHz, 24 bit


def _out_path(src: str, suffix: str = "_javitott", ext: Optional[str] = None) -> str:
    base, e = os.path.splitext(src)
    e = ext or e
    out = base + suffix + e
    i = 2
    while os.path.exists(out):
        out = "%s%s_%d%s" % (base, suffix, i, e)
        i += 1
    return out


# ---------------------------------------------------------------------------
# WAV
# ---------------------------------------------------------------------------

def _iter_riff_chunks(data: bytes, start: int = 12):
    p = start
    n = len(data)
    while p + 8 <= n:
        cid = data[p:p + 4]
        size = struct.unpack("<I", data[p + 4:p + 8])[0]
        if not all(32 <= c < 127 for c in cid):
            return
        yield cid, p, size
        p += 8 + size + (size & 1)


def make_fmt(fmt_tag: int, channels: int, rate: int, bits: int) -> bytes:
    block = channels * ((bits + 7) // 8)
    body = struct.pack("<HHIIHH", fmt_tag, channels, rate, rate * block, block, bits)
    return b"fmt " + struct.pack("<I", len(body)) + body


def parse_fmt(body: bytes) -> Tuple[int, int, int, int, int]:
    tag, ch, rate, _bps, block, bits = struct.unpack("<HHIIHH", body[:16])
    return tag, ch, rate, block, bits


def _read_reference_fmt(reference: str) -> Optional[bytes]:
    with open(reference, "rb") as f:
        head = f.read(1 << 20)
    if head[:4] not in (b"RIFF", b"RF64") or head[8:12] != b"WAVE":
        return None
    for cid, p, size in _iter_riff_chunks(head):
        if cid == b"fmt ":
            return head[p:p + 8 + size]
    return None


def repair_wav(path: str, reference: Optional[str], out_path: Optional[str], rep: Reporter,
               default_fmt=DEFAULT_FMT) -> RepairResult:
    fsize = os.path.getsize(path)
    with open(path, "rb") as f:
        head = f.read(min(fsize, 4 << 20))
    fmt_chunk = None
    extra_chunks = []
    data_off = -1
    declared = 0
    riff_ok = head[:4] in (b"RIFF", b"RF64") and head[8:12] == b"WAVE"
    if riff_ok:
        for cid, p, size in _iter_riff_chunks(head):
            if cid == b"fmt ":
                fmt_chunk = head[p:p + 8 + size]
            elif cid == b"data":
                data_off = p + 8
                declared = size
                break
            elif cid in (b"bext", b"iXML", b"LIST", b"cue ", b"junk", b"JUNK", b"fact", b"ds64", b"_PMX", b"axml"):
                if cid not in (b"ds64", b"junk", b"JUNK") and p + 8 + size <= len(head):
                    extra_chunks.append(head[p:p + 8 + size + (size & 1)])
    if data_off < 0:
        i = head.find(b"data")
        if i >= 0 and i + 8 <= len(head):
            data_off = i + 8
            declared = struct.unpack("<I", head[i + 4:i + 8])[0]
            rep.log("A 'data' rész keresés útján megvan (%d. bájt)." % data_off)
    if fmt_chunk is None:
        i = head.find(b"fmt ")
        if i >= 0:
            size = struct.unpack("<I", head[i + 4:i + 8])[0]
            if 16 <= size <= 64:
                fmt_chunk = head[i:i + 8 + size]
    if fmt_chunk is not None:
        try:
            tag, ch, rate, block, bits = parse_fmt(fmt_chunk[8:])
            if not (1 <= ch <= 64 and 1000 <= rate <= 768000 and bits in (8, 16, 24, 32, 64) and block):
                fmt_chunk = None
        except struct.error:
            fmt_chunk = None
    used_ref = False
    if fmt_chunk is None and reference:
        fmt_chunk = _read_reference_fmt(reference)
        used_ref = fmt_chunk is not None
    used_default = False
    if fmt_chunk is None:
        fmt_chunk = make_fmt(*default_fmt) if default_fmt[0] != 3 else make_fmt(3, *default_fmt[1:])
        used_default = True
    tag, ch, rate, block, bits = parse_fmt(fmt_chunk[8:])
    if data_off < 0:
        data_off = 44 if not reference else _ref_data_offset(reference) or 44
        rep.warn("Nem találtam a hangadat kezdetét, a %d. bájttól veszem." % data_off)
    available = fsize - data_off
    data_len = available - (available % block)
    if declared and declared <= available and declared % block == 0 and declared not in (0xFFFFFFFF,) \
            and declared == data_len and riff_ok and not used_ref and not used_default:
        return RepairResult("intact", None, "A WAV fájl fejléce rendben van, nem találtam hibát.")
    # trailing zero padding at the end of an interrupted recording is kept (it's silence)
    out_path = out_path or _out_path(path)
    rf64 = data_len + data_off > 0xFFFFFFF0
    header = bytearray()
    body_chunks = fmt_chunk + b"".join(extra_chunks)
    if rf64:
        ds64 = b"ds64" + struct.pack("<I", 28) + struct.pack("<QQQI", 0, data_len, 0, 0)
        header += b"RF64" + struct.pack("<I", 0xFFFFFFFF) + b"WAVE" + ds64 + body_chunks
        header += b"data" + struct.pack("<I", 0xFFFFFFFF)
    else:
        header += b"RIFF" + b"\x00\x00\x00\x00" + b"WAVE" + body_chunks
        header += b"data" + struct.pack("<I", data_len)
    total = len(header) + data_len + (data_len & 1)
    if rf64:
        header[20:28] = struct.pack("<Q", total - 8)
    else:
        header[4:8] = struct.pack("<I", total - 8)
    tmp = out_path + ".part"
    with open(path, "rb") as src, open(tmp, "wb") as out:
        out.write(header)
        src.seek(data_off)
        left = data_len
        while left > 0:
            b = src.read(min(left, 16 << 20))
            if not b:
                break
            out.write(b)
            left -= len(b)
        if data_len & 1:
            out.write(b"\x00")
    os.replace(tmp, out_path)
    secs = data_len / float(rate * block) if rate and block else 0
    msg = "A WAV fejléc újraépítve: %s (%d Hz, %d bit, %d csatorna)." % (_fmt_dur(secs), rate, bits, ch)
    res = RepairResult("ok", out_path, msg, details={"seconds": round(secs, 2), "rate": rate, "bits": bits,
                                                   "channels": ch})
    if used_default:
        res.status = "partial"
        rep.warn("A hangformátum nem volt kiolvasható, alapértelmezést (48 kHz, 24 bit, sztereó) használtam. "
                 "Ha torz a hang, adj meg egy ép WAV mintát ugyanarról az eszközről.")
    elif used_ref:
        rep.note("A hangformátumot a mintafájlból vettem.")
    return res


def _ref_data_offset(reference: str) -> Optional[int]:
    with open(reference, "rb") as f:
        head = f.read(1 << 20)
    for cid, p, size in _iter_riff_chunks(head):
        if cid == b"data":
            return p + 8
    return None


# ---------------------------------------------------------------------------
# MP3
# ---------------------------------------------------------------------------

_BITRATES = {
    (1, 1): [0, 32, 64, 96, 128, 160, 192, 224, 256, 288, 320, 352, 384, 416, 448],
    (1, 2): [0, 32, 48, 56, 64, 80, 96, 112, 128, 160, 192, 224, 256, 320, 384],
    (1, 3): [0, 32, 40, 48, 56, 64, 80, 96, 112, 128, 160, 192, 224, 256, 320],
    (2, 1): [0, 32, 48, 56, 64, 80, 96, 112, 128, 144, 160, 176, 192, 224, 256],
    (2, 2): [0, 8, 16, 24, 32, 40, 48, 56, 64, 80, 96, 112, 128, 144, 160],
    (2, 3): [0, 8, 16, 24, 32, 40, 48, 56, 64, 80, 96, 112, 128, 144, 160],
}
_RATES = {3: [44100, 48000, 32000], 2: [22050, 24000, 16000], 0: [11025, 12000, 8000]}


def mp3_frame_len(h: bytes) -> int:
    if len(h) < 4 or h[0] != 0xFF or (h[1] & 0xE0) != 0xE0:
        return 0
    ver_bits = (h[1] >> 3) & 3
    layer_bits = (h[1] >> 1) & 3
    if ver_bits == 1 or layer_bits == 0:
        return 0
    br_idx = h[2] >> 4
    sr_idx = (h[2] >> 2) & 3
    if br_idx in (0, 15) or sr_idx == 3:
        return 0
    pad = (h[2] >> 1) & 1
    layer = 4 - layer_bits
    v = 1 if ver_bits == 3 else 2
    br = _BITRATES[(v, layer)][br_idx] * 1000
    sr = _RATES[ver_bits][sr_idx]
    if layer == 1:
        return (12 * br // sr + pad) * 4
    if layer == 3 and v == 2:
        return 72 * br // sr + pad
    return 144 * br // sr + pad


def repair_mp3(path: str, out_path: Optional[str], rep: Reporter) -> RepairResult:
    with open(path, "rb") as f:
        data = f.read()
    n = len(data)
    out = bytearray()
    p = 0
    if data[:3] == b"ID3" and n > 10:
        sz = ((data[6] & 0x7F) << 21) | ((data[7] & 0x7F) << 14) | ((data[8] & 0x7F) << 7) | (data[9] & 0x7F)
        if 10 + sz < n:
            out += data[:10 + sz]
            p = 10 + sz
    frames = 0
    dropped = 0
    run_start = None
    run_frames = 0
    while p + 4 <= n:
        ln = mp3_frame_len(data[p:p + 4])
        if ln and p + ln <= n:
            nxt = data[p + ln:p + ln + 4]
            if p + ln == n or mp3_frame_len(nxt) or nxt[:3] == b"TAG":
                if run_start is None:
                    run_start = p
                    run_frames = 0
                run_frames += 1
                p += ln
                continue
        if run_start is not None:
            if run_frames >= 2:
                out += data[run_start:p]
                frames += run_frames
            else:
                dropped += p - run_start
            run_start = None
        nx = data.find(b"\xff", p + 1)
        if nx < 0:
            dropped += n - p
            break
        dropped += nx - p
        p = nx
    if run_start is not None and run_frames >= 1:
        out += data[run_start:p]
        frames += run_frames
    if frames == 0:
        return RepairResult("failed", None, "Nem találtam ép MP3 keretet a fájlban.")
    if dropped == 0 and len(out) == n:
        return RepairResult("intact", None, "Az MP3 fájl ép, nem találtam benne hibát.")
    out_path = out_path or _out_path(path)
    with open(out_path, "wb") as f:
        f.write(out)
    secs = frames * 1152 / 44100.0
    return RepairResult("ok", out_path, "MP3 helyreállítva: %d ép keret megtartva, %d sérült bájt eltávolítva."
                        % (frames, dropped), details={"frames": frames, "dropped_bytes": dropped,
                                                      "seconds_estimate": round(secs, 1)})


def _fmt_dur(sec: float) -> str:
    sec = int(round(sec))
    h, r = divmod(sec, 3600)
    m, s = divmod(r, 60)
    return "%d:%02d:%02d" % (h, m, s) if h else "%d:%02d" % (m, s)


def repair_audio(path: str, reference: Optional[str] = None, out_path: Optional[str] = None,
                 reporter: Optional[Reporter] = None, wav_default=DEFAULT_FMT, **_kw) -> RepairResult:
    rep = reporter or Reporter()
    ext = os.path.splitext(path)[1].lower()
    if ext in MP3_EXT:
        res = repair_mp3(path, out_path, rep)
    else:
        res = repair_wav(path, reference, out_path, rep, wav_default)
    res.log = rep.lines
    res.warnings = rep.warnings
    res.notes = rep.notes
    return res
