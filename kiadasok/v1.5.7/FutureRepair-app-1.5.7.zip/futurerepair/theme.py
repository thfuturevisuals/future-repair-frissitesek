"""The look of the desktop window: the studio's "B" design, as on the CRM and delivery.thefuturevisuals.com.

Warm paper and ink (light) or near-black (dark), the CRM's teal, Jost (the Futura-style face the CRM and the
delivery site fall back to where Futura PT is not available), pill buttons and tabs, borderless rounded boxes,
small upper-case titles, and the "thefuturevisuals" wordmark in the brand's Montserrat, which also runs as the
loading indicator. Light, dark, or following the system (the default); the choice is kept between starts.

Colours come from the delivery site's tema-b.css. Qt style sheets know no letter spacing or upper case, so the
widgets that need them (titles, tabs, filled buttons, table headers) get their fonts here in code, and the
style sheet sets colours, borders and shapes only.
"""
from __future__ import annotations

import os
import tempfile
import time
from typing import Dict, List, Optional

from PySide6.QtCore import QObject, QPointF, QRectF, QSettings, QSize, Qt, QTimer, Signal
from PySide6.QtGui import (QAction, QActionGroup, QColor, QFont, QFontDatabase, QFontMetricsF, QGuiApplication,
                           QIcon, QPainter, QPainterPath, QPalette, QPen, QPixmap)
from PySide6.QtWidgets import (QApplication, QFrame, QHBoxLayout, QLabel, QMenu, QProgressBar, QPushButton,
                               QSizePolicy, QStackedWidget, QStyledItemDelegate, QToolButton, QVBoxLayout, QWidget)

ASSETS = os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets")

LIGHT = dict(
    bg="#F6F5F2", surface="#FFFFFF", s2="#F1EFEB", s3="#E9E6E1",
    text="#1C1B19", sub="#55524D", muted="#6B6762",
    line="#E4E1DB", row_line="#EFEDE9", field="#D6D2CC", input="#FFFFFF", track="#E4E1DB",
    acc="#007A7A", acc_hi="#006B6B", acc_hover="#006B6B",
    hover="rgba(28, 27, 25, 0.06)", press="rgba(28, 27, 25, 0.10)",
    ok="#0F7B57", warn="#B26A00", bad="#A3321F",
)
DARK = dict(
    bg="#0D0D0C", surface="#161614", s2="#1A1A18", s3="#1F1E1B",
    text="#F1EEE8", sub="#C9C4BC", muted="#A19C93",
    line="#24231F", row_line="#1E1D1A", field="#2E2C29", input="#121211", track="#2A2926",
    acc="#008080", acc_hi="#33CCCC", acc_hover="#009999",
    hover="rgba(241, 238, 232, 0.07)", press="rgba(241, 238, 232, 0.12)",
    ok="#3DCB9A", warn="#F0B35A", bad="#F08F7D",
)
MODES = [("auto", "Automatikus (a rendszer szerint)"), ("light", "Világos"), ("dark", "Sötét")]

P: Dict[str, str] = dict(LIGHT)          # the colours in use now
_mode = "auto"
_dark = False
_fonts: Dict[str, Dict[int, str]] = {"ui": {}, "mark": {}}


class _Notifier(QObject):
    changed = Signal()


notifier = _Notifier()


# ---------------------------------------------------------------------------------------------
# colours
# ---------------------------------------------------------------------------------------------

def _mix(a: str, b: str, t: float) -> str:
    """a blended toward b by t (0..1), as #RRGGBB."""
    ca, cb = QColor(a), QColor(b)
    return QColor(round(ca.red() + (cb.red() - ca.red()) * t), round(ca.green() + (cb.green() - ca.green()) * t),
                  round(ca.blue() + (cb.blue() - ca.blue()) * t)).name()


def tone(name: Optional[str]) -> str:
    """The colour of a status: ok, warn, bad, accent, muted, text."""
    return {"ok": P["ok"], "warn": P["warn"], "bad": P["bad"], "accent": P["acc_hi"], "running": P["acc_hi"],
            "muted": P["muted"], "sub": P["sub"]}.get(name or "", P["text"])


def is_dark() -> bool:
    return _dark


# ---------------------------------------------------------------------------------------------
# fonts
# ---------------------------------------------------------------------------------------------

def _load_fonts() -> None:
    """Register the bundled faces and remember under which family name each weight answers (one family on
    most systems; a family per weight where the platform reads the older names)."""
    folder = os.path.join(ASSETS, "fonts")
    files = {("ui", 400): "Jost-Regular.ttf", ("ui", 500): "Jost-Medium.ttf", ("ui", 600): "Jost-SemiBold.ttf"}
    for w in (200, 300, 400, 500, 600, 700, 800):
        files[("mark", w)] = "Montserrat-wordmark-%d.ttf" % w
    for (kind, w), name in files.items():
        fid = QFontDatabase.addApplicationFont(os.path.join(folder, name))
        fams = QFontDatabase.applicationFontFamilies(fid) if fid >= 0 else []
        if fams:
            _fonts[kind][w] = fams[0]


def ui_family(weight: int = 400) -> str:
    f = _fonts["ui"]
    if weight in f:
        return f[weight]
    return f.get(400) or "Segoe UI"


def font(px: float, weight: int = 400, spacing_em: float = 0.0, kind: str = "ui") -> QFont:
    """Jost (or the wordmark's Montserrat) at a pixel size, weight and letter spacing (in em)."""
    fams = _fonts[kind]
    if kind == "mark":
        w = min(fams, key=lambda k: abs(k - weight)) if fams else weight
        fam = fams.get(w) or "Montserrat"
    else:
        w = weight
        fam = ui_family(weight)
    f = QFont(fam)
    f.setFamilies([fam, "Jost", "Segoe UI", "Helvetica Neue", "Arial"])
    f.setPixelSize(max(1, round(px)))
    f.setWeight(QFont.Weight(w))
    f.setHintingPreference(QFont.PreferNoHinting)
    if spacing_em:
        f.setLetterSpacing(QFont.AbsoluteSpacing, spacing_em * px)
    return f


def spaced(w: QWidget, px: float, weight: int = 500, spacing_em: float = 0.1) -> QWidget:
    w.setFont(font(px, weight, spacing_em))
    return w


# ---------------------------------------------------------------------------------------------
# small pictures the style sheet points at (check marks, the combo box arrow)
# ---------------------------------------------------------------------------------------------

def _icon_dir() -> str:
    d = os.path.join(tempfile.gettempdir(), "futurerepair-ui", "dark" if _dark else "light")
    os.makedirs(d, exist_ok=True)
    return d


def _draw_png(path: str, size: int, paint) -> None:
    for scale, suffix in ((1, ""), (2, "@2x")):
        pm = QPixmap(size * scale, size * scale)
        pm.fill(Qt.transparent)
        p = QPainter(pm)
        p.setRenderHint(QPainter.Antialiasing)
        p.scale(scale, scale)
        paint(p)
        p.end()
        root, ext = os.path.splitext(path)
        pm.save(root + suffix + ext)


def _icons() -> Dict[str, str]:
    d = _icon_dir()
    out = {}

    def check(p):
        pen = QPen(QColor("#FFFFFF"), 2.0, Qt.SolidLine, Qt.RoundCap, Qt.RoundJoin)
        p.setPen(pen)
        path = QPainterPath(QPointF(3.6, 8.3))
        path.lineTo(6.7, 11.2)
        path.lineTo(12.4, 4.9)
        p.drawPath(path)

    def dash(p):
        p.setPen(QPen(QColor("#FFFFFF"), 2.0, Qt.SolidLine, Qt.RoundCap))
        p.drawLine(QPointF(4.5, 8), QPointF(11.5, 8))

    def chevron(p):
        p.setPen(QPen(QColor(P["muted"]), 1.6, Qt.SolidLine, Qt.RoundCap, Qt.RoundJoin))
        path = QPainterPath(QPointF(3.5, 6))
        path.lineTo(8, 10.5)
        path.lineTo(12.5, 6)
        p.drawPath(path)

    for name, fn in (("check", check), ("dash", dash), ("chevron", chevron)):
        path = os.path.join(d, name + ".png")
        _draw_png(path, 16, fn)
        out[name] = path.replace("\\", "/")
    return out


# ---------------------------------------------------------------------------------------------
# the style sheet
# ---------------------------------------------------------------------------------------------

def stylesheet() -> str:
    c = dict(P)
    c.update(_icons())
    c["mono"] = '"Menlo", "Consolas", "DejaVu Sans Mono", monospace'
    c["acc_off"] = _mix(P["acc"], P["surface"], 0.55)
    c["on_acc_off"] = _mix("#FFFFFF", P["surface"], 0.25 if _dark else 0.0)
    c["text_off"] = _mix(P["muted"], P["bg"], 0.45)
    c["scroll"] = _mix(P["muted"], P["bg"], 0.55)
    c["scroll_hi"] = _mix(P["muted"], P["bg"], 0.25)
    c["sel"] = _mix(P["acc"], P["surface"], 0.86 if not _dark else 0.78)
    return """
QMainWindow, QDialog, QMessageBox {{ background: {bg}; }}
QWidget {{ color: {text}; }}
QLabel {{ background: transparent; }}
QLabel#title {{ color: {text}; }}
QLabel#subtitle {{ color: {sub}; }}
QLabel#muted {{ color: {muted}; }}
QLabel#sub {{ color: {sub}; }}
QLabel#h {{ color: {muted}; }}
QLabel#tag {{ color: {muted}; }}
QLabel#preview {{ background: {s2}; border-radius: 12px; color: {muted}; }}
QFrame#topbar {{ background: {bg}; border: none; border-bottom: 1px solid {line}; }}
QFrame#card {{ background: {surface}; border: none; border-radius: 16px; }}
QFrame#note {{ background: {s2}; border: none; border-radius: 12px; }}

QPushButton {{ background: transparent; color: {text}; border: 1px solid {field}; border-radius: 18px;
              padding: 0 16px; min-height: 34px; }}
QPushButton:hover {{ background: {hover}; }}
QPushButton:pressed {{ background: {press}; }}
QPushButton:disabled {{ color: {text_off}; border-color: {line}; background: transparent; }}
QPushButton:focus {{ outline: none; }}
QPushButton#primary {{ background: {acc}; color: #FFFFFF; border: none; padding: 0 22px; min-height: 36px; }}
QPushButton#primary:hover {{ background: {acc_hover}; }}
QPushButton#primary:disabled {{ background: {acc_off}; color: {on_acc_off}; }}
QPushButton#tab {{ background: transparent; color: {sub}; border: none; border-radius: 17px; padding: 0 16px;
                  min-height: 34px; }}
QPushButton#tab:hover {{ background: {hover}; color: {text}; }}
QPushButton#tab:checked {{ background: {text}; color: {bg}; }}
QPushButton#chip {{ background: {s2}; color: {sub}; border: 1px solid transparent; border-radius: 15px;
                   padding: 0 12px; min-height: 28px; }}
QPushButton#chip:hover {{ color: {text}; border-color: {acc_hi}; background: {s2}; }}
QPushButton#chip[accent="true"] {{ color: {acc_hi}; border-color: {acc_hi}; }}
QPushButton#link {{ background: transparent; border: none; color: {acc_hi}; padding: 0 4px; min-height: 28px; }}
QPushButton#link:hover {{ text-decoration: underline; background: transparent; }}
QToolButton#round {{ background: {s2}; border: 1px solid transparent; border-radius: 15px; min-width: 30px;
                    max-width: 30px; min-height: 30px; max-height: 30px; padding: 0; }}
QToolButton#round:hover {{ border-color: {acc_hi}; }}
QToolButton#round::menu-indicator {{ image: none; width: 0; }}

QLineEdit {{ background: {input}; color: {text}; border: 1px solid {field}; border-radius: 12px;
            padding: 0 12px; min-height: 34px; selection-background-color: {acc}; selection-color: #FFFFFF; }}
QLineEdit:focus {{ border-color: {acc_hi}; }}
QLineEdit#search {{ background: {s2}; border: 1px solid transparent; border-radius: 18px; padding-left: 16px; }}
QLineEdit#search:focus {{ border-color: {acc_hi}; }}
QComboBox {{ background: {input}; color: {text}; border: 1px solid {field}; border-radius: 18px;
            padding: 0 34px 0 14px; min-height: 34px; }}
QComboBox:hover, QComboBox:focus {{ border-color: {acc_hi}; }}
QComboBox:disabled {{ color: {text_off}; border-color: {line}; }}
QComboBox::drop-down {{ border: none; width: 30px; subcontrol-origin: padding; subcontrol-position: center right; }}
QComboBox::down-arrow {{ image: url("{chevron}"); width: 14px; height: 14px; }}
QComboBox QAbstractItemView {{ background: {surface}; color: {text}; border: 1px solid {line}; padding: 4px;
                              selection-background-color: {sel}; selection-color: {text}; outline: 0; }}

QTableWidget, QTreeWidget, QTableView, QTreeView {{ background: {surface}; alternate-background-color: {surface};
    border: none; selection-background-color: {sel}; selection-color: {text}; gridline-color: transparent;
    outline: 0; }}
QTableView::item, QTreeView::item {{ padding: 5px 8px; border: none; border-bottom: 1px solid {row_line}; }}
QTableView::item:hover, QTreeView::item:hover {{ background: {hover}; }}
QTableView::item:selected, QTreeView::item:selected {{ background: {sel}; }}
QHeaderView {{ background: {surface}; border: none; }}
QHeaderView::section {{ background: {surface}; color: {muted}; border: none; border-bottom: 1px solid {line};
                        padding: 4px 8px 8px 8px; }}
QTableCornerButton::section {{ background: {surface}; border: none; }}
QTreeView::indicator, QCheckBox::indicator {{ width: 16px; height: 16px; border: 1px solid {field};
    border-radius: 5px; background: {input}; }}
QTreeView::indicator:hover, QCheckBox::indicator:hover {{ border-color: {acc_hi}; }}
QTreeView::indicator:checked, QCheckBox::indicator:checked {{ background: {acc}; border-color: {acc};
    image: url("{check}"); }}
QTreeView::indicator:indeterminate {{ background: {acc}; border-color: {acc}; image: url("{dash}"); }}
QCheckBox {{ spacing: 8px; color: {text}; background: transparent; }}

QPlainTextEdit {{ background: {s2}; color: {sub}; border: none; border-radius: 12px; padding: 6px 8px;
                 selection-background-color: {acc}; selection-color: #FFFFFF; }}
QPlainTextEdit#log {{ font-family: {mono}; font-size: 11px; }}
QProgressBar {{ background: {track}; border: none; border-radius: 3px; min-height: 6px; max-height: 6px; }}
QProgressBar::chunk {{ background: {acc_hi}; border-radius: 3px; }}
QStatusBar {{ background: {bg}; color: {muted}; border: none; }}
QStatusBar::item {{ border: none; }}
QSplitter::handle {{ background: transparent; }}
QToolTip {{ background: {surface}; color: {text}; border: 1px solid {line}; padding: 6px 8px; }}
QMenu {{ background: {surface}; color: {text}; border: 1px solid {line}; padding: 6px; }}
QMenu::item {{ padding: 7px 18px 7px 26px; border-radius: 8px; }}
QMenu::item:selected {{ background: {hover}; }}
QMenu::indicator {{ width: 14px; height: 14px; left: 6px; }}
QMenu::indicator:checked {{ image: url("{check}"); background: {acc}; border-radius: 7px; }}
QScrollBar:vertical {{ background: transparent; width: 10px; margin: 2px; }}
QScrollBar:horizontal {{ background: transparent; height: 10px; margin: 2px; }}
QScrollBar::handle:vertical {{ background: {scroll}; border-radius: 3px; min-height: 32px; }}
QScrollBar::handle:horizontal {{ background: {scroll}; border-radius: 3px; min-width: 32px; }}
QScrollBar::handle:hover {{ background: {scroll_hi}; }}
QScrollBar::add-line, QScrollBar::sub-line {{ width: 0; height: 0; }}
QScrollBar::add-page, QScrollBar::sub-page {{ background: transparent; }}
""".format(**c)


def _palette() -> QPalette:
    pal = QPalette()
    for group in (QPalette.Active, QPalette.Inactive):
        pal.setColor(group, QPalette.Window, QColor(P["bg"]))
        pal.setColor(group, QPalette.WindowText, QColor(P["text"]))
        pal.setColor(group, QPalette.Base, QColor(P["surface"]))
        pal.setColor(group, QPalette.AlternateBase, QColor(P["surface"]))
        pal.setColor(group, QPalette.Text, QColor(P["text"]))
        pal.setColor(group, QPalette.Button, QColor(P["surface"]))
        pal.setColor(group, QPalette.ButtonText, QColor(P["text"]))
        pal.setColor(group, QPalette.Highlight, QColor(_mix(P["acc"], P["surface"], 0.82)))
        pal.setColor(group, QPalette.HighlightedText, QColor(P["text"]))
        pal.setColor(group, QPalette.ToolTipBase, QColor(P["surface"]))
        pal.setColor(group, QPalette.ToolTipText, QColor(P["text"]))
        pal.setColor(group, QPalette.PlaceholderText, QColor(P["muted"]))
        pal.setColor(group, QPalette.Link, QColor(P["acc_hi"]))
        pal.setColor(group, QPalette.Mid, QColor(P["line"]))
        pal.setColor(group, QPalette.Midlight, QColor(P["line"]))
        pal.setColor(group, QPalette.Light, QColor(P["surface"]))
        pal.setColor(group, QPalette.Dark, QColor(P["field"]))
        pal.setColor(group, QPalette.Shadow, QColor(P["field"]))
    off = _mix(P["muted"], P["bg"], 0.45)
    for role in (QPalette.WindowText, QPalette.Text, QPalette.ButtonText):
        pal.setColor(QPalette.Disabled, role, QColor(off))
    for role, key in ((QPalette.Window, "bg"), (QPalette.Base, "surface"), (QPalette.Button, "surface")):
        pal.setColor(QPalette.Disabled, role, QColor(P[key]))
    return pal


# ---------------------------------------------------------------------------------------------
# light / dark
# ---------------------------------------------------------------------------------------------

def _settings() -> QSettings:
    return QSettings("The Future Visuals", "Future Repair")


def mode() -> str:
    return _mode


def _system_dark() -> bool:
    try:
        return QGuiApplication.styleHints().colorScheme() == Qt.ColorScheme.Dark
    except AttributeError:                      # Qt older than 6.5
        return False


def apply() -> None:
    """Put the colours of the chosen look on the whole program."""
    global _dark, P
    app = QApplication.instance()
    if app is None:
        return
    _dark = _system_dark() if _mode == "auto" else _mode == "dark"
    P = dict(DARK if _dark else LIGHT)
    hints = app.styleHints()
    try:                                        # Qt 6.8+: the window frames follow too (macOS, Windows)
        if _mode == "auto":
            hints.unsetColorScheme()
        else:
            hints.setColorScheme(Qt.ColorScheme.Dark if _dark else Qt.ColorScheme.Light)
    except AttributeError:
        pass
    app.setPalette(_palette())
    app.setStyleSheet(stylesheet())
    notifier.changed.emit()


def set_mode(m: str) -> None:
    global _mode
    if m not in dict(MODES):
        m = "auto"
    _mode = m
    _settings().setValue("megjelenes/tema", m)
    apply()


def setup(app: QApplication) -> None:
    """Fonts, the saved look, and following the system's light/dark switch."""
    global _mode
    _load_fonts()
    app.setFont(font(14, 400))
    m = str(_settings().value("megjelenes/tema", "auto") or "auto")
    _mode = m if m in dict(MODES) else "auto"
    try:
        app.styleHints().colorSchemeChanged.connect(lambda _s: apply() if _mode == "auto" else None)
    except AttributeError:
        pass
    apply()


# ---------------------------------------------------------------------------------------------
# widgets of the look
# ---------------------------------------------------------------------------------------------

ROLE_TONE = Qt.UserRole + 40


class ToneDelegate(QStyledItemDelegate):
    """Colours a cell by the status tone stored in it (ROLE_TONE), in the colours of the look in use."""

    def initStyleOption(self, option, index):
        super().initStyleOption(option, index)
        t = index.data(ROLE_TONE)
        if t:
            c = QColor(tone(t))
            option.palette.setColor(QPalette.Text, c)
            option.palette.setColor(QPalette.HighlightedText, c)


def header_font(view) -> None:
    """Small spaced upper-case column titles. Given to the header items themselves: a font set on the
    header widget does not survive the view being placed into its box."""
    from PySide6.QtWidgets import QTableWidget, QTreeWidget
    f = font(11, 600, 0.14)
    if isinstance(view, QTreeWidget):
        hi = view.headerItem()
        for c in range(view.columnCount()):
            hi.setFont(c, f)
    elif isinstance(view, QTableWidget):
        for c in range(view.columnCount()):
            it = view.horizontalHeaderItem(c)
            if it is not None:
                it.setFont(f)


def heading(text: str) -> QLabel:
    """Small upper-case title of a box or section."""
    lab = QLabel(text.upper())
    lab.setObjectName("h")
    lab.setFont(font(11, 600, 0.14))
    return lab


def title(text: str) -> QLabel:
    lab = QLabel(text.upper())
    lab.setObjectName("title")
    lab.setFont(font(26, 600, 0.01))
    return lab


def subtitle(text: str) -> QLabel:
    lab = QLabel(text)
    lab.setObjectName("subtitle")
    lab.setWordWrap(True)
    return lab


def page_head(title_text: str, sub_text: str) -> QWidget:
    """A page's upper-case title with its line of explanation under it."""
    w = QWidget()
    lay = QVBoxLayout(w)
    lay.setContentsMargins(0, 0, 0, 2)
    lay.setSpacing(4)
    lay.addWidget(title(title_text))
    lay.addWidget(subtitle(sub_text))
    return w


class Card(QFrame):
    """A borderless rounded box, a step lighter than the page."""

    def __init__(self, heading_text: Optional[str] = None, margins=(18, 16, 18, 16), spacing: int = 10, parent=None):
        super().__init__(parent)
        self.setObjectName("card")
        self.lay = QVBoxLayout(self)
        self.lay.setContentsMargins(*margins)
        self.lay.setSpacing(spacing)
        if heading_text:
            self.lay.addWidget(heading(heading_text))


class PrimaryButton(QPushButton):
    """The filled teal pill: upper case, semibold, spaced."""

    def __init__(self, text: str = "", parent=None):
        super().__init__(parent)
        self.setObjectName("primary")
        self.setFont(font(12.5, 600, 0.1))
        self.setCursor(Qt.PointingHandCursor)
        self.setText(text)

    def setText(self, text: str) -> None:            # noqa: N802 (Qt name)
        super().setText(text.upper())


class TabButton(QPushButton):
    """One of the page tabs: a pill, the open one filled with ink."""

    def __init__(self, text: str, parent=None):
        super().__init__(text.upper(), parent)
        self.setObjectName("tab")
        self.setCheckable(True)
        self.setFont(font(12, 600, 0.1))
        self.setCursor(Qt.PointingHandCursor)


def chip(text: str = "") -> QPushButton:
    b = QPushButton(text)
    b.setObjectName("chip")
    b.setFont(font(12.5, 500))
    b.setCursor(Qt.PointingHandCursor)
    return b


def dot_icon(color: str, size: int = 8) -> QIcon:
    pm = QPixmap(size * 2, size * 2)
    pm.setDevicePixelRatio(2.0)
    pm.fill(Qt.transparent)
    p = QPainter(pm)
    p.setRenderHint(QPainter.Antialiasing)
    p.setPen(Qt.NoPen)
    p.setBrush(QColor(color))
    p.drawEllipse(QRectF(0.5, 0.5, size - 1, size - 1))
    p.end()
    return QIcon(pm)


# -- the wordmark -------------------------------------------------------------------------------

_WORD = [("the", False), ("future", True), ("visuals", False)]
_CYCLE = 1.8            # seconds, as the delivery site's loader
_STEP = 0.075           # the wave's delay from one letter to the next


def _ease(t: float) -> float:
    return t * t * (3 - 2 * t)


def _wave(t: float, base: float, peak: float) -> float:
    t %= 1.0
    if t < 0.27:
        return base + (peak - base) * _ease(t / 0.27)
    if t < 0.55:
        return peak + (base - peak) * _ease((t - 0.27) / 0.28)
    return base


class Wordmark(QWidget):
    """thefuturevisuals: "the" and "visuals" light, "future" bold. Animated, it is the studio's loading
    indicator: a weight wave runs across the letters (the/visuals thicken, future thins), and every letter
    keeps the width of its heaviest form, so the word never changes width."""

    def __init__(self, px: float = 17, animated: bool = False, colour_key: str = "text", parent=None):
        super().__init__(parent)
        self.px = px
        self.animated = animated
        self.colour_key = colour_key
        self._t0 = time.monotonic()
        self._timer = QTimer(self)
        self._timer.setInterval(33)
        self._timer.timeout.connect(self.update)
        self._letters: List[tuple] = []
        for word, bold in _WORD:
            for ch in word:
                self._letters.append((ch, bold))
        self._measure()
        self.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
        notifier.changed.connect(self.update)

    def _measure(self):
        fm_heavy = QFontMetricsF(font(self.px, 800, kind="mark"))
        self._cells = [fm_heavy.horizontalAdvance(ch) for ch, _b in self._letters]
        fm = QFontMetricsF(font(self.px, 300, kind="mark"))
        self._ascent = fm.ascent()
        self._height = fm.height()
        if not self.animated:
            self._width = sum(QFontMetricsF(font(self.px, 700 if b else 300, kind="mark")).horizontalAdvance(w)
                              for w, b in _WORD)
        else:
            self._width = sum(self._cells)

    def sizeHint(self) -> QSize:
        return QSize(int(self._width + 2), int(self._height + 2))

    def minimumSizeHint(self) -> QSize:
        return self.sizeHint()

    def showEvent(self, e):
        if self.animated:
            self._t0 = time.monotonic()
            self._timer.start()
        super().showEvent(e)

    def hideEvent(self, e):
        self._timer.stop()
        super().hideEvent(e)

    def paintEvent(self, _e):
        p = QPainter(self)
        p.setRenderHint(QPainter.TextAntialiasing)
        p.setPen(QColor(P.get(self.colour_key, P["text"])))
        y = (self.height() - self._height) / 2 + self._ascent
        x = max(0.0, (self.width() - self._width) / 2) if self.animated else 0.0
        if not self.animated:
            for word, bold in _WORD:
                f = font(self.px, 700 if bold else 300, kind="mark")
                p.setFont(f)
                p.drawText(QPointF(x, y), word)
                x += QFontMetricsF(f).horizontalAdvance(word)
            p.end()
            return
        now = time.monotonic() - self._t0
        for i, (ch, bold) in enumerate(self._letters):
            t = (now - i * _STEP) / _CYCLE
            w = _wave(t, 700, 200) if bold else _wave(t, 300, 800)
            f = font(self.px, int(round(w / 100.0) * 100), kind="mark")
            p.setFont(f)
            adv = QFontMetricsF(f).horizontalAdvance(ch)
            p.drawText(QPointF(x + (self._cells[i] - adv) / 2, y), ch)
            x += self._cells[i]
        p.end()


class ProgressLine(QWidget):
    """Progress in the look: the text above a thin bar; while there is nothing to measure (range 0..0)
    the animated wordmark runs in the bar's place. Speaks the QProgressBar calls the pages use."""

    def __init__(self, parent=None):
        super().__init__(parent)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(4)
        self.label = QLabel("")
        self.label.setObjectName("sub")
        self.label.setFont(font(12.5, 500))
        self.label.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        lay.addWidget(self.label)
        self.stack = QStackedWidget()
        self.stack.setFixedHeight(18)
        holder = QWidget()
        hl = QVBoxLayout(holder)
        hl.setContentsMargins(0, 6, 0, 6)
        self.bar = QProgressBar()
        self.bar.setTextVisible(False)
        hl.addWidget(self.bar)
        self.stack.addWidget(holder)
        self.mark = Wordmark(13, animated=True, colour_key="muted")
        wrap = QWidget()
        wl = QHBoxLayout(wrap)
        wl.setContentsMargins(0, 0, 0, 0)
        wl.addStretch(1)
        wl.addWidget(self.mark)
        self.stack.addWidget(wrap)
        lay.addWidget(self.stack)
        self.setRange(0, 1)

    def setRange(self, a: int, b: int) -> None:       # noqa: N802
        self.bar.setRange(a, b)
        busy = a == 0 and b == 0
        self.stack.setCurrentIndex(1 if busy else 0)

    def setValue(self, v: int) -> None:               # noqa: N802
        self.bar.setValue(v)

    def value(self) -> int:
        return self.bar.value()

    def maximum(self) -> int:
        return self.bar.maximum()

    def minimum(self) -> int:
        return self.bar.minimum()

    def setFormat(self, text: str) -> None:           # noqa: N802
        self.label.setText(text)

    def setTextVisible(self, _on: bool) -> None:      # noqa: N802
        pass

    def reset(self) -> None:
        self.setRange(0, 1)
        self.bar.setValue(0)
        self.label.setText("")


# -- light / dark switch ------------------------------------------------------------------------

def _mode_icon(m: str, colour: str) -> QIcon:
    size = 16
    pm = QPixmap(size * 2, size * 2)
    pm.setDevicePixelRatio(2.0)
    pm.fill(Qt.transparent)
    p = QPainter(pm)
    p.setRenderHint(QPainter.Antialiasing)
    c = QColor(colour)
    if m == "dark":                              # a crescent
        path = QPainterPath()
        path.addEllipse(QRectF(2.5, 2.5, 11, 11))
        cut = QPainterPath()
        cut.addEllipse(QRectF(6.2, 0.8, 10, 10))
        p.fillPath(path.subtracted(cut), c)
    elif m == "light":                           # a sun
        p.setPen(Qt.NoPen)
        p.setBrush(c)
        p.drawEllipse(QRectF(5, 5, 6, 6))
        p.setPen(QPen(c, 1.4, Qt.SolidLine, Qt.RoundCap))
        import math
        for k in range(8):
            a = k * math.pi / 4
            p.drawLine(QPointF(8 + 4.9 * math.cos(a), 8 + 4.9 * math.sin(a)),
                       QPointF(8 + 6.6 * math.cos(a), 8 + 6.6 * math.sin(a)))
    else:                                        # half and half: following the system
        p.setPen(QPen(c, 1.4))
        p.setBrush(Qt.NoBrush)
        p.drawEllipse(QRectF(2.5, 2.5, 11, 11))
        half = QPainterPath()
        half.moveTo(8, 2.5)
        half.arcTo(QRectF(2.5, 2.5, 11, 11), 90, 180)
        half.closeSubpath()
        p.fillPath(half, c)
    p.end()
    return QIcon(pm)


class ThemeButton(QToolButton):
    """Round button with the look's choices: following the system, light, dark."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("round")
        self.setPopupMode(QToolButton.InstantPopup)
        self.setCursor(Qt.PointingHandCursor)
        self.setToolTip("Megjelenés: világos, sötét vagy a rendszer szerint")
        menu = QMenu(self)
        group = QActionGroup(self)
        group.setExclusive(True)
        self._actions = {}
        for key, label in MODES:
            a = QAction(label, self, checkable=True)
            a.triggered.connect(lambda _c=False, k=key: set_mode(k))
            group.addAction(a)
            menu.addAction(a)
            self._actions[key] = a
        self.setMenu(menu)
        notifier.changed.connect(self._refresh)
        self._refresh()

    def _refresh(self):
        self._actions.get(_mode, self._actions["auto"]).setChecked(True)
        self.setIcon(_mode_icon(_mode, P["sub"]))
        self.setIconSize(QSize(16, 16))
