"""Putting a fragmented MXF recording (e.g. Sony FX6 / FX9, Canon XF-AVC) back together.

An MXF file is one long chain of KLV packets (16-byte key that starts with 06 0E 2B 34, a BER
length, the value). Walking the chain tells exactly where the next packet must start after a
piece boundary, so a candidate piece is right only if a valid packet starts at exactly that
offset and the chain runs on through the whole piece. Frame-wrapped recordings also carry a
system item in every frame whose continuity count goes up by one, which tells two cameras with
the same settings apart. The Random Index Pack at the very end lists where every partition
starts; it is looked for first (just before the sidecar XML) and bounds the search.
"""
from __future__ import annotations

import time
from typing import Dict, List, Optional, Set, Tuple

from .pieces import PieceRebuild

PREFIX = b"\x06\x0e\x2b\x34"
PARTITION = b"\x06\x0e\x2b\x34\x02\x05\x01\x01\x0d\x01\x02\x01\x01"      # + kind (2/3/4) + status + 00
RIP_KEY = b"\x06\x0e\x2b\x34\x02\x05\x01\x01\x0d\x01\x02\x01\x01\x11\x01\x00"
FILL_KEY = b"\x06\x0e\x2b\x34\x01\x01\x01\x02\x03\x01\x02\x10\x01\x00\x00\x00"
WHY_RIP = "a partíció nem ott van, ahol a fájl vége szerint kell"
SYSTEM_PACK = b"\x06\x0e\x2b\x34\x02\x05\x01\x01\x0d\x01\x03\x01\x04\x01\x01\x00"


def klv_header(b: bytes, i: int = 0) -> Optional[Tuple[bytes, int, int]]:
    """(key, header length, value length) of the packet at b[i], or None."""
    if len(b) < i + 17:
        return None
    if b[i:i + 4] != PREFIX or b[i + 4] not in (1, 2, 3, 4):
        return None
    L = b[i + 16]
    if L < 0x80:
        return bytes(b[i:i + 16]), 17, L
    n = L & 0x7F
    if n == 0 or n > 8 or len(b) < i + 17 + n:
        return None
    return bytes(b[i:i + 16]), 17 + n, int.from_bytes(b[i + 17:i + 17 + n], "big")


def is_mxf_start(head: bytes) -> bool:
    return head[:13] == PARTITION and len(head) > 13 and head[13] == 2


FPS = [0, 24, 25, 30, 48, 50, 60, 72, 75, 90, 96, 100, 120]


def tc_frames(tc: bytes, fps: int) -> Optional[int]:
    """Frame number of an SMPTE 12M time code (4 BCD bytes: frames, seconds, minutes, hours)."""
    if len(tc) < 4 or not fps:
        return None
    def bcd(v, tens_mask):
        return ((v >> 4) & tens_mask) * 10 + (v & 0x0F)
    f, sec, m, h = bcd(tc[0], 0x3), bcd(tc[1], 0x7), bcd(tc[2], 0x7), bcd(tc[3], 0x3)
    if f >= fps or sec > 59 or m > 59 or h > 23:
        return None
    return ((h * 60 + m) * 60 + sec) * fps + f


class Walk:
    """State of the packet chain at a point: where the next packet starts, the last continuity
    count, time code and picture element seen; where the last system item (frame) and the last
    packet started, and how many frames came so far."""
    __slots__ = ("next", "cc", "n", "tc", "fps", "pic", "last", "sys", "fr", "lastoff", "ccbreak")

    def __init__(self, nxt: int, cc: Optional[int] = None, n: int = 0, tc: Optional[int] = None,
                 fps: int = 0, pic: Optional[Tuple[int, int]] = None, last=None, sys: Optional[int] = None,
                 fr: int = -1, lastoff: Optional[int] = None):
        self.next, self.cc, self.n, self.tc, self.fps, self.pic, self.last = nxt, cc, n, tc, fps, pic, last
        self.sys, self.fr, self.lastoff = sys, fr, lastoff
        self.ccbreak = False

    def copy(self, nxt=None):
        return Walk(self.next if nxt is None else nxt, self.cc, self.n, self.tc, self.fps, self.pic, self.last,
                    self.sys, self.fr, self.lastoff)


class MxfRebuild(PieceRebuild):
    kind = "mxf"

    def __init__(self, *a, **kw):
        super().__init__(*a, **kw)
        self.rip: List[int] = []                # partition offsets from the Random Index Pack
        self.rip_set: Set[int] = set()
        self.uncertain: List[int] = []
        self.decided: Dict[str, int] = {}
        self.twin_prone = False
        self.why: Dict[str, int] = {}        # why candidates were turned down (for the log when a piece is missing)
        self.rip_dropped = False
        # probe: try this write size quickly (bounded search, give up at the first missing piece);
        # final: the size to use - search further (up to a time budget), then lose a missing piece
        # and pick the chain up again after it
        self.mode = "probe"
        self.deep_limit = 400_000            # candidates per deep search (about 7 minutes on a hard disk)
        self.deep_until: Optional[float] = None
        self.deep_out = False                # the deep-search time of this file is used up
        self.limit: Optional[int] = None
        self.until: Optional[float] = None
        self.pat: Optional[List[int]] = None     # frame sizes repeating (constant bytes per frame)
        self.pat0 = 0
        self.part_over: Optional[int] = None     # partition start -> first frame after it
        self.missing: List[int] = []
        self.fills: List[Tuple[int, int]] = []   # in-file ranges written as KLV fill (lost data)
        self.ev: List[Tuple[str, int, int]] = []
        self.anchor_part = False                 # the search starts at a partition (after lost data)
        self.cc_window: Optional[Tuple[int, int, int]] = None   # (count before, least, most frames on)

    # chain walking ------------------------------------------------------------------------
    def walk(self, read, w: Walk, stop: int, need_cc: bool = False, max_packets: Optional[int] = None,
             starts: Optional[Set[int]] = None, info: Optional[Dict] = None,
             pic_sizes: Optional[List[int]] = None, strict: bool = False,
             events: Optional[List[Tuple[str, int, int]]] = None) -> Tuple[bool, Walk, Optional[int]]:
        """Follow the chain from w.next while packets start before `stop`.
        Returns (ok, new state, first continuity count seen); `info` gets the first time code and
        the first whole picture element after the start. `strict`: every frame's continuity count
        must follow the one before (the data of another recording with the same structure can
        carry the chain on, but not the count). `events` gets ("sys", offset, frame) and
        ("part", offset, 0)."""
        st = w.copy()
        off = st.next
        first_cc = None
        count = 0
        while off < stop:
            h = read(off, 32)
            if len(h) < 17 and off + 17 <= self.size:
                st.next = off
                return True, st, first_cc
            r = klv_header(h, 0)
            if r is None:
                if len(h) < 32 and off + 32 <= self.size and h[:4] == PREFIX[:len(h[:4])]:
                    st.next = off
                    return True, st, first_cc
                st.next = off
                return False, st, first_cc
            key, hl, vl = r
            end = off + hl + vl
            if end > self.size:
                st.next = off
                return False, st, first_cc
            if starts is not None:
                starts.add(off)
            if key[:13] == PARTITION and events is not None:
                events.append(("part", off, key[13]))
            if key == SYSTEM_PACK and vl >= 7:
                v = read(off + hl, min(vl, 57))
                if len(v) >= 7:
                    c = int.from_bytes(v[5:7], "big")
                    if first_cc is None:
                        first_cc = c
                        if need_cc and st.cc is not None and c != (st.cc + 1) & 0xFFFF:
                            st.next = off
                            return False, st, first_cc
                    elif strict and st.cc is not None and c != (st.cc + 1) & 0xFFFF:
                        st.next = off
                        st.ccbreak = True
                        return False, st, first_cc
                    st.cc = c
                st.sys = off
                st.fr += 1
                if events is not None:
                    events.append(("sys", off, st.fr))
                if len(v) >= 57:
                    st.fps = FPS[(v[1] >> 1) & 0x1F] if ((v[1] >> 1) & 0x1F) < len(FPS) else 0
                    tcb = v[41:45] if v[40] == 0x81 else (v[24:28] if v[23] == 0x81 else b"")
                    t = tc_frames(tcb, st.fps) if tcb else None
                    if info is not None and "tc" not in info and t is not None:
                        info["tc"] = t
                    st.tc = t
            elif key[12] in (0x05, 0x15) and key[4] == 0x01 and end <= stop:
                if pic_sizes is not None:
                    pic_sizes.append(vl)
                if info is not None and "pic" not in info:
                    info["pic"] = (off + hl, vl)
                st.pic = (off + hl, vl)
            st.last = ("pic" if key[12] in (0x05, 0x15) and key[4] == 0x01 else
                       "snd" if key[12] in (0x06, 0x16) and key[4] == 0x01 else "other", off + hl, vl)
            st.lastoff = off
            off = end
            st.n += 1
            count += 1
            if max_packets is not None and count >= max_packets and (first_cc is not None or not need_cc):
                break
        st.next = off
        return True, st, first_cc

    def _piece_ok(self, k: int, c: int, w: Walk, info: Optional[Dict] = None) -> Optional[Walk]:
        """Does piece k fit at cluster c, coming after chain state w? Returns the state at its end."""
        read = self.reader({k: c})
        lo = k * self.U
        hi = lo + self.plen(k)

        def no(reason):
            self.why[reason] = self.why.get(reason, 0) + 1
            return None
        # quick test: a packet must start exactly where the chain says
        h = read(w.next, 32)
        if klv_header(h, 0) is None and len(h) >= 32:
            return no("nincs csomag a helyén")
        if self.anchor_part:
            # picked up again at a partition: every partition of every MXF begins the same, but its own
            # place in the file is written in it
            r = klv_header(h, 0)
            v = read(w.next + r[1], 16) if r is not None else b""
            if r is None or r[0][:13] != PARTITION or len(v) < 16 or int.from_bytes(v[8:16], "big") != w.next:
                return no("a partíció nem ide való")
        ok, w2, first_cc = self.walk(read, w, hi, need_cc=w.cc is not None, max_packets=6)
        if not ok:
            if w.cc is not None and first_cc is not None and first_cc != (w.cc + 1) & 0xFFFF:
                return no("más a képkockaszámláló")
            return no("a lánc az elején megszakad")
        # the whole piece: every packet valid, the partitions where the index says
        starts: Set[int] = set()
        events: List[Tuple[str, int, int]] = []
        ok, w3, cc3 = self.walk(read, w, hi, need_cc=w.cc is not None, starts=starts, info=info, events=events)
        if info is not None:
            info["events"] = events
        if not ok:
            return no("a lánc a darab közepén megszakad")
        if self.cc_window is not None and cc3 is not None:
            base, dmin, dmax = self.cc_window
            if not dmin <= ((cc3 - base) & 0xFFFF) <= dmax:
                return no("más a képkockaszámláló")
        for p in self.rip:
            if max(lo, w.next) <= p < hi and p not in starts:
                return no("a partíció nem ott van, ahol a fájl vége szerint kell")
        if k == self.K - 1 and w3.next != self.size:
            return no("a lánc nem a fájl végén ér véget")
        return w3

    def _choose(self, k: int, w: Walk, passes: List[Tuple[int, int, Walk, Dict]]):
        """Several positions fit piece k structurally (two cameras with the same settings): decide
        by the time code, then by the picture."""
        if w.tc is not None:
            nxt = [p for p in passes if p[3].get("tc") is not None and p[3]["tc"] - w.tc == 1]
            if len(nxt) == 1:
                self.decided["time code"] = self.decided.get("time code", 0) + 1
                return nxt[0]
            if nxt:
                passes = nxt
        if w.pic is not None:
            from .thumbs import mad, thumb
            left = thumb(self.reader()(w.pic[0], w.pic[1]))
            # the picture that runs across the boundary, put together with each candidate
            lt = w.last
            if left is not None and lt is not None and lt[0] == "pic" and lt[1] < k * self.U < lt[1] + lt[2]:
                scored = []
                for p in passes:
                    t = thumb(self.reader({k: p[1]})(lt[1], lt[2]))
                    scored.append((mad(left, t) if t is not None else 1e9, p))
                scored.sort(key=lambda x: x[0])
                if scored[0][0] < 1e9 and (len(scored) == 1 or scored[0][0] < 0.75 * scored[1][0]):
                    self.decided["picture"] = self.decided.get("picture", 0) + 1
                    return scored[0][1]
            if left is not None:
                scored = []
                for p in passes:
                    pic = p[3].get("pic")
                    if pic is None:
                        continue
                    t = thumb(self.reader({k: p[1]})(pic[0], pic[1]))
                    if t is not None:
                        scored.append((mad(left, t), p))
                scored.sort(key=lambda x: x[0])
                if scored and (len(scored) == 1 or scored[0][0] < 0.75 * scored[1][0]):
                    self.decided["picture"] = self.decided.get("picture", 0) + 1
                    return scored[0][1]
        self.uncertain.append(k)
        if getattr(self, "debug", False):
            self.log("    bizonytalan %d. darab: %s; bal kép: %s; jelöltek: %s" % (
                k, [(p[0], p[1], p[3].get("tc"), p[3].get("pic")) for p in passes], w.pic, w.tc))
        return passes[0]

    def _find_piece(self, k: int, w: Walk, first: Optional[int] = None):
        n = self.plen_cl(k)
        passes = []
        first_i = None
        cands = self.candidates(k)
        if first is not None:
            import itertools
            cands = itertools.chain([first], (c for c in cands if c != first))
        # recordings with the same size for every frame (XAVC Intra, DNxHD...) from a second camera
        # look the same piece by piece: then look further for a look-alike before deciding
        extra = (4 * self.ucl + 32) if self.twin_prone else 24
        for i, c in enumerate(cands):
            if i % 256 == 0:
                self.cancelled()
                if self.until is not None and first_i is None and time.time() > self.until:
                    self.deep_out = True
                    break
            if self.limit is not None and first_i is None and i >= self.limit:
                break
            if first_i is not None and i > first_i + extra:
                break
            if not self.free(c, n):
                continue
            self.tried += 1
            info: Dict = {}
            r = self._piece_ok(k, c, w, info)
            if r is not None:
                passes.append((i, c, r, info))
                if first_i is None:
                    first_i = i
        if getattr(self, "debug", False):
            self.log("    %s darab %d: megfelel %s" % (self.name, k, [(p[0], p[1]) for p in passes]))
        if not passes:
            return None
        if len(passes) == 1:
            return passes[0]
        got = self._choose(k, w, passes)
        if getattr(self, "debug", False):
            self.log("      -> %d" % got[1])
        return got

    # the Random Index Pack at the end ------------------------------------------------------------
    def _rip_at(self, c: int) -> Optional[List[int]]:
        k = self.K - 1
        lo = k * self.U
        read = self.reader({k: c})
        tail = read(self.size - 4, 4)
        if len(tail) < 4:
            return None
        L = int.from_bytes(tail, "big")
        start = self.size - L
        if L < 16 + 1 + 4 + 12 or L > (8 << 20) or start < lo:
            return None
        h = read(start, 32)
        r = klv_header(h, 0)
        if r is None or r[0] != RIP_KEY:
            return None
        hl, vl = r[1], r[2]
        if hl + vl != L or (vl - 4) % 12:
            return None
        body = read(start + hl, vl - 4)
        offs = []
        for i in range(0, len(body), 12):
            offs.append(int.from_bytes(body[i + 4:i + 12], "big"))
        if not offs or offs[0] != 0 or any(b <= a for a, b in zip(offs, offs[1:])) or offs[-1] >= self.size:
            return None
        foot = offs[-1]
        if foot >= lo:
            fh = read(foot, 16)
            if fh[:13] != PARTITION or fh[13] != 4:
                return None
        return offs

    def find_end(self) -> bool:
        if self.K < 2:
            return False
        k = self.K - 1
        for i, c in enumerate(self.last_candidates()):
            if i % 256 == 0:
                self.cancelled()
            if not self.free(c, self.plen_cl(k)):
                continue
            offs = self._rip_at(c)
            if offs:
                self.pieces[k] = c
                self.found_by[k] = i
                self.rip = offs
                self.rip_set = set(offs)
                self.log("  %s: a fájl vége (partíciólista) megvan a %d. klaszterben (%d. jelölt)." % (
                    self.name, c, i + 1))
                return True
        return False

    # frames with the same size (XAVC Intra): where the chain goes on after lost data -------------
    def _learn_pattern(self, events: List[Tuple[str, int, int]]) -> None:
        """From the first piece: the frame sizes, if they repeat (with a period of up to 10 frames,
        e.g. 29.97 fps sound), and how far the first frame is after a body partition."""
        sizes: List[Tuple[int, int]] = []        # (frame number, bytes) of frames with no partition inside
        overs = set()
        prev = None
        part = None
        for kind, off, fr in events:
            if kind == "part":
                if fr == 3:                      # a body partition (the header partition comes before frame 0)
                    part = off
                continue
            if prev is not None and part is None:
                sizes.append((prev[1], off - prev[0]))
            if part is not None and prev is not None:
                overs.add(off - part)
            prev = (off, fr)
            part = None
        if len(overs) == 1:
            self.part_over = overs.pop()
        if len(sizes) < 6:
            return
        # frames are consecutive between partitions; check the period on the longest run
        vals = [b for _f, b in sizes]
        f0 = sizes[0][0]
        for n in range(1, 11):
            if len(vals) < 3 * n:
                break
            if all(sizes[i][1] == sizes[i + n][1] for i in range(len(sizes) - n)
                   if sizes[i + n][0] - sizes[i][0] == n):
                self.pat = [0] * n
                for fr, b in sizes:
                    self.pat[(fr - f0) % n] = b
                self.pat0 = f0
                return

    def _frame_after(self, w: Walk, target: int) -> Optional[Tuple[int, int]]:
        """(offset, frames on) of the first frame that starts at or after in-file `target`, counted
        on from the last frame the chain saw - only for recordings whose frames have the same size."""
        if not self.pat or w.sys is None or w.fr < 0:
            return None
        n = len(self.pat)
        pos, fr = w.sys, w.fr
        parts = sorted(p for p in self.rip if p > pos)
        pi = 0
        guard = 0
        while pos < target:
            nxt = pos + self.pat[(fr - self.pat0) % n]
            while pi < len(parts) and parts[pi] < nxt:
                return None                      # a partition inside a frame: the sizes do not hold
            if pi < len(parts) and parts[pi] == nxt:
                if self.part_over is None:
                    return None
                nxt += self.part_over
                pi += 1
            pos, fr = nxt, fr + 1
            guard += 1
            if guard > 2_000_000:
                return None
        return pos, fr - w.fr

    def _resume_cbr_ok(self, w: Walk, k: int) -> bool:
        """Can the frame sizes tell where the chain goes on in piece k?"""
        if (not self.pat or self.part_over is None) and len(self.ev) > 8:
            pat, pat0 = self.pat, self.pat0
            self._learn_pattern(self.ev)
            if not self.pat and pat:
                self.pat, self.pat0 = pat, pat0
        return self._frame_after(w, k * self.U) is not None

    def _keep_events(self, info: Optional[Dict]) -> None:
        ev = (info or {}).get("events")
        if ev:
            self.ev.extend(ev)
            if len(self.ev) > 4000:
                del self.ev[:len(self.ev) - 3000]

    def _resume(self, w: Walk, k: int) -> Optional[Tuple[int, Walk]]:
        """After piece k-1 (state w) data is lost from piece k on: where can the chain be picked up
        in piece k or later? (piece, state at that point)"""
        if (not self.pat or self.part_over is None) and len(self.ev) > 8:
            # the first piece was too short to see the frame sizes, or had no body partition in it
            pat, pat0 = self.pat, self.pat0
            self._learn_pattern(self.ev)
            if not self.pat and pat:
                self.pat, self.pat0 = pat, pat0
        if getattr(self, "debug", False):
            self.log("    folytatás keresése a %d. darabtól: képkockaméretek %s (kezdet %d), partíció után %s, "
                     "utolsó képkocka %s/%d, események %d" % (k, self.pat, self.pat0, self.part_over, w.sys, w.fr,
                                                              len(self.ev)))
        target = k * self.U
        got = self._frame_after(w, target)
        if got is not None:
            off, m = got
            if off < self.size:
                w2 = Walk(off, None if w.cc is None else (w.cc + m - 1) & 0xFFFF, w.n,
                          None if w.tc is None else w.tc + m - 1, w.fps, None, None, None, w.fr + m - 1, None)
                return off // self.U, w2
        # different frame sizes: a body partition (its place is in the list at the end) starts a packet
        nxt = [p for p in self.rip if p >= target]
        if nxt and nxt[0] < self.size:
            return nxt[0] // self.U, Walk(nxt[0], None, w.n, None, w.fps)
        return None

    def _scan_resync(self, k: int, w: Walk):
        """Frames of different sizes: look in the likely places of piece k for the first frame that
        starts in it (its system item), with a count that fits the frames lost since the last one seen,
        and the chain running on from it to the piece's end. ((i, c, state, info), offset) or None."""
        fb = self._frame_bytes()
        if not fb or w.cc is None or w.sys is None or k >= self.K:
            return None
        span = min(self.plen(k), max(2 * fb[1] + 4096, 1 << 20), 16 << 20)
        n = self.plen_cl(k)
        self.cur_k = k
        passes = []
        first_i = None
        for i, c in enumerate(self.candidates(k)):
            if i >= 96 or (first_i is not None and i > first_i + 24):
                break
            if i % 16 == 0:
                self.cancelled()
            if not self.free(c, n):
                continue
            self.tried += 1
            blob = self.src.read(self.pos(c), span)
            d = blob.find(SYSTEM_PACK)
            if d < 0:
                continue
            r = klv_header(blob, d)
            if r is None or d + r[1] + 7 > len(blob):
                continue
            cc = int.from_bytes(blob[d + r[1] + 5:d + r[1] + 7], "big")
            off = k * self.U + d
            m = (cc - w.cc) & 0xFFFF
            if not self._frames_fit(off - w.sys, m, fb):
                continue
            w2 = Walk(off, (cc - 1) & 0xFFFF, w.n, None if w.tc is None else w.tc + m - 1, w.fps,
                      None, None, None, w.fr + m - 1, None)
            info: Dict = {}
            got = self._piece_ok(k, c, w2, info)
            if got is not None:
                passes.append(((i, c, got, info), off, m))
                if first_i is None:
                    first_i = i
        if getattr(self, "debug", False):
            self.log("    tartalom szerinti folytatás a %d. darabban: %s (előtte tc %s, cc %s)" % (
                k, [(p[0][1], p[2], p[0][3].get("tc")) for p in passes], w.tc, w.cc))
        if w.tc is not None:
            # the time code runs on frame by frame: another recording of the same camera does not fit it
            passes = [p for p in passes if p[0][3].get("tc") is not None and p[0][3]["tc"] - w.tc == p[2]]
            # what is left is this recording: the pieces before the gap are taken, so the one with the
            # fewest frames since the last one seen is the next piece (the others are later pieces)
            ms = sorted(p[2] for p in passes)
            if len(ms) > 1 and ms[0] < ms[1]:
                passes = [p for p in passes if p[2] == ms[0]]
        if len(passes) == 1:
            return passes[0][0], passes[0][1]
        if len(passes) > 1 and w.pic is not None:
            from .thumbs import mad, thumb
            left = thumb(self.reader()(w.pic[0], w.pic[1]))
            scored = []
            for p in passes:
                pic = p[0][3].get("pic")
                t = thumb(self.reader({k: p[0][1]})(pic[0], pic[1])) if (left is not None and pic) else None
                if t is not None:
                    scored.append((mad(left, t), p))
            scored.sort(key=lambda x: x[0])
            if scored and (len(scored) == 1 or scored[0][0] < 0.75 * scored[1][0]):
                self.decided["picture"] = self.decided.get("picture", 0) + 1
                return scored[0][1][0], scored[0][1][1]
        # nothing, or several recordings that cannot be told apart: rather lose this stretch than take
        # another file's piece
        return None

    @staticmethod
    def _frames_fit(dist: int, m: int, fb: Tuple[int, int]) -> bool:
        """Can m frames (each the size of the smallest to the largest seen lately) span `dist` bytes?
        (A body partition in between adds a little.)"""
        if m < 1:
            return False
        return m * fb[0] * 0.85 <= dist <= m * fb[1] * 1.15 + 65536

    def _frame_bytes(self) -> Optional[Tuple[int, int]]:
        """Smallest and largest frame seen lately."""
        sz = []
        prev = None
        for kind, off, _fr in self.ev:
            if kind == "part":
                prev = None
                continue
            if prev is not None:
                sz.append(off - prev)
            prev = off
        return (min(sz), max(sz)) if sz else None

    def _search(self, k: int, w: Walk, first: Optional[int] = None):
        """Piece k after chain state w: nearby first; in the final round further, while time allows."""
        self.cur_k = k
        self.why = {}
        self.bounded = True
        got = self._find_piece(k, w, first=first)
        if got is None and self.rip and not self.rip_dropped and self.why.get(WHY_RIP):
            # the partition list found at the end may belong to a look-alike recording: try without it
            why = dict(self.why)
            saved, self.rip, self.rip_set = self.rip, [], set()
            got = self._find_piece(k, w, first=first)
            if got is None:
                self.rip, self.rip_set = saved, set(saved)
                self.why = why
            else:
                self.rip_dropped = True
                self.log("  %s: a fájl végén talált partíciólista nem ehhez a felvételhez tartozik, "
                         "nélküle folytatom." % self.name)
        if got is None and self.mode == "final" and not self.deep_out and self.deep_until:
            why = dict(self.why)
            self.bounded = False
            self.deep_skip = True                # what the window covered is not looked at again
            self.limit, self.until = self.deep_limit, self.deep_until
            try:
                got = self._find_piece(k, w, first=first)
            finally:
                self.bounded = True
                self.deep_skip = False
                self.limit = self.until = None
            for key, v in why.items():
                self.why[key] = max(self.why.get(key, 0), v)
        return got

    def _infile_extents(self, a: int, b: int) -> List[Tuple[int, int]]:
        out: List[Tuple[int, int]] = []
        while a < b:
            k = a // self.U
            c = self.pieces[k]
            e = min(b, (k + 1) * self.U, self.size)
            p = self.pos(c) + (a - k * self.U)
            q = p + (e - a)
            if out and out[-1][1] == p:
                out[-1] = (out[-1][0], q)
            else:
                out.append((p, q))
            a = e
        return out

    def gap_extents(self, cut: Optional[int] = None) -> List:
        """Output: the found pieces, every lost stretch as one KLV fill packet (a reader skips it and
        the rest of the file keeps its offsets); `cut`: the file ends there (nothing after it found)."""
        out: List = []
        a = 0
        end = self.size if cut is None else cut
        for fa, fb in self.fills:
            if fa >= end:
                break
            out += self._infile_extents(a, fa)
            n = fb - fa
            out.append(("data", FILL_KEY + b"\x88" + (n - 25).to_bytes(8, "big")))
            out.append(("zero", n - 25))
            a = fb
        if a < end:
            out += self._infile_extents(a, end)
        return out

    def runs(self) -> List[List[int]]:
        """[first piece, cluster, pieces] of every stretch of pieces lying one after the other (for the
        status file: where the recording was found)."""
        out: List[List[int]] = []
        for k in sorted(self.pieces):
            c = self.pieces[k]
            if out and out[-1][0] + out[-1][2] == k and self.pieces[k - 1] + self.plen_cl(k - 1) == c:
                out[-1][2] += 1
            else:
                out.append([k, c, 1])
        return out

    # main --------------------------------------------------------------------------------------
    def run(self) -> Dict:
        read0 = self.reader()
        head = read0(0, 64)
        if not is_mxf_start(head):
            return self.result("failed", "A fájl eleje nem MXF a lemezen.")
        if self.K == 1:
            return self.result("complete", "Egy darabban.")
        self.cur_k = self.K - 1
        self.find_end()
        w = Walk(0)
        sizes: List[int] = []
        events: List[Tuple[str, int, int]] = []
        ok, w, _ = self.walk(read0, w, self.plen(0), pic_sizes=sizes, strict=True, events=events)
        if not ok:
            # the chain breaks inside the first piece: the copy program wrote smaller pieces, and the
            # first one ends between the last good packet and the broken one (or, when the frame count
            # jumps, between the last good frame and that one: another recording's data went on)
            if w.ccbreak and w.sys is not None:
                lo = max(1, w.sys + 1)
            else:
                last = w.last
                lo = max(1, (last[1] - 64) if last else 1)
            return self.result("partial", "Az első darab rövidebb %d MB-nál (a másolóprogram kisebb darabokban írt), "
                                          "vagy felülíródott." % (self.U >> 20), first_break=(lo, w.next), reached=lo)
        self._learn_pattern(events)
        self.ev = list(events)               # the frames of the last pieces walked (for the frame sizes)
        self.twin_prone = len(sizes) >= 5 and len(set(sizes)) == 1
        last_known = self.pieces.get(self.K - 1)
        k = 1
        cut = None
        while k < self.K:
            if self.progress:
                self.progress(k / float(self.K))
            first = None
            if k == self.K - 1 and last_known is not None:
                # the end found first only bounded the search; it is checked like any other
                # candidate (a camera with the same settings has an end that looks the same)
                self.pieces.pop(k, None)
                first = last_known
            got = self._search(k, w, first=first)
            if got is not None:
                i, c, w, _info = got
                self.found_by[k] = i
                self.pieces[k] = c
                self.claim(c, self.plen_cl(k))
                self._keep_events(_info)
                k += 1
                continue
            why = ", ".join("%s: %d" % kv for kv in sorted(self.why.items(), key=lambda x: -x[1])[:4])
            if self.mode != "final":
                if getattr(self, "debug", False):
                    self.log("  %s: %d MB-os darabokkal a %d. darab nincs meg (%d jelölt; %s)." % (
                        self.name, self.U >> 20, k + 1, self.tried, why or "nem volt szabad jelölt"))
                jumps = sum(1 for x in self.pieces if x > 0 and (x - 1) in self.pieces and x != self.K - 1 and
                            self.pieces[x] != self.pieces[x - 1] + self.plen_cl(x - 1))
                return self.result("partial", "A %d darabból a %d.-at nem találtam meg." % (self.K, k + 1),
                                   missing_from=k, found=len(self.pieces), why=self.why,
                                   reached=min(w.next, k * self.U), jumps=jumps)
            # final round: this piece is lost - fill its place, pick the chain up again after it
            self.log("  %s: a %d. darab (%d MB-tól) nincs meg a lemezen (%d jelölt; %s)%s." % (
                self.name, k + 1, (k * self.U) >> 20, self.tried, why or "nem volt szabad jelölt",
                "" if not self.deep_out else "; a mélykeresés ideje lejárt"))
            # the packet that runs into the lost piece is not whole: the fill starts with it
            fill_from = w.next
            if w.next > k * self.U and w.lastoff is not None:
                fill_from = w.lastoff
            lost = [k]
            picked = None
            nxt_k = k + 1
            if not self._resume_cbr_ok(w, nxt_k):
                # frames of different sizes: the first frame in one of the next pieces, found by its content
                for t in range(nxt_k, min(nxt_k + 3, self.K - 1)):
                    sc = self._scan_resync(t, w)
                    if sc is not None:
                        picked = (t, sc[0], sc[1])
                        lost += [x for x in range(nxt_k, t) if x not in lost]
                        break
            while picked is None and len(lost) <= 64:
                rs = self._resume(w, nxt_k)
                if rs is None:
                    break
                kk, w2 = rs
                for x in range(nxt_k, min(kk, self.K)):
                    if x not in lost:
                        lost.append(x)
                if kk >= self.K:
                    break
                first = last_known if (kk == self.K - 1 and last_known is not None) else None
                if first is not None:
                    self.pieces.pop(kk, None)
                self.anchor_part = w2.cc is None
                fb = self._frame_bytes()
                if self.anchor_part and w.cc is not None and w.sys is not None and fb:
                    # how many frames can lie between the last one seen and the partition
                    dist = w2.next - w.sys
                    self.cc_window = (w.cc, max(1, int(dist / (fb[1] * 1.15 + 65536))),
                                      int(dist / max(1.0, fb[0] * 0.85)) + 1)
                try:
                    got = self._search(kk, w2, first=first)
                finally:
                    self.anchor_part = False
                    self.cc_window = None
                if got is not None:
                    picked = (kk, got, w2.next)
                    break
                lost.append(kk)
                nxt_k = kk + 1
            if picked is None:
                cut = fill_from
                self.missing += [x for x in range(k, self.K) if x not in self.pieces]
                for x in list(self.pieces):
                    if x >= k:
                        del self.pieces[x]
                self.log("  %s: a %d. darab után nem találtam meg a folytatást – csak az eleje jön vissza (%.0f%%)." % (
                    self.name, k, 100.0 * cut / self.size))
                break
            kk, (i, c, w, _info), resume_at = picked
            self.ev = []                         # frame numbers on the far side are counted on, not walked
            self._keep_events(_info)
            self.missing += sorted(lost)
            self.fills.append((fill_from, resume_at))
            self.found_by[kk] = i
            self.pieces[kk] = c
            self.claim(c, self.plen_cl(kk))
            self.log("  %s: a lánc a %d. darabban folytatódik; a kiesett rész %.1f MB." % (
                self.name, kk + 1, (resume_at - fill_from) / 1048576.0))
            k = kk + 1
        if cut is None and w.next != self.size:
            return self.result("partial", "A csomagok lánca nem a fájl végén ér véget.")
        msg_dec = ""
        if self.decided:
            msg_dec = " Hasonló felvétel darabjai közül %s döntött." % ", ".join(
                "%d helyen %s" % (v, {"time code": "az időkód", "picture": "a kép"}[k_]) for k_, v in self.decided.items())
        if self.uncertain:
            msg_dec += " %d darabnál nem lehetett biztosan dönteni két hasonló felvétel között." % len(self.uncertain)
        if self.fills or cut is not None:
            lost_b = sum(b - a for a, b in self.fills) + ((self.size - cut) if cut is not None else 0)
            where = ", ".join("%.0f%%" % (100.0 * a / self.size) for a, _b in self.fills[:8])
            if cut is not None:
                msg = ("A felvétel elejéből %.1f GB (%.0f%%) jött vissza; a folytatását nem találtam a lemezen." % (
                    cut / 1e9, 100.0 * cut / self.size))
                if self.fills:
                    msg += " Előtte %d helyen kiesett egy-egy darab (%s)." % (len(self.fills), where)
            else:
                msg = ("%d darabból %d nem volt meg a lemezen (%.0f MB, a felvétel %s táján); a helyükön üres "
                       "kitöltés van, a többi rész ép." % (self.K, len(self.missing), lost_b / 1048576.0, where))
            r = self.result("gaps", msg + msg_dec, missing=self.missing[:200], lost=lost_b,
                            fills=self.fills[:200], cut=cut, packets=w.n, u_evidence=True)
            r["extents"] = self.gap_extents(cut)
            r["runs"] = self.runs()[:400]
            return r
        msg = "Teljes: %d darab, %d csomag végigellenőrizve." % (self.K, w.n) + msg_dec
        r = self.result("complete", msg, packets=w.n, partitions=len(self.rip), uncertain=len(self.uncertain),
                        uncertain_pieces=self.uncertain[:50])
        r["runs"] = self.runs()[:400]
        return r
