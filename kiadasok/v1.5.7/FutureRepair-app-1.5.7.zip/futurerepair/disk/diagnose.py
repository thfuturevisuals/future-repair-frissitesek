"""Quick survey of a formatted disk: what is left of the old file system and how files were laid out.

Reads (never writes) about 20-25 GB: the start of the disk, the FAT area, the start of the data
area and samples spread over the whole disk. Answers the questions the rebuild depends on:
- Are the old folders still there (file names, sizes, first clusters)?
- What was the old cluster size and where was the old data area (heap)?
- Are the old allocation chains (FAT) still there?
- Which files were stored in one piece and where do the fragmented ones break?
"""
from __future__ import annotations

import json
import os
import time
from collections import Counter
from typing import Dict, List, Tuple

from . import oldfs
from .survey import residue_stats, scan_regions, _starts_in

SIZES = [1 << k for k in range(12, 26)]          # 4 KB ... 32 MB
ENTRIES_FILE = "futurerepair_lemez_bejegyzesek.json"


def _mb(x: float) -> str:
    if x >= 1 << 30:
        return "%.1f GB" % (x / float(1 << 30))
    if x >= 1 << 20:
        return "%d MB" % (x >> 20)
    return "%d KB" % (x >> 10)


def run_survey(rec, src, region: Tuple[int, int]) -> Dict:
    a, b = region
    st = rec.status.setdefault("survey", {})
    now = rec.status.get("filesystem_now") or {}
    cancel = rec.cancel
    t0 = time.time()

    # 1) boot sectors of earlier file systems -------------------------------------------
    rec.phase("Korábbi fájlrendszerek nyomai a lemez elején", 0.0)
    head_end = min(src.size, a + (2 << 30))
    boots = oldfs.scan_boot_sectors(src, 0, head_end, cancel=cancel,
                                    progress=lambda x: rec.set_progress(0.08 * x))
    boots += oldfs.scan_boot_sectors(src, max(head_end, src.size - (64 << 20)), src.size, cancel=cancel)
    cur = {a, a + 12 * 512}
    old_boots = [d for d in boots if d["type"] != "GPT" and d["pos"] not in cur]
    gpts = [d["pos"] for d in boots if d["type"] == "GPT"]
    st["boot_sectors"] = old_boots
    st["gpt_headers"] = gpts
    if old_boots:
        for d in old_boots[:12]:
            extra = ""
            if d["type"] == "exFAT":
                extra = ", klaszter %s, adatterület %d, FAT %d (%s), %d klaszter, sorozatszám %s" % (
                    _mb(d["cluster"]), d["heap"], d["fat"], _mb(d["fat_len"]), d["clusters"], d["serial"])
            elif "cluster" in d:
                extra = ", blokk %s" % _mb(d["cluster"])
            rec.log("Régi rendszerindító szektor: %s a %d. bájtnál%s" % (d["type"], d["pos"], extra))
    else:
        rec.log("A lemez elején nincs régebbi fájlrendszer rendszerindító szektora (csak a mostani).")

    # 2) what the current FAT area holds -------------------------------------------------
    fat_info = None
    if now.get("type") == "exFAT" and now.get("fat"):
        rec.phase("A FAT-terület vizsgálata", 0.08)
        fat_info = oldfs.fat_stats(src, now["fat"], now["clusters"], cancel=cancel,
                                   progress=lambda x: rec.set_progress(0.08 + 0.04 * x))
        st["fat_now"] = fat_info
        rec.log("A mostani FAT-terület: %d bejegyzésből %d nem nulla (lánc vége %d, mintában: %d hivatkozás, "
                "ebből %d a következő klaszterre)." % (fat_info["entries"], fat_info["nonzero"], fat_info["eoc"],
                                                       fat_info["sample_link"], fat_info["sample_next"]))

    # 3) read the start of the data area and samples over the whole disk ------------------
    regions = []
    heap_now = now.get("heap") or a
    regions.append((heap_now, min(b, heap_now + (8 << 30))))
    win = 256 << 20
    nsamp = 48
    for i in range(nsamp):
        s = a + ((b - a) * (2 * i + 1)) // (2 * nsamp)
        s -= s % (1 << 20)
        if s < regions[0][1]:
            continue
        regions.append((s, min(b, s + win)))
    kinds: Dict[int, str] = {}
    hits: List[int] = []
    entries: List[Dict] = []
    mft = [0]
    mft_pos: List[int] = []

    def visit(buf, base, n):
        hits.extend(_starts_in(buf, base, 512, kinds, limit=n))
        if len(entries) < 300000:
            entries.extend(oldfs.find_entry_sets(buf, base, limit=n))
        j = buf.find(b"FILE0\x00\x03\x00")
        while j != -1 and j < n:
            if (base + j) % 1024 == 0:
                mft[0] += 1
                if len(mft_pos) < 20:
                    mft_pos.append(base + j)
            j = buf.find(b"FILE0\x00\x03\x00", j + 1)
    total = sum(e - s for s, e in regions)
    rec.phase("Minták olvasása: az adatterület eleje és %d pont a lemezen (%s)" % (len(regions) - 1, _mb(total)),
              0.12)
    scan_regions(src, regions, visit, progress=lambda x: rec.set_progress(0.12 + 0.6 * x), cancel=cancel)
    hits = sorted(set(hits))
    kc = Counter(kinds.get(p, "?") for p in hits)
    st["file_starts"] = dict(kc)
    st["regions"] = [[s, e] for s, e in regions]
    rec.log("Átolvasva %s %.0f perc alatt. Fájlkezdetek: %d (%s)." % (
        _mb(total), (time.time() - t0) / 60, len(hits), ", ".join("%s %d" % kv for kv in kc.most_common())))
    if mft[0]:
        rec.log("Régi NTFS fájlrekordok (MFT): %d db, pl. a %s. bájtnál." % (mft[0], ", ".join(map(str, mft_pos[:3]))))
    st["ntfs_records"] = {"count": mft[0], "pos": mft_pos}

    mp4 = [p for p in hits if kinds.get(p) == "mp4"]
    for label, hs in (("videó", mp4), ("összes", hits)):
        rs = residue_stats(hs, SIZES)
        st["align_" + ("mp4" if label == "videó" else "all")] = rs
        if hs:
            rec.log("Fájlkezdetek igazodása (%s, %d db): %s" % (label, len(hs), ", ".join(
                "%s %d%%" % (_mb(B), round(100.0 * n / max(1, t))) for B, _r, n, t in rs if B >= 64 << 10)))

    # 4) old directory entries -------------------------------------------------------------
    uniq = {}
    for e in entries:
        uniq.setdefault(e["pos"], e)
    entries = sorted(uniq.values(), key=lambda e: e["pos"])
    live = [e for e in entries if not e["deleted"]]
    vids = [e for e in live if oldfs.is_video(e)]
    dirs = [e for e in live if e["dir"]]
    st["entries"] = {"total": len(entries), "deleted": len(entries) - len(live), "dirs": len(dirs),
                     "videos": len(vids), "video_contiguous": sum(1 for e in vids if e["contig"]),
                     "video_bytes": sum(e["size"] for e in vids)}
    rec.log("Régi exFAT mappabejegyzések: %d (törölt %d), mappa %d, videó %d (%s), ebből egy darabban tárolt "
            "(NoFatChain) %d." % (len(entries), len(entries) - len(live), len(dirs), len(vids),
                                   _mb(sum(e["size"] for e in vids)), st["entries"]["video_contiguous"]))
    for e in vids[:6]:
        rec.log("  pl. %s – %s, első klaszter %d, %s, %s" % (e["name"], _mb(e["size"]), e["first"],
                                                            "egy darabban" if e["contig"] else "láncolt",
                                                            e.get("mtime") or ""))

    # 5) where was the old data area? ------------------------------------------------------
    layout = None
    if entries:
        rec.phase("A régi adatterület helyének megkeresése", 0.75)
        hyps: Dict[Tuple[int, int], str] = {}
        for d in old_boots:
            if d["type"] == "exFAT":
                hyps[(d["cluster"], d["heap"])] = "régi rendszerindító szektor"
        if now.get("cluster") and now.get("heap"):
            hyps.setdefault((now["cluster"], now["heap"]), "a mostani beosztás")
        votes = oldfs.layout_votes(entries, mp4, oldfs.run_starts(entries), (a, b), SIZES)
        for (G, H), v in votes.most_common(25):
            if v >= 2:
                hyps.setdefault((G, H), "%d egyezés" % v)
        checks = []
        for i, ((G, H), why) in enumerate(hyps.items()):
            if cancel and cancel():
                raise InterruptedError
            r = oldfs.check_layout(src, entries, G, H, b, per_kind=10)
            r["why"] = why
            checks.append(r)
            rec.set_progress(0.75 + 0.1 * (i + 1) / max(1, len(hyps)))
        checks.sort(key=lambda r: (r["ok"], r["ok"] / float(max(1, r["n"]))), reverse=True)
        st["layout_checks"] = checks[:10]
        best = checks[0] if checks else None
        if best and best["ok"] >= 3 and best["ok"] >= 0.6 * best["n"]:
            layout = best
            rec.log("A régi fájlrendszer: klaszter %s, adatterület kezdete %d (%s) – ellenőrizve: %d/%d "
                    "(videó %d/%d, mappa %d/%d)." % (_mb(best["G"]), best["H"], best["why"], best["ok"], best["n"],
                                                     best["video_ok"], best["video_n"], best["dir_ok"], best["dir_n"]))
        else:
            rec.log("A régi adatterület helyét nem sikerült biztosan megállapítani (legjobb: %s)." % (
                "%s/%d" % (best["ok"], best["n"]) if best else "-"))
    st["layout"] = layout

    # 6) old allocation chains, first breaks ---------------------------------------------
    if layout:
        G, H = layout["G"], layout["H"]
        oldfs.build_paths(entries, G, H)
        fat_pos = None
        count = None
        for d in old_boots:
            if d["type"] == "exFAT" and d["cluster"] == G and d["heap"] == H:
                fat_pos, count = d["fat"], d["clusters"]
        if fat_pos is None and now.get("cluster") == G and now.get("heap") == H:
            fat_pos, count = now["fat"], now["clusters"]
        frag = [e for e in vids if not e["contig"] and e["first"] >= 2 and e["size"] > G]
        if fat_pos is not None and frag:
            rec.phase("A régi FAT-láncok ellenőrzése", 0.86)
            fr = oldfs.FatReader(src, fat_pos, count)
            res = []
            for e in frag[:12]:
                r = oldfs.follow_chain(fr, e["first"], e["size"], G, max_steps=2_000_000)
                r["name"] = e["name"]
                res.append(r)
            st["chains"] = res
            good = sum(1 for r in res if r.get("ok"))
            rec.log("Régi FAT-láncok: %d láncolt videóból %d ép lánc (első lépésnél nulla: %d)." % (
                len(res), good, sum(1 for r in res if r.get("steps") == 1 and r.get("value") == 0)))
        refs = list(rec.job.get("references") or [])
        prof = rec._profile(refs[0]) if refs else None
        if prof is not None and frag:
            rec.phase("Hol szakadnak meg a láncolt videók?", 0.9)
            st["first_breaks"] = first_breaks(src, frag[:6], G, H, prof, rec.log)
        # disk positions for the list
        for e in entries:
            if e["first"] >= 2:
                e["disk_pos"] = H + (e["first"] - 2) * G
    # 7) save the entries -----------------------------------------------------------------
    try:
        path = os.path.join(rec.out, ENTRIES_FILE)
        with open(path + ".part", "w", encoding="utf-8") as f:
            json.dump({"layout": layout, "entries": entries}, f, ensure_ascii=False)
        os.replace(path + ".part", path)
        rec.log("A talált bejegyzések listája: %s" % path)
    except OSError as e:
        rec.log("A bejegyzéslistát nem sikerült menteni: %s" % e)
    rec.log("Felmérés kész (%.0f perc)." % ((time.time() - t0) / 60))
    return st


def first_breaks(src, files: List[Dict], G: int, H: int, prof, log) -> List[Dict]:
    """Where the recording stops continuing when the file's clusters are read in a row."""
    from ..video.fragments import BlockView
    from ..video.scanner import Scanner
    from .reassemble import parse_header
    out = []
    for e in files:
        P = H + (e["first"] - 2) * G
        n = min(e["size"], 192 << 20)
        view = BlockView(src, [(P, P + n)])
        hdr = parse_header(view, n)
        r = {"name": e["name"], "pos": P}
        if "mdat_start" not in hdr:
            r["why"] = "nincs mdat a fejlécben"
            out.append(r)
            continue
        sc = Scanner(view, hdr["mdat_start"], n, prof.models, prof.transitions, stop_on_fail=True)
        try:
            sc.run()
        except Exception as ex:  # noqa: BLE001
            r["why"] = str(ex)
            out.append(r)
            continue
        r["fail_at"] = sc.fail_at
        if sc.fail_at is not None:
            f = sc.fail_at
            r["cluster_index"] = f // G
            r["mod_32mb"] = f % (32 << 20)
            log("  %s: egyben olvasva a %s-nál szakad meg (a %d. klaszterben)." % (e["name"], _mb(f), f // G))
        else:
            log("  %s: az első %s egyben folytonos." % (e["name"], _mb(n)))
        out.append(r)
    return out
