"""Tiny grey thumbnails of single video frames, to tell which of two look-alike pieces continues a
recording (two cameras with the same settings write pieces that only differ in the picture)."""
from __future__ import annotations

from typing import Optional

W, H = 32, 18


def codec_of_frame(data: bytes) -> Optional[str]:
    """Codec name (FFmpeg) of a single frame by its first bytes, for frames stored on their own."""
    if data[:4] == b"\x00\x00\x00\x01" or data[:3] == b"\x00\x00\x01":
        i = 4 if data[:4] == b"\x00\x00\x00\x01" else 3
        if i < len(data):
            b = data[i]
            if b == 0xB3 or b == 0x00:
                return "mpeg2video"
            if (b & 0x1F) in (1, 5, 6, 7, 8, 9):
                return "h264"
            if ((b >> 1) & 0x3F) in (32, 33, 34, 35, 39, 19, 20, 1):
                return "hevc"
        return "h264"
    if data[4:8] == b"icpf":
        return "prores"
    if data[:4] == b"\x00\x00\x02\x80" or data[:4] == b"\x00\x00\x02\x82":
        return "dnxhd"
    if data[:2] == b"\xff\xd8":
        return "mjpeg"
    if data[:4] == b"\xff\x4f\xff\x51":
        return "jpeg2000"
    return None


def thumb(data: bytes, codec: Optional[str] = None, extradata: Optional[bytes] = None) -> Optional[bytes]:
    """W x H grey pixels of the frame, or None if it cannot be decoded on its own."""
    try:
        import av
    except Exception:  # noqa: BLE001
        return None
    codec = codec or codec_of_frame(data)
    if not codec:
        return None
    try:
        ctx = av.CodecContext.create(codec, "r")
        if extradata:
            ctx.extradata = extradata
        frames = list(ctx.decode(av.Packet(data)))
        try:
            frames += list(ctx.decode(None))
        except Exception:  # noqa: BLE001
            pass
        if not frames:
            return None
        fr = frames[0].reformat(width=W, height=H, format="gray")
        pl = fr.planes[0]
        raw = bytes(pl)
        ls = pl.line_size
        return b"".join(raw[y * ls:y * ls + W] for y in range(H))
    except Exception:  # noqa: BLE001
        return None


def mad(a: bytes, b: bytes) -> float:
    return sum(abs(x - y) for x, y in zip(a, b)) / float(max(1, len(a)))
