"""Read-only random access to whole disks and disk images.

Windows:  \\\\.\\PhysicalDriveN   (needs administrator rights)
macOS:    /dev/rdiskN            (needs root)
Linux:    /dev/sdX
Any other path is treated as an image file.

Nothing in this module ever writes: devices are opened with read access only.
Reads are done in aligned pages (raw devices only accept sector-aligned I/O) through a small
LRU cache, and the object can be sliced like `bytes`, so the video scanner works on it directly.
"""
from __future__ import annotations

import os
import plistlib
import re
import subprocess
import sys
from collections import OrderedDict
from typing import Dict, List, Optional

PAGE = 1 << 20


# ---------------------------------------------------------------------------
# Backends
# ---------------------------------------------------------------------------

class _FileBackend:
    def __init__(self, path: str):
        self.fd = os.open(path, os.O_RDONLY | getattr(os, "O_BINARY", 0))
        st = os.fstat(self.fd)
        size = st.st_size
        if size == 0:
            size = _posix_device_size(self.fd)
        self.size = size

    def read_at(self, off: int, n: int) -> bytes:
        if hasattr(os, "pread"):
            return os.pread(self.fd, n, off)
        os.lseek(self.fd, off, os.SEEK_SET)
        return os.read(self.fd, n)

    def close(self) -> None:
        try:
            os.close(self.fd)
        except OSError:
            pass


def _posix_device_size(fd: int) -> int:
    import fcntl
    import struct
    try:
        if sys.platform == "darwin":
            DKIOCGETBLOCKSIZE = 0x40046418
            DKIOCGETBLOCKCOUNT = 0x40086419
            bs = struct.unpack("I", fcntl.ioctl(fd, DKIOCGETBLOCKSIZE, b"\0" * 4))[0]
            bc = struct.unpack("Q", fcntl.ioctl(fd, DKIOCGETBLOCKCOUNT, b"\0" * 8))[0]
            return bs * bc
        BLKGETSIZE64 = 0x80081272
        return struct.unpack("Q", fcntl.ioctl(fd, BLKGETSIZE64, b"\0" * 8))[0]
    except OSError:
        pos = os.lseek(fd, 0, os.SEEK_END)
        return pos


class _WinDiskBackend:
    """\\\\.\\PhysicalDriveN through the Win32 API (read access only)."""

    GENERIC_READ = 0x80000000
    FILE_SHARE_READ = 1
    FILE_SHARE_WRITE = 2
    OPEN_EXISTING = 3
    IOCTL_DISK_GET_LENGTH_INFO = 0x0007405C

    def __init__(self, path: str):
        import ctypes
        from ctypes import wintypes
        self.ct = ctypes
        k = ctypes.WinDLL("kernel32", use_last_error=True)
        k.CreateFileW.restype = wintypes.HANDLE
        k.CreateFileW.argtypes = [wintypes.LPCWSTR, wintypes.DWORD, wintypes.DWORD, ctypes.c_void_p,
                                  wintypes.DWORD, wintypes.DWORD, wintypes.HANDLE]
        k.DeviceIoControl.restype = wintypes.BOOL
        k.DeviceIoControl.argtypes = [wintypes.HANDLE, wintypes.DWORD, ctypes.c_void_p, wintypes.DWORD,
                                      ctypes.c_void_p, wintypes.DWORD, ctypes.POINTER(wintypes.DWORD),
                                      ctypes.c_void_p]
        k.SetFilePointerEx.restype = wintypes.BOOL
        k.SetFilePointerEx.argtypes = [wintypes.HANDLE, ctypes.c_longlong, ctypes.c_void_p, wintypes.DWORD]
        k.ReadFile.restype = wintypes.BOOL
        k.ReadFile.argtypes = [wintypes.HANDLE, ctypes.c_void_p, wintypes.DWORD,
                               ctypes.POINTER(wintypes.DWORD), ctypes.c_void_p]

        class OVERLAPPED(ctypes.Structure):
            _fields_ = [("Internal", ctypes.c_void_p), ("InternalHigh", ctypes.c_void_p),
                        ("Offset", wintypes.DWORD), ("OffsetHigh", wintypes.DWORD), ("hEvent", wintypes.HANDLE)]
        self.OVERLAPPED = OVERLAPPED
        k.CloseHandle.argtypes = [wintypes.HANDLE]
        k.VirtualAlloc.restype = ctypes.c_void_p
        k.VirtualAlloc.argtypes = [ctypes.c_void_p, ctypes.c_size_t, wintypes.DWORD, wintypes.DWORD]
        self.k = k
        h = k.CreateFileW(path, self.GENERIC_READ, self.FILE_SHARE_READ | self.FILE_SHARE_WRITE, None,
                          self.OPEN_EXISTING, 0, None)
        if h is None or h == ctypes.c_void_p(-1).value:
            err = ctypes.get_last_error()
            if err == 5:
                raise PermissionError("A lemez olvasásához rendszergazdai jog kell (%s)." % path)
            raise OSError(err, "Nem nyitható meg: %s (Windows hiba %d)" % (path, err))
        self.h = h
        length = ctypes.c_longlong(0)
        ret = wintypes.DWORD(0)
        if k.DeviceIoControl(h, self.IOCTL_DISK_GET_LENGTH_INFO, None, 0, ctypes.byref(length),
                             ctypes.sizeof(length), ctypes.byref(ret), None):
            self.size = length.value
        else:
            import struct as _st
            geo = ctypes.create_string_buffer(256)
            if not k.DeviceIoControl(h, 0x000700A0, None, 0, geo, 256, ctypes.byref(ret), None):  # GEOMETRY_EX
                err = ctypes.get_last_error()
                k.CloseHandle(h)
                raise OSError(err, "A lemez mérete nem kérdezhető le: %s" % path)
            self.size = _st.unpack_from("<q", geo.raw, 24)[0]
        self.bufsize = PAGE
        self.buf = k.VirtualAlloc(None, self.bufsize, 0x3000, 0x04)   # MEM_COMMIT|MEM_RESERVE, PAGE_READWRITE

    def read_at(self, off: int, n: int) -> bytes:
        ct = self.ct
        out = bytearray()
        while n > 0:
            chunk = min(n, self.bufsize)
            ov = self.OVERLAPPED()
            ov.Offset = off & 0xFFFFFFFF            # positioned read: the offset travels with the request
            ov.OffsetHigh = off >> 32
            got = ct.c_ulong(0)
            if not self.k.ReadFile(self.h, self.buf, chunk, ct.byref(got), ct.byref(ov)):
                raise OSError(ct.get_last_error(), "Olvasási hiba a lemezen (%d. bájtnál)" % off)
            if got.value == 0:
                break
            out += ct.string_at(self.buf, got.value)
            off += got.value
            n -= got.value
            if got.value < chunk:
                break
        return bytes(out)

    def close(self) -> None:
        try:
            self.k.CloseHandle(self.h)
        except Exception:  # noqa: BLE001
            pass


def is_device_path(path: str) -> bool:
    p = path.replace("/", "\\").lower()
    return p.startswith("\\\\.\\physicaldrive") or path.startswith("/dev/")


# ---------------------------------------------------------------------------
# Cached, sliceable source
# ---------------------------------------------------------------------------

class RawSource:
    """A disk or image that can be sliced like bytes (read-only)."""

    def __init__(self, path: str, page: int = PAGE, cache_pages: int = 256):
        self.path = path
        if sys.platform.startswith("win") and is_device_path(path):
            self.b = _WinDiskBackend(path)
        else:
            self.b = _FileBackend(path)
        self.size = self.b.size
        self.page = page
        self.cache_pages = cache_pages
        self._cache: "OrderedDict[int, bytes]" = OrderedDict()
        self.bytes_read = 0
        self.reads = 0

    def __len__(self) -> int:
        return self.size

    def close(self) -> None:
        self.b.close()

    def _page(self, k: int) -> bytes:
        c = self._cache.get(k)
        if c is not None:
            self._cache.move_to_end(k)
            return c
        off = k * self.page
        n = min(self.page, self.size - off)
        if n <= 0:
            return b""
        data = self.b.read_at(off, n)
        self.bytes_read += len(data)
        self.reads += 1
        self._cache[k] = data
        if len(self._cache) > self.cache_pages:
            self._cache.popitem(last=False)
        return data

    def read(self, off: int, n: int) -> bytes:
        if off < 0:
            off = 0
        end = min(self.size, off + n)
        if end <= off:
            return b""
        k0 = off // self.page
        k1 = (end - 1) // self.page
        if k0 == k1:
            p = self._page(k0)
            return p[off - k0 * self.page:end - k0 * self.page]
        parts = []
        for k in range(k0, k1 + 1):
            p = self._page(k)
            a = max(off, k * self.page) - k * self.page
            b = min(end, (k + 1) * self.page) - k * self.page
            parts.append(p[a:b])
        return b"".join(parts)

    def read_direct(self, off: int, n: int, align: int = 4096) -> bytes:
        """Read that bypasses the cache (aligned to the sector size)."""
        a = (off // align) * align
        e = min(self.size, -(-(off + n) // align) * align)
        data = self.b.read_at(a, e - a)
        self.bytes_read += len(data)
        self.reads += 1
        return data[off - a:off - a + n]

    def __getitem__(self, key):
        if isinstance(key, slice):
            start, stop, step = key.indices(self.size)
            if step != 1:
                raise ValueError("step not supported")
            return self.read(start, stop - start)
        if key < 0:
            key += self.size
        if key < 0 or key >= self.size:
            raise IndexError("RawSource index out of range")
        k = key // self.page
        return self._page(k)[key - k * self.page]

    # searching helpers (used by the video models)
    def _windows(self, start: int, end: int, overlap: int):
        step = 8 << 20
        pos = start
        while pos < end:
            w_end = min(end, pos + step)
            yield pos, self.read(pos, min(self.size, w_end + overlap) - pos)
            pos = w_end

    def find(self, sub: bytes, start: int = 0, end: Optional[int] = None) -> int:
        end = self.size if end is None else min(end, self.size)
        for off, buf in self._windows(start, end, len(sub)):
            i = buf.find(sub)
            if i != -1 and off + i + len(sub) <= end:
                return off + i
        return -1

    def finditer(self, regex, start: int, end: int):
        end = min(end, self.size)
        seen = start - 1
        for off, buf in self._windows(start, end, 64):
            for m in regex.finditer(buf):
                p = off + m.start()
                if p >= end:
                    break
                if p <= seen:
                    continue
                seen = p
                yield p


# ---------------------------------------------------------------------------
# Listing disks (no administrator rights needed)
# ---------------------------------------------------------------------------

def list_disks() -> List[Dict]:
    if sys.platform.startswith("win"):
        return _list_windows()
    if sys.platform == "darwin":
        return _list_mac()
    return _list_linux()


def _list_windows() -> List[Dict]:
    import ctypes
    import struct
    from ctypes import wintypes
    k = ctypes.WinDLL("kernel32", use_last_error=True)
    k.CreateFileW.restype = wintypes.HANDLE
    k.CreateFileW.argtypes = [wintypes.LPCWSTR, wintypes.DWORD, wintypes.DWORD, ctypes.c_void_p,
                              wintypes.DWORD, wintypes.DWORD, wintypes.HANDLE]
    k.DeviceIoControl.restype = wintypes.BOOL
    k.DeviceIoControl.argtypes = [wintypes.HANDLE, wintypes.DWORD, ctypes.c_void_p, wintypes.DWORD,
                                  ctypes.c_void_p, wintypes.DWORD, ctypes.POINTER(wintypes.DWORD),
                                  ctypes.c_void_p]
    k.CloseHandle.argtypes = [wintypes.HANDLE]
    IOCTL_DISK_GET_DRIVE_GEOMETRY_EX = 0x000700A0
    IOCTL_STORAGE_QUERY_PROPERTY = 0x002D1400
    BUS = {1: "SCSI", 2: "ATAPI", 3: "ATA", 4: "1394", 5: "SSA", 6: "Fibre", 7: "USB", 8: "RAID",
           9: "iSCSI", 10: "SAS", 11: "SATA", 12: "SD", 13: "MMC", 17: "NVMe"}
    out = []
    invalid = ctypes.c_void_p(-1).value
    for i in range(64):
        path = "\\\\.\\PhysicalDrive%d" % i
        h = k.CreateFileW(path, 0, 3, None, 3, 0, None)       # no access rights: query only
        if h is None or h == invalid:
            continue
        try:
            buf = ctypes.create_string_buffer(1024)
            ret = wintypes.DWORD(0)
            size = 0
            if k.DeviceIoControl(h, IOCTL_DISK_GET_DRIVE_GEOMETRY_EX, None, 0, buf, 1024, ctypes.byref(ret), None):
                size = struct.unpack_from("<q", buf.raw, 24)[0]
            query = struct.pack("<II", 0, 0) + b"\0" * 4          # StorageDeviceProperty, PropertyStandardQuery
            qbuf = ctypes.create_string_buffer(query, len(query))
            if k.DeviceIoControl(h, IOCTL_STORAGE_QUERY_PROPERTY, qbuf, len(query), buf, 1024, ctypes.byref(ret), None):
                raw = buf.raw[:ret.value]
                vend_off, prod_off = struct.unpack_from("<II", raw, 12)
                ser_off = struct.unpack_from("<I", raw, 24)[0] if len(raw) >= 28 else 0
                bus = struct.unpack_from("<I", raw, 28)[0] if len(raw) >= 32 else 0

                def cstr(o):
                    if not o or o >= len(raw):
                        return ""
                    end = raw.find(b"\0", o)
                    return raw[o:end if end >= 0 else len(raw)].decode("latin-1", "replace").strip()
                model = (cstr(vend_off) + " " + cstr(prod_off)).strip()
                serial = cstr(ser_off)
            else:
                model, bus, serial = "", 0, ""
            out.append({"path": path, "number": i, "size": size, "model": model, "bus": BUS.get(bus, str(bus)),
                        "serial": serial})
        finally:
            k.CloseHandle(h)
    return out


def _list_mac() -> List[Dict]:
    out = []
    try:
        raw = subprocess.run(["diskutil", "list", "-plist", "physical"], capture_output=True, timeout=30).stdout
        disks = plistlib.loads(raw).get("WholeDisks", [])
    except Exception:  # noqa: BLE001
        return out
    for d in disks:
        info = {}
        try:
            info = plistlib.loads(subprocess.run(["diskutil", "info", "-plist", d], capture_output=True,
                                                 timeout=30).stdout)
        except Exception:  # noqa: BLE001
            pass
        out.append({"path": "/dev/r" + d, "number": int(re.sub(r"\D", "", d) or 0), "size": info.get("TotalSize", 0),
                    "model": info.get("MediaName", ""), "bus": info.get("BusProtocol", "")})
    return out


def _list_linux() -> List[Dict]:
    out = []
    base = "/sys/block"
    if not os.path.isdir(base):
        return out
    for name in sorted(os.listdir(base)):
        if name.startswith(("loop", "ram", "zram", "dm-")):
            continue
        try:
            size = int(open(os.path.join(base, name, "size")).read()) * 512
        except OSError:
            continue
        model = ""
        try:
            model = open(os.path.join(base, name, "device", "model")).read().strip()
        except OSError:
            pass
        out.append({"path": "/dev/" + name, "number": len(out), "size": size, "model": model, "bus": ""})
    return out
