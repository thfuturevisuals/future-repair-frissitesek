"""Restoring files listed by the old folder entries that a survey found.

job = {"device", "output", "entries_file" (or the survey's JSON among "sources"),
       "only": names to restore (empty: every video), "piece": write size (default 32 MB)}
- files stored in one piece (and small ones) are copied straight from their clusters;
- fragmented recordings are put back together with their own index (moovchain);
- every restored video is checked frame by frame (structure) and by decoding a few points.
"""
from __future__ import annotations

import json
import os
import re
import shutil
import time
from typing import Dict, List, Optional, Tuple

from . import oldfs
from .moovchain import MoovRebuild, NAL_CODECS, nal_len_size, _walk_nal


def _safe(part: str) -> str:
    part = re.sub(r'[<>:"/\\|?*\x00-\x1f]', "_", part).rstrip(" .")
    return part or "_"


def check_all_samples(path: str) -> Dict:
    """Walk the NAL units of every video frame the file's index lists (finds foreign data anywhere)."""
    from ..video.analyze import read_layout
    lay = read_layout(path)
    if lay.moov is None:
        return {"ok": False, "why": "nincs index"}
    total = bad = 0
    first_bad = None
    import mmap
    with open(path, "rb") as f:
        mm = mmap.mmap(f.fileno(), 0, access=mmap.ACCESS_READ)
        try:
            for t in lay.moov.tracks:
                if not t.is_video or t.codec not in NAL_CODECS:
                    continue
                nls = nal_len_size(t)
                for i, (off, sz) in enumerate(zip(t.offsets, t.sizes)):
                    total += 1
                    if not _walk_nal(mm, off, sz, nls):
                        bad += 1
                        if first_bad is None:
                            first_bad = (i, off)
        finally:
            mm.close()
    if total == 0:
        return {"ok": None, "frames": 0, "why": "a videó kódolása miatt képkockánként nem ellenőrizhető"}
    return {"ok": bad == 0, "frames": total, "bad": bad, "first_bad": first_bad}


def check_mxf_file(path: str) -> Dict:
    """Walk the whole KLV chain of an MXF file: it must run from the start exactly to the end."""
    from .mxfchain import klv_header
    size = os.path.getsize(path)
    n = 0
    off = 0
    with open(path, "rb") as f:
        while off < size:
            f.seek(off)
            r = klv_header(f.read(32), 0)
            if r is None:
                return {"ok": False, "packets": n, "bad_at": off}
            off += r[1] + r[2]
            n += 1
    return {"ok": off == size, "packets": n}


def _decode_ok(path: str) -> Dict:
    try:
        from ..video.verify import deep_verify
        d = deep_verify(path, points=5, frames_per_point=3)
        return {"ok": bool(d.get("ok")), "duration": d.get("duration")}
    except Exception as e:  # noqa: BLE001
        return {"ok": None, "why": str(e)}


def _verify(path: str, kind: str) -> Dict:
    out: Dict = {"kind": kind}
    if kind == "mp4":
        try:
            out["frames"] = check_all_samples(path)
        except Exception as e:  # noqa: BLE001
            out["frames"] = {"ok": False, "why": str(e)}
        out["decode"] = _decode_ok(path)
        fr, dec = out["frames"].get("ok"), out["decode"].get("ok")
        out["ok"] = (fr is not False) and (dec is not False) and (fr or dec) is True
    elif kind == "mxf":
        out["chain"] = check_mxf_file(path)
        out["decode"] = _decode_ok(path)
        out["ok"] = bool(out["chain"].get("ok")) and out["decode"].get("ok") is not False
    else:
        out["ok"] = True
    return out


def _sniff(head: bytes) -> str:
    from .mxfchain import is_mxf_start
    from .survey import F_MP4, head_flags
    if head_flags(head[:64]) & F_MP4 or head[4:8] in (b"ftyp", b"wide", b"free", b"skip", b"mdat", b"moov",
                                                       b"pnot", b"uuid"):
        return "mp4"
    if is_mxf_start(head):
        return "mxf"
    if head[:4] in (b"RIFF", b"RF64", b"BW64") and head[8:12] == b"WAVE":
        return "wav"
    return "other"


def _message(kind: str, v: Dict, how: str) -> Tuple[str, str]:
    if kind == "mp4":
        fr = v.get("frames") or {}
        if v.get("ok"):
            if fr.get("ok"):
                return "complete", "Kész, minden képkocka szerkezete ép (%d), lejátszható." % fr.get("frames", 0)
            return "complete", "Kész, lejátszható (a kódolás miatt képkockánként nem ellenőrizhető)."
        if fr.get("ok") is False and fr.get("why") == "nincs index":
            return "check", ("Elkészült, de a fájl indexét (moov) nem találom benne – ez a rész a lemezen "
                             "felülíródhatott, vagy a felvétel nem zárult le rendesen. Nézd meg lejátszóban, "
                             "vagy javítsd a Fájljavítás fülön.")
        if fr.get("ok") is False:
            return "check", "Elkészült, de %d képkocka hibás – felülírt terület lehet benne." % fr.get("bad", 0)
        if fr.get("ok") is None:
            return "check", ("Elkészült (a darabokat a képkockák fejléce alapján ellenőriztem); ezt a kódolást "
                             "a program nem tudja lejátszással ellenőrizni – nyisd meg pl. DaVinci Resolve-ban.")
        return "check", "Elkészült, de nem sikerült dekódolni – nézd meg lejátszóban."
    if kind == "mxf":
        ch = v.get("chain") or {}
        if v.get("ok"):
            return "complete", "Kész, az MXF teljes csomaglánca ép (%d csomag)." % ch.get("packets", 0)
        return "check", "Elkészült, de az MXF szerkezete nem ép (%s)." % ch
    return "complete", "Kész."


def _select(job, live: List[Dict]) -> List[Dict]:
    paths = set(job.get("paths") or [])
    prefixes = [o[len("#mappa:"):].rstrip("/") + "/" for o in (job.get("only") or []) if o.startswith("#mappa:")]
    names = [n.lower() for n in (job.get("only") or []) if not n.startswith("#")]
    if paths or prefixes or names:
        return [e for e in live if not e["dir"] and (e.get("path") in paths or e["name"].lower() in names or
                                                       any((e.get("path") or "").startswith(p) for p in prefixes))]
    return [e for e in live if not e["dir"] and oldfs.is_video(e)]


def _sidecars(sel: List[Dict], live: List[Dict]) -> List[Dict]:
    by_parent: Dict = {}
    for e in live:
        by_parent.setdefault(e.get("parent"), []).append(e)
    have = {id(e) for e in sel}
    extra = []
    for e in sel:
        stem = os.path.splitext(e["name"])[0].lower()
        for s in by_parent.get(e.get("parent"), []):
            if id(s) not in have and not s["dir"] and s["name"].lower().startswith(stem) and \
                    os.path.splitext(s["name"])[1].lower() in (".xml", ".thm", ".bim", ".smi"):
                extra.append(s)
                have.add(id(s))
    return extra


def _piece_sizes(U: int, G: int, learned: Dict) -> List[int]:
    """Write sizes to try: the one that worked before first, then the usual ones."""
    out = []
    for x in [learned.get("U"), U, 32 << 20, 16 << 20, 64 << 20, 8 << 20, 4 << 20, 2 << 20, 1 << 20, 128 << 20]:
        if x and x >= G and x % G == 0 and x not in out:
            out.append(x)
    return out


def _zip_ok(path: str) -> Optional[bool]:
    """True/False for a zip-based file (DaVinci .drp, .zip, .docx...), None for anything else."""
    import zipfile
    try:
        if not zipfile.is_zipfile(path):
            with open(path, "rb") as f:
                return False if f.read(4) == b"PK\x03\x04" else None
        with zipfile.ZipFile(path) as z:
            return z.testzip() is None
    except Exception:  # noqa: BLE001
        return False


def _sizes_from_break(lo: int, hi: int, G: int) -> List[int]:
    """The first piece of the file ends somewhere in [lo, hi] (in-file): the copy program's piece
    size is most likely a cluster multiple there - round sizes (whole MB, powers of two) first."""
    out = []
    a = -(-lo // G) * G
    while a <= hi and len(out) < 64:
        if a > 0:
            out.append(a)
        a += G
    MB = 1 << 20

    def rank(x):
        pow2 = x & (x - 1) == 0
        return (0 if pow2 else 1 if x % MB == 0 else 2, -x)
    return sorted(out, key=rank)


def _hint_for(e: Dict, live_by_parent: Dict) -> Optional[int]:
    """First cluster of the file's sidecar (written right after the file by the copy program)."""
    stem = os.path.splitext(e["name"])[0].lower()
    best = None
    for s in live_by_parent.get(e.get("parent"), []):
        n = s["name"].lower()
        if s is not e and n.startswith(stem) and n.endswith(".xml") and s["first"] > e["first"]:
            if best is None or s["first"] < best:
                best = s["first"]
    return best


def run_entries(rec, src, region) -> None:
    from .mxfchain import MxfRebuild
    from .reassemble import copy_extents
    from .wavchain import WavRebuild
    job = rec.job
    data = _load_survey(job)
    lay = data["layout"]
    G, H = int(lay["G"]), int(lay["H"])
    count = (region[1] - H) // G
    U = int(job.get("piece") or (32 << 20))
    entries = data["entries"]
    live = [e for e in entries if not e["deleted"] and e["first"] >= 2 and e["size"] > 0]
    rec.log("Régi fájlrendszer: klaszter %d KB, adatterület %d; %d élő bejegyzés a listában." % (
        G >> 10, H, len(live)))
    # is this the disk the listing was made from? (disk numbers can change when a USB disk is re-plugged)
    probe = [e for e in live if not e["dir"] and e["contig"] and oldfs.magic_ok(e["name"], b"") is not None
             and not e.get("maybe_overwritten")]
    probe = probe[:: max(1, len(probe) // 12)][:12]
    if probe:
        hits = 0
        for e in probe:
            try:
                hits += bool(oldfs.magic_ok(e["name"], src.read(H + (e["first"] - 2) * G, 1024)))
            except OSError:
                pass
        rec.log("Lemez-azonosítás: a lista %d mintafájljából %d van a helyén." % (len(probe), hits))
        if hits < max(1, len(probe) // 2):
            raise RuntimeError("Ez nem az a lemez, amelyikről a lista készült (a fájlok nincsenek a helyükön). "
                               "Válaszd ki a helyes lemezt, vagy olvasd be újra.")
    # clusters that belong to other known files (or were written after the format)
    claimed = bytearray(count + 2)
    if job.get("overwritten_below") is not None:
        low = int(job["overwritten_below"])
    else:
        ext = oldfs.newfs_extent(src, rec.status.get("filesystem_now") or {})
        rec.status["newfs_extent"] = ext
        low = (ext["high"] + 1) if ext.get("high") is not None else 1024
        rec.log("A formázás után írt új fájlrendszer a %d. klaszterig használta a lemezt (ami ez alatt van, "
                "felülíródhatott)." % low)
    claimed[0:low] = b"\x01" * low
    # who holds a claim (for the log when a piece is found claimed): the listing's entries
    listed = sorted((e["first"], e["first"] + (-(-e["size"] // G) if (e["dir"] or e["contig"]) else 1),
                     e.get("path") or e["name"], "mappa" if e["dir"] else ("egybefüggő fájl" if e["contig"]
                                                                            else "első klasztere"))
                    for e in live if e["size"] > 0 or e["dir"])
    listed_starts = [x[0] for x in listed]
    frag = []
    for e in live:
        n = -(-e["size"] // G)
        # a fragmented file's own first piece is known only once the write size is: until then
        # just its first cluster (a file start never continues another file anyway)
        m = n if (e["dir"] or e["contig"]) else 1
        if not (e["dir"] or e["contig"]):
            frag.append(e)
        a = e["first"]
        b = min(count + 2, a + m)
        if b > a:
            claimed[a:b] = b"\x01" * (b - a)

    def claim_first_pieces(u: int) -> None:
        for x in frag:
            n = min(-(-x["size"] // G), u // G)
            a = x["first"]
            b = min(count + 2, a + n)
            claimed[a:b] = b"\x01" * (b - a)
    if job.get("piece"):
        claim_first_pieces(int(job["piece"]))
    sel = _select(job, live)
    sel = sorted(sel + _sidecars(sel, live), key=lambda e: e["first"])
    # the files in one piece first (they come back fast and certainly), the ones to put together after
    easy = [e for e in sel if e["contig"] or e["size"] <= G]
    hard = [e for e in sel if not (e["contig"] or e["size"] <= G)]
    sel = easy + hard
    if easy and hard:
        rec.log("Előbb az egy darabban lévő %d fájlt hozom vissza, utána az összerakandó %d-t." % (len(easy), len(hard)))
    by_parent: Dict = {}
    for e in live:
        by_parent.setdefault(e.get("parent"), []).append(e)
    total_bytes = sum(e["size"] for e in sel)
    rec.log("Visszaállítandó: %d fájl, %s (%s)." % (len(sel), _human(total_bytes),
                                                     ", ".join(e["name"] for e in sel[:6]) +
                                                     (" …" if len(sel) > 6 else "")))
    learned: Dict = {"U": int(job["piece"])} if job.get("piece") else {}
    # files an earlier run of this job finished (only those are skipped; anything else is redone)
    prev: Dict[str, str] = getattr(rec, "prev_files", {}) or {}
    prev_res: Dict[str, Dict] = getattr(rec, "prev_results", {}) or {}

    owners: List = []                    # (first cluster, clusters, file name) of what has been put together
    owner_starts: List[int] = []

    def own(name: str, ranges) -> None:
        for c, n in ranges:
            owners.append((c, n, name))
        owners.sort()
        owner_starts[:] = [o[0] for o in owners]

    def owner_of(c: int) -> Optional[str]:
        import bisect as _b
        i = _b.bisect_right(owner_starts, c) - 1
        if i >= 0 and owners[i][0] <= c < owners[i][0] + owners[i][1]:
            return owners[i][2]
        return None

    def who_claims(c: int) -> Optional[str]:
        """Which file or what else holds cluster c (for the log)."""
        import bisect as _b
        if c < low:
            return "a formázás után írt új fájlrendszer"
        for a, n, nm in owners:                       # what was put together (ranges may lie inside each other)
            if a <= c < a + n:
                return "%s (visszahozva)" % nm
        i = _b.bisect_right(listed_starts, c)
        for a, b, nm, kind in reversed(listed[max(0, i - 64):i]):
            if a <= c < b:
                return "%s – %s a lista szerint" % (nm.rsplit("/", 1)[-1], kind)
        return "nem tudni, mi (%d. klaszter)" % c

    def claim_prev(pr: Dict, e: Dict) -> None:
        """The pieces of a file an earlier run put together belong to it: keep the other files'
        searches away from them."""
        pieces = pr.get("pieces")
        if not isinstance(pieces, list) or not pieces:
            return
        fsize = pr.get("size") or e["size"]
        u = pr.get("U")
        if not u:
            K = len(pieces)
            u = next((x for x in [32 << 20, 16 << 20, 64 << 20, 8 << 20, 4 << 20, 2 << 20, 1 << 20, 128 << 20]
                      if -(-fsize // x) == K), None)
        if not u:
            return
        splits = {int(k): v for k, v in (pr.get("splits") or {}).items()}
        ranges = []
        for k, c in enumerate(pieces):
            if not isinstance(c, int) or c < 2:
                continue
            if k in splits:
                ranges += [(cc, n) for _o, cc, n in splits[k]]
                continue
            n = -(-(min(fsize, (k + 1) * u) - k * u) // G)
            ranges.append((c, n))
        for c, n in ranges:
            b = min(count + 2, c + n)
            if b > c:
                claimed[c:b] = b"\x01" * (b - c)
        own(e.get("name") or "", ranges)
    ov = {"files_total": len(sel), "files_done": 0, "bytes_total": total_bytes, "bytes_done": 0}
    rec.status["overall"] = ov
    strip = job.get("strip_prefix") or ""
    for i, e in enumerate(sel):
        if rec.cancel and rec.cancel():
            raise InterruptedError
        name = e["name"]
        rel = e.get("path") or name
        if strip and rel.startswith(strip):
            rel = rel[len(strip):].lstrip("/")
        parts = [p for p in rel.split("/")[:-1] if p]
        out_dir = os.path.join(rec.out, *[_safe(p) for p in parts]) if parts else rec.out
        os.makedirs(out_dir, exist_ok=True)
        out_path = os.path.join(out_dir, _safe(name))
        r: Dict = {"name": name, "path": e.get("path"), "size": e["size"], "first": e["first"],
                   "contig": e["contig"], "output": out_path}
        fsize = e["size"]
        if prev.get(e.get("path")) is None and (e["contig"] or e["size"] <= G) and os.path.exists(out_path) and \
                os.path.getsize(out_path) == e["size"]:
            # no record of an earlier run (its state file got lost), but the file is there with its size: a
            # file in one piece is written to a .part file and renamed only when whole - it is done
            r.update(state="complete", message="Már megvan a célmappában (egy korábbi futásból; egy darabban volt, "
                                                "bájtra átmásolva).")
            rec.status["files"].append(r)
            ov["files_done"] += 1
            ov["bytes_done"] += e["size"]
            continue
        st0 = prev.get(e.get("path"))
        # done before: whole, or (a file in one piece, copied byte for byte) to be checked - again it would be the same
        if (st0 == "complete" or (st0 == "check" and (e["contig"] or e["size"] <= G))) and os.path.exists(out_path) and \
                os.path.getsize(out_path) == ((prev_res.get(e.get("path")) or {}).get("size") or e["size"]):
            claim_prev(prev_res.get(e.get("path")) or {}, e)
            pr = prev_res.get(e.get("path")) or {}
            for key in ("pieces", "U", "how", "rebuild", "size", "splits"):
                if key in pr:
                    r[key] = pr[key]
            if st0 == "complete":
                r.update(state="complete", message="Már kész egy korábbi futásból.")
            else:
                r.update(state="check", message="Egy korábbi futásból: %s" % (pr.get("message") or "ellenőrizendő."))
            rec.status["files"].append(r)
            ov["files_done"] += 1
            ov["bytes_done"] += e["size"]
            continue
        free = shutil.disk_usage(rec.out).free
        if free < e["size"] + (64 << 20):
            raise RuntimeError("Elfogyott a hely a célmappában (%s): %s kellene, %s szabad." % (
                rec.out, _human(e["size"]), _human(free)))
        rec.phase("%s (%d / %d)" % (name, i + 1, len(sel)), 0.0)
        rec.status["current"] = {"name": name, "size": e["size"], "path": e.get("path")}
        t0 = time.time()
        P0 = H + (e["first"] - 2) * G
        try:
            head = src.read(P0, 4096)
            kind = _sniff(head)
            if e.get("maybe_overwritten"):
                r["warning"] = "A fájl a lemez elején van, ahová a formázás után írtak: lehet, hogy sérült."
            if e["contig"] or e["size"] <= G:
                extents = [(P0, P0 + e["size"])]
                r["how"] = "egy darabban"
                if oldfs.magic_ok(name, head) is False:
                    r["warning"] = "A fájl eleje nem olyan, mint amilyennek lennie kellene (felülírva?)."
            else:
                cls = {"mp4": MoovRebuild, "mxf": MxfRebuild, "wav": WavRebuild}.get(kind)
                if cls is None and e["size"] <= (learned.get("U") or U):
                    # smaller than one write of the copy program: written in one go, so most likely in one
                    # piece even though the folder entry does not say so
                    cls = "one"
                if cls is None:
                    r.update(state="skipped", message="Darabokban tárolt %s fájl – ezt a fajtát a program még "
                                                      "nem rakja össze." % (os.path.splitext(name)[1] or "ismeretlen"))
                    rec.status["files"].append(r)
                    ov["files_done"] += 1
                    continue
                # the copy program's write size: learnt from the files done so far, else tried in turn; an
                # attempt that sees where the first piece really ends narrows the sizes to try next
                res, mb, used_U = None, None, None
                order = [x for x in _piece_sizes(U, G, learned) if x < e["size"]] if cls != "one" else []
                if cls == "one":
                    res = {"state": "complete", "extents": [(P0, P0 + e["size"])], "message": "egy darabban"}
                done_sizes = set()
                moov_at = None
                attempt = 0
                best = None             # the attempt that found most of the recording (a piece or two lost)
                mxf_best = None         # MXF: (pieces found elsewhere, bytes followed, size) of the best quick try
                while order:
                    U_try = order.pop(0)
                    if U_try in done_sizes:
                        continue
                    done_sizes.add(U_try)
                    kw = dict(cancel=rec.cancel, progress=rec.set_progress, hint=_hint_for(e, by_parent), name=name,
                              window=(32 << 30) if attempt == 0 else (4 << 30), beat=rec.detail)
                    if kind == "mp4" and moov_at is not None:
                        kw["moov_at"] = moov_at
                    if kind == "mp4":
                        kw["owner"] = owner_of
                        kw["who_claims"] = who_claims
                    mb = cls(src, G, H, count, U_try, e["first"], fsize, claimed, rec.log, **kw)
                    mb.debug = bool(os.environ.get("FR_DEBUG"))
                    if mb.debug:
                        rec.log("    %s: próba %d KB-os darabokkal" % (name, U_try >> 10))
                    if kind == "mxf":
                        mb.window_cl = (4 << 30) // G        # a quick try per size; the search goes further at the end
                    res = mb.run()
                    attempt += 1
                    if kind == "mxf" and res.get("state") == "partial" and res.get("reached"):
                        score = (res.get("jumps", 0), res.get("reached", 0), U_try)
                        if mxf_best is None or score > mxf_best:
                            mxf_best = score
                    moov_at = getattr(mb, "moov_at", None) or moov_at
                    if res.get("state") == "complete":
                        used_U = U_try
                        break
                    if os.environ.get("FR_DEBUG"):
                        rec.log("    %s: %d KB-os darabokkal: %s" % (name, U_try >> 10, res.get("message")))
                    if res.get("state") == "resize" and fsize == e["size"]:
                        # the folder entry lost whole 4 GB steps of the size: start again with the real one
                        mb.release()
                        fsize = res["size"]
                        r["size"] = fsize
                        r["size_in_entry"] = e["size"]
                        rec.log("  %s: %s" % (name, res.get("message")))
                        if shutil.disk_usage(rec.out).free < fsize + (64 << 20):
                            res = {"state": "failed", "message": "%s Ennyi hely nincs a célmappában." % res["message"]}
                            break
                        order = [x for x in _piece_sizes(U, G, learned) if x < fsize]
                        done_sizes = set()
                        moov_at = None
                        attempt = 0
                        continue
                    if res.get("state") == "gaps":
                        lost = res.get("lost", 0) / float(fsize)
                        if res.get("u_evidence") and lost <= 0.05:
                            used_U = U_try          # the write size is right; a piece or two are gone
                            break
                        if best is None or lost < best[0]:
                            best = (lost, res, U_try, list(mb.claims), mb)
                    mb.release()
                    fb = res.get("first_break")
                    if fb:
                        sizes = [x for x in _sizes_from_break(fb[0], fb[1], G) if x < e["size"] and x not in done_sizes]
                        order = sizes + [x for x in order if x <= fb[1] and x not in sizes]
                        if os.environ.get("FR_DEBUG"):
                            rec.log("    %s: az első darab %d és %d KB között ér véget -> %s" % (
                                name, fb[0] >> 10, fb[1] >> 10, [x >> 10 for x in order[:6]]))
                    if res.get("state") == "failed":
                        break
                if kind == "mxf" and res is not None and res.get("state") != "complete" and mxf_best is not None:
                    # every size got stuck somewhere: the one that followed the recording furthest (with the most
                    # pieces found away from the one before) is put together now, searching further, and what
                    # is not on the disk any more is left out
                    U_f = mxf_best[2]
                    rec.log("  %s: %s darabokkal megy a legtovább (%s követhető), azzal rakom össze; ami "
                            "nincs meg, azt kihagyom." % (name, ("%d MB-os" % (U_f >> 20)) if U_f % (1 << 20) == 0
                                                          else ("%d KB-os" % (U_f >> 10)), _human(mxf_best[1])))
                    kw = dict(cancel=rec.cancel, progress=rec.set_progress, hint=_hint_for(e, by_parent), name=name,
                              window=32 << 30, beat=rec.detail)
                    mb = MxfRebuild(src, G, H, count, U_f, e["first"], fsize, claimed, rec.log, **kw)
                    mb.debug = bool(os.environ.get("FR_DEBUG"))
                    mb.mode = "final"
                    # time for the search beyond the window: on the 24 TB disk it found nothing in hours, the
                    # recordings need a search by their frames' time code instead - until then 10 minutes at most
                    deep_min = float(os.environ.get("FR_DEEP_MIN") or min(10.0, 3.0 + fsize / 10e9))
                    mb.deep_until = time.time() + 60 * deep_min
                    if os.environ.get("FR_DEEP_LIMIT"):
                        mb.deep_limit = int(os.environ["FR_DEEP_LIMIT"])
                    res = mb.run()
                    used_U = U_f
                    if res.get("state") not in ("complete", "gaps"):
                        mb.release()
                        mb = None
                if res is not None and res.get("state") not in ("complete", "gaps") and best is not None:
                    _lost, res, used_U, claims, mb = best
                    for c0, n0 in claims:
                        claimed[c0:c0 + n0] = b"\x01" * n0
                    mb.claims = list(claims)
                if res is None:
                    res = {"state": "failed", "message": "A fájl darabjai nem azonosíthatók."}
                r["how"] = {"mp4": "index alapján összerakva", "mxf": "MXF-csomaglánc alapján összerakva",
                            "wav": "hangfolytonosság alapján összerakva"}.get(kind, "egy darabban (kisebb egy írásnál)")
                r["rebuild"] = {k: v for k, v in res.items() if k != "extents"}
                if res.get("state") not in ("complete", "gaps"):
                    r.update(state=res.get("state", "failed"), message=res.get("message"))
                    rec.log("%s: %s" % (name, res.get("message")))
                    rec.status["files"].append(r)
                    ov["files_done"] += 1
                    rec.write_status(force=True)
                    continue
                extents = res["extents"]
                if mb is not None:
                    r["U"] = used_U
                    r["u_evidence"] = res.get("u_evidence", True)
                    r["pieces"] = [mb.pieces.get(k) for k in range(mb.K)]
                    if getattr(mb, "splits", None):
                        r["splits"] = {str(k): v for k, v in mb.splits.items()}
                    own(name, list(mb.claims))
                if res.get("uncertain"):
                    r["warning"] = res.get("message")
                    r["uncertain"] = res.get("uncertain")
            copy_extents(src, extents, out_path, progress=rec.set_progress, cancel=rec.cancel)
            v = _verify(out_path, kind if kind in ("mp4", "mxf") else "other")
            r["verify"] = v
            st, msg = _message(kind if kind in ("mp4", "mxf") else "other", v, r.get("how", ""))
            if st == "complete" and r.get("U") and r.get("u_evidence", True) and learned.get("U") != r["U"]:
                # a size is learnt only from a file whose every frame checked out
                learned["U"] = r["U"]
                rec.log("A másolóprogram %s-onként írt (darabméret)." % (
                    ("%d MB" % (r["U"] >> 20)) if r["U"] % (1 << 20) == 0 else ("%d KB" % (r["U"] >> 10))))
                claim_first_pieces(r["U"])
            if r.get("how", "").startswith("egy darabban (kisebb"):
                zv = _zip_ok(out_path)
                if zv is True:
                    st, msg = "complete", "Kész, a tömörített állomány minden része ép (egy darabban volt)."
                elif zv is False:
                    st, msg = "check", "Kimentve, de a tömörített állomány nem ép: nem egy darabban volt a lemezen."
                else:
                    st, msg = "check", ("Egy darabban kimentve (kisebb, mint a másolóprogram egy írása, így "
                                        "valószínűleg ép) – a fajtája miatt nem tudom ellenőrizni, nyisd meg.")
            if (r.get("rebuild") or {}).get("state") == "gaps":
                st, msg = "check", "Visszahozva, de hiányos. " + r["rebuild"]["message"]
            if st == "complete" and (r.get("rebuild") or {}).get("filled"):
                st, msg = "check", msg + " Figyelem: a felvétel legvégén egy rövid hangrész nem volt azonosítható, " \
                                         "csenddel pótoltam."
            if st == "complete" and r.get("uncertain") and kind == "mxf":
                st, msg = "check", msg + " Figyelem: %d darabnál két egyforma beállítású felvétel darabjai " \
                                         "között nem lehetett biztosan dönteni – nézd meg a végét." % r["uncertain"]
            r.update(state=st, message=msg)
            r["seconds"] = round(time.time() - t0, 1)
            if st == "complete" and kind == "mp4":
                try:                                # a camera file back in one piece: the shared knowledge learns it
                    from .. import knowledge
                    knowledge.learn_async(out_path, "lemez-visszaállítás")
                except Exception:  # noqa: BLE001
                    pass
        except InterruptedError:
            raise
        except Exception as ex:  # noqa: BLE001
            r.update(state="error", message=str(ex))
        rec.log("%s: %s (%s, %.0f mp)" % (name, r.get("message"), r.get("how", ""), time.time() - t0))
        rec.status["files"].append(r)
        ov["files_done"] += 1
        ov["bytes_done"] += e["size"]
        rec.write_status(force=True)
    files = rec.status["files"]
    rec.status["summary"] = {
        "complete": sum(1 for x in files if x.get("state") == "complete"),
        "check": sum(1 for x in files if x.get("state") == "check"),
        "partial": sum(1 for x in files if x.get("state") in ("partial", "no_index", "failed", "error")),
        "skipped": sum(1 for x in files if x.get("state") == "skipped"),
    }
    sm = rec.status["summary"]
    rec.log("Kész: %d / %d fájl rendben; ellenőrizendő %d, nem sikerült %d, kihagyva %d." % (
        sm["complete"], len(sel), sm["check"], sm["partial"], sm["skipped"]))


def _load_survey(job) -> Dict:
    path = job.get("entries_file") or next((s for s in job.get("sources") or []
                                             if s.lower().endswith(".json")), None)
    if not path or not os.path.exists(path):
        raise RuntimeError("Nincs meg a felmérés bejegyzéslistája (futurerepair_lemez_bejegyzesek.json).")
    with open(path, encoding="utf-8") as f:
        data = json.load(f)
    if not data.get("layout"):
        raise RuntimeError("A felmérés nem állapította meg a régi fájlrendszer beosztását.")
    return data


def _human(n: float) -> str:
    for unit, k in (("TB", 1e12), ("GB", 1e9), ("MB", 1e6)):
        if n >= k:
            return "%.1f %s" % (n / k, unit)
    return "%d KB" % (n // 1000)


def run_tree(rec, src, region) -> None:
    """List everything the old folders still describe (walks the old directory tree)."""
    from .diagnose import ENTRIES_FILE
    data = _load_survey(rec.job)
    G, H = int(data["layout"]["G"]), int(data["layout"]["H"])
    count = (region[1] - H) // G
    now = rec.status.get("filesystem_now") or {}
    ext = oldfs.newfs_extent(src, now)
    low = (ext["high"] + 1) if ext.get("high") is not None else 1024
    rec.status["newfs_extent"] = ext
    rec.phase("A formázás után létrejött új fájlrendszer bejárása", 0.0)
    new_dirs = set()
    new_files: List[Dict] = []
    if now.get("type") == "exFAT" and now.get("root_cluster"):
        w = oldfs.walk_tree(src, now["cluster"], now["heap"], now["clusters"], [],
                            [(now["root_cluster"], "")], cancel=rec.cancel)
        new_dirs = set(w["visited"])
        new_files = [e for e in w["entries"] if not e["dir"]]
    nbytes = sum(e["size"] for e in new_files)
    rec.log("A formázás után a lemezre írt fájlok: %d db, %s (a %d. klaszterig); ezek helyén a régi adat "
            "felülíródhatott." % (len(new_files), _human(nbytes), low))
    for e in sorted(new_files, key=lambda x: -x["size"])[:5]:
        rec.log("  pl. %s – %s, %s%s" % (e["path"], _human(e["size"]), e.get("mtime"), " (törölve)" if e["deleted"] else ""))
    # seeds: known old folders whose parent is unknown, and directory clusters whose own entry is lost
    old = [e for e in data["entries"] if (e.get("cluster_of_entry") or 0) not in new_dirs]
    # Every entry the survey saw lies in some directory cluster. Clusters that are not (part of) a
    # known directory are directories whose own entry is lost: the walk starts from those and
    # reaches the known ones through them.
    import bisect
    ranges = sorted((e["first"], e["first"] + max(1, -(-e["size"] // G))) for e in old
                    if e["dir"] and not e["deleted"] and e["first"] >= 2 and (e["contig"] or e["size"] <= G))
    starts = [r[0] for r in ranges]

    def in_known(c):
        i = bisect.bisect_right(starts, c) - 1
        return i >= 0 and ranges[i][0] <= c < ranges[i][1]
    orphan_cl = sorted({e.get("cluster_of_entry") for e in old if e.get("cluster_of_entry")} - new_dirs)
    orphan_cl = [c for c in orphan_cl if c >= 2 and not in_known(c)]
    orphans = [(c, "_ismeretlen_mappa_%d" % c) for c in orphan_cl]
    seeds: List[Dict] = []
    rec.phase("A régi mappák bejárása", 0.05)
    w = oldfs.walk_tree(src, G, H, count, seeds, orphans, cancel=rec.cancel,
                        progress=lambda x: rec.set_progress(0.05 + 0.9 * x), log=rec.log)
    uniq: Dict[int, Dict] = {}
    for e in w["entries"]:
        if e.get("dir_first") in new_dirs:
            continue
        uniq.setdefault(e["pos"], e)
    entries = sorted(uniq.values(), key=lambda e: e["path"].lower())
    for e in entries:
        e["parent"] = e.get("dir_first")
        if e["first"] >= 2:
            e["disk_pos"] = H + (e["first"] - 2) * G
            e["maybe_overwritten"] = e["first"] < low
    files = [e for e in entries if not e["dir"] and not e["deleted"] and e["size"] > 0]
    vids = [e for e in files if oldfs.is_video(e)]
    st = {"files": len(files), "bytes": sum(e["size"] for e in files), "videos": len(vids),
          "video_bytes": sum(e["size"] for e in vids),
          "video_contig": sum(1 for e in vids if e["contig"]),
          "video_contig_bytes": sum(e["size"] for e in vids if e["contig"]),
          "dirs": sum(1 for e in entries if e["dir"] and not e["deleted"]),
          "deleted": sum(1 for e in entries if e["deleted"]),
          "fragmented_dirs": w["fragmented_dirs"][:50], "orphans": len(orphans), "new_files": len(new_files),
          "overwritten_below": low}
    rec.status["tree"] = st
    rec.log("Régi fájlok: %d db, %s; ebből videó %d db (%s), egy darabban %d db (%s)." % (
        st["files"], _human(st["bytes"]), st["videos"], _human(st["video_bytes"]), st["video_contig"],
        _human(st["video_contig_bytes"])))
    rec.log("Mappák: %d, ismeretlen nevű kiinduló mappa: %d; törölt bejegyzés: %d." % (
        st["dirs"], st["orphans"], st["deleted"]))
    if st["fragmented_dirs"]:
        rec.log("Több darabban tárolt mappa (csak az első darabja olvasható): %d" % len(w["fragmented_dirs"]))
    # top folders by size
    tops: Dict[str, List[int]] = {}
    for e in files:
        top = e["path"].split("/")[0]
        t = tops.setdefault(top, [0, 0])
        t[0] += 1
        t[1] += e["size"]
    for name, (n, b) in sorted(tops.items(), key=lambda kv: -kv[1][1])[:15]:
        rec.log("  %s: %d fájl, %s" % (name, n, _human(b)))
    path = os.path.join(rec.out, ENTRIES_FILE)
    with open(path + ".part", "w", encoding="utf-8") as f:
        json.dump({"layout": data["layout"], "entries": entries, "summary": st}, f, ensure_ascii=False)
    os.replace(path + ".part", path)
    lst = os.path.join(rec.out, "futurerepair_lemez_lista.txt")
    with open(lst, "w", encoding="utf-8-sig") as f:
        f.write("Útvonal\tMéret (bájt)\tTárolás\tMódosítva\tMegjegyzés\n")
        for e in entries:
            if e["dir"] or e["deleted"]:
                continue
            note = "felülíródhatott" if e.get("maybe_overwritten") else ""
            f.write("%s\t%d\t%s\t%s\t%s\n" % (e["path"], e["size"], "egy darabban" if e["contig"] else "darabolt",
                                              e.get("mtime") or "", note))
    rec.log("A teljes lista: %s" % lst)
