"""Windows helpers for disk recovery: drive letters, system disk, elevation, read-only protection."""
from __future__ import annotations

import os
import re
import struct
import subprocess
import tempfile
from typing import Dict, List, Optional


def _k32():
    import ctypes
    from ctypes import wintypes
    k = ctypes.WinDLL("kernel32", use_last_error=True)
    k.CreateFileW.restype = wintypes.HANDLE
    k.CreateFileW.argtypes = [wintypes.LPCWSTR, wintypes.DWORD, wintypes.DWORD, ctypes.c_void_p,
                              wintypes.DWORD, wintypes.DWORD, wintypes.HANDLE]
    k.DeviceIoControl.restype = wintypes.BOOL
    k.DeviceIoControl.argtypes = [wintypes.HANDLE, wintypes.DWORD, ctypes.c_void_p, wintypes.DWORD,
                                  ctypes.c_void_p, wintypes.DWORD, ctypes.POINTER(wintypes.DWORD), ctypes.c_void_p]
    k.CloseHandle.argtypes = [wintypes.HANDLE]
    return ctypes, wintypes, k


def disk_number_of_letter(letter: str) -> Optional[int]:
    """Physical disk number behind a drive letter (no administrator rights needed)."""
    ctypes, wintypes, k = _k32()
    path = "\\\\.\\%s:" % letter.strip().rstrip(":\\")[0].upper()
    h = k.CreateFileW(path, 0, 3, None, 3, 0, None)
    if h is None or h == ctypes.c_void_p(-1).value:
        return None
    try:
        buf = ctypes.create_string_buffer(12)
        ret = wintypes.DWORD(0)
        IOCTL_STORAGE_GET_DEVICE_NUMBER = 0x002D1080
        if not k.DeviceIoControl(h, IOCTL_STORAGE_GET_DEVICE_NUMBER, None, 0, buf, 12, ctypes.byref(ret), None):
            return None
        _typ, num, _part = struct.unpack("<IIi", buf.raw)
        return num
    finally:
        k.CloseHandle(h)


def letters_by_disk() -> Dict[int, List[str]]:
    out: Dict[int, List[str]] = {}
    import string
    for c in string.ascii_uppercase:
        if os.path.exists(c + ":\\"):
            n = disk_number_of_letter(c)
            if n is not None:
                out.setdefault(n, []).append(c + ":")
    return out


def system_disk() -> Optional[int]:
    drive = os.environ.get("SystemDrive", "C:")
    return disk_number_of_letter(drive)


def is_admin() -> bool:
    try:
        import ctypes
        return bool(ctypes.windll.shell32.IsUserAnAdmin())
    except Exception:  # noqa: BLE001
        return False


def launch_elevated(exe: str, args: List[str], cwd: Optional[str] = None) -> int:
    """Start exe elevated (UAC prompt). Returns the ShellExecute result (> 32 = started)."""
    import ctypes
    params = subprocess.list2cmdline(args)
    return int(ctypes.windll.shell32.ShellExecuteW(None, "runas", exe, params, cwd, 0))


def diskpart(script: str, timeout: int = 120) -> str:
    fd, path = tempfile.mkstemp(suffix=".txt", prefix="fr_diskpart_")
    with os.fdopen(fd, "w", encoding="ascii") as f:
        f.write(script.strip() + "\nexit\n")
    try:
        r = subprocess.run(["diskpart", "/s", path], capture_output=True, timeout=timeout,
                           creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        return (r.stdout or b"").decode("cp852", "replace") + (r.stderr or b"").decode("cp852", "replace")
    finally:
        try:
            os.remove(path)
        except OSError:
            pass


def set_disk_readonly(number: int, on: bool = True) -> str:
    """Windows-level read-only flag of a whole disk (needs administrator rights).
    It is kept by Windows, not written into the disk's partition table."""
    sysd = system_disk()
    if sysd is not None and number == sysd:
        raise RuntimeError("A rendszerlemezt nem lehet így megjelölni.")
    out = diskpart("select disk %d\nattributes disk %s readonly\nattributes disk\n" % (number, "set" if on else "clear"))
    return out


def disk_readonly_state(text: str) -> Optional[bool]:
    m = re.search(r"(Current Read-only State|Aktu.lis .r.sv.dett .llapot)\s*:\s*(\w+)", text, re.I)
    if not m:
        return None
    return m.group(2).lower() in ("yes", "igen")
