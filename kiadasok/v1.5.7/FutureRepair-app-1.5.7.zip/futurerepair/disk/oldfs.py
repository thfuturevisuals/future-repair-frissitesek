"""Remains of the file system that was on the disk before it was formatted.

A quick format writes a new boot sector, FAT, allocation bitmap and root directory, but the
directories of the old file system stay where they were, spread over the disk. Their entries
(exFAT: file name, size, first cluster, whether the file is stored in one piece) tell where each
file started - and, for files stored in one piece, where all of it is.

Everything here only reads.
"""
from __future__ import annotations

import array
import os
import struct
import sys
from collections import Counter
from typing import Callable, Dict, Iterable, List, Optional, Tuple

from .survey import F_MP4, head_flags

ATTR_DIR = 0x10
EOC = 0xFFFFFFFF
BAD = 0xFFFFFFF7

VIDEO_EXT = {".mp4", ".mov", ".m4v", ".mxf", ".3gp", ".insv", ".lrv", ".avi", ".mts", ".m2ts", ".braw", ".r3d",
             ".crm", ".mkv", ".lrf"}

# a file's first bytes, by extension (used to check a guessed layout)
_MAGIC = {
    ".mp4": "mp4", ".mov": "mp4", ".m4v": "mp4", ".3gp": "mp4", ".insv": "mp4", ".lrv": "mp4", ".heic": "mp4",
    ".cr3": "mp4", ".m4a": "mp4",
    ".jpg": (b"\xff\xd8\xff",), ".jpeg": (b"\xff\xd8\xff",),
    ".arw": (b"II*\x00", b"MM\x00*"), ".tif": (b"II*\x00", b"MM\x00*"), ".tiff": (b"II*\x00", b"MM\x00*"),
    ".dng": (b"II*\x00", b"MM\x00*"), ".nef": (b"II*\x00", b"MM\x00*"), ".cr2": (b"II*\x00",),
    ".png": (b"\x89PNG",), ".pdf": (b"%PDF",), ".wav": (b"RIFF", b"RF64"), ".avi": (b"RIFF",),
    ".mxf": (b"\x06\x0e\x2b\x34\x02\x05\x01\x01",), ".psd": (b"8BPS",), ".zip": (b"PK\x03\x04",),
    ".xml": (b"<?xml", b"\xef\xbb\xbf<?xml"), ".mp3": (b"ID3", b"\xff\xfb", b"\xff\xf3", b"\xff\xfa"),
    ".bim": (b"<?xml",),
}


def ext_of(name: str) -> str:
    return os.path.splitext(name)[1].lower()


def is_video(e: Dict) -> bool:
    return not e.get("dir") and ext_of(e.get("name", "")) in VIDEO_EXT


def magic_ok(name: str, head: bytes) -> Optional[bool]:
    """Does `head` look like the start of a file called `name`? None: no rule for this kind."""
    m = _MAGIC.get(ext_of(name))
    if m is None:
        return None
    if m == "mp4":
        return bool(head_flags(head[:64]) & F_MP4)
    return any(head.startswith(s) for s in m)


# ---------------------------------------------------------------------------
# exFAT directory entry sets
# ---------------------------------------------------------------------------

def set_checksum(data) -> int:
    c = 0
    for i, b in enumerate(data):
        if i == 2 or i == 3:
            continue
        c = (((c >> 1) | ((c & 1) << 15)) + b) & 0xFFFF
    return c


def _ts(v: int, ms10: int = 0) -> Optional[str]:
    if not v:
        return None
    sec = (v & 0x1F) * 2 + ms10 // 100
    minute = (v >> 5) & 0x3F
    hour = (v >> 11) & 0x1F
    day = (v >> 16) & 0x1F
    month = (v >> 21) & 0x0F
    year = 1980 + ((v >> 25) & 0x7F)
    if not (1 <= month <= 12 and 1 <= day <= 31 and hour < 24 and minute < 60 and sec < 61):
        return None
    return "%04d-%02d-%02d %02d:%02d:%02d" % (year, month, day, hour, minute, min(sec, 59))


def parse_entry_set(buf, i: int = 0) -> Optional[Dict]:
    """The exFAT file entry set at buf[i] (also a deleted one), or None if there is none."""
    if i < 0 or i + 96 > len(buf):
        return None
    t = buf[i]
    if t not in (0x85, 0x05):
        return None
    n = buf[i + 1]
    if n < 2 or n > 18 or i + 32 * (n + 1) > len(buf):
        return None
    s = buf[i + 32]
    if s not in (0xC0, 0x40) or (s & 0x80) != (t & 0x80):
        return None
    nlen = buf[i + 35]
    if nlen == 0 or (nlen + 14) // 15 > n - 1:
        return None
    raw = bytearray(buf[i:i + 32 * (n + 1)])
    deleted = not (t & 0x80)
    if deleted:
        for k in range(n + 1):
            raw[32 * k] |= 0x80
    if set_checksum(raw) != struct.unpack_from("<H", raw, 2)[0]:
        return None
    parts = []
    for k in range((nlen + 14) // 15):
        e = 32 * (2 + k)
        if raw[e] != 0xC1:
            return None
        parts.append(bytes(raw[e + 2:e + 32]))
    name = b"".join(parts).decode("utf-16-le", "replace")[:nlen]
    attr = struct.unpack_from("<H", raw, 4)[0]
    ctime, mtime = struct.unpack_from("<II", raw, 8)
    flags = raw[33]
    return {
        "name": name,
        "dir": bool(attr & ATTR_DIR),
        "attr": attr,
        "size": struct.unpack_from("<Q", raw, 56)[0],
        "valid": struct.unpack_from("<Q", raw, 40)[0],
        "first": struct.unpack_from("<I", raw, 52)[0],
        "contig": bool(flags & 2),
        "alloc": bool(flags & 1),
        "ctime": _ts(ctime, raw[20]),
        "mtime": _ts(mtime, raw[21]),
        "deleted": deleted,
        "len": 32 * (n + 1),
    }


_STREAM = (b"\xc0\x01\x00", b"\xc0\x03\x00", b"\x40\x01\x00", b"\x40\x03\x00")


def find_entry_sets(buf, base: int, limit: Optional[int] = None) -> List[Dict]:
    """All exFAT file entry sets in buf (buf[0] is at disk position `base`) that start before `limit`."""
    limit = len(buf) if limit is None else limit
    out = []
    seen = set()
    for pat in _STREAM:
        j = buf.find(pat)
        while j != -1:
            i = j - 32
            if i >= 0 and i < limit and (base + i) % 32 == 0 and i not in seen:
                e = parse_entry_set(buf, i)
                if e is not None:
                    e["pos"] = base + i
                    out.append(e)
                    seen.add(i)
            j = buf.find(pat, j + 1)
    out.sort(key=lambda e: e["pos"])
    return out


def run_starts(entries: List[Dict]) -> List[int]:
    """Positions where a group of consecutive entry sets begins (a directory cluster starts like that)."""
    ends = {e["pos"] + e["len"] for e in entries}
    return [e["pos"] for e in entries if e["pos"] not in ends]


# ---------------------------------------------------------------------------
# Boot sectors of earlier file systems
# ---------------------------------------------------------------------------

def parse_exfat_boot(bs: bytes, pos: int) -> Optional[Dict]:
    if len(bs) < 512 or bs[3:11] != b"EXFAT   " or bs[510:512] != b"\x55\xaa":
        return None
    (part_off, vol_len, fat_off, fat_len, heap_off, count, root) = struct.unpack_from("<QQIIIII", bs, 64)
    serial = struct.unpack_from("<I", bs, 100)[0]
    bps_sh, spc_sh, nfats = bs[108], bs[109], bs[110]
    if not (9 <= bps_sh <= 12 and bps_sh + spc_sh <= 25 and count > 0 and heap_off > 0):
        return None
    bps = 1 << bps_sh
    return {"type": "exFAT", "pos": pos, "cluster": 1 << (bps_sh + spc_sh), "sector": bps,
            "heap": pos + heap_off * bps, "fat": pos + fat_off * bps, "fat_len": fat_len * bps,
            "clusters": count, "root_cluster": root, "serial": "%08X" % serial, "fats": nfats,
            "volume_bytes": vol_len * bps, "partition_offset": part_off * bps}


def parse_ntfs_boot(bs: bytes, pos: int) -> Optional[Dict]:
    if len(bs) < 512 or bs[3:11] != b"NTFS    " or bs[510:512] != b"\x55\xaa":
        return None
    bps = struct.unpack_from("<H", bs, 11)[0]
    spc = bs[13]
    spc = 1 << (256 - spc) if spc > 0x80 else spc
    if bps not in (512, 1024, 2048, 4096) or not spc:
        return None
    total, mft, mftm = struct.unpack_from("<QQQ", bs, 0x28)
    return {"type": "NTFS", "pos": pos, "cluster": bps * spc, "sector": bps, "volume_bytes": total * bps,
            "mft": pos + mft * bps * spc, "serial": "%016X" % struct.unpack_from("<Q", bs, 0x48)[0]}


def scan_boot_sectors(src, start: int, end: int, cancel=None,
                      progress: Optional[Callable[[float], None]] = None) -> List[Dict]:
    """Boot sectors / superblocks of file systems between start and end (sector aligned)."""
    found = []
    pos = start
    step = 16 << 20
    while pos < end:
        if cancel and cancel():
            raise InterruptedError
        n = min(step, end - pos)
        buf = src.read_direct(pos, n + 4096 if pos + n + 4096 <= src.size else n)
        for sig, off in ((b"EXFAT   ", 3), (b"NTFS    ", 3)):
            j = buf.find(sig)
            while j != -1:
                p = j - off
                if 0 <= p < n and (pos + p) % 512 == 0:
                    d = (parse_exfat_boot if sig[0:1] == b"E" else parse_ntfs_boot)(buf[p:p + 512], pos + p)
                    if d:
                        found.append(d)
                j = buf.find(sig, j + 1)
        j = buf.find(b"FAT32   ")
        while j != -1:
            p = j - 82
            if 0 <= p < n and (pos + p) % 512 == 0 and buf[p + 510:p + 512] == b"\x55\xaa":
                found.append({"type": "FAT32", "pos": pos + p,
                              "cluster": struct.unpack_from("<H", buf, p + 11)[0] * buf[p + 13]})
            j = buf.find(b"FAT32   ", j + 1)
        j = buf.find(b"NXSB")
        while j != -1:
            p = j - 32
            if 0 <= p < n and (pos + p) % 4096 == 0:
                bsz, cnt = struct.unpack_from("<IQ", buf, p + 36)
                if bsz in (4096, 8192, 16384, 32768, 65536):
                    found.append({"type": "APFS", "pos": pos + p, "cluster": bsz, "volume_bytes": bsz * cnt})
            j = buf.find(b"NXSB", j + 1)
        for sig in (b"H+\x00\x04", b"HX\x00\x05"):
            j = buf.find(sig)
            while j != -1:
                p = j - 1024
                if 0 <= p < n and (pos + p) % 512 == 0:
                    bsz, cnt = struct.unpack_from(">II", buf, j + 40)
                    if bsz in (512, 1024, 2048, 4096, 8192, 16384, 32768, 65536) and cnt:
                        found.append({"type": "HFS+", "pos": pos + p, "cluster": bsz, "volume_bytes": bsz * cnt})
                j = buf.find(sig, j + 1)
        j = buf.find(b"EFI PART")
        while j != -1:
            if j < n and (pos + j) % 512 == 0:
                found.append({"type": "GPT", "pos": pos + j})
            j = buf.find(b"EFI PART", j + 1)
        pos += n
        if progress:
            progress((pos - start) / float(max(1, end - start)))
    found.sort(key=lambda d: d["pos"])
    return found


# ---------------------------------------------------------------------------
# FAT
# ---------------------------------------------------------------------------

def fat_stats(src, fat_pos: int, count: int, cancel=None,
              progress: Optional[Callable[[float], None]] = None, buckets: int = 64) -> Dict:
    """What the FAT region holds: entries that are zero, end-of-chain, links to the next cluster."""
    total = count + 2
    nbytes = total * 4
    st = {"entries": total, "zero": 0, "eoc": 0, "bad": 0, "sample": 0, "sample_link": 0,
          "sample_next": 0, "sample_other": 0, "nonzero_by_part": []}
    per = -(-total // buckets)
    nz_bucket = [0] * buckets
    pos = 0
    step = 16 << 20
    while pos < nbytes:
        if cancel and cancel():
            raise InterruptedError
        n = min(step, nbytes - pos)
        buf = src.read_direct(fat_pos + pos, n)
        a = array.array("I")
        a.frombytes(buf[:len(buf) - len(buf) % 4])
        if sys.byteorder != "little":
            a.byteswap()
        z = a.count(0)
        st["zero"] += z
        st["eoc"] += a.count(EOC)
        st["bad"] += a.count(BAD)
        base = pos // 4
        if z < len(a):
            # how the non-zero entries are spread over the volume
            for k in range(0, len(a), 4096):
                part = a[k:k + 4096]
                nzc = len(part) - part.count(0)
                if nzc:
                    nz_bucket[min(buckets - 1, (base + k) // per)] += nzc
            for k in range(0, len(a), 997):
                v = a[k]
                if v == 0 or v == EOC or v == BAD:
                    continue
                st["sample"] += 1
                if 2 <= v < total:
                    st["sample_link"] += 1
                    if v == base + k + 1:
                        st["sample_next"] += 1
                else:
                    st["sample_other"] += 1
        pos += n
        if progress:
            progress(pos / float(nbytes))
    st["nonzero"] = total - st["zero"]
    st["nonzero_by_part"] = nz_bucket
    return st


class FatReader:
    def __init__(self, src, fat_pos: int, count: int):
        self.src = src
        self.fat_pos = fat_pos
        self.count = count
        self._page: Dict[int, array.array] = {}

    def get(self, c: int) -> int:
        k = c >> 16                            # 64 Ki entries per page (256 KB)
        a = self._page.get(k)
        if a is None:
            buf = self.src.read_direct(self.fat_pos + k * 262144, 262144)
            a = array.array("I")
            a.frombytes(buf[:len(buf) - len(buf) % 4])
            if sys.byteorder != "little":
                a.byteswap()
            if len(self._page) > 2048:
                self._page.clear()
            self._page[k] = a
        i = c & 0xFFFF
        return a[i] if i < len(a) else 0


def follow_chain(fr: FatReader, first: int, size: int, G: int, max_steps: int = 4_000_000) -> Dict:
    """Follow a file's FAT chain: is it complete and consistent with the file size?"""
    need = max(1, -(-size // G))
    c = first
    steps = 1
    jumps = 0
    while steps < need:
        if steps > max_steps:
            return {"ok": None, "steps": steps, "need": need, "jumps": jumps, "why": "too long"}
        v = fr.get(c)
        if not (2 <= v < fr.count + 2):
            return {"ok": False, "steps": steps, "need": need, "jumps": jumps, "value": v}
        if v != c + 1:
            jumps += 1
        c = v
        steps += 1
    v = fr.get(c)
    return {"ok": v == EOC, "steps": steps, "need": need, "jumps": jumps, "last": v}


def chain_list(fr: FatReader, first: int, size: int, G: int) -> Optional[List[int]]:
    need = max(1, -(-size // G))
    out = [first]
    c = first
    while len(out) < need:
        v = fr.get(c)
        if not (2 <= v < fr.count + 2):
            return None
        out.append(v)
        c = v
    return out


# ---------------------------------------------------------------------------
# Where the old cluster heap was
# ---------------------------------------------------------------------------

def layout_votes(entries: List[Dict], mp4_hits: Iterable[int], starts: Iterable[int], part: Tuple[int, int],
                 sizes: List[int], cap: int = 600) -> Counter:
    """Candidate (cluster size G, heap start H) pairs: the first cluster c of an old entry sits at
    H + (c-2)*G. A directory's first cluster begins with entry sets; a video's with its header."""
    lo, hi = part[0], part[0] + (40 << 30)
    dirs = [e for e in entries if e["dir"] and e["first"] >= 2][:cap]
    vids = [e for e in entries if is_video(e) and e["first"] >= 2 and e["size"] > (1 << 20)][:cap]
    starts = list(starts)[:cap * 2]
    mp4_hits = list(mp4_hits)[:cap * 2]
    votes: Counter = Counter()
    for G in sizes:
        for group, pts in ((dirs, starts), (vids, mp4_hits)):
            for e in group:
                off = (e["first"] - 2) * G
                for X in pts:
                    H = X - off
                    if lo <= H < hi and not H % 512:
                        votes[(G, H)] += 1
    return votes


def check_layout(src, entries: List[Dict], G: int, H: int, end: int, per_kind: int = 16) -> Dict:
    """Read the first sector of a few old files/folders where this layout puts them."""
    res = {"G": G, "H": H, "ok": 0, "n": 0, "video_ok": 0, "video_n": 0, "dir_ok": 0, "dir_n": 0}
    kinds: Dict[str, int] = {}
    for e in entries:
        if e["first"] < 2 or e["deleted"]:
            continue
        P = H + (e["first"] - 2) * G
        if P < 0 or P + 1024 > end:
            continue
        if e["dir"]:
            kind = "dir"
        else:
            if e["size"] < 64 or magic_ok(e["name"], b"") is None:
                continue
            kind = "video" if is_video(e) else ext_of(e["name"])
        if kinds.get(kind, 0) >= per_kind:
            continue
        kinds[kind] = kinds.get(kind, 0) + 1
        try:
            head = src.read_direct(P, 1024)
        except OSError:
            continue
        if e["dir"]:
            good = parse_entry_set(head, 0) is not None
        else:
            good = bool(magic_ok(e["name"], head))
        res["n"] += 1
        res["ok"] += int(good)
        if kind == "video":
            res["video_n"] += 1
            res["video_ok"] += int(good)
        elif kind == "dir":
            res["dir_n"] += 1
            res["dir_ok"] += int(good)
    return res


def build_paths(entries: List[Dict], G: int, H: int) -> None:
    """Give every entry its folder path: an entry set at disk position p lies in the directory
    whose clusters contain p (directory entries know their first cluster)."""
    dirs = {}
    for e in entries:
        if e["dir"] and e["first"] >= 2 and not e["deleted"]:
            dirs.setdefault(e["first"], e)
    for e in entries:
        c = (e["pos"] - H) // G + 2 if e["pos"] >= H else None
        e["cluster_of_entry"] = c
    # parent = the directory whose first cluster holds the entry (directories usually fit in one)
    for e in entries:
        p = dirs.get(e.get("cluster_of_entry"))
        e["parent"] = p["first"] if p is not None else None

    def path_of(e, depth=0):
        if depth > 32:
            return e["name"]
        par = dirs.get(e.get("parent")) if e.get("parent") else None
        if par is None or par is e:
            return e["name"]
        return path_of(par, depth + 1) + "/" + e["name"]
    for e in entries:
        e["path"] = path_of(e)


# ---------------------------------------------------------------------------
# What the file system written by the format has used since then
# ---------------------------------------------------------------------------

def newfs_extent(src, fsi: Dict) -> Dict:
    """Highest cluster the current (new) exFAT has in use (allocation bitmap) or has ever chained
    (FAT). Old data below it may have been overwritten after the format."""
    out: Dict = {"bitmap_high": None, "fat_high": None, "high": None}
    if fsi.get("type") != "exFAT":
        return out
    G = fsi["cluster"]
    heap = fsi["heap"]
    root = fsi.get("root_cluster") or 0
    count = fsi.get("clusters") or 0
    try:
        rd = src.read_direct(heap + (root - 2) * G, G)
        for i in range(0, len(rd), 32):
            t = rd[i]
            if t == 0x00:
                break
            if t == 0x81:
                first, length = struct.unpack_from("<IQ", rd, i + 20)
                bm = src.read_direct(heap + (first - 2) * G, min(length, (count + 7) // 8 + 8))
                j = len(bm.rstrip(b"\x00"))
                if j:
                    b = bm[j - 1]
                    out["bitmap_high"] = 2 + (j - 1) * 8 + b.bit_length() - 1
                break
    except (OSError, struct.error):
        pass
    fat, flen = fsi.get("fat"), fsi.get("fat_len")
    if fat and flen:
        step = 16 << 20
        end = min(flen, (count + 2) * 4)
        pos = end
        while pos > 0:
            a = max(0, pos - step)
            buf = src.read_direct(fat + a, pos - a)
            j = len(buf.rstrip(b"\x00"))
            if j:
                out["fat_high"] = (a + j - 1) // 4
                break
            pos = a
    vals = [v for v in (out["bitmap_high"], out["fat_high"]) if v is not None]
    out["high"] = max(vals) if vals else None
    return out


# ---------------------------------------------------------------------------
# Walking the old folder tree
# ---------------------------------------------------------------------------

def parse_dir_buffer(buf, base: int) -> Tuple[List[Dict], bool]:
    """Entry sets of a directory's clusters, in order. Returns (entries, reached_end_marker)."""
    out = []
    i = 0
    n = len(buf)
    while i + 32 <= n:
        t = buf[i]
        if t == 0x00:
            return out, True
        if t in (0x85, 0x05):
            e = parse_entry_set(buf, i)
            if e is not None:
                e["pos"] = base + i
                out.append(e)
                i += e["len"]
                continue
        i += 32
    return out, False


def walk_tree(src, G: int, H: int, count: int, seeds: List[Dict], orphans: List[Tuple[int, str]],
              cancel=None, progress: Optional[Callable[[float], None]] = None,
              log: Optional[Callable[[str], None]] = None, max_dirs: int = 200000) -> Dict:
    """Read every old directory reachable from the known ones.

    seeds: directory entries with a known path ({"first", "size", "contig", "path"});
    orphans: (cluster, name) of directory clusters whose own entry is lost.
    Returns {"entries": [...], "dirs_read": n, "fragmented_dirs": [...]}"""
    from collections import deque
    q = deque()
    seen = set()
    # directory clusters whose own entry is lost go first: what is inside them keeps their grouping
    for c, name in orphans:
        q.append((c, G, True, name))
    for e in seeds:
        q.append((e["first"], e["size"], e["contig"], e["path"]))
    entries: List[Dict] = []
    frag_dirs = []
    n_read = 0
    while q:
        if cancel and cancel():
            raise InterruptedError
        c, size, contig, path = q.popleft()
        if c in seen or c < 2 or c >= count + 2:
            continue
        seen.add(c)
        if n_read >= max_dirs:
            break
        size = max(G, size)
        nbytes = size if (contig or size <= G) else G
        try:
            buf = src.read_direct(H + (c - 2) * G, min(nbytes, 64 << 20))
        except OSError:
            continue
        n_read += 1
        found, _end = parse_dir_buffer(buf, H + (c - 2) * G)
        if not contig and size > G:
            frag_dirs.append({"path": path, "first": c, "size": size})
        for e in found:
            e["path"] = path + "/" + e["name"] if path else e["name"]
            e["dir_first"] = c
            entries.append(e)
            if e["dir"] and not e["deleted"] and e["first"] >= 2:
                q.append((e["first"], e["size"], e["contig"], e["path"]))
        if progress and n_read % 50 == 0:
            progress(min(0.99, n_read / float(n_read + len(q) + 1)))
    if log:
        log("Bejárt mappák: %d, talált bejegyzés: %d." % (n_read, len(entries)))
    return {"entries": entries, "dirs_read": n_read, "fragmented_dirs": frag_dirs, "visited": sorted(seen)}
