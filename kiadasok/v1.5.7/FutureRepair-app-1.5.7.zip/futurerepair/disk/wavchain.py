"""Putting a fragmented WAV (PCM) recording back together.

PCM audio has no structure inside the samples, so a candidate piece is judged by the sound
itself: across the piece boundary the waveform has to continue the way it went before it (a
second-order prediction from the samples before the boundary must fit the samples after it about
as well as it fits inside the recording), and the level must not jump. Pieces that are silent on
both sides cannot be told apart this way: there only the most likely position (the same gap as
before) is accepted, and the result says so. Chunks after the audio (LIST, iXML ...) must start
exactly where the header says.
"""
from __future__ import annotations

import struct
from typing import Dict, List, Optional, Tuple

from .pieces import PieceRebuild

WIN = 96            # frames looked at on each side of a boundary


def parse_wav_header(head: bytes, size: int) -> Optional[Dict]:
    if len(head) < 12 or head[8:12] != b"WAVE" or head[:4] not in (b"RIFF", b"RF64", b"BW64"):
        return None
    pos = 12
    fmt = None
    ds64_data = None
    while pos + 8 <= len(head):
        cid = head[pos:pos + 4]
        csz = struct.unpack_from("<I", head, pos + 4)[0]
        body = pos + 8
        if cid == b"ds64" and csz >= 24 and body + 24 <= len(head):
            ds64_data = struct.unpack_from("<Q", head, body + 8)[0]
        elif cid == b"fmt " and csz >= 16 and body + 16 <= len(head):
            tag, ch, rate, _brate, align, bits = struct.unpack_from("<HHIIHH", head, body)
            if tag == 0xFFFE and csz >= 40 and body + 40 <= len(head):
                tag = struct.unpack_from("<H", head, body + 24)[0]
            fmt = {"tag": tag, "channels": ch, "rate": rate, "align": align, "bits": bits}
        elif cid == b"data":
            dsz = ds64_data if (csz == 0xFFFFFFFF and ds64_data) else csz
            if fmt is None:
                return None
            end = min(size, body + dsz)
            return dict(fmt, data_start=body, data_end=end, data_size=dsz)
        if not all(32 <= c < 127 for c in cid):
            return None
        pos = body + csz + (csz & 1)
    return None


def _samples(b: bytes, fmt: Dict) -> List[List[float]]:
    """Per-channel sample values of whole frames in b."""
    ch, align, tag = fmt["channels"], fmt["align"], fmt["tag"]
    if ch < 1 or align < ch:
        return []
    bps = align // ch
    n = len(b) // align
    out = [[] for _ in range(ch)]
    for f in range(n):
        base = f * align
        for c in range(ch):
            o = base + c * bps
            s = b[o:o + bps]
            if tag == 3 and bps == 4:
                v = struct.unpack("<f", s)[0]
                if v != v or abs(v) > 1e3:
                    v = 0.0
            elif bps == 1:
                v = s[0] - 128
            else:
                v = int.from_bytes(s, "little", signed=True)
            out[c].append(float(v))
    return out


def junction(left: List[List[float]], right: List[List[float]], full_scale: float) -> Tuple[str, float]:
    """('silent'|'ok'|'bad', score) for the samples just before and after a boundary."""
    worst = 0.0
    loud = False
    weak = False
    for L, R in zip(left, right):
        if len(L) < 8 or len(R) < 8:
            continue
        rms_l = (sum(v * v for v in L) / len(L)) ** 0.5
        rms_r = (sum(v * v for v in R) / len(R)) ** 0.5
        quiet = full_scale * 1e-4
        if rms_l < quiet and rms_r < quiet:
            continue
        loud = True
        if (rms_l < quiet) != (rms_r < quiet):
            # sound starts or stops right at the boundary: possible, but weak evidence
            weak = True
            continue
        ratio = max(rms_l, rms_r) / max(1e-9, min(rms_l, rms_r))
        if ratio > 8:
            return "bad", 1e9
        res_l = [abs(L[i] - 2 * L[i - 1] + L[i - 2]) for i in range(2, len(L))]
        res_r = [abs(R[i] - 2 * R[i - 1] + R[i - 2]) for i in range(2, len(R))]
        typ = sorted(res_l + res_r)[(len(res_l) + len(res_r)) * 3 // 4] + full_scale * 1e-6
        x = L[-2:] + R[:3]
        jres = max(abs(x[i] - 2 * x[i - 1] + x[i - 2]) for i in range(2, len(x)))
        worst = max(worst, jres / typ)
    if not loud:
        return "silent", 0.0
    if worst == 0.0 and weak:
        return "weak", 0.0
    return ("ok" if worst < 6.0 else "bad"), worst


class WavRebuild(PieceRebuild):
    kind = "wav"

    def run(self) -> Dict:
        read0 = self.reader()
        head = read0(0, min(self.plen(0), 1 << 20))
        fmt = parse_wav_header(head, self.size)
        if fmt is None:
            return self.result("failed", "A fájl eleje nem WAV a lemezen.")
        if fmt["tag"] not in (1, 3) or fmt["bits"] not in (8, 16, 24, 32):
            return self.result("failed", "Ezt a hangformátumot (nem PCM) a program még nem rakja össze.")
        self.fmt = fmt
        self.full = float(1 << (fmt["bits"] - 1)) if fmt["tag"] == 1 else 1.0
        silent_guess = 0
        for k in range(1, self.K):
            if self.progress:
                self.progress(k / float(self.K))
            c, how = self._find(k)
            if c is None:
                return self.result("partial", "A %d darabból a %d.-at nem találtam meg." % (self.K, k + 1),
                                   missing_from=k, found=sorted(self.pieces))
            if how == "silent":
                silent_guess += 1
            self.pieces[k] = c
            self.claim(c, self.plen_cl(k))
        msg = "Teljes: %d darab, a hang folytonossága alapján." % self.K
        if silent_guess:
            msg += " %d darab határán csend van, ott a legvalószínűbb helyet választottam." % silent_guess
        return self.result("complete", msg, uncertain=silent_guess)

    def _frames_around(self, k: int, c: int):
        fmt = self.fmt
        b = k * self.U
        a = fmt["align"]
        ds, de = fmt["data_start"], fmt["data_end"]
        read = self.reader({k: c})
        if not (ds < b < de):
            return None
        f0 = (b - ds) // a                       # frame that the boundary cuts (or starts at b)
        lstart = ds + max(0, f0 - WIN) * a
        left = read(lstart, ds + f0 * a - lstart)
        rstart = ds + f0 * a
        right = read(rstart, min(de, rstart + (WIN + 1) * a) - rstart)
        return _samples(left, fmt), _samples(right, fmt), read

    def _check(self, k: int, c: int) -> Tuple[str, float]:
        fmt = self.fmt
        lo = k * self.U
        hi = lo + self.plen(k)
        read = self.reader({k: c})
        de = fmt["data_end"]
        # chunks after the audio must start right where the header says
        if lo <= de < hi and de + 8 <= self.size:
            h = read(de + (de & 1), 8)
            if len(h) == 8 and not all(32 <= ch < 127 for ch in h[:4]):
                return "bad", 1e9
        r = self._frames_around(k, c)
        if r is None:
            return ("ok", 0.0) if lo >= de else ("silent", 0.0)
        left, right, _ = r
        return junction(left, right, self.full)

    def _find(self, k: int) -> Tuple[Optional[int], str]:
        n = self.plen_cl(k)
        scored: Dict[int, Tuple[str, float]] = {}
        silent_first = None
        window = 16384                      # clusters (4 GB) looked through when the usual places fail
        for i, c in enumerate(self.candidates(k)):
            if i % 256 == 0:
                self.cancelled()
            if i >= 16 + window:
                break
            if not self.free(c, n) or c in scored:
                continue
            self.tried += 1
            st, sc = self._check(k, c)
            scored[c] = (st, sc)
            if st == "ok" and sc < (3.0 if i < 16 else 1.5):
                return c, "ok"
            if st in ("silent", "weak") and silent_first is None and i < 16:
                silent_first = c
        best = sorted((sc, c) for c, (st, sc) in scored.items() if st == "ok")
        if best and (len(best) == 1 or best[0][0] < 0.6 * best[1][0]):
            return best[0][1], "ok"
        if silent_first is not None:
            return silent_first, "silent"
        if best:
            return best[0][1], "silent"
        return None, ""
