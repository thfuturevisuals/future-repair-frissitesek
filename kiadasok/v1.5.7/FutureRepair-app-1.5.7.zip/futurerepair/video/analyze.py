"""Builds track models from a healthy reference file (or from the broken file's own moov)."""
from __future__ import annotations

import mmap
import os
from collections import Counter
from dataclasses import dataclass, field
from typing import List, Optional, Tuple

from . import entries as E
from .h264 import H264, parse_avcc
from .hevc import HEVC, parse_hvcc
from .models import AacModel, FixedModel, GpmfModel, MJPEGModel, Model, NalVideoModel, PcmModel, ProResModel
from .mp4 import Movie, Track, parse_moov, read_box_payload, scan_top_level


class RepairError(Exception):
    """A user-facing error (message is shown in the UI)."""


@dataclass
class FileLayout:
    size: int
    ftyp: bytes = b""
    moov: Optional[Movie] = None
    moov_box: Optional[object] = None
    mdat_start: int = -1           # first payload byte of mdat
    mdat_end: int = -1             # end of mdat payload (clamped to file size)
    mdat_declared_end: int = -1
    top: list = field(default_factory=list)
    fragmented: bool = False
    notes: List[str] = field(default_factory=list)


def read_layout(path: str) -> FileLayout:
    size = os.path.getsize(path)
    lay = FileLayout(size)
    with open(path, "rb") as f:
        top = scan_top_level(f, size)
        lay.top = top
        for b in top:
            if b.type == b"ftyp" and not lay.ftyp and b.size < 4096:
                f.seek(b.start)
                lay.ftyp = f.read(b.size)
            elif b.type == b"moov" and lay.moov is None and not b.truncated and b.size < 1 << 31:
                payload = read_box_payload(f, b)
                try:
                    lay.moov = parse_moov(payload, b.data_start)
                    lay.moov_box = b
                except Exception:  # noqa: BLE001 - corrupt moov is treated as missing
                    lay.notes.append("moov_corrupt")
                    lay.moov = None
            elif b.type == b"mdat" and lay.mdat_start < 0:
                lay.mdat_start = b.data_start
                lay.mdat_declared_end = b.start + b.size
                lay.mdat_end = min(size, b.start + b.size)
            elif b.type == b"moof":
                lay.fragmented = True
        if lay.mdat_start < 0:
            # Header damaged or unusual: look for an 'mdat' tag in the first 64 MB.
            f.seek(0)
            head = f.read(min(size, 64 * 1024 * 1024))
            i = head.find(b"mdat")
            if i >= 4:
                lay.mdat_start = i + 4
                declared = int.from_bytes(head[i - 4:i], "big")
                if declared == 1 and i + 12 <= len(head):
                    lay.mdat_start = i + 12
                    declared = int.from_bytes(head[i + 4:i + 12], "big")
                lay.mdat_end = size if declared in (0, 1) else min(size, i - 4 + declared)
                lay.mdat_declared_end = i - 4 + declared if declared > 1 else size
                lay.notes.append("mdat_found_by_search")
            else:
                lay.mdat_start = 0
                lay.mdat_end = size
                lay.notes.append("no_mdat")
    return lay


# ---------------------------------------------------------------------------

@dataclass
class Profile:
    movie: Movie
    layout: FileLayout
    models: List[Model]
    track_of_model: List[Optional[Track]]
    transitions: Counter
    video_codec: str = ""
    notes: List[str] = field(default_factory=list)
    sync_i_frames: bool = False      # reference marks non-IDR I-frames as sync samples


def _track_chunks(movie: Movie) -> List[Tuple[int, int, int, int]]:
    """All chunks of all tracks: (offset, track index, samples, stsz bytes) sorted by offset."""
    out = []
    for ti, t in enumerate(movie.tracks):
        si = 0
        for ci, off in enumerate(t.chunk_offsets):
            k = t.chunk_samples[ci]
            out.append((off, ti, k, sum(t.sizes[si:si + k])))
            si += k
    out.sort()
    return out


def _video_model(t: Track, mm, notes: List[str]) -> Optional[Model]:
    fourcc = t.codec
    if fourcc in E.AVC_CODECS or fourcc in E.HEVC_CODECS:
        typ, cfg = E.video_config(t.sample_entry)
        if typ == b"avcC":
            nls, sps, pps = parse_avcc(cfg)
            codec = H264(nls)
            for n in sps + pps:
                codec.add_param_set(n)
        elif typ == b"hvcC":
            nls, nals = parse_hvcc(cfg)
            codec = HEVC(nls)
            for n in nals:
                codec.add_param_set(n)
        else:
            notes.append("video_config_missing")
            return None
        model = NalVideoModel(codec)
        # Learn the frame structure from the first frames of the reference.
        aus = []
        mismatch = 0
        n = min(len(t.sizes), 600)
        for i in range(n):
            off, sz = t.offsets[i], t.sizes[i]
            if off + sz > len(mm):
                break
            a = codec.parse_au(mm, off, off + sz, strict=False)
            if a is None:
                mismatch += 1
                continue
            if a.length != sz:
                mismatch += 1
            aus.append(a)
        if not aus:
            notes.append("video_unparsable")
            return None
        if mismatch > n * 0.2:
            notes.append("video_au_mismatch")
        codec.learn(aus)
        lengths = [a.length for a in aus]
        model.min_au = max(1, min(lengths) // 16)
        model.max_au = min(codec.max_au, max(max(lengths) * 4, 1024 * 1024))
        codec.max_au = model.max_au
        # every frame starts with an AUD of the same length?
        aud_lens = set()
        for i, a in enumerate(aus):
            if not a.nal_types or a.nal_types[0] not in (9, 35):
                aud_lens = None
                break
            off = t.offsets[i]
            aud_lens.add(int.from_bytes(mm[off:off + codec.nls], "big"))
        if aud_lens and len(aud_lens) == 1:
            model.aud_len = aud_lens.pop()
        spc = Counter(t.chunk_samples)
        if spc:
            top, cnt = spc.most_common(1)[0]
            if cnt >= 0.98 * sum(spc.values()):
                model.max_per_chunk = max(spc)          # camera-style fixed interleave
            else:
                model.max_per_chunk = max(spc) * 2 + 2
        else:
            model.max_per_chunk = 4096
        return model
    if fourcc in E.PRORES_CODECS:
        return ProResModel()
    if fourcc in E.MJPEG_CODECS:
        return MJPEGModel()
    notes.append("video_codec_unsupported:" + fourcc.decode("latin-1"))
    return None


def _measure_units(t: Track, chunks, ti: int, data_end: int) -> int:
    """Real bytes per stsz sample for fixed-size tracks, measured from chunk spacing."""
    if t.stsz_const > 1:
        return t.stsz_const
    ratios = Counter()
    for i, (off, tix, k, _b) in enumerate(chunks):
        if tix != ti or k == 0:
            continue
        nxt = chunks[i + 1][0] if i + 1 < len(chunks) else data_end
        span = nxt - off
        if span > 0 and span % k == 0:
            ratios[span // k] += 1
    if ratios:
        return ratios.most_common(1)[0][0]
    return max(1, t.stsz_const)


def build_profile(path: str, layout: Optional[FileLayout] = None, max_learn_bytes: int = 0) -> Profile:
    lay = layout or read_layout(path)
    if lay.moov is None:
        raise RepairError("A mintafájlban nincs olvasható 'moov' (index) rész, ezért mintának nem használható.")
    movie = lay.moov
    notes: List[str] = []
    models: List[Model] = []
    track_of_model: List[Optional[Track]] = []
    with open(path, "rb") as f:
        mm = mmap.mmap(f.fileno(), 0, access=mmap.ACCESS_READ)
        try:
            chunks = _track_chunks(movie)
            data_end = lay.mdat_end if lay.mdat_end > 0 else lay.size
            model_of_track = {}
            video_done = False
            sync_i = False
            for ti, t in enumerate(movie.tracks):
                m: Optional[Model] = None
                if t.is_video and not video_done:
                    m = _video_model(t, mm, notes)
                    if m is not None:
                        video_done = True
                        if isinstance(m, NalVideoModel) and t.sync is not None:
                            # does the reference mark non-IDR I-frames as sync samples?
                            for i in sorted(t.sync)[:50]:
                                if i < len(t.offsets):
                                    a = m.codec.parse_au(mm, t.offsets[i], t.offsets[i] + t.sizes[i], strict=False)
                                    if a is not None and not getattr(a, "idr", a.keyframe):
                                        sync_i = True
                                        break
                elif t.is_audio:
                    info = E.audio_info(t.sample_entry)
                    if t.codec in E.AAC_CODECS and info.asc:
                        try:
                            am = AacModel("audio", info.asc)
                        except Exception as e:  # noqa: BLE001
                            notes.append("aac_decoder_error:%s" % e)
                            am = None
                        if am is not None:
                            am.frames_per_chunk = Counter(t.chunk_samples)
                            if t.sizes:
                                am.avg_frame = int(sum(t.sizes[:2000]) / len(t.sizes[:2000]))
                            am.finalize()
                            m = am
                    elif t.codec in E.PCM_CODECS:
                        unit = _measure_units(t, chunks, ti, data_end)
                        pm = PcmModel("audio", unit)
                        for k in t.chunk_samples:
                            pm.size_counts[k * unit] += 1
                        pm.finalize()
                        m = pm
                    else:
                        notes.append("audio_codec_unsupported:" + t.codec.decode("latin-1"))
                        if t.stsz_const:
                            fm = FixedModel("other", t.stsz_const, output=False, kind="other")
                            for k in t.chunk_samples:
                                fm.size_counts[k * t.stsz_const] += 1
                            fm.finalize()
                            m = fm
                elif t.is_video:
                    notes.append("extra_video_track")
                else:
                    if t.codec == b"gpmd":
                        m = GpmfModel("gpmd")
                    elif t.stsz_const or (t.sizes and len(set(t.sizes[:500])) == 1):
                        unit = t.stsz_const or t.sizes[0]
                        fm = FixedModel(t.handler.decode("latin-1", "replace"), unit, output=False, kind="other")
                        for k in t.chunk_samples:
                            fm.size_counts[k * unit] += 1
                        fm.finalize()
                        m = fm
                    elif t.sizes:
                        # variable-size metadata: remember the chunk sizes seen in the reference
                        fm = FixedModel(t.handler.decode("latin-1", "replace"), 1, output=False, kind="other")
                        si = 0
                        for k in t.chunk_samples:
                            fm.size_counts[sum(t.sizes[si:si + k])] += 1
                            si += k
                        fm.finalize()
                        fm.max_size = min(fm.max_size, 1 << 20)
                        m = fm
                if m is not None:
                    model_of_track[ti] = len(models)
                    models.append(m)
                    track_of_model.append(t)
                    m.ref_track = t
            # transition statistics between models (in file order)
            trans: Counter = Counter()
            prev = -1
            for off, ti, k, _b in chunks:
                mi = model_of_track.get(ti)
                if mi is None:
                    continue
                trans[(prev, mi)] += 1
                trans[("any", mi)] += 1
                prev = mi
        finally:
            mm.close()
    vcodec = ""
    for m in models:
        if isinstance(m, NalVideoModel):
            vcodec = m.codec.name
        elif isinstance(m, ProResModel):
            vcodec = "prores"
        elif isinstance(m, MJPEGModel):
            vcodec = "mjpeg"
    prof = Profile(movie, lay, models, track_of_model, trans, vcodec, notes)
    prof.sync_i_frames = sync_i
    return prof
