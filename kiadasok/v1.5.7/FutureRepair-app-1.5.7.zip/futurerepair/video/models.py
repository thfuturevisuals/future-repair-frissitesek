"""Track models: how to recognise and delimit the chunks of one track inside raw mdat data."""
from __future__ import annotations

import re
from collections import Counter
from dataclasses import dataclass, field
from typing import List, Optional

from .bits import be32
from .h264 import H264
from .hevc import HEVC


@dataclass
class Chunk:
    start: int
    end: int
    sizes: List[int]                 # byte size of each sample written to stsz
    infos: list = field(default_factory=list)   # per-sample codec info (video AUs)
    units: int = 0                   # number of stsz samples (PCM)


class Model:
    """Base class. `selfdesc` models can recognise their own chunk starts."""
    kind = "other"          # 'video' | 'audio' | 'other'
    selfdesc = False

    def __init__(self, name: str, output: bool = False):
        self.name = name
        self.output = output
        self.ref_track = None          # mp4.Track from reference (if any)
        self.index = -1
        self.chunks: List[Chunk] = []
        self.max_per_chunk = 4096

    # self-describing models
    def match(self, mm, p: int, end: int) -> bool:
        return False

    def unit_len(self, mm, p: int, end: int) -> Optional[int]:
        return None

    def partial_start(self, mm, p: int, end: int) -> bool:
        """A unit of this track starts at p but is cut off by the end of the data."""
        return False

    def candidates(self, mm, start: int, end: int):
        """Yield possible chunk start positions >= start (fast pre-filter)."""
        return iter(())

    def read_chunk(self, sc, p: int) -> Optional[Chunk]:
        return None

    @property
    def nsamples(self) -> int:
        return sum(len(c.sizes) for c in self.chunks) if self.kind != "audio_pcm" else sum(c.units for c in self.chunks)


# ---------------------------------------------------------------------------
# Video: H.264 / HEVC (length-prefixed NAL units)
# ---------------------------------------------------------------------------

class NalVideoModel(Model):
    kind = "video"
    selfdesc = True

    def __init__(self, codec, name: str = "video"):
        super().__init__(name, output=True)
        self.codec = codec
        self.min_au = 1
        self.max_au = codec.max_au
        self._re = None
        self.aud_len = None    # length of AUD NAL if every frame starts with one

    def _build_regex(self):
        nls = self.codec.nls
        heads = sorted(self.codec.first_nal_headers())
        cls = b"[" + b"".join(re.escape(bytes([h])) for h in heads) + b"]"
        if self.aud_len is not None and nls == 4:
            # Every frame starts with an access-unit delimiter: very specific pattern.
            if isinstance(self.codec, H264):
                pat = b"\x00\x00\x00" + bytes([self.aud_len]) + b"[\x09]"
            else:
                pat = b"\x00\x00\x00" + bytes([self.aud_len]) + b"\x46\x01"
        elif nls == 4:
            pat = b"\x00[\x00-\x05]..(?=" + cls + b")"
        elif nls == 2:
            pat = b"..(?=" + cls + b")"
        else:
            pat = b".(?=" + cls + b")"
        self._re = re.compile(pat, re.DOTALL)

    def candidates(self, mm, start, end):
        if self._re is None:
            self._build_regex()
        if hasattr(mm, "finditer"):
            yield from mm.finditer(self._re, start, end)
            return
        for m in self._re.finditer(mm, start, end):
            yield m.start()

    def unit_len(self, mm, p, end):
        a = self.codec.parse_au(mm, p, end, strict=True)
        if a is None or not self._plausible(a):
            return None
        return a.length

    def match(self, mm, p, end):
        return self.unit_len(mm, p, end) is not None

    def partial_start(self, mm, p, end):
        nls = self.codec.nls
        if p + nls + 2 > end:
            return p < end
        ln = int.from_bytes(mm[p:p + nls], "big")
        if ln < 1 or ln > self.max_au or p + nls + ln <= end:
            return False
        h = mm[p + nls]
        if h & 0x80:
            return False
        if isinstance(self.codec, H264):
            t = h & 0x1F
        else:
            t = (h >> 1) & 0x3F
        first = self.codec.allowed_first
        return first is None or t in first

    def _plausible(self, a) -> bool:
        if a.length < self.min_au or a.length > self.max_au:
            return False
        if self.aud_len is not None and a.nal_types and a.nal_types[0] not in (9, 35):
            return False
        return True

    def read_chunk(self, sc, p):
        mm, end = sc.mm, sc.end
        a = self.codec.parse_au(mm, p, end, strict=True)
        if a is None or not self._plausible(a):
            return None
        aus = [a]
        q = p + a.length
        while q < end and len(aus) < self.max_per_chunk:
            b = self.codec.parse_au(mm, q, end, strict=True)
            if b is None or not self._plausible(b):
                break
            aus.append(b)
            q += b.length
        return Chunk(p, q, [x.length for x in aus], aus)


# ---------------------------------------------------------------------------
# Video: Apple ProRes (each frame: 4-byte size + 'icpf')
# ---------------------------------------------------------------------------

class ProResModel(Model):
    kind = "video"
    selfdesc = True

    def __init__(self, name="video"):
        super().__init__(name, output=True)
        self.max_frame = 512 * 1024 * 1024

    def _frame(self, mm, p, end):
        if p + 8 > end:
            return None
        if mm[p + 4:p + 8] != b"icpf":
            return None
        n = be32(mm[p:p + 4])
        if n < 28 or n > self.max_frame or p + n > end:
            return None
        return n

    def unit_len(self, mm, p, end):
        return self._frame(mm, p, end)

    def partial_start(self, mm, p, end):
        if p + 8 > end:
            return p < end
        n = be32(mm[p:p + 4])
        return mm[p + 4:p + 8] == b"icpf" and p + n > end and n <= self.max_frame

    def match(self, mm, p, end):
        return self._frame(mm, p, end) is not None

    def candidates(self, mm, start, end):
        i = mm.find(b"icpf", start + 4, end)
        while i != -1:
            yield i - 4
            i = mm.find(b"icpf", i + 1, end)

    def read_chunk(self, sc, p):
        mm, end = sc.mm, sc.end
        n = self._frame(mm, p, end)
        if n is None:
            return None
        sizes = [n]
        q = p + n
        while q < end and len(sizes) < self.max_per_chunk:
            n = self._frame(mm, q, end)
            if n is None:
                break
            sizes.append(n)
            q += n
        return Chunk(p, q, sizes, [None] * len(sizes))


# ---------------------------------------------------------------------------
# Video: Motion JPEG (each frame starts with FFD8 and ends with FFD9)
# ---------------------------------------------------------------------------

class MJPEGModel(Model):
    kind = "video"
    selfdesc = True

    def __init__(self, name="video"):
        super().__init__(name, output=True)
        self.max_frame = 64 * 1024 * 1024

    def _frame(self, mm, p, end):
        if mm[p:p + 3] != b"\xff\xd8\xff":
            return None
        e = mm.find(b"\xff\xd9", p + 3, min(end, p + self.max_frame))
        if e == -1:
            return None
        return e + 2 - p

    def unit_len(self, mm, p, end):
        return self._frame(mm, p, end)

    def partial_start(self, mm, p, end):
        return mm[p:p + 3] == b"\xff\xd8\xff" and self._frame(mm, p, end) is None

    def match(self, mm, p, end):
        return self._frame(mm, p, end) is not None

    def candidates(self, mm, start, end):
        i = mm.find(b"\xff\xd8\xff", start, end)
        while i != -1:
            yield i
            i = mm.find(b"\xff\xd8\xff", i + 1, end)

    def read_chunk(self, sc, p):
        mm, end = sc.mm, sc.end
        n = self._frame(mm, p, end)
        if n is None:
            return None
        sizes = [n]
        q = p + n
        while q < end and len(sizes) < self.max_per_chunk:
            n = self._frame(mm, q, end)
            if n is None:
                break
            sizes.append(n)
            q += n
        return Chunk(p, q, sizes, [None] * len(sizes))


# ---------------------------------------------------------------------------
# GoPro GPMF telemetry ('DEVC' KLV) - recognised so it can be skipped
# ---------------------------------------------------------------------------

class GpmfModel(Model):
    kind = "other"
    selfdesc = True

    def _sample(self, mm, p, end):
        if p + 8 > end or mm[p:p + 4] != b"DEVC" or mm[p + 4] != 0:
            return None
        n = mm[p + 5] * int.from_bytes(mm[p + 6:p + 8], "big")
        n = 8 + ((n + 3) & ~3)
        if p + n > end:
            return None
        return n

    def unit_len(self, mm, p, end):
        return self._sample(mm, p, end)

    def match(self, mm, p, end):
        return self._sample(mm, p, end) is not None

    def candidates(self, mm, start, end):
        i = mm.find(b"DEVC", start, end)
        while i != -1:
            yield i
            i = mm.find(b"DEVC", i + 1, end)

    def read_chunk(self, sc, p):
        mm, end = sc.mm, sc.end
        n = self._sample(mm, p, end)
        if n is None:
            return None
        sizes = [n]
        q = p + n
        while q < end and len(sizes) < 64:
            n = self._sample(mm, q, end)
            if n is None:
                break
            sizes.append(n)
            q += n
        return Chunk(p, q, sizes)


# ---------------------------------------------------------------------------
# Fixed-size data (PCM audio, timecode, fixed metadata)
# ---------------------------------------------------------------------------

class FixedModel(Model):
    """Chunks whose byte size can't be read from the data itself.

    `unit` is the number of bytes per stsz sample, chunk sizes are learned
    from the reference file.
    """

    def __init__(self, name: str, unit: int, output: bool, kind: str):
        super().__init__(name, output=output)
        self.kind = kind
        self.unit = max(1, unit)
        self.size_counts: Counter = Counter()
        self.sizes: List[int] = []
        self.min_size = self.unit
        self.max_size = self.unit * 48000

    def finalize(self):
        self.sizes = [s for s, _ in self.size_counts.most_common(12)]
        if self.size_counts:
            self.min_size = min(self.size_counts)
            self.max_size = max(self.size_counts)

    def read_chunk(self, sc, p):
        end = sc.end
        for s in self.sizes:
            if p + s <= end and sc.strong_start(p + s, depth=1, exclude=self):
                return self._chunk(p, s)
        if getattr(sc, "fast", False):
            return None
        # fall back: any multiple of the unit size up to a few times the largest chunk
        u = self.unit
        lo = max(u, (self.min_size // 2) // u * u)
        hi = max(self.max_size * 3, u * 4)
        s = lo
        while s <= hi and p + s <= end:
            if sc.confirmed_start(p + s):
                return self._chunk(p, s)
            s += u
        return None

    def _chunk(self, p, s):
        units = s // self.unit
        return Chunk(p, p + s, [self.unit] * units if self.kind != "audio_pcm" else [], units=units)


class PcmModel(FixedModel):
    def __init__(self, name: str, unit: int):
        super().__init__(name, unit, output=True, kind="audio_pcm")


# ---------------------------------------------------------------------------
# AAC audio (raw frames, boundaries found by trial decoding)
# ---------------------------------------------------------------------------

class AacProber:
    MAX_FRAME = 8192

    def __init__(self, asc: bytes):
        import av  # noqa: WPS433 (optional heavy import)
        av.logging.set_level(None)
        self._av = av
        self.cc = av.CodecContext.create("aac", "r")
        self.cc.extradata = asc
        self.cc.open()
        self.calls = 0

    def _ok(self, data: bytes) -> bool:
        self.calls += 1
        try:
            frames = self.cc.decode(self._av.Packet(data))
        except Exception:  # noqa: BLE001 - any decoder error means "not a whole frame"
            return False
        return len(frames) > 0

    def frame_len(self, mm, p: int, end: int, hint: int = 0) -> Optional[int]:
        hi = min(end - p, self.MAX_FRAME)
        if hi <= 1:
            return None
        data = bytes(mm[p:p + hi])
        # try a window around the hint first (cheap), then the full range
        if hint and hint * 3 < hi:
            w = hint * 3
            if self._ok(data[:w]):
                hi = w
            elif not self._ok(data):
                return None
        elif not self._ok(data):
            return None
        lo = 0
        while hi - lo > 1:
            mid = (lo + hi) // 2
            if self._ok(data[:mid]):
                hi = mid
            else:
                lo = mid
        return hi


class AacModel(Model):
    kind = "audio_aac"

    def __init__(self, name: str, asc: bytes):
        super().__init__(name, output=True)
        self.prober = AacProber(asc)
        self.frames_per_chunk: Counter = Counter()
        self.avg_frame = 0
        self.fixed_count = 0

    def looks_like_start(self, sc, r: int) -> bool:
        mm, end = sc.mm, sc.end
        n1 = self.prober.frame_len(mm, r, end, self.avg_frame)
        if n1 is None:
            return False
        r2 = r + n1
        if r2 >= end or sc.strong_start(r2, depth=0):
            return True
        return self.prober.frame_len(mm, r2, end, self.avg_frame) is not None

    def finalize(self):
        if self.frames_per_chunk:
            top, cnt = self.frames_per_chunk.most_common(1)[0]
            total = sum(self.frames_per_chunk.values())
            if cnt >= 0.9 * total:
                self.fixed_count = top
            self.max_per_chunk = max(self.frames_per_chunk) * 2 + 2

    def read_chunk(self, sc, p):
        mm, end = sc.mm, sc.end
        sizes = []
        q = p
        limit = self.fixed_count or self.max_per_chunk
        while q < end and len(sizes) < limit:
            if sizes and sc.strong_start(q, depth=1, exclude=self):
                break
            n = self.prober.frame_len(mm, q, end, self.avg_frame)
            if n is None:
                break
            if q + n < end and not sc.strong_start(q + n, depth=1, exclude=self):
                # The decoder may accept a too-long packet when non-AAC data follows the
                # last frame of a chunk: look for a real chunk start inside this frame.
                j = sc.find_start_in(q + 1, q + n)
                if j is not None and self.prober._ok(bytes(mm[q:j])):
                    sizes.append(j - q)
                    q = j
                    break
            sizes.append(n)
            q += n
        if not sizes:
            return None
        if self.fixed_count and len(sizes) < self.fixed_count and q < end and not sc.strong_start(q, depth=1, exclude=self):
            # an unexpected short chunk that is not followed by a known start: likely garbage
            if len(sizes) < max(1, self.fixed_count // 4):
                return None
        return Chunk(p, q, sizes)
