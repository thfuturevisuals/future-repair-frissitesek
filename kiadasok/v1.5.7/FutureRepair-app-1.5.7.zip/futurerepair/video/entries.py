"""Sample-entry helpers: codec configuration extraction and patching."""
from __future__ import annotations

import struct
from dataclasses import dataclass
from typing import List, Optional, Tuple

from .bits import be16, be32
from .mp4 import make_box

VIDEO_HEADER = 86          # size+type(8) + 78 bytes VisualSampleEntry fields
AUDIO_HEADER_V0 = 36       # size+type(8) + 28 bytes AudioSampleEntry fields

AVC_CODECS = {b"avc1", b"avc3", b"avc2", b"avc4", b"ai5p", b"ai5q", b"ai52", b"ai53", b"ai55",
              b"ai56", b"aivx", b"AVin", b"ai1p", b"ai1q", b"ai12", b"ai13", b"ai15", b"ai16",
              b"xalg"}
HEVC_CODECS = {b"hvc1", b"hev1", b"dvh1", b"dvhe"}
PRORES_CODECS = {b"apch", b"apcn", b"apcs", b"apco", b"ap4h", b"ap4x", b"aprh", b"aprn"}
MJPEG_CODECS = {b"jpeg", b"mjpa", b"mjpb", b"AVDJ", b"dmb1"}
AAC_CODECS = {b"mp4a"}
PCM_CODECS = {b"twos", b"sowt", b"raw ", b"in24", b"in32", b"fl32", b"fl64", b"lpcm",
              b"ipcm", b"fpcm", b"NONE", b"ulaw", b"alaw"}


def iter_child_boxes(entry: bytes, start: int):
    o = start
    while o + 8 <= len(entry):
        sz = be32(entry, o)
        typ = entry[o + 4:o + 8]
        if sz < 8 or o + sz > len(entry):
            break
        yield typ, o, sz
        o += sz


def find_box_recursive(data: bytes, typ: bytes) -> Optional[Tuple[int, int]]:
    """Find a box by scanning for its fourcc (works through nested wave/etc)."""
    i = data.find(typ)
    while i >= 4:
        sz = be32(data, i - 4)
        if 8 <= sz <= len(data) - (i - 4):
            return i - 4, sz
        i = data.find(typ, i + 1)
    return None


def video_config(entry: bytes) -> Tuple[Optional[bytes], Optional[bytes]]:
    """-> (config box type, config payload) e.g. (b'avcC', payload)."""
    for typ, o, sz in iter_child_boxes(entry, VIDEO_HEADER):
        if typ in (b"avcC", b"hvcC"):
            return typ, entry[o + 8:o + sz]
    for typ in (b"avcC", b"hvcC"):
        r = find_box_recursive(entry[VIDEO_HEADER:], typ)
        if r:
            o, sz = r
            o += VIDEO_HEADER
            return typ, entry[o + 8:o + sz]
    return None, None


def video_dims(entry: bytes) -> Tuple[int, int]:
    return be16(entry, 32), be16(entry, 34)


def replace_video_config(entry: bytes, cfg_type: bytes, payload: bytes,
                         width: int = 0, height: int = 0) -> bytes:
    """Return a copy of the sample entry with its avcC/hvcC replaced."""
    out = bytearray(entry[:VIDEO_HEADER])
    if width and height:
        out[32:34] = width.to_bytes(2, "big")
        out[34:36] = height.to_bytes(2, "big")
    replaced = False
    for typ, o, sz in iter_child_boxes(entry, VIDEO_HEADER):
        if typ == cfg_type and not replaced:
            out += make_box(cfg_type, payload)
            replaced = True
        else:
            out += entry[o:o + sz]
    if not replaced:
        out += make_box(cfg_type, payload)
    out[0:4] = len(out).to_bytes(4, "big")
    return bytes(out)


def make_video_entry(fourcc: bytes, width: int, height: int, cfg_type: bytes, cfg: bytes,
                     extra_boxes: bytes = b"") -> bytes:
    body = b"\x00" * 6 + struct.pack(">H", 1)
    body += b"\x00" * 16
    body += struct.pack(">HHIIIH", width, height, 0x00480000, 0x00480000, 0, 1)
    name = b"Future Repair"
    body += bytes([len(name)]) + name + b"\x00" * (31 - len(name))
    body += struct.pack(">Hh", 0x18, -1)
    body += make_box(cfg_type, cfg) + extra_boxes
    return make_box(fourcc, body)


def make_stsd(entries: List[bytes]) -> bytes:
    return make_box(b"stsd", struct.pack(">II", 0, len(entries)) + b"".join(entries))


# --------------------------------------------------------------------------
# Audio
# --------------------------------------------------------------------------

@dataclass
class AudioInfo:
    channels: int
    sample_rate: int
    bits: int
    bytes_per_frame: int = 0       # for PCM
    asc: bytes = b""               # AudioSpecificConfig for AAC
    version: int = 0


def _read_desc_len(b: bytes, o: int) -> Tuple[int, int]:
    ln = 0
    for _ in range(4):
        c = b[o]
        o += 1
        ln = (ln << 7) | (c & 0x7F)
        if not c & 0x80:
            break
    return ln, o


def parse_esds_asc(esds_payload: bytes) -> bytes:
    """Extract the AudioSpecificConfig from an esds payload (after version/flags)."""
    b = esds_payload[4:]
    o = 0
    if o >= len(b) or b[o] != 0x03:
        return b""
    o += 1
    _, o = _read_desc_len(b, o)
    o += 2  # ES_ID
    flags = b[o]
    o += 1
    if flags & 0x80:
        o += 2
    if flags & 0x40:
        o += 1 + b[o]
    if flags & 0x20:
        o += 2
    if o >= len(b) or b[o] != 0x04:
        return b""
    o += 1
    _, o = _read_desc_len(b, o)
    o += 13
    if o >= len(b) or b[o] != 0x05:
        return b""
    o += 1
    ln, o = _read_desc_len(b, o)
    return b[o:o + ln]


def audio_info(entry: bytes) -> AudioInfo:
    ver = be16(entry, 16)
    ch = be16(entry, 24)
    bits = be16(entry, 26)
    rate = be32(entry, 32) >> 16
    info = AudioInfo(ch, rate, bits, version=ver)
    fourcc = entry[4:8]
    if ver == 1 and len(entry) >= 52:
        bpf = be32(entry, 44)
        info.bytes_per_frame = bpf
    elif ver == 2 and len(entry) >= 72:
        rate_f = struct.unpack(">d", entry[40:48])[0]
        info.sample_rate = int(round(rate_f))
        info.channels = be32(entry, 48)
        info.bits = be32(entry, 56)
        info.bytes_per_frame = be32(entry, 64)
    if not info.bytes_per_frame:
        b = info.bits
        if fourcc == b"in24":
            b = 24
        elif fourcc in (b"in32", b"fl32"):
            b = 32
        elif fourcc == b"fl64":
            b = 64
        elif fourcc in (b"ulaw", b"alaw", b"raw "):
            b = 8 if fourcc != b"raw " else (b or 8)
        info.bytes_per_frame = max(1, (b // 8) * max(1, info.channels))
    r = find_box_recursive(entry[28:], b"esds")
    if r:
        o, sz = r
        o += 28
        try:
            info.asc = parse_esds_asc(entry[o + 8:o + sz])
        except IndexError:
            info.asc = b""
    return info


AAC_RATES = [96000, 88200, 64000, 48000, 44100, 32000, 24000, 22050, 16000, 12000, 11025, 8000, 7350]


def make_asc(sample_rate: int, channels: int, object_type: int = 2) -> bytes:
    idx = AAC_RATES.index(sample_rate) if sample_rate in AAC_RATES else 3
    v = (object_type << 11) | (idx << 7) | (channels << 3)
    return v.to_bytes(2, "big")


def make_esds(asc: bytes, avg_bitrate: int = 0, max_bitrate: int = 0) -> bytes:
    dsi = b"\x05" + bytes([len(asc)]) + asc
    dcd_body = bytes([0x40, 0x15]) + b"\x00\x18\x00" + struct.pack(">II", max_bitrate, avg_bitrate) + dsi
    dcd = b"\x04" + bytes([len(dcd_body)]) + dcd_body
    sl = b"\x06\x01\x02"
    es_body = b"\x00\x01\x00" + dcd + sl
    es = b"\x03" + bytes([len(es_body)]) + es_body
    return make_box(b"esds", b"\x00\x00\x00\x00" + es)


def make_mp4a_entry(sample_rate: int, channels: int, asc: bytes) -> bytes:
    body = b"\x00" * 6 + struct.pack(">H", 1) + b"\x00" * 8
    body += struct.pack(">HHHHI", channels, 16, 0, 0, (sample_rate if sample_rate < 65536 else 0) << 16)
    body += make_esds(asc)
    return make_box(b"mp4a", body)
