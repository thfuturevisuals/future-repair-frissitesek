"""Minimal ISO-BMFF / QuickTime box reader and writer.

Only what the repair engine needs: top-level scanning of (possibly broken)
files, parsing a moov tree into tracks with full sample tables, and
serialising new boxes.
"""
from __future__ import annotations

import struct
from dataclasses import dataclass, field
from typing import BinaryIO, List, Optional

from .bits import be16, be32, be64

CONTAINERS = {
    b"moov", b"trak", b"mdia", b"minf", b"stbl", b"edts", b"dinf",
    b"mvex", b"moof", b"traf", b"tref", b"tapt", b"gmhd",
}

# Box types that may legally appear at the top level of a file.
TOP_LEVEL = {
    b"ftyp", b"moov", b"mdat", b"free", b"skip", b"wide", b"uuid",
    b"pnot", b"PICT", b"meta", b"moof", b"mfra", b"styp", b"sidx",
    b"pdin", b"junk", b"prfl", b"udta", b"ssix", b"emsg", b"prft",
}


@dataclass
class Box:
    type: bytes
    start: int          # absolute offset of the box header
    size: int           # total size including header
    header: int         # header size (8 or 16)
    payload: bytes = b""  # payload bytes (only for in-memory parsed boxes)
    children: List["Box"] = field(default_factory=list)
    truncated: bool = False

    @property
    def end(self) -> int:
        return self.start + self.size

    @property
    def data_start(self) -> int:
        return self.start + self.header

    def find(self, *path: bytes) -> Optional["Box"]:
        node: Optional[Box] = self
        for p in path:
            if node is None:
                return None
            node = next((c for c in node.children if c.type == p), None)
        return node

    def find_all(self, t: bytes) -> List["Box"]:
        return [c for c in self.children if c.type == t]

    def raw(self) -> bytes:
        """Re-serialise this box (payload + children are kept verbatim)."""
        if self.children and not self.payload:
            body = b"".join(c.raw() for c in self.children)
        else:
            body = self.payload
        return make_box(self.type, body)


def is_fourcc(b: bytes) -> bool:
    return len(b) == 4 and all(32 <= c < 127 for c in b)


def parse_box_tree(buf: bytes, start: int, end: int, base: int = 0, depth: int = 0) -> List[Box]:
    """Parse boxes contained in buf[start:end]. `base` is added to offsets."""
    boxes: List[Box] = []
    pos = start
    while pos + 8 <= end:
        size = be32(buf, pos)
        typ = bytes(buf[pos + 4:pos + 8])
        hdr = 8
        if size == 1:
            if pos + 16 > end:
                break
            size = be64(buf, pos + 8)
            hdr = 16
        elif size == 0:
            size = end - pos
        if size < hdr or not is_fourcc(typ):
            break
        truncated = False
        if pos + size > end:
            truncated = True
            size = end - pos
        box = Box(typ, base + pos, size, hdr, truncated=truncated)
        body_start = pos + hdr
        body_end = pos + size
        if typ in CONTAINERS and depth < 12:
            box.children = parse_box_tree(buf, body_start, body_end, base, depth + 1)
        else:
            box.payload = bytes(buf[body_start:body_end])
        boxes.append(box)
        pos += size
    return boxes


def scan_top_level(f: BinaryIO, file_size: int, limit: int = 100000) -> List[Box]:
    """Walk top-level boxes of a file without reading payloads.

    Stops at the first box with an invalid header; a box running past the
    end of file is reported with truncated=True.
    """
    boxes: List[Box] = []
    pos = 0
    while pos + 8 <= file_size and len(boxes) < limit:
        f.seek(pos)
        h = f.read(16)
        if len(h) < 8:
            break
        size = be32(h, 0)
        typ = h[4:8]
        hdr = 8
        if size == 1:
            if len(h) < 16:
                break
            size = be64(h, 8)
            hdr = 16
        elif size == 0:
            size = file_size - pos
        if not is_fourcc(typ) or size < hdr:
            break
        b = Box(typ, pos, size, hdr)
        if pos + size > file_size:
            b.truncated = True
        boxes.append(b)
        if b.truncated:
            break
        pos += size
    return boxes


def read_box_payload(f: BinaryIO, box: Box) -> bytes:
    f.seek(box.data_start)
    return f.read(box.size - box.header)


# ----------------------------------------------------------------------------
# Sample tables
# ----------------------------------------------------------------------------

@dataclass
class Track:
    track_id: int
    handler: bytes                  # b'vide', b'soun', b'tmcd', b'meta', ...
    timescale: int
    media_duration: int
    trak: Box
    stsd: bytes                     # full raw stsd box (header included)
    codec: bytes                    # fourcc of first sample entry
    sample_entry: bytes             # raw first sample entry (header included)
    sizes: List[int] = field(default_factory=list)
    offsets: List[int] = field(default_factory=list)
    durations: List[int] = field(default_factory=list)
    cts: List[int] = field(default_factory=list)       # composition offsets
    sync: Optional[set] = None                         # None => all samples are sync
    chunk_offsets: List[int] = field(default_factory=list)
    chunk_samples: List[int] = field(default_factory=list)
    stsz_const: int = 0              # constant sample size value written in stsz (0 = per-sample)
    elst: List[tuple] = field(default_factory=list)   # (segment_duration, media_time, rate)
    tkhd: bytes = b""
    mdhd_language: int = 0x55C4      # 'und'

    @property
    def nsamples(self) -> int:
        return len(self.sizes)

    @property
    def is_video(self) -> bool:
        return self.handler == b"vide"

    @property
    def is_audio(self) -> bool:
        return self.handler == b"soun"


def _full(payload: bytes):
    return payload[0], int.from_bytes(payload[1:4], "big")


def parse_track(trak: Box) -> Optional[Track]:
    tkhd = trak.find(b"tkhd")
    mdia = trak.find(b"mdia")
    if tkhd is None or mdia is None:
        return None
    mdhd = mdia.find(b"mdhd")
    hdlr = mdia.find(b"hdlr")
    stbl = mdia.find(b"minf", b"stbl")
    if mdhd is None or hdlr is None or stbl is None:
        return None
    v, _ = _full(tkhd.payload)
    track_id = be32(tkhd.payload, 12 if v == 0 else 20)
    v, _ = _full(mdhd.payload)
    if v == 1:
        timescale = be32(mdhd.payload, 20)
        mdur = be64(mdhd.payload, 24)
        lang = be16(mdhd.payload, 32)
    else:
        timescale = be32(mdhd.payload, 12)
        mdur = be32(mdhd.payload, 16)
        lang = be16(mdhd.payload, 20)
    handler = hdlr.payload[8:12]
    stsd = stbl.find(b"stsd")
    if stsd is None or len(stsd.payload) < 16:
        return None
    entry_size = be32(stsd.payload, 8)
    sample_entry = stsd.payload[8:8 + entry_size]
    codec = stsd.payload[12:16]

    t = Track(track_id, handler, timescale or 1, mdur, trak, stsd.raw(), codec, sample_entry,
              tkhd=tkhd.payload, mdhd_language=lang)

    # --- stsz / stz2
    stsz = stbl.find(b"stsz")
    stz2 = stbl.find(b"stz2")
    if stsz is not None:
        p = stsz.payload
        const = be32(p, 4)
        count = be32(p, 8)
        if const:
            t.sizes = [const] * count
            t.stsz_const = const
        else:
            n = min(count, (len(p) - 12) // 4)
            t.sizes = list(struct.unpack(">%dI" % n, p[12:12 + 4 * n]))
    elif stz2 is not None:
        p = stz2.payload
        fs = p[7]
        count = be32(p, 8)
        raw = p[12:]
        if fs == 16:
            n = min(count, len(raw) // 2)
            t.sizes = list(struct.unpack(">%dH" % n, raw[:2 * n]))
        elif fs == 8:
            t.sizes = list(raw[:count])
        elif fs == 4:
            out = []
            for b in raw:
                out.append(b >> 4)
                out.append(b & 15)
            t.sizes = out[:count]
    n = len(t.sizes)

    # --- chunk offsets
    stco = stbl.find(b"stco")
    co64 = stbl.find(b"co64")
    if stco is not None:
        p = stco.payload
        c = min(be32(p, 4), (len(p) - 8) // 4)
        t.chunk_offsets = list(struct.unpack(">%dI" % c, p[8:8 + 4 * c]))
    elif co64 is not None:
        p = co64.payload
        c = min(be32(p, 4), (len(p) - 8) // 8)
        t.chunk_offsets = list(struct.unpack(">%dQ" % c, p[8:8 + 8 * c]))

    # --- stsc -> samples per chunk
    stsc = stbl.find(b"stsc")
    runs = []
    if stsc is not None:
        p = stsc.payload
        c = min(be32(p, 4), (len(p) - 8) // 12)
        for i in range(c):
            fc, spc, _sdi = struct.unpack(">III", p[8 + 12 * i:20 + 12 * i])
            runs.append((fc, spc))
    nchunks = len(t.chunk_offsets)
    spc_list = []
    for i, (fc, spc) in enumerate(runs):
        last = runs[i + 1][0] - 1 if i + 1 < len(runs) else nchunks
        for _ in range(fc, last + 1):
            spc_list.append(spc)
    spc_list = spc_list[:nchunks]

    # --- sample offsets (trim to what the tables describe consistently)
    offsets = []
    chunk_samples = []
    si = 0
    for ci, co in enumerate(t.chunk_offsets):
        k = spc_list[ci] if ci < len(spc_list) else 0
        o = co
        taken = 0
        for _ in range(k):
            if si >= n:
                break
            offsets.append(o)
            o += t.sizes[si]
            si += 1
            taken += 1
        chunk_samples.append(taken)
        if si >= n:
            break
    t.chunk_offsets = t.chunk_offsets[:len(chunk_samples)]
    t.chunk_samples = chunk_samples
    t.offsets = offsets
    t.sizes = t.sizes[:len(offsets)]
    n = len(t.sizes)

    # --- stts
    stts = stbl.find(b"stts")
    durs: List[int] = []
    if stts is not None:
        p = stts.payload
        c = min(be32(p, 4), (len(p) - 8) // 8)
        for i in range(c):
            cnt, d = struct.unpack(">II", p[8 + 8 * i:16 + 8 * i])
            durs.extend([d] * min(cnt, n - len(durs)))
            if len(durs) >= n:
                break
    if len(durs) < n:
        durs.extend([durs[-1] if durs else 1] * (n - len(durs)))
    t.durations = durs[:n]

    # --- ctts
    ctts = stbl.find(b"ctts")
    cts: List[int] = []
    if ctts is not None:
        p = ctts.payload
        ver = p[0]
        c = min(be32(p, 4), (len(p) - 8) // 8)
        fmt = ">Ii" if ver == 1 else ">II"
        for i in range(c):
            cnt, off = struct.unpack(fmt, p[8 + 8 * i:16 + 8 * i])
            if ver == 0 and off >= 0x80000000:
                off -= 1 << 32   # some writers put negative values in v0
            cts.extend([off] * min(cnt, n - len(cts)))
            if len(cts) >= n:
                break
    if len(cts) < n:
        cts.extend([0] * (n - len(cts)))
    t.cts = cts[:n]

    # --- stss
    stss = stbl.find(b"stss")
    if stss is not None:
        p = stss.payload
        c = min(be32(p, 4), (len(p) - 8) // 4)
        t.sync = set(x - 1 for x in struct.unpack(">%dI" % c, p[8:8 + 4 * c]))

    # --- edit list
    elst = trak.find(b"edts", b"elst")
    if elst is not None:
        p = elst.payload
        ver = p[0]
        c = be32(p, 4)
        o = 8
        for _ in range(c):
            if ver == 1:
                if o + 20 > len(p):
                    break
                sd, mt = struct.unpack(">Qq", p[o:o + 16])
                rate = be32(p, o + 16)
                o += 20
            else:
                if o + 12 > len(p):
                    break
                sd, mt = struct.unpack(">Ii", p[o:o + 8])
                rate = be32(p, o + 8)
                o += 12
            t.elst.append((sd, mt, rate))
    return t


@dataclass
class Movie:
    moov: Box
    timescale: int
    duration: int
    tracks: List[Track]
    fragmented: bool = False


def parse_moov(payload: bytes, base: int = 0) -> Optional[Movie]:
    """Parse a moov payload (without its own header)."""
    children = parse_box_tree(payload, 0, len(payload), base)
    moov = Box(b"moov", base - 8, len(payload) + 8, 8, children=children)
    mvhd = moov.find(b"mvhd")
    if mvhd is None:
        return None
    v = mvhd.payload[0]
    if v == 1:
        ts = be32(mvhd.payload, 20)
        dur = be64(mvhd.payload, 24)
    else:
        ts = be32(mvhd.payload, 12)
        dur = be32(mvhd.payload, 16)
    tracks = []
    for trak in moov.find_all(b"trak"):
        try:
            t = parse_track(trak)
        except (struct.error, IndexError, ValueError):
            t = None
        if t is not None:
            tracks.append(t)
    return Movie(moov, ts or 1000, dur, tracks, fragmented=moov.find(b"mvex") is not None)


# ----------------------------------------------------------------------------
# Writing
# ----------------------------------------------------------------------------

def make_box(typ: bytes, body: bytes) -> bytes:
    size = len(body) + 8
    if size > 0xFFFFFFFF:
        return struct.pack(">I4sQ", 1, typ, size + 8) + body
    return struct.pack(">I4s", size, typ) + body


def make_full_box(typ: bytes, version: int, flags: int, body: bytes) -> bytes:
    return make_box(typ, struct.pack(">I", (version << 24) | (flags & 0xFFFFFF)) + body)


def runs(values):
    """Run-length encode a sequence -> list of (count, value)."""
    out = []
    prev = None
    cnt = 0
    for v in values:
        if v == prev:
            cnt += 1
        else:
            if cnt:
                out.append((cnt, prev))
            prev = v
            cnt = 1
    if cnt:
        out.append((cnt, prev))
    return out
