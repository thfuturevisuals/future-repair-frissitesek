"""Checks a repaired file with FFmpeg (PyAV) and renders a preview frame."""
from __future__ import annotations

import os
import tempfile


def verify_output(path: str, preview_path: str = "") -> dict:
    out = {"playable": False}
    try:
        import av
        av.logging.set_level(None)
    except ImportError:
        return out
    try:
        with av.open(path) as c:
            out["duration"] = round(float(c.duration or 0) / 1e6, 2)
            vs = next((s for s in c.streams if s.type == "video"), None)
            aus = next((s for s in c.streams if s.type == "audio"), None)
            if vs is not None:
                out["width"] = vs.codec_context.width
                out["height"] = vs.codec_context.height
                out["codec"] = vs.codec_context.name
                if vs.average_rate:
                    out["fps"] = round(float(vs.average_rate), 3)
            if aus is not None:
                out["audio_codec"] = aus.codec_context.name
                out["audio_rate"] = aus.codec_context.sample_rate
            target = vs or aus
            if target is None:
                return out
            decoded = 0
            errors = 0
            frame_img = None
            for pkt in c.demux(target):
                try:
                    for fr in pkt.decode():
                        decoded += 1
                        if vs is not None and frame_img is None and decoded >= 1:
                            frame_img = fr
                except Exception:  # noqa: BLE001
                    errors += 1
                if decoded >= 24 or errors > 8:
                    break
            out["decoded_frames"] = decoded
            out["decode_errors"] = errors
            out["playable"] = decoded > 0 and errors <= max(2, decoded // 4)
            if frame_img is not None:
                pp = preview_path or os.path.join(_preview_dir(), os.path.splitext(os.path.basename(path))[0] + ".jpg")
                try:
                    img = frame_img.to_image()
                    img.thumbnail((960, 960))
                    img.save(pp, quality=85)
                    out["preview"] = pp
                except Exception:  # noqa: BLE001
                    pass
    except Exception as e:  # noqa: BLE001
        out["error"] = str(e)
    return out


def _preview_dir() -> str:
    d = os.path.join(tempfile.gettempdir(), "futurerepair_previews")
    os.makedirs(d, exist_ok=True)
    return d


def _open_av():
    import av
    av.logging.set_level(None)
    return av


def deep_verify(path: str, points: int = 6, frames_per_point: int = 6) -> dict:
    """Decode a few frames at several positions across the whole file (seeking)."""
    av = _open_av()
    out = {"path": path, "checks": []}
    with av.open(path) as c:
        dur = float(c.duration or 0) / 1e6
        out["duration"] = round(dur, 2)
        vs = next((s for s in c.streams if s.type == "video"), None)
        aus = next((s for s in c.streams if s.type == "audio"), None)
        out["streams"] = [{"type": s.type, "codec": s.codec_context.name,
                           "frames": int(s.frames or 0)} for s in c.streams if s.type in ("video", "audio")]
        target = vs or aus
        if target is None:
            out["ok"] = False
            return out
        n = max(1, points)
        for i in range(n):
            frac = 0.0 if n == 1 else min(0.97, i / float(n - 1))
            t = dur * frac
            rec = {"position": round(frac, 3), "time": round(t, 2), "decoded": 0, "errors": 0}
            try:
                if t > 0 and target.time_base:
                    c.seek(int(t / float(target.time_base)), stream=target, backward=True)
                for pkt in c.demux(target):
                    try:
                        frames = pkt.decode()
                    except Exception:  # noqa: BLE001
                        rec["errors"] += 1
                        frames = []
                    rec["decoded"] += len(frames)
                    if rec["decoded"] >= frames_per_point or rec["errors"] > 6:
                        break
            except Exception as e:  # noqa: BLE001
                rec["error"] = str(e)
            out["checks"].append(rec)
        if aus is not None and vs is not None:
            arec = {"audio_decoded": 0, "audio_errors": 0}
            try:
                c.seek(0)
                for pkt in c.demux(aus):
                    try:
                        arec["audio_decoded"] += len(pkt.decode())
                    except Exception:  # noqa: BLE001
                        arec["audio_errors"] += 1
                    if arec["audio_decoded"] >= 50 or arec["audio_errors"] > 5:
                        break
            except Exception as e:  # noqa: BLE001
                arec["error"] = str(e)
            out["audio"] = arec
    out["ok"] = all(r["decoded"] > 0 and r["errors"] <= 2 and "error" not in r for r in out["checks"])
    return out


def frame_at(path: str, position: float = 0.5):
    """PIL image of the frame nearest to `position` (0..1) of a video."""
    av = _open_av()
    with av.open(path) as c:
        vs = next((s for s in c.streams if s.type == "video"), None)
        if vs is None:
            return None
        dur = float(c.duration or 0) / 1e6
        t = max(0.0, min(0.999, position)) * dur
        if t > 0 and vs.time_base:
            c.seek(int(t / float(vs.time_base)), stream=vs, backward=True)
        target_pts = t / float(vs.time_base) if vs.time_base else 0
        last = None
        for pkt in c.demux(vs):
            try:
                frames = pkt.decode()
            except Exception:  # noqa: BLE001
                continue
            for fr in frames:
                last = fr
                if fr.pts is None or fr.pts >= target_pts:
                    return fr.to_image()
            if last is not None and last.pts is not None and last.pts > target_pts + 10 / float(vs.time_base or 1):
                break
        return last.to_image() if last is not None else None
