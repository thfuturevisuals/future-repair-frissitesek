"""H.265 / HEVC: parameter sets, slice headers, access-unit splitting."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Optional

from .bits import BitReader, unescape

VCL_TYPES = set(range(0, 10)) | set(range(16, 22))
IRAP = set(range(16, 24))
IDR = {19, 20}
BLA = {16, 17, 18}
# Non-VCL types that start a new access unit when they follow VCL NALs (layer 0).
AU_START = {32, 33, 34, 35, 39, 41, 42, 43, 44} | set(range(48, 56))
# Non-VCL types allowed anywhere (stay in the current AU when after VCL).
SUFFIX = {36, 37, 38, 40} | set(range(56, 64))
ALLOWED = VCL_TYPES | AU_START | SUFFIX
RASL = {8, 9}
RADL = {6, 7}
SUB_LAYER_NON_REF = {0, 2, 4, 6, 8, 10, 12, 14}


@dataclass
class SPS:
    sps_id: int
    max_sub_layers: int
    temporal_id_nesting: int
    ptl: bytes                 # 12 bytes of general profile_tier_level
    chroma_format_idc: int = 1
    separate_colour_plane: int = 0
    width: int = 0
    height: int = 0
    bit_depth_luma: int = 8
    bit_depth_chroma: int = 8
    log2_max_poc_lsb: int = 8
    raw: bytes = b""


@dataclass
class PPS:
    pps_id: int
    sps_id: int
    dependent_slice_segments_enabled: int
    output_flag_present: int
    num_extra_slice_header_bits: int
    raw: bytes = b""


def _skip_ptl(br: BitReader, max_sub_layers_minus1: int) -> bytes:
    start = br.pos
    br.skip(96)
    ptl = bytes(br.data[start // 8:start // 8 + 12]) if start % 8 == 0 else b""
    sub_profile = []
    sub_level = []
    for _ in range(max_sub_layers_minus1):
        sub_profile.append(br.u(1))
        sub_level.append(br.u(1))
    if max_sub_layers_minus1 > 0:
        for _ in range(max_sub_layers_minus1, 8):
            br.u(2)
    for i in range(max_sub_layers_minus1):
        if sub_profile[i]:
            br.skip(88)
        if sub_level[i]:
            br.skip(8)
    return ptl


def parse_sps(nal: bytes) -> Optional[SPS]:
    try:
        rb = unescape(nal[2:])
        br = BitReader(rb)
        br.u(4)                       # sps_video_parameter_set_id
        msl = br.u(3)
        tin = br.u(1)
        if msl > 6:
            return None
        ptl = _skip_ptl(br, msl)
        sps_id = br.ue()
        if sps_id > 15:
            return None
        s = SPS(sps_id, msl + 1, tin, ptl, raw=bytes(nal))
        s.chroma_format_idc = br.ue()
        if s.chroma_format_idc > 3:
            return None
        if s.chroma_format_idc == 3:
            s.separate_colour_plane = br.u(1)
        w = br.ue()
        h = br.ue()
        if br.u(1):                   # conformance_window_flag
            l, r, t, b = br.ue(), br.ue(), br.ue(), br.ue()
            sub_w = 2 if s.chroma_format_idc in (1, 2) and not s.separate_colour_plane else 1
            sub_h = 2 if s.chroma_format_idc == 1 and not s.separate_colour_plane else 1
            w -= (l + r) * sub_w
            h -= (t + b) * sub_h
        s.width, s.height = w, h
        s.bit_depth_luma = br.ue() + 8
        s.bit_depth_chroma = br.ue() + 8
        s.log2_max_poc_lsb = br.ue() + 4
        if s.log2_max_poc_lsb > 16:
            return None
        return s
    except (EOFError, ValueError):
        return None


def parse_pps(nal: bytes) -> Optional[PPS]:
    try:
        br = BitReader(unescape(nal[2:]))
        pps_id = br.ue()
        sps_id = br.ue()
        if pps_id > 63 or sps_id > 15:
            return None
        dse = br.u(1)
        ofp = br.u(1)
        nesb = br.u(3)
        return PPS(pps_id, sps_id, dse, ofp, nesb, raw=bytes(nal))
    except (EOFError, ValueError):
        return None


@dataclass
class SliceInfo:
    first_slice: int
    pps_id: int
    slice_type: int = -1
    poc_lsb: int = 0
    full: bool = False


def parse_slice_header(nal: bytes, nal_type: int, sps_map: Dict[int, SPS],
                       pps_map: Dict[int, PPS]) -> Optional[SliceInfo]:
    try:
        br = BitReader(unescape(nal[2:48]))
        first = br.u(1)
        if 16 <= nal_type <= 23:
            br.u(1)                   # no_output_of_prior_pics_flag
        pps_id = br.ue()
        if pps_id > 63:
            return None
        si = SliceInfo(first, pps_id)
        if not first:
            return si
        pps = pps_map.get(pps_id)
        sps = sps_map.get(pps.sps_id) if pps else None
        if pps is None or sps is None:
            return si
        br.skip(pps.num_extra_slice_header_bits)
        si.slice_type = br.ue()
        if si.slice_type > 2:
            return None
        if pps.output_flag_present:
            br.u(1)
        if sps.separate_colour_plane:
            br.u(2)
        if nal_type not in IDR:
            si.poc_lsb = br.u(sps.log2_max_poc_lsb)
        si.full = True
        return si
    except (EOFError, ValueError):
        return None


@dataclass
class AU:
    length: int
    keyframe: bool
    nal_types: tuple
    vcl_type: int
    tid: int
    slice: Optional[SliceInfo]
    param_sets: tuple


class HEVC:
    name = "hevc"

    def __init__(self, length_size: int = 4):
        self.nls = length_size
        self.vps: Dict[int, bytes] = {}
        self.sps: Dict[int, SPS] = {}
        self.pps: Dict[int, PPS] = {}
        self.allowed_first: Optional[set] = None
        self.allowed_slice_types: Optional[set] = None
        self.max_au = 96 * 1024 * 1024

    def add_param_set(self, nal: bytes) -> None:
        if len(nal) < 3:
            return
        t = (nal[0] >> 1) & 0x3F
        layer = ((nal[0] & 1) << 5) | (nal[1] >> 3)
        if layer != 0:
            return
        if t == 32:
            self.vps[(nal[2] >> 4) & 0xF] = bytes(nal)
        elif t == 33:
            s = parse_sps(nal)
            if s:
                self.sps[s.sps_id] = s
        elif t == 34:
            p = parse_pps(nal)
            if p:
                self.pps[p.pps_id] = p

    @staticmethod
    def is_param_set(nal: bytes) -> bool:
        return len(nal) >= 2 and ((nal[0] >> 1) & 0x3F) in (32, 33, 34)

    def parse_au(self, mm, pos: int, end: int, strict: bool = True) -> Optional[AU]:
        nls = self.nls
        p = pos
        seen_vcl = False
        types: List[int] = []
        first_slice: Optional[SliceInfo] = None
        vcl_type = -1
        tid = 0
        psets = []
        nal_count = 0
        while p + nls + 1 < end:
            ln = int.from_bytes(mm[p:p + nls], "big")
            if ln < 2 or p + nls + ln - pos > self.max_au:
                if not seen_vcl:
                    return None
                break
            if p + nls + ln > end:
                # the data ends inside this NAL: the access unit is incomplete
                return None
            h0 = mm[p + nls]
            h1 = mm[p + nls + 1]
            if h0 & 0x80:
                if not seen_vcl:
                    return None
                break
            t = (h0 >> 1) & 0x3F
            layer = ((h0 & 1) << 5) | (h1 >> 3)
            tidp1 = h1 & 7
            if tidp1 == 0 or layer > 1 or t not in ALLOWED:
                if not seen_vcl:
                    return None
                break
            if t in IRAP and tidp1 != 1 and layer == 0:
                if not seen_vcl:
                    return None
                break
            if nal_count == 0 and strict and self.allowed_first is not None and t not in self.allowed_first:
                return None
            if t in VCL_TYPES:
                hb = mm[p + nls:p + nls + min(ln, 48)]
                if layer == 0:
                    si = parse_slice_header(hb, t, self.sps, self.pps)
                    if si is None:
                        if not seen_vcl:
                            return None
                        break
                    if seen_vcl:
                        if si.first_slice:
                            break
                        if si.pps_id != first_slice.pps_id or t != vcl_type:
                            break
                    else:
                        if not si.first_slice:
                            return None
                        if strict:
                            if self.pps and si.pps_id not in self.pps:
                                return None
                            if (self.allowed_slice_types is not None and si.slice_type >= 0
                                    and si.slice_type not in self.allowed_slice_types):
                                return None
                        first_slice = si
                        vcl_type = t
                        tid = tidp1 - 1
                    seen_vcl = True
                elif not seen_vcl:
                    return None
            elif seen_vcl and t in AU_START and layer == 0:
                break
            elif seen_vcl and (
                    (t in (36, 37) and ln != 2)
                    or (t == 38 and ln > 2 and (mm[p + nls + 2] != 0xFF or mm[p + nls + ln - 1] != 0x80))
                    or (t == 40 and (ln > 1 << 20 or mm[p + nls + ln - 1] == 0))
                    or (56 <= t <= 61)
                    or (t in (62, 63) and ln > 8 << 20)):
                break
            elif t in (32, 33, 34):
                psets.append(bytes(mm[p + nls:p + nls + ln]))
            types.append(t)
            nal_count += 1
            p += nls + ln
            if p - pos > self.max_au:
                return None
        if not seen_vcl or first_slice is None:
            return None
        for ps in psets:
            self.add_param_set(ps)
        return AU(p - pos, vcl_type in IRAP, tuple(types), vcl_type, tid, first_slice, tuple(psets))

    def learn(self, aus: List[AU]) -> None:
        firsts = set()
        stypes = set()
        for a in aus:
            if a.nal_types:
                firsts.add(a.nal_types[0])
            if a.slice is not None and a.slice.slice_type >= 0:
                stypes.add(a.slice.slice_type)
        if firsts:
            if firsts & VCL_TYPES:
                firsts |= VCL_TYPES      # any picture type may open an access unit
            self.allowed_first = firsts
        if stypes:
            self.allowed_slice_types = stypes

    def first_nal_headers(self) -> set:
        """First header byte values (h0) for fast candidate searching (layer 0)."""
        types = self.allowed_first or (VCL_TYPES | {32, 33, 34, 35, 39})
        return {(t << 1) for t in types}


def poc_sequence(aus: List[AU], codec: HEVC) -> Optional[List[int]]:
    out = []
    prev_tid0_poc = 0
    first = True
    for a in aus:
        si = a.slice
        if si is None or not si.full:
            return None
        pps = codec.pps.get(si.pps_id)
        sps = codec.sps.get(pps.sps_id) if pps else None
        if sps is None:
            return None
        t = a.vcl_type
        if t in IDR:
            poc = 0
        else:
            maxlsb = 1 << sps.log2_max_poc_lsb
            no_rasl_output = t in BLA or (first and t in IRAP)
            if no_rasl_output:
                msb = 0
            else:
                prev_lsb = prev_tid0_poc & (maxlsb - 1)
                prev_msb = prev_tid0_poc - prev_lsb
                lsb = si.poc_lsb
                if lsb < prev_lsb and prev_lsb - lsb >= maxlsb // 2:
                    msb = prev_msb + maxlsb
                elif lsb > prev_lsb and lsb - prev_lsb > maxlsb // 2:
                    msb = prev_msb - maxlsb
                else:
                    msb = prev_msb
            poc = msb + si.poc_lsb
        if a.tid == 0 and t not in RASL and t not in RADL and t not in SUB_LAYER_NON_REF:
            prev_tid0_poc = poc
        first = False
        out.append(poc)
    return out


def parse_hvcc(payload: bytes):
    """-> (length_size, [nal arrays as raw NAL bytes])"""
    nls = (payload[21] & 3) + 1
    narr = payload[22]
    o = 23
    nals = []
    for _ in range(narr):
        if o + 3 > len(payload):
            break
        n = int.from_bytes(payload[o + 1:o + 3], "big")
        o += 3
        for _ in range(n):
            ln = int.from_bytes(payload[o:o + 2], "big")
            nals.append(payload[o + 2:o + 2 + ln])
            o += 2 + ln
    return nls, nals


def build_hvcc(vps: List[bytes], sps: List[bytes], pps: List[bytes], length_size: int = 4,
               extra: Optional[List[bytes]] = None) -> bytes:
    sp = parse_sps(sps[0])
    if sp is None or len(sp.ptl) != 12:
        raise ValueError("cannot parse SPS for hvcC")
    body = bytes([1]) + sp.ptl
    body += bytes([0xF0, 0x00, 0xFC, 0xFC | sp.chroma_format_idc,
                   0xF8 | (sp.bit_depth_luma - 8), 0xF8 | (sp.bit_depth_chroma - 8)])
    body += b"\x00\x00"   # avgFrameRate
    body += bytes([((sp.max_sub_layers & 7) << 3) | ((sp.temporal_id_nesting & 1) << 2) | (length_size - 1)])
    arrays = [(32, vps), (33, sps), (34, pps)]
    if extra:
        arrays.append((39, extra))
    arrays = [(t, l) for t, l in arrays if l]
    body += bytes([len(arrays)])
    for t, lst in arrays:
        body += bytes([0x80 | t]) + len(lst).to_bytes(2, "big")
        for n in lst:
            body += len(n).to_bytes(2, "big") + n
    return body
