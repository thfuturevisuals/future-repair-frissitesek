"""Builds a fresh moov for recovered samples and writes ftyp + moov + mdat."""
from __future__ import annotations

import os
import struct
from dataclasses import dataclass, field
from typing import Callable, List, Optional

from .mp4 import Track, make_box, make_full_box, runs
from . import entries as E

IDENTITY_MATRIX = struct.pack(">9I", 0x00010000, 0, 0, 0, 0x00010000, 0, 0, 0, 0x40000000)


@dataclass
class OutTrack:
    handler: bytes
    timescale: int
    sample_entry: bytes
    chunk_src: List[int]           # chunk start offsets in the SOURCE file
    chunk_counts: List[int]        # stsz samples per chunk
    chunk_bytes: List[int]         # bytes per chunk
    sizes: Optional[List[int]]     # per-sample sizes (None => constant stsz_const)
    stsz_const: int = 0
    durations: List[tuple] = field(default_factory=list)   # stts runs (count, delta)
    cts: Optional[List[int]] = None
    sync: Optional[List[int]] = None   # 0-based indices of sync samples
    media_time: int = 0                # edit list start (media timescale), 0 = none
    ref: Optional[Track] = None
    track_id: int = 1
    language: int = 0x55C4

    @property
    def nsamples(self) -> int:
        return sum(self.chunk_counts)

    @property
    def media_duration(self) -> int:
        return sum(c * d for c, d in self.durations)


def _tkhd(t: OutTrack, duration_mv: int) -> bytes:
    flags = 0x000003
    layer = alt = 0
    volume = 0x0100 if t.handler == b"soun" else 0
    matrix = IDENTITY_MATRIX
    width = height = 0
    if t.ref is not None and t.ref.tkhd:
        p = t.ref.tkhd
        v = p[0]
        o = 4 + (32 if v == 1 else 20)
        try:
            flags = int.from_bytes(p[1:4], "big") or 3
            o += 8  # reserved
            layer, alt, volume = struct.unpack(">hhH", p[o:o + 6])
            o += 8
            matrix = p[o:o + 36]
            o += 36
            width, height = struct.unpack(">II", p[o:o + 8])
        except struct.error:
            pass
    if t.handler == b"vide" and not width:
        w, h = E.video_dims(t.sample_entry)
        width, height = w << 16, h << 16
    if duration_mv > 0xFFFFFFFF:
        head = struct.pack(">QQIIQ", 0, 0, t.track_id, 0, duration_mv)
        ver = 1
    else:
        head = struct.pack(">IIIII", 0, 0, t.track_id, 0, duration_mv)
        ver = 0
    body = head + b"\x00" * 8 + struct.pack(">hhHH", layer, alt, volume, 0) + matrix + struct.pack(">II", width, height)
    return make_full_box(b"tkhd", ver, flags | 1, body)


def _mdhd(t: OutTrack) -> bytes:
    d = t.media_duration
    if d > 0xFFFFFFFF:
        return make_full_box(b"mdhd", 1, 0, struct.pack(">QQIQHH", 0, 0, t.timescale, d, t.language, 0))
    return make_full_box(b"mdhd", 0, 0, struct.pack(">IIIIHH", 0, 0, t.timescale, d, t.language, 0))


def _default_hdlr(handler: bytes) -> bytes:
    name = {b"vide": b"VideoHandler", b"soun": b"SoundHandler"}.get(handler, b"DataHandler")
    return make_full_box(b"hdlr", 0, 0, b"\x00" * 4 + handler + b"\x00" * 12 + name + b"\x00")


def _minf_header(handler: bytes) -> bytes:
    if handler == b"vide":
        return make_full_box(b"vmhd", 0, 1, b"\x00" * 8)
    if handler == b"soun":
        return make_full_box(b"smhd", 0, 0, b"\x00" * 4)
    return make_full_box(b"nmhd", 0, 0, b"")


def _dinf() -> bytes:
    dref = make_full_box(b"dref", 0, 0, struct.pack(">I", 1) + make_full_box(b"url ", 0, 1, b""))
    return make_box(b"dinf", dref)


def _stbl(t: OutTrack, chunk_offsets: List[int], use64: bool) -> bytes:
    parts = [E.make_stsd([t.sample_entry])]
    parts.append(make_full_box(b"stts", 0, 0, struct.pack(">I", len(t.durations)) +
                               b"".join(struct.pack(">II", c, d) for c, d in t.durations)))
    if t.cts is not None:
        r = runs(t.cts)
        parts.append(make_full_box(b"ctts", 0, 0, struct.pack(">I", len(r)) +
                                   b"".join(struct.pack(">II", c, v & 0xFFFFFFFF) for c, v in r)))
    if t.sync is not None:
        parts.append(make_full_box(b"stss", 0, 0, struct.pack(">I", len(t.sync)) +
                                   b"".join(struct.pack(">I", i + 1) for i in t.sync)))
    # stsc
    entries = []
    prev = None
    for ci, n in enumerate(t.chunk_counts):
        if n != prev:
            entries.append(struct.pack(">III", ci + 1, n, 1))
            prev = n
    parts.append(make_full_box(b"stsc", 0, 0, struct.pack(">I", len(entries)) + b"".join(entries)))
    if t.sizes is None:
        parts.append(make_full_box(b"stsz", 0, 0, struct.pack(">II", t.stsz_const, t.nsamples)))
    else:
        parts.append(make_full_box(b"stsz", 0, 0, struct.pack(">II", 0, len(t.sizes)) +
                                   struct.pack(">%dI" % len(t.sizes), *t.sizes)))
    if use64:
        parts.append(make_full_box(b"co64", 0, 0, struct.pack(">I", len(chunk_offsets)) +
                                   struct.pack(">%dQ" % len(chunk_offsets), *chunk_offsets)))
    else:
        parts.append(make_full_box(b"stco", 0, 0, struct.pack(">I", len(chunk_offsets)) +
                                   struct.pack(">%dI" % len(chunk_offsets), *chunk_offsets)))
    return make_box(b"stbl", b"".join(parts))


def _trak(t: OutTrack, movie_ts: int, chunk_offsets: List[int], use64: bool) -> bytes:
    mdur = t.media_duration
    pres = max(0, mdur - t.media_time)
    dur_mv = pres * movie_ts // max(1, t.timescale)
    parts = [_tkhd(t, dur_mv)]
    if t.media_time:
        if dur_mv > 0xFFFFFFFF or t.media_time > 0x7FFFFFFF:
            elst = make_full_box(b"elst", 1, 0, struct.pack(">IQqI", 1, dur_mv, t.media_time, 0x00010000))
        else:
            elst = make_full_box(b"elst", 0, 0, struct.pack(">IIiI", 1, dur_mv, t.media_time, 0x00010000))
        parts.append(make_box(b"edts", elst))
    # mdia
    mdia = [_mdhd(t)]
    minf_children = []
    hdlr = None
    if t.ref is not None:
        md = t.ref.trak.find(b"mdia")
        h = md.find(b"hdlr") if md else None
        if h is not None:
            hdlr = h.raw()
        mi = md.find(b"minf") if md else None
        if mi is not None:
            for c in mi.children:
                if c.type != b"stbl":
                    minf_children.append(c.raw())
    mdia.append(hdlr or _default_hdlr(t.handler))
    if not minf_children:
        minf_children = [_minf_header(t.handler), _dinf()]
    minf = make_box(b"minf", b"".join(minf_children) + _stbl(t, chunk_offsets, use64))
    mdia.append(minf)
    parts.append(make_box(b"mdia", b"".join(mdia)))
    return make_box(b"trak", b"".join(parts)), dur_mv


def build_moov(tracks: List[OutTrack], movie_ts: int, base: int, copy_start: int, use64: bool) -> bytes:
    traks = []
    max_dur = 0
    for t in tracks:
        offs = [base + (o - copy_start) for o in t.chunk_src]
        tb, dur = _trak(t, movie_ts, offs, use64)
        traks.append(tb)
        max_dur = max(max_dur, dur)
    next_id = max(t.track_id for t in tracks) + 1
    tail = struct.pack(">IH", 0x00010000, 0x0100) + b"\x00" * 10 + IDENTITY_MATRIX + b"\x00" * 24 + struct.pack(">I", next_id)
    if max_dur > 0xFFFFFFFF:
        mvhd = make_full_box(b"mvhd", 1, 0, struct.pack(">QQIQ", 0, 0, movie_ts, max_dur) + tail)
    else:
        mvhd = make_full_box(b"mvhd", 0, 0, struct.pack(">IIII", 0, 0, movie_ts, max_dur) + tail)
    return make_box(b"moov", mvhd + b"".join(traks))


def write_file(out_path: str, src_path: str, ftyp: bytes, tracks: List[OutTrack], movie_ts: int = 1000,
               progress: Optional[Callable[[float], None]] = None,
               cancel: Optional[Callable[[], bool]] = None, view=None) -> int:
    """Write the repaired file. Returns the number of payload bytes copied."""
    tracks = [t for t in tracks if t.nsamples > 0]
    if not tracks:
        raise ValueError("no samples to write")
    copy_start = min(min(t.chunk_src) for t in tracks)
    copy_end = max(max(o + b for o, b in zip(t.chunk_src, t.chunk_bytes)) for t in tracks)
    payload = copy_end - copy_start
    big_mdat = payload + 8 > 0xFFFFFFFF
    mdat_hdr = 16 if big_mdat else 8
    if not ftyp:
        ftyp = make_box(b"ftyp", b"isom\x00\x00\x02\x00isomiso2mp41")
    # moov size does not depend on the base offset values -> build twice
    est_total = len(ftyp) + payload + mdat_hdr + 64 * 1024 * 1024
    use64 = est_total > 0xFFFFFFFF
    moov = build_moov(tracks, movie_ts, 0, copy_start, use64)
    base = len(ftyp) + len(moov) + mdat_hdr
    moov = build_moov(tracks, movie_ts, base, copy_start, use64)
    tmp = out_path + ".part"
    with open(src_path, "rb") as src, open(tmp, "wb") as out:
        out.write(ftyp)
        out.write(moov)
        if big_mdat:
            out.write(struct.pack(">I4sQ", 1, b"mdat", payload + 16))
        else:
            out.write(struct.pack(">I4s", payload + 8, b"mdat"))
        if view is not None:
            got = view.read_into(src, copy_start, payload, out,
                                 progress=(lambda d: progress(d / max(1, payload))) if progress else None,
                                 cancel=cancel)
            if got != payload:
                raise IOError("source ended early")
            left = 0
        else:
            src.seek(copy_start)
            left = payload
        done = 0
        bs = 16 * 1024 * 1024
        while left > 0:
            if cancel and cancel():
                raise InterruptedError
            b = src.read(min(bs, left))
            if not b:
                break
            out.write(b)
            left -= len(b)
            done += len(b)
            if progress:
                progress(done / max(1, payload))
        if left > 0:
            raise IOError("source ended early")
    os.replace(tmp, out_path)
    return payload
