"""Walks raw mdat data and splits it into chunks using the track models."""
from __future__ import annotations

from collections import Counter
from typing import Callable, List, Optional

from .models import Chunk, FixedModel, Model

WINDOW = 4 * 1024 * 1024


class Scanner:
    def __init__(self, mm, start: int, end: int, models: List[Model],
                 transitions: Optional[Counter] = None,
                 progress: Optional[Callable[[float], None]] = None,
                 cancel: Optional[Callable[[], bool]] = None,
                 confirm: bool = True,
                 stop_on_fail: bool = False,
                 fast: bool = False,
                 on_skip: Optional[Callable[["Scanner"], bool]] = None):
        self.mm = mm
        self.start = start
        self.end = end
        self.models = models
        for i, m in enumerate(models):
            m.index = i
            m.chunks = []
        self.selfdesc = [m for m in models if m.selfdesc]
        self.others = [m for m in models if not m.selfdesc]
        self.fixed = [m for m in self.others if isinstance(m, FixedModel)]
        self.aac = [m for m in self.others if m.kind == "audio_aac"]
        self.transitions = transitions or Counter()
        self.progress = progress
        self.cancel = cancel
        self.skipped_bytes = 0
        self.skips: List[tuple] = []
        self.skip_units: List[int] = []     # start of the last unit before each skip
        self.order: List[tuple] = []        # (model index, chunk) in file order
        self.tail_from = end                # position after which data is the truncated tail
        self.tail_window = 256 * 1024 * 1024  # partial units are only accepted this close to the end
        # When unknown data (e.g. audio we have no model for) sits between video chunks, a start
        # can't be confirmed by what follows it - then a single strict match has to do.
        self.confirm = confirm
        # stop_on_fail: stop at the first position where nothing can be read (fail_at) instead of
        # searching for the next chunk start - used to test whether data continues across a cut.
        self.stop_on_fail = stop_on_fail
        self.fail_at: Optional[int] = None
        # fast: fixed-size tracks only try the chunk sizes learned from the reference
        self.fast = fast
        # on_skip(scanner) -> True stops the scan (aborted = True)
        self.on_skip = on_skip
        self.aborted = False

    # ------------------------------------------------------------------
    def at_tail(self, p: int) -> bool:
        """True if nothing recognisable follows p (end of the recording)."""
        return self.find_next(p + 1, limit=self.end) is None

    def strong_start(self, p: int, depth: int = 1, exclude: Optional[Model] = None) -> bool:
        if p == self.end:
            return True
        if p > self.end:
            return False
        mm, end = self.mm, self.end
        for m in self.selfdesc:
            if m is not exclude and m.match(mm, p, end):
                return True
        if end - p < self.tail_window:
            for m in self.selfdesc:
                if m.partial_start(mm, p, end):
                    return True
        if depth > 0:
            for m in self.fixed:
                if m is exclude:
                    continue
                for s in m.sizes[:4]:
                    if p + s <= end and self.strong_start(p + s, depth - 1, exclude=m):
                        return True
        return False

    def confirmed_start(self, p: int) -> bool:
        """A self-describing chunk starts at p AND the data after its first unit makes sense."""
        if p >= self.end:
            return p == self.end
        mm, end = self.mm, self.end
        for m in self.selfdesc:
            n = m.unit_len(mm, p, end)
            if n is None:
                continue
            r = p + n
            if r >= end or self.strong_start(r, depth=1):
                return True
            for a in self.aac:
                if a.looks_like_start(self, r):
                    return True
        return False

    def find_start_in(self, a: int, b: int) -> Optional[int]:
        """First position in [a, b) where a self-describing chunk starts (single check)."""
        best = None
        for m in self.selfdesc:
            for q in m.candidates(self.mm, a, min(self.end, b + 16)):
                if q >= b or (best is not None and q >= best):
                    break
                if q >= a and m.match(self.mm, q, self.end):
                    best = q
                    break
        return best

    def find_next(self, p: int, limit: Optional[int] = None) -> Optional[int]:
        """Next position >= p where a self-describing chunk starts."""
        end = self.end if limit is None else min(limit, self.end)
        mm = self.mm
        w0 = p
        while w0 < end:
            w1 = min(end, w0 + WINDOW)
            best = None
            for m in self.selfdesc:
                for q in m.candidates(mm, w0, min(end, w1 + 16)):
                    if q < p:
                        continue
                    if best is not None and q >= best:
                        break
                    if q >= w1:
                        break
                    if (self.confirmed_start(q) if self.confirm else m.match(mm, q, self.end)):
                        best = q
                        break
            if best is not None:
                return best
            if self.cancel and self.cancel():
                return None
            w0 = w1
        return None

    def _ordered_others(self, last: Optional[Model]) -> List[Model]:
        if not self.others:
            return []
        li = last.index if last is not None else -1
        def key(m):
            return -self.transitions.get((li, m.index), 0), -self.transitions.get(("any", m.index), 0)
        return sorted(self.others, key=key)

    # ------------------------------------------------------------------
    def run(self) -> None:
        p = self.start
        end = self.end
        last: Optional[Model] = None
        next_report = p
        total = max(1, end - self.start)
        while p < end:
            if p >= next_report:
                if self.progress:
                    self.progress((p - self.start) / total)
                if self.cancel and self.cancel():
                    break
                next_report = p + 2 * 1024 * 1024
            res = None
            for m in self.selfdesc:
                c = m.read_chunk(self, p)
                if c is not None:
                    res = (m, c)
                    break
            if res is None:
                for m in self._ordered_others(last):
                    c = m.read_chunk(self, p)
                    if c is not None and c.end > p:
                        res = (m, c)
                        break
            if res is None:
                if self.stop_on_fail:
                    self.fail_at = p
                    self.tail_from = p
                    break
                q = self.find_next(p + 1)
                if q is None:
                    self.tail_from = p
                    break
                self.skipped_bytes += q - p
                self.skips.append((p, q))
                self.skip_units.append(self._last_unit_start(p))
                if self.on_skip is not None and self.on_skip(self):
                    self.aborted = True
                    self.tail_from = p
                    break
                p = q
                last = None
                continue
            m, c = res
            m.chunks.append(c)
            self.order.append((m.index, c))
            p = c.end
            last = m
        if self.progress:
            self.progress(1.0)

    def _last_unit_start(self, p: int) -> int:
        """Start of the last unit the scanner read before p (a fixed-size chunk is one unit)."""
        if not self.order:
            return p
        mi, c = self.order[-1]
        if c.end != p:
            return p
        if isinstance(self.models[mi], FixedModel):
            return c.start
        pos = c.start
        last = c.start
        for sz in (c.sizes or []):
            last = pos
            pos += sz
        return last

    def summary(self) -> dict:
        return {
            "skipped_bytes": self.skipped_bytes,
            "skips": len(self.skips),
            "tail_bytes": max(0, self.end - self.tail_from),
            "chunks": {m.name: len(m.chunks) for m in self.models},
        }
