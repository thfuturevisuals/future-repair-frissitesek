"""H.264 / AVC: parameter sets, slice headers, access-unit splitting."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Optional

from .bits import BitReader, unescape

HIGH_PROFILES = {100, 110, 122, 244, 44, 83, 86, 118, 128, 138, 139, 134, 135}

# NAL types that may appear in an AVC elementary stream we accept.
ALLOWED = {1, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 19, 20, 21}
VCL = {1, 5}
# Non-VCL types that start a new access unit if a VCL NAL was already seen.
AU_START = {6, 7, 8, 9, 13, 14, 15}
MUST_REF = {5, 7, 8}          # nal_ref_idc must be != 0
MUST_NONREF = {6, 9, 10, 11, 12}  # nal_ref_idc must be 0


@dataclass
class SPS:
    sps_id: int
    profile_idc: int
    constraint: int
    level_idc: int
    chroma_format_idc: int = 1
    separate_colour_plane: int = 0
    bit_depth_luma: int = 8
    bit_depth_chroma: int = 8
    log2_max_frame_num: int = 4
    poc_type: int = 0
    log2_max_poc_lsb: int = 4
    delta_pic_order_always_zero: int = 0
    frame_mbs_only: int = 1
    width: int = 0
    height: int = 0
    fps_num: int = 0
    fps_den: int = 0
    sar_w: int = 1
    sar_h: int = 1
    raw: bytes = b""


@dataclass
class PPS:
    pps_id: int
    sps_id: int
    entropy_coding_mode: int
    bottom_field_pic_order_in_frame_present: int
    raw: bytes = b""


def _scaling_list(br: BitReader, size: int) -> None:
    last = 8
    nxt = 8
    for _ in range(size):
        if nxt != 0:
            delta = br.se()
            nxt = (last + delta + 256) % 256
        last = nxt if nxt != 0 else last


def parse_sps(nal: bytes) -> Optional[SPS]:
    try:
        rb = unescape(nal[1:])
        br = BitReader(rb)
        profile = br.u(8)
        constraint = br.u(8)
        level = br.u(8)
        sps_id = br.ue()
        if sps_id > 31:
            return None
        s = SPS(sps_id, profile, constraint, level, raw=bytes(nal))
        if profile in HIGH_PROFILES:
            s.chroma_format_idc = br.ue()
            if s.chroma_format_idc > 3:
                return None
            if s.chroma_format_idc == 3:
                s.separate_colour_plane = br.u(1)
            s.bit_depth_luma = br.ue() + 8
            s.bit_depth_chroma = br.ue() + 8
            br.u(1)  # qpprime_y_zero_transform_bypass_flag
            if br.u(1):  # seq_scaling_matrix_present_flag
                for i in range(8 if s.chroma_format_idc != 3 else 12):
                    if br.u(1):
                        _scaling_list(br, 16 if i < 6 else 64)
        s.log2_max_frame_num = br.ue() + 4
        if s.log2_max_frame_num > 16:
            return None
        s.poc_type = br.ue()
        if s.poc_type == 0:
            s.log2_max_poc_lsb = br.ue() + 4
            if s.log2_max_poc_lsb > 16:
                return None
        elif s.poc_type == 1:
            s.delta_pic_order_always_zero = br.u(1)
            br.se()
            br.se()
            n = br.ue()
            for _ in range(min(n, 255)):
                br.se()
        elif s.poc_type != 2:
            return None
        br.ue()      # max_num_ref_frames
        br.u(1)      # gaps_in_frame_num_value_allowed_flag
        w_mbs = br.ue() + 1
        h_map = br.ue() + 1
        s.frame_mbs_only = br.u(1)
        if not s.frame_mbs_only:
            br.u(1)  # mb_adaptive_frame_field_flag
        br.u(1)      # direct_8x8_inference_flag
        width = w_mbs * 16
        height = h_map * 16 * (2 - s.frame_mbs_only)
        if br.u(1):  # frame_cropping_flag
            cl, cr, ct, cb = br.ue(), br.ue(), br.ue(), br.ue()
            if s.chroma_format_idc == 0 or s.separate_colour_plane:
                cx, cy = 1, 2 - s.frame_mbs_only
            else:
                sub_w = 2 if s.chroma_format_idc in (1, 2) else 1
                sub_h = 2 if s.chroma_format_idc == 1 else 1
                cx, cy = sub_w, sub_h * (2 - s.frame_mbs_only)
            width -= (cl + cr) * cx
            height -= (ct + cb) * cy
        s.width, s.height = width, height
        if br.u(1):  # vui_parameters_present_flag
            _parse_vui(br, s)
        return s
    except (EOFError, ValueError):
        return None


def _parse_vui(br: BitReader, s: SPS) -> None:
    try:
        if br.u(1):  # aspect_ratio_info_present_flag
            idc = br.u(8)
            table = {1: (1, 1), 2: (12, 11), 3: (10, 11), 4: (16, 11), 5: (40, 33), 6: (24, 11),
                     7: (20, 11), 8: (32, 11), 9: (80, 33), 10: (18, 11), 11: (15, 11),
                     12: (64, 33), 13: (160, 99), 14: (4, 3), 15: (3, 2), 16: (2, 1)}
            if idc == 255:
                s.sar_w, s.sar_h = br.u(16), br.u(16)
            elif idc in table:
                s.sar_w, s.sar_h = table[idc]
        if br.u(1):  # overscan_info_present_flag
            br.u(1)
        if br.u(1):  # video_signal_type_present_flag
            br.u(3)
            br.u(1)
            if br.u(1):
                br.u(24)
        if br.u(1):  # chroma_loc_info_present_flag
            br.ue()
            br.ue()
        if br.u(1):  # timing_info_present_flag
            nut = br.u(32)
            ts = br.u(32)
            if nut and ts:
                s.fps_num, s.fps_den = ts, 2 * nut
    except (EOFError, ValueError):
        pass


def parse_pps(nal: bytes) -> Optional[PPS]:
    try:
        br = BitReader(unescape(nal[1:]))
        pps_id = br.ue()
        sps_id = br.ue()
        if pps_id > 255 or sps_id > 31:
            return None
        ecm = br.u(1)
        bfp = br.u(1)
        return PPS(pps_id, sps_id, ecm, bfp, raw=bytes(nal))
    except (EOFError, ValueError):
        return None


@dataclass
class SliceInfo:
    first_mb: int
    slice_type: int
    pps_id: int
    frame_num: int = 0
    field_pic: int = 0
    bottom_field: int = 0
    idr_pic_id: int = 0
    poc_lsb: int = 0
    delta_poc_bottom: int = 0
    full: bool = False   # True if POC fields could be parsed (SPS/PPS known)


def parse_slice_header(nal: bytes, nal_type: int, sps_map: Dict[int, SPS],
                       pps_map: Dict[int, PPS]) -> Optional[SliceInfo]:
    try:
        br = BitReader(unescape(nal[1:48]))
        first_mb = br.ue()
        slice_type = br.ue()
        if slice_type > 9:
            return None
        pps_id = br.ue()
        if pps_id > 255:
            return None
        si = SliceInfo(first_mb, slice_type, pps_id)
        pps = pps_map.get(pps_id)
        if pps is None:
            return si
        sps = sps_map.get(pps.sps_id)
        if sps is None:
            return si
        if sps.separate_colour_plane:
            br.u(2)
        si.frame_num = br.u(sps.log2_max_frame_num)
        if not sps.frame_mbs_only:
            si.field_pic = br.u(1)
            if si.field_pic:
                si.bottom_field = br.u(1)
        if nal_type == 5:
            si.idr_pic_id = br.ue()
        if sps.poc_type == 0:
            si.poc_lsb = br.u(sps.log2_max_poc_lsb)
            if pps.bottom_field_pic_order_in_frame_present and not si.field_pic:
                si.delta_poc_bottom = br.se()
        si.full = True
        return si
    except (EOFError, ValueError):
        return None


@dataclass
class AU:
    length: int
    keyframe: bool
    nal_types: tuple
    ref_idc: int
    idr: bool
    slice: Optional[SliceInfo]
    param_sets: tuple   # raw SPS/PPS NALs found in this AU


class H264:
    """Access unit parser for length-prefixed AVC streams (as in MP4/MOV)."""

    name = "h264"

    def __init__(self, length_size: int = 4):
        self.nls = length_size
        self.sps: Dict[int, SPS] = {}
        self.pps: Dict[int, PPS] = {}
        self.allowed_first: Optional[set] = None   # learned from reference
        self.allowed_slice_types: Optional[set] = None
        self.max_au = 64 * 1024 * 1024

    # -- parameter sets ---------------------------------------------------
    def add_param_set(self, nal: bytes) -> None:
        if not nal:
            return
        t = nal[0] & 0x1F
        if t == 7:
            s = parse_sps(nal)
            if s:
                self.sps[s.sps_id] = s
        elif t == 8:
            p = parse_pps(nal)
            if p:
                self.pps[p.pps_id] = p

    @staticmethod
    def is_param_set(nal: bytes) -> bool:
        return bool(nal) and (nal[0] & 0x1F) in (7, 8)

    # -- AU parsing -------------------------------------------------------
    def parse_au(self, mm, pos: int, end: int, strict: bool = True) -> Optional[AU]:
        nls = self.nls
        p = pos
        seen_vcl = False
        types: List[int] = []
        first_slice: Optional[SliceInfo] = None
        ref_idc_au = 0
        idr = False
        psets = []
        nal_count = 0
        while p + nls < end:
            ln = int.from_bytes(mm[p:p + nls], "big")
            if ln < 1 or p + nls + ln - pos > self.max_au:
                if not seen_vcl:
                    return None
                break
            if p + nls + ln > end:
                # the data ends inside this NAL: the access unit is incomplete
                return None
            hdr = mm[p + nls]
            if hdr & 0x80:
                if not seen_vcl:
                    return None
                break
            t = hdr & 0x1F
            ref_idc = hdr >> 5
            if t not in ALLOWED:
                if not seen_vcl:
                    return None
                break
            if (t in MUST_REF and ref_idc == 0) or (t in MUST_NONREF and ref_idc != 0):
                if not seen_vcl:
                    return None
                break
            if nal_count == 0 and strict and self.allowed_first is not None and t not in self.allowed_first:
                return None
            if t in VCL:
                hb = mm[p + nls:p + nls + min(ln, 48)]
                si = parse_slice_header(hb, t, self.sps, self.pps)
                if si is None:
                    if not seen_vcl:
                        return None
                    break
                if seen_vcl:
                    if si.first_mb == 0:
                        break           # next picture starts here
                    # another slice of the same picture must agree with the first one
                    if (si.pps_id != first_slice.pps_id or (t == 5) != idr or (ref_idc == 0) != (ref_idc_au == 0)
                            or (si.full and first_slice.full and si.frame_num != first_slice.frame_num)):
                        break
                else:
                    if si.first_mb != 0:
                        return None     # a picture must start at macroblock 0
                    if strict:
                        if self.pps and si.pps_id not in self.pps:
                            return None
                        if self.allowed_slice_types is not None and (si.slice_type % 5) not in self.allowed_slice_types:
                            return None
                    first_slice = si
                    ref_idc_au = ref_idc
                    idr = (t == 5)
                seen_vcl = True
            elif seen_vcl and t in AU_START:
                break
            elif seen_vcl and t in (10, 11) and ln != 1:
                break          # end of sequence / stream NALs carry no payload
            elif seen_vcl and t == 12 and ln > 1 and (mm[p + nls + 1] != 0xFF or mm[p + nls + ln - 1] != 0x80):
                break          # filler data is FF FF ... 80
            elif t in (7, 8):
                psets.append(bytes(mm[p + nls:p + nls + ln]))
            types.append(t)
            nal_count += 1
            p += nls + ln
            if p - pos > self.max_au:
                return None
        if not seen_vcl:
            return None
        if psets:
            for ps in psets:
                self.add_param_set(ps)
        key = idr or (first_slice is not None and first_slice.slice_type % 5 in (2, 4) and 7 in types)
        return AU(p - pos, idr or key, tuple(types), ref_idc_au, idr, first_slice, tuple(psets))

    # -- learning from a reference track -----------------------------------
    def learn(self, aus: List[AU]) -> None:
        firsts = set()
        stypes = set()
        for a in aus:
            if a.nal_types:
                firsts.add(a.nal_types[0])
            if a.slice is not None:
                stypes.add(a.slice.slice_type % 5)
        if firsts:
            if firsts & VCL:
                firsts |= VCL
            self.allowed_first = firsts
        if stypes:
            self.allowed_slice_types = stypes

    def first_nal_headers(self) -> set:
        """Header byte values a frame's first NAL may have (for fast searching)."""
        types = self.allowed_first or {1, 5, 6, 7, 8, 9}
        out = set()
        for t in types:
            for ref in range(4):
                if t in MUST_REF and ref == 0:
                    continue
                if t in MUST_NONREF and ref != 0:
                    continue
                out.add((ref << 5) | t)
        return out


def poc_sequence(aus: List[AU], codec: H264) -> Optional[List[int]]:
    """Picture order count for each AU in decode order (None if unknown)."""
    out = []
    prev_msb = 0
    prev_lsb = 0
    prev_frame_num = 0
    frame_num_offset = 0
    for a in aus:
        si = a.slice
        if si is None or not si.full:
            return None
        pps = codec.pps.get(si.pps_id)
        sps = codec.sps.get(pps.sps_id) if pps else None
        if sps is None:
            return None
        if sps.poc_type == 0:
            if a.idr:
                prev_msb = prev_lsb = 0
            maxlsb = 1 << sps.log2_max_poc_lsb
            lsb = si.poc_lsb
            if lsb < prev_lsb and prev_lsb - lsb >= maxlsb // 2:
                msb = prev_msb + maxlsb
            elif lsb > prev_lsb and lsb - prev_lsb > maxlsb // 2:
                msb = prev_msb - maxlsb
            else:
                msb = prev_msb
            top = msb + lsb
            poc = top
            if not si.field_pic and si.delta_poc_bottom < 0:
                poc = top + si.delta_poc_bottom
            if a.ref_idc:
                prev_msb, prev_lsb = msb, lsb
            out.append(poc)
        elif sps.poc_type == 2:
            maxfn = 1 << sps.log2_max_frame_num
            if a.idr:
                frame_num_offset = 0
            elif prev_frame_num > si.frame_num:
                frame_num_offset += maxfn
            prev_frame_num = si.frame_num
            v = 2 * (frame_num_offset + si.frame_num)
            if not a.ref_idc:
                v -= 1
            out.append(v)
        else:
            return None
    return out


def build_avcc(sps_list: List[bytes], pps_list: List[bytes], length_size: int = 4) -> bytes:
    s0 = sps_list[0]
    body = bytes([1, s0[1], s0[2], s0[3], 0xFC | (length_size - 1), 0xE0 | len(sps_list)])
    for s in sps_list:
        body += len(s).to_bytes(2, "big") + s
    body += bytes([len(pps_list)])
    for p in pps_list:
        body += len(p).to_bytes(2, "big") + p
    sp = parse_sps(s0)
    if sp and sp.profile_idc in (100, 110, 122, 144):
        body += bytes([0xFC | sp.chroma_format_idc, 0xF8 | (sp.bit_depth_luma - 8),
                       0xF8 | (sp.bit_depth_chroma - 8), 0])
    return body


def parse_avcc(payload: bytes):
    """-> (length_size, [sps], [pps])"""
    nls = (payload[4] & 3) + 1
    n = payload[5] & 0x1F
    o = 6
    sps, pps = [], []
    for _ in range(n):
        ln = int.from_bytes(payload[o:o + 2], "big")
        sps.append(payload[o + 2:o + 2 + ln])
        o += 2 + ln
    n = payload[o]
    o += 1
    for _ in range(n):
        ln = int.from_bytes(payload[o:o + 2], "big")
        pps.append(payload[o + 2:o + 2 + ln])
        o += 2 + ln
    return nls, sps, pps
