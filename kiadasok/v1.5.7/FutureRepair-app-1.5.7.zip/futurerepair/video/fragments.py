"""Reassembly of recordings whose data is split into blocks interleaved with foreign data.

Memory cards (exFAT/FAT) allocate space in clusters, cameras often in big allocation units
(e.g. 32 MB). When two files grow at the same time, or the allocation information is lost and
a recovery tool copies a contiguous run of the card, the file contains the recording in
fixed-size blocks with blocks of other data in between. This module finds the block size,
follows the recording block by block (a block continues the recording if the unit cut at the
end of the previous block parses correctly across the join) and offers a contiguous virtual
view of the recording for the scanner and the writer.
"""
from __future__ import annotations

from typing import Callable, Dict, List, Optional, Tuple

from .models import FixedModel, NalVideoModel
from .scanner import Scanner

REV = 2

BLOCK_SIZES = [1 << k for k in range(27, 15, -1)]   # 128 MiB ... 64 KiB


class BlockView:
    """Read-only, contiguous view over a list of physical extents (start, end) of a buffer."""

    def __init__(self, mm, extents: List[Tuple[int, int]]):
        self.mm = mm
        self.extents = [(s, e) for s, e in extents if e > s]
        self.starts = []          # logical start of each extent
        pos = 0
        for s, e in self.extents:
            self.starts.append(pos)
            pos += e - s
        self.size = pos

    def __len__(self) -> int:
        return self.size

    def _locate(self, i: int) -> int:
        lo, hi = 0, len(self.starts) - 1
        while lo < hi:
            mid = (lo + hi + 1) // 2
            if self.starts[mid] <= i:
                lo = mid
            else:
                hi = mid - 1
        return lo

    def physical(self, i: int) -> int:
        """Physical (file) offset of logical position i."""
        if not self.extents:
            return i
        if i >= self.size:
            return self.extents[-1][1] + (i - self.size)
        k = self._locate(i)
        return self.extents[k][0] + (i - self.starts[k])

    def __getitem__(self, key):
        if isinstance(key, slice):
            start, stop, step = key.indices(self.size)
            if step != 1:
                raise ValueError("step not supported")
            if stop <= start:
                return b""
            k = self._locate(start)
            s, e = self.extents[k]
            a = s + (start - self.starts[k])
            if a + (stop - start) <= e:          # common case: inside one extent
                return self.mm[a:a + (stop - start)]
            out = []
            pos = start
            while pos < stop and k < len(self.extents):
                s, e = self.extents[k]
                ls = self.starts[k]
                a = s + (pos - ls)
                b = min(e, s + (stop - ls))
                out.append(self.mm[a:b])
                pos += b - a
                k += 1
            return b"".join(out)
        if key < 0:
            key += self.size
        if key < 0 or key >= self.size:
            raise IndexError("BlockView index out of range")
        k = self._locate(key)
        return self.mm[self.extents[k][0] + (key - self.starts[k])]

    # --- searching ----------------------------------------------------------
    def _windows(self, start: int, end: int, overlap: int):
        """Yield (logical_offset, bytes) windows covering [start, end) with overlap."""
        step = 8 << 20
        pos = start
        while pos < end:
            w_end = min(end, pos + step)
            yield pos, self[pos:min(self.size, w_end + overlap)]
            pos = w_end

    def find(self, sub: bytes, start: int = 0, end: Optional[int] = None) -> int:
        end = self.size if end is None else min(end, self.size)
        for off, buf in self._windows(start, end, len(sub)):
            i = buf.find(sub)
            if i != -1 and off + i + len(sub) <= end:
                return off + i
        return -1

    def finditer(self, regex, start: int, end: int):
        end = min(end, self.size)
        seen = start - 1
        for off, buf in self._windows(start, end, 64):
            for m in regex.finditer(buf):
                p = off + m.start()
                if p >= end:
                    break
                if p <= seen:
                    continue
                seen = p
                yield p

    def read_into(self, f, start: int, length: int, out, bs: int = 16 << 20,
                  progress: Optional[Callable[[int], None]] = None, cancel=None) -> int:
        """Copy logical [start, start+length) from file object f to out."""
        done = 0
        pos = start
        stop = start + length
        while pos < stop:
            if cancel and cancel():
                raise InterruptedError
            k = self._locate(pos)
            s, e = self.extents[k]
            phys = s + (pos - self.starts[k])
            n = min(bs, e - phys, stop - pos)
            f.seek(phys)
            b = f.read(n)
            if not b:
                break
            out.write(b)
            pos += len(b)
            done += len(b)
            if progress:
                progress(done)
        return done


# ---------------------------------------------------------------------------
# Block size
# ---------------------------------------------------------------------------

def max_unit_size(models) -> int:
    """Largest unit the scanner reads in one go (a frame, or a whole fixed-size chunk)."""
    best = 0
    for m in models:
        if isinstance(m, FixedModel):
            if m.size_counts:
                best = max(best, max(m.size_counts))
            continue
        t = m.ref_track
        if t is not None and t.sizes:
            best = max(best, max(t.sizes))
    return best or (1 << 20)


def detect_block_size(skips: List[Tuple[int, int]], units: List[int], data_start: int,
                      max_unit: int) -> Optional[int]:
    """Largest power-of-two block size that explains the places where the stream breaks.

    For a break [p, q) whose last recognised unit started at u, the cut lies on the first block
    boundary after u, no later than the end of the unit that starts at p, and the recording
    resumes (q) after the cut.
    """
    n = len(skips)
    if n < 3:
        return None
    need = max(3, -(-8 * n // 10))
    for B in BLOCK_SIZES:
        if B < 2 * max_unit:
            break                      # blocks this small can't be told apart reliably
        good = 0
        for (p, q), u in zip(skips, units):
            b = (u // B + 1) * B
            if data_start < b <= p + max_unit and q >= b:
                good += 1
        if good >= need:
            return B
    return None


# ---------------------------------------------------------------------------
# Following the recording
# ---------------------------------------------------------------------------

def _units_after(sc: Scanner, boundary: int) -> int:
    """Number of units that end after `boundary` (a fixed-size chunk counts as one)."""
    n = 0
    for mi, c in sc.order:
        if c.end <= boundary:
            continue
        if isinstance(sc.models[mi], FixedModel) or not c.sizes:
            n += 1
            continue
        pos = c.start
        for sz in c.sizes:
            pos += sz
            if pos > boundary:
                n += 1
    return n


class ChainBuilder:
    """Follows a recording block by block.

    In-file mode (default): blocks are B-sized pieces of one damaged file counted from offset 0.
    Disk mode (origin/limit/skip set by a subclass or caller): blocks are allocation units of a
    whole disk on a grid starting at `origin`, the chain stops after `limit` bytes.
    """

    def __init__(self, mm, start: int, end: int, B: int, models, transitions, max_unit: int,
                 log: Optional[Callable[[str], None]] = None, cancel=None,
                 progress: Optional[Callable[[float], None]] = None, max_ahead: int = 96):
        self.mm = mm
        self.start = start
        self.end = end
        self.B = B
        self.origin = 0                 # physical offset of block 0
        self.extent_start = None        # physical start of the first extent (default: start)
        self.restart0 = 0               # logical position of the first unit
        self.limit = None               # stop when the reassembled view is this long
        self.max_back = 0               # also look this many blocks backwards
        self.skip = None                # skip(block) -> True for blocks that can't continue anything
        self.trim_to_limit = True       # cut the last extent at `limit`
        self.slow_limit = None          # how many candidates get the (slow) second pass
        self.pred_skip = None           # pred_skip(block) -> True for blocks that can't precede anything
        self.models = models
        self.transitions = transitions
        self.max_unit = max_unit
        self.probe = min(B, 3 * max_unit + (1 << 20))
        self.tail_allow = max_unit + 64
        self.log = log or (lambda s: None)
        self.cancel = cancel
        self.progress = progress
        self.max_ahead = max_ahead
        self.resync_ahead = 16
        self.stats: Dict[str, list] = {"gaps": [], "resync": [], "blocks": []}
        self.last_scan = (0, 0, 0)

    # -- helpers -------------------------------------------------------------
    def _seg(self, nb: int) -> Tuple[int, int]:
        a = self.origin + nb * self.B
        return a, min(self.end, a + self.B)

    def _block_of(self, pos: int) -> int:
        return (pos - self.origin) // self.B

    def _candidates(self, cur: int, last_block: int, used: set):
        def ok(nb):
            return nb not in used and (self.skip is None or not self.skip(nb))
        for nb in range(cur + 1, min(last_block, cur + self.max_ahead) + 1):
            if ok(nb):
                yield nb
        for nb in range(cur - 1, max(-1, cur - 1 - self.max_back), -1):
            if nb >= 0 and ok(nb):
                yield nb

    def _scanner(self, view, a, b, **kw) -> Scanner:
        sc = Scanner(view, a, b, self.models, self.transitions, cancel=self.cancel, **kw)
        sc.tail_window = self.probe
        return sc

    def _restart_point(self, view, restart: int, boundary: int):
        """A unit start shortly before the end of the current block, and whether the
        recording's data runs up to the end of the block (if not, the recording ends here)."""
        sc = self._scanner(view, restart, boundary)
        sc.run()
        r = sc.order[-1][1].start if sc.order else restart
        tail = sc.tail_from
        reaches = tail >= boundary - self.tail_allow or self._crosses(view, tail, boundary)
        if reaches and boundary - tail > 64:
            rest = view[tail:boundary]
            if not rest.strip(b"\x00"):
                reaches = False        # only zero padding after the last unit: the recording ended
        self.last_scan = (view.physical(tail) if tail < len(view) else tail, len(sc.skips), sc.skipped_bytes)
        return r, reaches

    def _crosses(self, view, p: int, boundary: int) -> bool:
        """True if a video frame starts at p whose NAL units run cleanly up to the boundary
        (a frame bigger than any in the sample can be cut by the end of the block)."""
        for m in self.models:
            if not isinstance(m, NalVideoModel):
                continue
            nls = m.codec.nls
            first = m.codec.allowed_first
            q = p
            n = 0
            while q + nls + 1 <= boundary:
                ln = int.from_bytes(view[q:q + nls], "big")
                if ln < 1 or ln > m.max_au:
                    break
                hdr = view[q + nls]
                if hdr & 0x80:
                    break
                if n == 0 and first is not None:
                    t = (hdr & 0x1F) if m.codec.name == "h264" else ((hdr >> 1) & 0x3F)
                    if t not in first:
                        break
                if q + nls + ln >= boundary:
                    return True
                q += nls + ln
                n += 1
                if q - p > m.max_au:
                    break
        return False

    def _continues(self, view, r: int, boundary: int, fast: bool) -> bool:
        end2 = min(len(view), boundary + self.probe)
        if end2 <= boundary:
            return False
        if self.limit is not None and not self.trim_to_limit and boundary < self.limit <= end2:
            # The recording is known to end at `limit` (disk mode): the units must run exactly
            # up to it.
            sc = self._scanner(view, r, self.limit, stop_on_fail=True, fast=fast)
            sc.run()
            n = _units_after(sc, boundary)
            ok_end = sc.fail_at is None or sc.fail_at >= self.limit
            return ok_end and n >= 1
        sc = self._scanner(view, r, end2, stop_on_fail=True, fast=fast)
        sc.run()
        n = _units_after(sc, boundary)
        if sc.fail_at is not None and sc.fail_at < end2 - self.tail_allow:
            # Either a wrong block, or the recording ends inside this block (followed by zero
            # padding or other data). Only accept it if several units read cleanly across the join.
            return n >= 3
        if end2 == len(view) and end2 - boundary < self.probe:
            # the file ends inside this block: one good unit across the join is all there is
            return n >= 1 or sc.fail_at is None
        return n >= 2

    def _find_continuation(self, extents, r: int, boundary: int, cur: int, last_block: int,
                           used: set) -> Optional[int]:
        cands = list(self._candidates(cur, last_block, used))
        for fast in (True, False):
            for nb in (cands if fast or self.slow_limit is None else cands[:self.slow_limit]):
                if self.cancel and self.cancel():
                    raise InterruptedError
                v2 = BlockView(self.mm, extents + [self._seg(nb)])
                if self._continues(v2, r, boundary, fast):
                    if not fast and self._continues_other(nb, used):
                        continue
                    return nb
        return None

    def _first_start(self, nb: int) -> Optional[int]:
        """Offset (inside block nb) of the first recognisable unit near the start of the block."""
        a, b = self._seg(nb)
        v = BlockView(self.mm, [(a, b)])
        sc = self._scanner(v, 0, len(v))
        return sc.find_next(0, limit=min(len(v), min(self.B, 2 * self.max_unit + (1 << 20))))

    def _continues_other(self, nb: int, used: set, depth: int = 8) -> bool:
        """True if block nb is the continuation of a block that is NOT part of the recording,
        i.e. it belongs to another stream with the same format (e.g. another clip)."""
        for y in range(nb - 1, max(-1, nb - 1 - depth), -1):
            if y in used or (self.pred_skip(y) if self.pred_skip is not None else self._seg(y)[0] < self.start):
                continue
            q = self._first_start(y)
            if q is None:
                continue
            a, b = self._seg(y)
            vy = BlockView(self.mm, [(a, b)])
            r, reaches = self._restart_point(vy, q, len(vy))
            if not reaches:
                continue
            v2 = BlockView(self.mm, [(a, b), self._seg(nb)])
            if self._continues(v2, r, len(vy), fast=True):
                return True
        return False

    def _resync(self, cur: int, last_block: int, used: set) -> Tuple[Optional[int], int]:
        """Next block in which the recording clearly goes on (after a lost or damaged block)."""
        for nb in range(cur + 1, min(last_block, cur + self.resync_ahead) + 1):
            if self.cancel and self.cancel():
                raise InterruptedError
            if nb in used or (self.skip is not None and self.skip(nb)):
                continue
            q = self._first_start(nb)
            if q is None:
                continue
            a, b = self._seg(nb)
            v = BlockView(self.mm, [(a, b)])
            need = min(len(v), q + max(4 * self.max_unit, 8 << 20))
            sc2 = self._scanner(v, q, need, stop_on_fail=True, fast=True)
            sc2.run()
            if sc2.fail_at is not None and sc2.fail_at < need - self.tail_allow:
                continue
            if self._continues_other(nb, used):
                self.log("Darabolás: a %d. blokk egy másik felvétel folytatása – kihagyva." % nb)
                continue
            return nb, q
        return None, 0

    # -- main ----------------------------------------------------------------
    def _done(self, extents) -> bool:
        if self.limit is not None:
            return sum(e - s for s, e in extents) >= self.limit
        return extents[-1][1] >= self.end

    def run(self, used: Optional[set] = None) -> List[Tuple[int, int]]:
        first = self._block_of(self.start)
        ext_start = self.start if self.extent_start is None else self.extent_start
        extents: List[Tuple[int, int]] = [(ext_start, self._seg(first)[1])]
        self.stats["blocks"].append(first)
        used = set() if used is None else used
        used.add(first)
        cur = first
        last_block = self._block_of(self.end - 1)
        restart = self.restart0
        while not self._done(extents):
            if self.cancel and self.cancel():
                raise InterruptedError
            if self.progress:
                if self.limit:
                    self.progress(min(1.0, sum(e - s for s, e in extents) / float(self.limit)))
                else:
                    self.progress(min(1.0, (cur - first) / float(max(1, last_block - first))))
            view = BlockView(self.mm, extents)
            boundary = len(view)
            r, reaches = self._restart_point(view, restart, boundary)
            nb = self._find_continuation(extents, r, boundary, cur, last_block, used)
            if nb is not None:
                extents.append(self._seg(nb))
                restart = r
            elif not reaches:
                # the recording's data stops inside this block: this is where it ends
                self.log("Darabolás: a felvétel a %d. blokkban véget ér (olvasható adat vége: %d, "
                         "kihagyás a blokkban: %d db / %d bájt)." % ((cur,) + self.last_scan))
                break
            elif not view[r:boundary].strip(b"\x00"):
                # nothing but zero padding up to the end of the block: the recording ended here
                self.log("Darabolás: a felvétel a %d. blokkban véget ér (utána csak kitöltés)." % cur)
                break
            else:
                nb, q = self._resync(cur, last_block, used)
                if nb is None:
                    self.log("Darabolás: a %d. blokk után nincs több saját adat (újrakezdési pont: %d, "
                             "a blokk vége: %d)." % (cur, view.physical(r), extents[-1][1]))
                    break
                self.log("Darabolás: a %d. blokk után a folytatás nem illeszthető; újrakezdés a %d. "
                         "blokkban (adatvesztés a határon)." % (cur, nb))
                self.stats["resync"].append((cur, nb))
                extents.append(self._seg(nb))
                restart = boundary + q
            if nb != cur + 1:
                self.stats["gaps"].append((cur, nb))
            self.stats["blocks"].append(nb)
            used.add(nb)
            cur = nb
        if self.progress:
            self.progress(1.0)
        self._log_summary()
        if self.limit is not None and self.trim_to_limit:
            extents = _trim(extents, self.limit)
        self.blocks = list(self.stats["blocks"])
        return _merge(extents)

    def _log_summary(self) -> None:
        blocks = self.stats["blocks"]
        runs = []
        for b in blocks:
            if runs and runs[-1][1] == b - 1:
                runs[-1][1] = b
            else:
                runs.append([b, b])
        txt = ", ".join(("%d" % a) if a == b else ("%d-%d" % (a, b)) for a, b in runs)
        if len(txt) > 1500:
            txt = txt[:1500] + " …"
        self.log("Darabolás: blokkméret %d KB, a felvétel blokkjai (%d db): %s"
                 % (self.B >> 10, len(blocks), txt))


def build_chain(mm, start: int, end: int, B: int, models, transitions, max_unit: int,
                log: Optional[Callable[[str], None]] = None, cancel=None,
                progress: Optional[Callable[[float], None]] = None):
    """Follow the recording block by block. Returns (physical extents in recording order, stats)."""
    cb = ChainBuilder(mm, start, end, B, models, transitions, max_unit, log=log, cancel=cancel,
                      progress=progress)
    ext = cb.run()
    return ext, cb.stats


def _trim(extents, limit: int):
    out = []
    total = 0
    for s, e in extents:
        if total >= limit:
            break
        e = min(e, s + (limit - total))
        out.append((s, e))
        total += e - s
    return out


def _merge(extents):
    out = []
    for s, e in extents:
        if out and out[-1][1] == s:
            out[-1] = (out[-1][0], e)
        else:
            out.append((s, e))
    return out
