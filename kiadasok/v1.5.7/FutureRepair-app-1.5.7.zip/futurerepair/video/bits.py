"""Bit-level helpers: big-endian bit reader with Exp-Golomb, NAL unescaping."""
from __future__ import annotations


class BitReader:
    __slots__ = ("data", "pos", "nbits")

    def __init__(self, data: bytes, start_bit: int = 0):
        self.data = data
        self.pos = start_bit
        self.nbits = len(data) * 8

    def left(self) -> int:
        return self.nbits - self.pos

    def bit(self) -> int:
        p = self.pos
        if p >= self.nbits:
            raise EOFError("bitstream exhausted")
        self.pos = p + 1
        return (self.data[p >> 3] >> (7 - (p & 7))) & 1

    def u(self, n: int) -> int:
        if n == 0:
            return 0
        p = self.pos
        if p + n > self.nbits:
            raise EOFError("bitstream exhausted")
        first = p >> 3
        last = (p + n - 1) >> 3
        chunk = int.from_bytes(self.data[first:last + 1], "big")
        total = (last - first + 1) * 8
        shift = total - ((p & 7) + n)
        self.pos = p + n
        return (chunk >> shift) & ((1 << n) - 1)

    def skip(self, n: int) -> None:
        self.pos += n
        if self.pos > self.nbits:
            raise EOFError("bitstream exhausted")

    def ue(self) -> int:
        zeros = 0
        while self.bit() == 0:
            zeros += 1
            if zeros > 31:
                raise ValueError("invalid exp-golomb code")
        if zeros == 0:
            return 0
        return (1 << zeros) - 1 + self.u(zeros)

    def se(self) -> int:
        k = self.ue()
        if k & 1:
            return (k + 1) >> 1
        return -(k >> 1)


def unescape(nal: bytes) -> bytes:
    """Remove emulation-prevention bytes (00 00 03 -> 00 00)."""
    if b"\x00\x00\x03" not in nal:
        return nal
    out = bytearray()
    zeros = 0
    for b in nal:
        if zeros >= 2 and b == 3:
            zeros = 0
            continue
        out.append(b)
        zeros = zeros + 1 if b == 0 else 0
    return bytes(out)


def be32(b: bytes, o: int = 0) -> int:
    return int.from_bytes(b[o:o + 4], "big")


def be16(b: bytes, o: int = 0) -> int:
    return int.from_bytes(b[o:o + 2], "big")


def be64(b: bytes, o: int = 0) -> int:
    return int.from_bytes(b[o:o + 8], "big")
