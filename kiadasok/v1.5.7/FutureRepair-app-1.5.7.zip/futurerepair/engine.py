"""Single entry point used by the GUI and the command line."""
from __future__ import annotations

import os
from typing import Callable, Optional

from .result import RepairResult, Reporter

VIDEO_EXT = {".mp4", ".mov", ".m4v", ".3gp", ".3g2", ".insv", ".lrv", ".m4a", ".mqv", ".qt"}
PHOTO_EXT = {".jpg", ".jpeg", ".jpe", ".jfif", ".cr2", ".cr3", ".crw", ".nef", ".nrw", ".arw", ".srf",
             ".sr2", ".dng", ".raf", ".orf", ".rw2", ".pef", ".srw", ".3fr", ".iiq", ".erf", ".mrw",
             ".x3f", ".kdc", ".dcr", ".mos", ".rwl"}
AUDIO_EXT = {".wav", ".wave", ".bwf", ".rf64", ".mp3"}

KIND_LABEL = {"video": "Videó", "photo": "Fotó", "audio": "Hang"}


def classify(path: str) -> Optional[str]:
    ext = os.path.splitext(path)[1].lower()
    if ext in VIDEO_EXT:
        return "video"
    if ext in PHOTO_EXT:
        return "photo"
    if ext in AUDIO_EXT:
        return "audio"
    # unknown extension: sniff
    try:
        with open(path, "rb") as f:
            head = f.read(64)
    except OSError:
        return None
    if head[4:8] in (b"ftyp", b"mdat", b"moov", b"wide", b"free"):
        return "video"
    if head[:3] == b"\xff\xd8\xff":
        return "photo"
    if head[:4] in (b"RIFF", b"RF64") or head[:3] == b"ID3":
        return "audio"
    return None


def needs_reference(kind: str) -> str:
    """Hint text for the UI about the sample file for a given kind."""
    return {
        "video": "Ép videó ugyanarról a kameráról, ugyanazzal a felbontással, fps-sel és kodekkel.",
        "photo": "Ép JPEG ugyanarról a gépről, ugyanabban a képméretben és minőségben (sérült fejlécnél kell).",
        "audio": "Ép WAV ugyanarról a felvevőről, ugyanazzal a mintavétellel (ha a fejléc teljesen elveszett).",
    }.get(kind, "")


def repair(path: str, reference: Optional[str] = None, out_path: Optional[str] = None,
           progress: Optional[Callable[[float], None]] = None,
           cancel: Optional[Callable[[], bool]] = None,
           reporter: Optional[Reporter] = None, **opts) -> RepairResult:
    kind = classify(path)
    rep = reporter or Reporter()
    if not os.path.isfile(path):
        return RepairResult("failed", None, "A fájl nem található.")
    if reference and os.path.abspath(reference) == os.path.abspath(path):
        reference = None
        rep.warn("A mintafájl ugyanaz, mint a sérült fájl – minta nélkül folytatom.")
    if kind == "video":
        from .video.repair import repair_video
        return repair_video(path, reference, out_path, fps=opts.get("fps"), progress=progress,
                            cancel=cancel, reporter=rep)
    if kind == "photo":
        from .photo.repair import repair_photo
        if progress:
            progress(0.2)
        res = repair_photo(path, reference, out_path, reporter=rep)
        if progress:
            progress(1.0)
        return res
    if kind == "audio":
        from .audio.repair import repair_audio
        if progress:
            progress(0.2)
        res = repair_audio(path, reference, out_path, reporter=rep)
        if progress:
            progress(1.0)
        return res
    return RepairResult("failed", None, "Ezt a fájltípust a program nem ismeri.")
