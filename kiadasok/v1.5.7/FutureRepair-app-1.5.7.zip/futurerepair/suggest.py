"""Finds a likely healthy sample file next to a broken video."""
from __future__ import annotations

import os
import re
from typing import Optional


def video_is_healthy(path: str) -> bool:
    from .video.analyze import read_layout
    try:
        lay = read_layout(path)
    except (OSError, ValueError):
        return False
    if lay.moov is None or lay.fragmented:
        return False
    if not any(t.is_video and t.sizes for t in lay.moov.tracks):
        return False
    for t in lay.moov.tracks:
        if t.sizes and t.offsets[-1] + t.sizes[-1] > lay.size:
            return False
    return True


def _stem_key(name: str) -> str:
    """'20260717_davisual_9451' -> '_davisual_' style pattern used to prefer the same camera."""
    return re.sub(r"\d+", "#", os.path.splitext(name)[0].lower())


_PROFILE_CACHE = {}


def match_score(broken: str, reference: str, probe_bytes: int = 24 * 1024 * 1024) -> float:
    """Share of the first `probe_bytes` of the broken file's data that the reference explains."""
    import mmap
    from .video.analyze import build_profile, read_layout
    from .video.scanner import Scanner
    try:
        key = (os.path.abspath(reference), os.path.getmtime(reference))
        prof = _PROFILE_CACHE.get(key)
        if prof is None:
            prof = build_profile(reference)
            _PROFILE_CACHE.clear()
            _PROFILE_CACHE[key] = prof
        lay = read_layout(broken)
    except Exception:  # noqa: BLE001
        return 0.0
    start = lay.mdat_start if lay.mdat_start >= 0 else 0
    end = lay.mdat_end if lay.mdat_end > 0 else lay.size
    end = min(end, start + probe_bytes)
    if end <= start:
        return 0.0
    with open(broken, "rb") as f:
        mm = mmap.mmap(f.fileno(), 0, access=mmap.ACCESS_READ)
        try:
            sc = Scanner(mm, start, end, prof.models, prof.transitions)
            sc.run()
            covered = sum(c.end - c.start for _mi, c in sc.order)
        finally:
            mm.close()
    return covered / float(end - start)


def suggest_reference(broken: str, max_files: int = 40) -> Optional[str]:
    folder = os.path.dirname(os.path.abspath(broken))
    ext = os.path.splitext(broken)[1].lower()
    try:
        names = sorted(os.listdir(folder))
    except OSError:
        return None
    me = os.path.basename(broken)
    key = _stem_key(me)
    try:
        my_mtime = os.path.getmtime(broken)
    except OSError:
        my_mtime = 0
    cands = []
    for n in names:
        if n == me or os.path.splitext(n)[1].lower() != ext or "_javitott" in n.lower():
            continue
        p = os.path.join(folder, n)
        try:
            st = os.stat(p)
        except OSError:
            continue
        if st.st_size < 256 * 1024:
            continue
        score = (0 if _stem_key(n) == key else 1, abs(st.st_mtime - my_mtime))
        cands.append((score, p))
    cands.sort()
    best = (0.0, None)
    tested = 0
    for _score, p in cands[:max_files]:
        if not video_is_healthy(p):
            continue
        sc = match_score(broken, p)
        if sc >= 0.9:
            return p
        if sc > best[0]:
            best = (sc, p)
        tested += 1
        if tested >= 6:
            break
    return best[1] if best[0] >= 0.3 else None
