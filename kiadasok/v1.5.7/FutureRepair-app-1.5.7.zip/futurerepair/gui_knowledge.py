"""The shared knowledge's chip in the top bar and its window."""
from __future__ import annotations

import time
from typing import Optional

from PySide6.QtCore import Qt, QTimer
from PySide6.QtWidgets import (QCheckBox, QDialog, QHBoxLayout, QInputDialog, QLabel, QMessageBox, QPlainTextEdit,
                               QPushButton, QVBoxLayout)

from . import knowledge, theme
from .gui_update import Background


def _when(ts) -> str:
    try:
        return time.strftime("%Y.%m.%d. %H:%M", time.localtime(float(ts)))
    except (TypeError, ValueError):
        return "még nem"


class KnowledgeButton(QPushButton):
    def __init__(self, window):
        super().__init__()
        self.window = window
        self.dialog: Optional[KnowledgeDialog] = None
        self.bg = Background(self)
        self.setObjectName("chip")
        self.setFont(theme.font(12.5, 500))
        self.setCursor(Qt.PointingHandCursor)
        self.clicked.connect(self.open_dialog)
        theme.notifier.changed.connect(self.refresh)
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.refresh)
        self.timer.start(60_000)
        self.refresh()

    def refresh(self):
        st = knowledge.status()
        ok = st["key"] and not st["last_error"]
        self.setText("Tudásbázis: %d minta" % st["templates"])
        self.setIcon(theme.dot_icon(theme.tone("ok" if ok else ("warn" if st["key"] else "muted"))))
        tip = ("Közös tudásbázis: ezekből a mintákból minta nélkül is megjavítja a már látott kamerák felvételeit.\n"
               "Utolsó szinkron: %s" % _when(st.get("last_sync")))
        if not st["key"]:
            tip += "\nNincs kulcs: a minták csak ezen a gépen gyűlnek."
        elif st["last_error"]:
            tip += "\nUtolsó hiba: %s" % st["last_error"]
        self.setToolTip(tip)
        if self.dialog is not None:
            self.dialog.refresh()

    def sync_now(self):
        def job():
            try:
                return knowledge.sync()
            except Exception as e:  # noqa: BLE001
                return {"ok": False, "error": str(e)}
        self.bg.start(job, self._synced)

    def _synced(self, r):
        self.refresh()
        if self.dialog is not None:
            self.dialog.last = r

    def open_dialog(self):
        if self.dialog is None:
            self.dialog = KnowledgeDialog(self)
        self.dialog.refresh()
        self.dialog.show()
        self.dialog.raise_()
        self.dialog.activateWindow()


class KnowledgeDialog(QDialog):
    def __init__(self, button: KnowledgeButton):
        super().__init__(button.window)
        self.button = button
        self.last = None
        self.setWindowTitle("Future Repair – közös tudásbázis")
        self.setMinimumWidth(560)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(28, 24, 28, 22)
        lay.setSpacing(12)
        lay.addWidget(theme.title("Közös tudásbázis"))
        intro = QLabel("Ha egy javítás mintafájllal sikerül, vagy a lemez-visszaállítás ép felvételt hoz vissza, a "
                       "program eltanulja annak a kamerának és beállításnak a fájlszerkezetét. Amit bármelyik gépen "
                       "megtanult, azt a többi is letölti, így ezeknek a kameráknak a sérült felvételét minta nélkül "
                       "is megjavítja. A kép, a hang, a fájlnév és a helyadatok nem kerülnek fel.")
        intro.setWordWrap(True)
        intro.setObjectName("sub")
        lay.addWidget(intro)
        self.info = QLabel()
        self.info.setWordWrap(True)
        self.info.setTextFormat(Qt.RichText)
        lay.addWidget(self.info)
        lay.addWidget(theme.heading("Ismert felvételfajták"))
        self.kinds = QPlainTextEdit()
        self.kinds.setReadOnly(True)
        self.kinds.setMinimumHeight(140)
        self.kinds.setPlaceholderText("Még nincs minta.")
        lay.addWidget(self.kinds, 1)
        self.share_cb = QCheckBox("Amit ez a gép megtanul, kerüljön fel a közösbe")
        self.share_cb.toggled.connect(knowledge.set_sharing)
        lay.addWidget(self.share_cb)
        row = QHBoxLayout()
        row.setSpacing(8)
        self.btn_sync = QPushButton("Szinkron most")
        self.btn_key = QPushButton("Kulcs megadása…")
        self.btn_close = QPushButton("Bezárás")
        row.addWidget(self.btn_sync)
        row.addWidget(self.btn_key)
        row.addStretch(1)
        row.addWidget(self.btn_close)
        lay.addLayout(row)
        self.btn_sync.clicked.connect(self._sync)
        self.btn_key.clicked.connect(self._key)
        self.btn_close.clicked.connect(self.close)
        self.button.bg.finished.connect(self.refresh)
        theme.notifier.changed.connect(self.refresh)

    def refresh(self):
        st = knowledge.status()
        sub, warn, ok = theme.tone("sub"), theme.tone("warn"), theme.tone("ok")
        rows = ["<span style='color:%s'>Minták ezen a gépen:</span> <b>%d</b> (ebből itt tanult: %d, beküldésre "
                "vár: %d)" % (sub, st["templates"], st["local"], st["pending"]),
                "<span style='color:%s'>Utolsó szinkron:</span> %s" % (sub, _when(st.get("last_sync")))]
        if self.button.bg.busy():
            rows.append("<span style='color:%s'>Szinkron folyamatban…</span>" % theme.tone("accent"))
        if not st["key"]:
            rows.append("<span style='color:%s'>Nincs kulcs: a minták csak ezen a gépen gyűlnek. A kulcsot a "
                        "telepítő adja, vagy a „Kulcs megadása…” gombbal lehet beírni.</span>" % warn)
        elif st["last_error"]:
            rows.append("<span style='color:%s'>Utolsó hiba: %s</span>" % (warn, st["last_error"]))
        elif self.last and self.last.get("ok"):
            rows.append("<span style='color:%s'>Szinkron kész: %d elküldve, %d új letöltve.</span>"
                        % (ok, self.last.get("sent", 0), self.last.get("got", 0)))
        self.info.setText("<br>".join(rows))
        self.kinds.setPlainText("\n".join(st["labels"]))
        self.share_cb.blockSignals(True)
        self.share_cb.setChecked(bool(st["share"]))
        self.share_cb.blockSignals(False)
        self.btn_sync.setEnabled(st["key"] and not self.button.bg.busy())
        self.btn_key.setVisible(not st["key"])

    def _sync(self):
        self.button.sync_now()
        self.refresh()

    def _key(self):
        k, ok = QInputDialog.getText(self, "Kulcs", "A közös tudásbázis kulcsa (a stúdiótól):")
        if ok and k.strip():
            if len(k.strip()) < 16:
                QMessageBox.warning(self, "Kulcs", "Ez nem tűnik kulcsnak.")
                return
            knowledge.save_key(k.strip())
            self.button.sync_now()
        self.refresh()
