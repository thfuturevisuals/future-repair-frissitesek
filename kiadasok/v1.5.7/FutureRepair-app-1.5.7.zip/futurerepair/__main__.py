import sys

if "--mcp" in sys.argv[1:]:
    from .mcp_server import main
elif len(sys.argv) > 1 and not sys.argv[1].startswith("-psn"):
    from .cli import main
else:
    from .gui import main

sys.exit(main())
