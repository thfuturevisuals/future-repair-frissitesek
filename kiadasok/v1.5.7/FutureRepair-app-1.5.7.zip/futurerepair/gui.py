"""Future Repair - desktop UI (PySide6)."""
from __future__ import annotations

import os
import subprocess
import sys
from dataclasses import dataclass, field
from typing import List, Optional

from PySide6.QtCore import QObject, QSize, Qt, QThread, QUrl, Signal
from PySide6.QtGui import QColor, QDesktopServices, QFont, QIcon, QPalette, QPixmap
from PySide6.QtWidgets import (QAbstractItemView, QApplication, QComboBox, QFileDialog, QFrame, QHBoxLayout,
                               QHeaderView, QLabel, QMainWindow, QMessageBox, QPlainTextEdit, QProgressBar,
                               QPushButton, QSizePolicy, QSplitter, QStackedWidget, QTableWidget, QTableWidgetItem,
                               QVBoxLayout, QWidget)

from . import __version__, theme
from .engine import AUDIO_EXT, KIND_LABEL, PHOTO_EXT, VIDEO_EXT, classify, needs_reference, repair
from .result import RepairResult, Reporter

STATUS_TEXT = {                 # text and colour tone (theme.tone) of a job's state
    "waiting": ("Várakozik", "muted"),
    "running": ("Fut…", "accent"),
    "ok": ("Kész", "ok"),
    "partial": ("Részleges", "warn"),
    "failed": ("Sikertelen", "bad"),
    "intact": ("Ép, nincs hiba", "ok"),
    "cancelled": ("Megszakítva", "muted"),
}

FPS_CHOICES = [("Automatikus", None), ("23,976", 23.976), ("24", 24.0), ("25", 25.0), ("29,97", 29.97),
               ("30", 30.0), ("50", 50.0), ("59,94", 59.94), ("60", 60.0), ("100", 100.0), ("120", 120.0)]


@dataclass
class Job:
    path: str
    kind: str
    reference: Optional[str] = None
    auto_ref: bool = False
    status: str = "waiting"
    progress: float = 0.0
    step: str = ""
    result: Optional[RepairResult] = None
    log: List[str] = field(default_factory=list)


def resource_path(name: str) -> str:
    base = getattr(sys, "_MEIPASS", os.path.dirname(os.path.abspath(__file__)))
    p = os.path.join(base, "assets", name)
    if os.path.exists(p):
        return p
    return os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets", name)


def human_size(n: int) -> str:
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if n < 1024 or unit == "TB":
            return ("%.0f %s" if unit in ("B", "KB") else "%.1f %s") % (n, unit)
        n /= 1024.0
    return str(n)


def open_path(path: str) -> None:
    QDesktopServices.openUrl(QUrl.fromLocalFile(path))


def reveal_in_folder(path: str) -> None:
    if sys.platform.startswith("win"):
        subprocess.Popen(["explorer", "/select,", os.path.normpath(path)])
    elif sys.platform == "darwin":
        subprocess.Popen(["open", "-R", path])
    else:
        open_path(os.path.dirname(path))


# ---------------------------------------------------------------------------
# Background worker
# ---------------------------------------------------------------------------

class Worker(QObject):
    progress = Signal(int, float)
    step = Signal(int, str)
    log = Signal(int, str)
    done = Signal(int, object)
    finished = Signal()

    def __init__(self, items, out_dir: Optional[str], fps: Optional[float]):
        super().__init__()
        self.items = items          # list of (row, path, reference)
        self.out_dir = out_dir
        self.fps = fps
        self._cancel = False

    def cancel(self):
        self._cancel = True

    def run(self):
        for row, path, ref in self.items:
            if self._cancel:
                break
            out_path = None
            if self.out_dir:
                base, ext = os.path.splitext(os.path.basename(path))
                out_path = os.path.join(self.out_dir, base + "_javitott" + ext)
                i = 2
                while os.path.exists(out_path):
                    out_path = os.path.join(self.out_dir, "%s_javitott_%d%s" % (base, i, ext))
                    i += 1
            rep = Reporter(on_step=lambda s, r=row: self.step.emit(r, s),
                           on_log=lambda s, r=row: self.log.emit(r, s))
            try:
                res = repair(path, ref, out_path, progress=lambda x, r=row: self.progress.emit(r, x),
                             cancel=lambda: self._cancel, reporter=rep, fps=self.fps)
            except Exception as e:  # noqa: BLE001 - never let the worker die silently
                import traceback
                rep.log(traceback.format_exc())
                res = RepairResult("failed", None, "Váratlan hiba: %s" % e, log=rep.lines)
            self.done.emit(row, res)
        self.finished.emit()


# ---------------------------------------------------------------------------
# Widgets
# ---------------------------------------------------------------------------

class DropTable(QTableWidget):
    filesDropped = Signal(list)

    def __init__(self):
        super().__init__(0, 5)
        self.setAcceptDrops(True)
        self.setDragDropMode(QAbstractItemView.DropOnly)
        self.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.verticalHeader().setVisible(False)
        self.verticalHeader().setDefaultSectionSize(36)
        self.setShowGrid(False)
        self.setFrameShape(QFrame.NoFrame)
        self.setItemDelegate(theme.ToneDelegate(self))
        self.setHorizontalHeaderLabels([t.upper() for t in ("Fájl", "Típus", "Méret", "Mintafájl", "Állapot")])
        theme.header_font(self)
        h = self.horizontalHeader()
        h.setDefaultAlignment(Qt.AlignLeft | Qt.AlignVCenter)
        h.setSectionResizeMode(0, QHeaderView.Stretch)
        h.setSectionResizeMode(1, QHeaderView.ResizeToContents)
        h.setSectionResizeMode(2, QHeaderView.ResizeToContents)
        h.setSectionResizeMode(3, QHeaderView.Stretch)
        h.setSectionResizeMode(4, QHeaderView.ResizeToContents)
        h.setHighlightSections(False)
        self.setAlternatingRowColors(False)
        self.empty_hint = "Húzd ide a sérült videókat, fotókat vagy hangfájlokat\nvagy kattints a „Fájlok hozzáadása” gombra"

    def dragEnterEvent(self, e):
        if e.mimeData().hasUrls():
            e.acceptProposedAction()

    def dragMoveEvent(self, e):
        if e.mimeData().hasUrls():
            e.acceptProposedAction()

    def dropEvent(self, e):
        paths = []
        for u in e.mimeData().urls():
            p = u.toLocalFile()
            if os.path.isdir(p):
                for n in sorted(os.listdir(p)):
                    q = os.path.join(p, n)
                    if os.path.isfile(q):
                        paths.append(q)
            elif p:
                paths.append(p)
        self.filesDropped.emit(paths)
        e.acceptProposedAction()

    def paintEvent(self, ev):
        super().paintEvent(ev)
        if self.rowCount() == 0:
            from PySide6.QtGui import QPainter
            p = QPainter(self.viewport())
            p.setPen(QColor(theme.tone("muted")))
            p.setFont(theme.font(15, 400))
            p.drawText(self.viewport().rect(), Qt.AlignCenter, self.empty_hint)
            p.end()


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Future Repair – fájljavító")
        self.resize(1180, 760)
        self.setMinimumSize(900, 600)
        icon = resource_path("icon.png")
        if os.path.exists(icon):
            self.setWindowIcon(QIcon(icon))
        self.jobs: List[Job] = []
        self.thread: Optional[QThread] = None
        self.worker: Optional[Worker] = None
        self.out_dir: Optional[str] = None
        self._build()
        self._refresh_buttons()

    # -- layout -----------------------------------------------------------
    def _build(self):
        root = QWidget()
        outer = QVBoxLayout(root)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)

        # the top bar: wordmark, the two pages as pill tabs, then Claude, the version and the light/dark switch
        top = QFrame()
        top.setObjectName("topbar")
        tl = QHBoxLayout(top)
        tl.setContentsMargins(24, 12, 20, 12)
        tl.setSpacing(8)
        tl.addWidget(theme.Wordmark(17), 0, Qt.AlignVCenter)
        tag = QLabel("REPAIR")
        tag.setObjectName("tag")
        tag.setFont(theme.font(11, 600, 0.18))
        tl.addSpacing(4)
        tl.addWidget(tag, 0, Qt.AlignVCenter)
        tl.addSpacing(28)
        self.mode_repair = theme.TabButton("Fájljavítás")
        self.mode_disk = theme.TabButton("Formázott lemez")
        self.mode_repair.setToolTip("Sérült videó-, fotó- és hangfájlok javítása.")
        self.mode_disk.setToolTip("Fájlok visszahozása leformázott lemezről a régi mappák alapján.")
        tl.addWidget(self.mode_repair)
        tl.addWidget(self.mode_disk)
        tl.addStretch(1)
        self.btn_claude = theme.chip()
        self.btn_claude.clicked.connect(self._claude_clicked)
        tl.addWidget(self.btn_claude)
        from .gui_knowledge import KnowledgeButton
        self.btn_knowledge = KnowledgeButton(self)
        tl.addWidget(self.btn_knowledge)
        from .gui_update import UpdateButton
        self.btn_update = UpdateButton(self)
        tl.addWidget(self.btn_update)
        tl.addWidget(theme.ThemeButton())
        outer.addWidget(top)
        self._claude_refresh()

        body = QWidget()
        lay = QVBoxLayout(body)
        lay.setContentsMargins(24, 20, 24, 8)
        lay.setSpacing(0)
        self.stack = QStackedWidget()
        page = QWidget()
        pl = QVBoxLayout(page)
        pl.setContentsMargins(0, 0, 0, 0)
        pl.setSpacing(14)
        self.stack.addWidget(page)
        from .gui_disk import DiskPage
        self.disk_page = DiskPage()
        self.stack.addWidget(self.disk_page)
        lay.addWidget(self.stack, 1)
        outer.addWidget(body, 1)
        self.mode_repair.clicked.connect(lambda: self._set_mode(0))
        self.mode_disk.clicked.connect(lambda: self._set_mode(1))
        self.mode_repair.setChecked(True)

        pl.addWidget(theme.page_head("Sérült fájlok javítása",
                                     "Videók, fotók és hangfelvételek. Az eredeti fájlokat a program soha nem "
                                     "módosítja: a javított változat külön fájlba kerül."))
        bar = QHBoxLayout()
        bar.setSpacing(8)
        self.btn_add = QPushButton("Fájlok hozzáadása…")
        self.btn_ref = QPushButton("Mintafájl megadása…")
        self.btn_ref.setToolTip("Ép fájl ugyanarról az eszközről, ugyanazokkal a beállításokkal.\n"
                                "Ebből építi újra a program a sérült fájl szerkezetét.")
        self.btn_auto = QPushButton("Minta keresése")
        self.btn_auto.setToolTip("Ép mintafájlt keres a sérült videó mappájában.")
        self.btn_remove = QPushButton("Eltávolítás")
        for b in (self.btn_add, self.btn_ref, self.btn_auto, self.btn_remove):
            bar.addWidget(b)
        bar.addStretch(1)
        fps_label = QLabel("Képkockaszám minta nélkül")
        fps_label.setObjectName("sub")
        bar.addWidget(fps_label)
        self.fps = QComboBox()
        for label, _v in FPS_CHOICES:
            self.fps.addItem(label)
        self.fps.setToolTip("Csak akkor számít, ha egy videóhoz nincs mintafájl.")
        bar.addWidget(self.fps)
        pl.addLayout(bar)

        split = QSplitter(Qt.Horizontal)
        split.setHandleWidth(14)
        split.setChildrenCollapsible(False)
        left = theme.Card("Sérült fájlok", margins=(16, 14, 16, 8), spacing=6)
        self.table = DropTable()
        self.table.filesDropped.connect(self.add_files)
        self.table.itemSelectionChanged.connect(self._on_select)
        left.lay.addWidget(self.table, 1)
        split.addWidget(left)

        side = theme.Card("Részletek")
        sl = side.lay
        self.preview = QLabel("Előnézet")
        self.preview.setObjectName("preview")
        self.preview.setAlignment(Qt.AlignCenter)
        self.preview.setMinimumSize(300, 180)
        self.preview.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        sl.addWidget(self.preview, 3)
        self.msg = QLabel("Válassz ki egy fájlt a listából.")
        self.msg.setWordWrap(True)
        self.msg.setObjectName("msg")
        self.msg.setFont(theme.font(15, 500))
        self.msg.setTextInteractionFlags(Qt.TextSelectableByMouse)
        sl.addWidget(self.msg)
        self.hint = QLabel("")
        self.hint.setWordWrap(True)
        self.hint.setObjectName("sub")
        sl.addWidget(self.hint)
        ob = QHBoxLayout()
        ob.setSpacing(8)
        self.btn_open = QPushButton("Megnyitás")
        self.btn_reveal = QPushButton("Mutasd a mappában")
        self.btn_open.clicked.connect(self._open_result)
        self.btn_reveal.clicked.connect(self._reveal_result)
        ob.addWidget(self.btn_open)
        ob.addWidget(self.btn_reveal)
        ob.addStretch(1)
        sl.addLayout(ob)
        self.details = QPlainTextEdit()
        self.details.setReadOnly(True)
        self.details.setObjectName("log")
        self.details.setPlaceholderText("Részletes napló")
        sl.addWidget(self.details, 2)
        split.addWidget(side)
        split.setStretchFactor(0, 3)
        split.setStretchFactor(1, 2)
        split.setSizes([700, 460])
        pl.addWidget(split, 1)

        bottom = QHBoxLayout()
        bottom.setSpacing(10)
        self.out_label = QLabel("Mentés helye: az eredeti fájl mellé")
        self.out_label.setObjectName("sub")
        self.btn_out = QPushButton("Mentés helye…")
        self.btn_out.setToolTip("Hová kerüljenek a javított fájlok. Alapból az eredeti mellé, „_javitott” végződéssel.")
        bottom.addWidget(self.out_label)
        bottom.addWidget(self.btn_out)
        bottom.addStretch(1)
        self.total = theme.ProgressLine()
        self.total.setFixedWidth(260)
        bottom.addWidget(self.total)
        bottom.addSpacing(6)
        self.btn_cancel = QPushButton("Megszakítás")
        self.btn_start = theme.PrimaryButton("Javítás indítása")
        bottom.addWidget(self.btn_cancel)
        bottom.addWidget(self.btn_start)
        pl.addLayout(bottom)

        self.setCentralWidget(root)
        self.btn_add.clicked.connect(self._pick_files)
        self.btn_ref.clicked.connect(self._pick_reference)
        self.btn_auto.clicked.connect(self._auto_reference)
        self.btn_remove.clicked.connect(self._remove_selected)
        self.btn_out.clicked.connect(self._pick_out_dir)
        self.btn_start.clicked.connect(self.start)
        self.btn_cancel.clicked.connect(self.cancel)
        self.statusBar().setSizeGripEnabled(False)
        theme.notifier.changed.connect(self._retheme)

    def _retheme(self):
        """The look changed (light / dark): what carries colours of its own is drawn again."""
        self._claude_refresh()
        self.table.viewport().update()

    # -- restart into a newly installed version --------------------------------
    def restart_app(self) -> bool:
        if self.thread is not None:
            QMessageBox.information(self, "Újraindítás", "Még fut egy javítás. Ha végzett, indítsd újra a programot.")
            return False
        from .gui_update import restart_command, start_detached
        try:
            start_detached(restart_command())
        except OSError as e:
            QMessageBox.warning(self, "Újraindítás", "Nem sikerült újraindítani: %s" % e)
            return False
        self.close()
        return True

    # -- Claude (MCP) connection -------------------------------------------
    def _claude_refresh(self):
        from .claude_connect import status
        st = status()
        tone = "muted"
        if st.get("error"):
            tone = "bad"
            self.btn_claude.setText("Claude: hibás beállításfájl")
            self.btn_claude.setToolTip(st["error"])
        elif st.get("connected") and st.get("current"):
            tone = "ok"
            self.btn_claude.setText("Claude-dal összekötve")
            self.btn_claude.setToolTip("A Claude asztali alkalmazás eléri a Future Repair eszközeit (MCP).\n"
                                       "Beállításfájl: %s" % st["config"])
        elif st.get("connected"):
            tone = "warn"
            self.btn_claude.setText("Claude-kapcsolat frissítése")
            self.btn_claude.setToolTip("A Claude egy másik Future Repair példányra mutat. Kattints, hogy erre "
                                       "a telepítésre mutasson.")
        else:
            self.btn_claude.setText("Összekötés a Claude-dal")
            self.btn_claude.setToolTip("Hozzáadja a Future Repairt a Claude asztali alkalmazás MCP-szerverei "
                                       "közé, így a Claude közvetlenül használhatja a javítóeszközöket.")
        self.btn_claude.setIcon(theme.dot_icon(theme.tone(tone)))
        return st

    def _claude_clicked(self):
        from .claude_connect import connect, disconnect, restart_hint, status
        st = status()
        if st.get("connected") and st.get("current"):
            r = QMessageBox.question(self, "Claude-kapcsolat",
                                     "A Future Repair már össze van kötve a Claude-dal.\n\n"
                                     "Bontsam a kapcsolatot?", QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
            if r != QMessageBox.Yes:
                return
            res = disconnect()
            if res.get("ok"):
                QMessageBox.information(self, "Claude-kapcsolat", "Kapcsolat bontva.\n\n" + restart_hint(False))
            else:
                QMessageBox.warning(self, "Claude-kapcsolat", "Nem sikerült: %s" % res.get("error"))
        else:
            from .claude_connect import selftest
            QApplication.setOverrideCursor(Qt.WaitCursor)
            try:
                res = connect()
                test = selftest() if res.get("ok") else None
            finally:
                QApplication.restoreOverrideCursor()
            if res.get("ok"):
                if test and test.get("ok"):
                    t = "Próba: a Claude-nak szóló szerver elindult, %d eszközt kínál." % test.get("tools", 0)
                else:
                    t = "Figyelem: a próbaindítás nem sikerült (%s)." % ((test or {}).get("error") or "ismeretlen hiba")
                QMessageBox.information(self, "Claude-kapcsolat",
                                        "Kész, a Future Repair hozzá van adva a Claude-hoz.\n%s\n\n%s"
                                        % (t, restart_hint()))
            else:
                QMessageBox.warning(self, "Claude-kapcsolat", "Nem sikerült: %s" % res.get("error"))
        self._claude_refresh()

    def _set_mode(self, i: int):
        self.stack.setCurrentIndex(i)
        self.mode_repair.setChecked(i == 0)
        self.mode_disk.setChecked(i == 1)
        self.statusBar().clearMessage()

    # -- job list -----------------------------------------------------------
    def add_files(self, paths):
        known = {os.path.normcase(os.path.abspath(j.path)) for j in self.jobs}
        skipped = 0
        for p in paths:
            ap = os.path.abspath(p)
            if os.path.normcase(ap) in known or "_javitott" in os.path.basename(ap).lower():
                continue
            kind = classify(ap)
            if kind is None:
                skipped += 1
                continue
            self.jobs.append(Job(ap, kind))
            known.add(os.path.normcase(ap))
            self._append_row(self.jobs[-1])
        if skipped:
            self.statusBar().showMessage("%d fájlt kihagytam, mert nem videó, fotó vagy hang." % skipped, 6000)
        self._auto_reference(only_missing=True, silent=True)
        self._refresh_buttons()
        if self.table.rowCount() and not self.table.selectedItems():
            self.table.selectRow(0)

    def _append_row(self, job: Job):
        r = self.table.rowCount()
        self.table.insertRow(r)
        name = QTableWidgetItem(os.path.basename(job.path))
        name.setToolTip(job.path)
        self.table.setItem(r, 0, name)
        self.table.setItem(r, 1, QTableWidgetItem(KIND_LABEL.get(job.kind, "?")))
        try:
            size = human_size(os.path.getsize(job.path))
        except OSError:
            size = "?"
        it = QTableWidgetItem(size)
        it.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
        self.table.setItem(r, 2, it)
        self.table.setItem(r, 3, QTableWidgetItem(""))
        self.table.setItem(r, 4, QTableWidgetItem(""))
        self._update_row(r)

    def _update_row(self, r: int):
        j = self.jobs[r]
        if j.reference:
            t = os.path.basename(j.reference) + ("  (automatikus)" if j.auto_ref else "")
        else:
            t = "– nincs –"
        ref_item = self.table.item(r, 3)
        ref_item.setText(t)
        ref_item.setToolTip(j.reference or needs_reference(j.kind))
        ref_item.setData(theme.ROLE_TONE, None if j.reference else "muted")
        text, tone = STATUS_TEXT.get(j.status, (j.status, None))
        if j.status == "running":
            text = "Fut… %d%%" % int(j.progress * 100)
        st = self.table.item(r, 4)
        st.setText(text)
        st.setData(theme.ROLE_TONE, tone)

    def _selected_rows(self) -> List[int]:
        return sorted({i.row() for i in self.table.selectedItems()})

    def _remove_selected(self):
        if self.thread is not None:
            return
        for r in reversed(self._selected_rows()):
            self.table.removeRow(r)
            del self.jobs[r]
        self._refresh_buttons()
        self._on_select()

    def _pick_files(self):
        exts = sorted(VIDEO_EXT | PHOTO_EXT | AUDIO_EXT)
        pattern = " ".join("*" + e for e in exts) + " " + " ".join("*" + e.upper() for e in exts)
        files, _ = QFileDialog.getOpenFileNames(self, "Sérült fájlok kiválasztása", "",
                                                "Támogatott fájlok (%s);;Minden fájl (*)" % pattern)
        if files:
            self.add_files(files)

    def _pick_reference(self):
        rows = self._selected_rows()
        if not rows:
            QMessageBox.information(self, "Mintafájl", "Előbb jelöld ki a listában, melyik fájlhoz adsz mintát.")
            return
        kind = self.jobs[rows[0]].kind
        start_dir = os.path.dirname(self.jobs[rows[0]].path)
        f, _ = QFileDialog.getOpenFileName(self, "Ép mintafájl kiválasztása – " + needs_reference(kind), start_dir)
        if not f:
            return
        for r in rows:
            if self.jobs[r].kind == kind:
                self.jobs[r].reference = f
                self.jobs[r].auto_ref = False
                self._update_row(r)
        self._on_select()

    def _auto_reference(self, only_missing: bool = False, silent: bool = False):
        from .suggest import suggest_reference
        rows = range(len(self.jobs)) if (only_missing or not self._selected_rows()) else self._selected_rows()
        found = 0
        QApplication.setOverrideCursor(Qt.WaitCursor)
        try:
            for r in rows:
                j = self.jobs[r]
                if j.kind != "video" or (only_missing and j.reference):
                    continue
                from .suggest import video_is_healthy
                if only_missing and video_is_healthy(j.path):
                    continue
                s = suggest_reference(j.path)
                if s:
                    j.reference = s
                    j.auto_ref = True
                    found += 1
                    self._update_row(r)
        finally:
            QApplication.restoreOverrideCursor()
        if not silent:
            if found:
                self.statusBar().showMessage("%d fájlhoz találtam mintát." % found, 6000)
            else:
                QMessageBox.information(self, "Minta keresése",
                                        "Nem találtam ép mintafájlt a sérült videó mappájában.\n"
                                        "Add meg kézzel a „Mintafájl megadása…” gombbal.")
        self._on_select()

    def _pick_out_dir(self):
        d = QFileDialog.getExistingDirectory(self, "Hová mentsem a javított fájlokat?")
        if d:
            self.out_dir = d
            self.out_label.setText("Mentés helye: " + d)
        else:
            self.out_dir = None
            self.out_label.setText("Mentés helye: az eredeti fájl mellé")

    # -- run ------------------------------------------------------------------
    def start(self):
        if self.thread is not None:
            return
        items = []
        for r, j in enumerate(self.jobs):
            if j.status in ("waiting", "failed", "cancelled", "partial"):
                if j.status == "partial" and j.result and j.result.output:
                    continue
                j.status = "waiting"
                j.progress = 0
                items.append((r, j.path, j.reference))
                self._update_row(r)
        if not items:
            self.statusBar().showMessage("Nincs javítandó fájl a listában.", 5000)
            return
        no_ref_videos = [self.jobs[r] for r, _p, ref in items if self.jobs[r].kind == "video" and not ref]
        if no_ref_videos:
            ans = QMessageBox.question(
                self, "Nincs mintafájl",
                "%d videóhoz nincs mintafájl.\n\nMinta nélkül általában csak a kép menthető, hang nélkül, "
                "és csak ha a kamera a kódolási adatokat a felvételbe is beírta.\n\nFolytatod így?"
                % len(no_ref_videos), QMessageBox.Yes | QMessageBox.No)
            if ans != QMessageBox.Yes:
                return
        self._done_count = 0
        self._total_count = len(items)
        self.total.setRange(0, 1000 * len(items))
        self.total.setValue(0)
        self.total.setFormat("0 / %d kész" % len(items))
        fps = FPS_CHOICES[self.fps.currentIndex()][1]
        self.thread = QThread(self)
        self.worker = Worker(items, self.out_dir, fps)
        self.worker.moveToThread(self.thread)
        self.thread.started.connect(self.worker.run)
        self.worker.progress.connect(self._on_progress)
        self.worker.step.connect(self._on_step)
        self.worker.log.connect(self._on_log)
        self.worker.done.connect(self._on_done)
        self.worker.finished.connect(self._on_finished)
        self.thread.start()
        self._refresh_buttons()

    def cancel(self):
        if self.worker:
            self.worker.cancel()
            self.statusBar().showMessage("Megszakítás…")

    def _on_progress(self, r, x):
        j = self.jobs[r]
        if j.status != "running":
            j.status = "running"
        j.progress = x
        self._update_row(r)
        self.total.setValue(int(1000 * (self._done_count + x)))

    def _on_step(self, r, s):
        j = self.jobs[r]
        j.status = "running"
        j.step = s
        self._update_row(r)
        self.statusBar().showMessage("%s – %s" % (os.path.basename(j.path), s))
        if self._current_row() == r:
            self._on_select()

    def _on_log(self, r, s):
        self.jobs[r].log.append(s)
        if self._current_row() == r:
            self.details.appendPlainText(s)

    def _on_done(self, r, res: RepairResult):
        j = self.jobs[r]
        j.result = res
        j.status = res.status
        j.progress = 1.0
        self._done_count += 1
        self.total.setValue(1000 * self._done_count)
        self.total.setFormat("%d / %d kész" % (self._done_count, self._total_count))
        self._update_row(r)
        if self._current_row() == r or len(self._selected_rows()) == 0:
            self.table.selectRow(r)
            self._on_select()

    def _on_finished(self):
        self.thread.quit()
        self.thread.wait()
        self.thread = None
        self.worker = None
        self._refresh_buttons()
        oks = sum(1 for j in self.jobs if j.status in ("ok", "partial"))
        self.statusBar().showMessage("Kész. %d fájl helyreállítva." % oks, 10000)

    # -- side panel ---------------------------------------------------------------
    def _current_row(self) -> int:
        rows = self._selected_rows()
        return rows[0] if rows else -1

    def _on_select(self):
        r = self._current_row()
        self.details.clear()
        self.btn_open.setEnabled(False)
        self.btn_reveal.setEnabled(False)
        if r < 0 or r >= len(self.jobs):
            self.preview.setPixmap(QPixmap())
            self.preview.setText("Előnézet")
            self.msg.setText("Válassz ki egy fájlt a listából.")
            self.hint.setText("")
            self._refresh_buttons()
            return
        j = self.jobs[r]
        self.details.setPlainText("\n".join(j.log))
        res = j.result
        if res is None:
            self.preview.setPixmap(QPixmap())
            self.preview.setText(KIND_LABEL.get(j.kind, ""))
            if j.status == "running":
                self.msg.setText(j.step or "Feldolgozás…")
            else:
                self.msg.setText(os.path.basename(j.path))
            self.hint.setText(("Mintafájl: " + needs_reference(j.kind)) if not j.reference else
                              "Minta: " + j.reference)
        else:
            lines = [res.message]
            for w in res.warnings:
                lines.append("⚠ " + w)
            for n in res.notes:
                lines.append("• " + n)
            self.msg.setText("\n".join(lines))
            d = res.details
            info = []
            if d.get("width"):
                info.append("%sx%s" % (d.get("width"), d.get("height")))
            if d.get("codec"):
                info.append(d["codec"])
            if d.get("fps"):
                info.append("%s fps" % d["fps"])
            if d.get("video_seconds"):
                info.append("kép: %.1f mp" % d["video_seconds"])
            if d.get("audio_seconds"):
                info.append("hang: %.1f mp" % d["audio_seconds"])
            if res.output:
                info.append("→ " + res.output)
            self.hint.setText("   ".join(info))
            prev = res.preview or d.get("preview")
            if prev and os.path.exists(prev):
                pm = QPixmap(prev)
                self.preview.setPixmap(pm.scaled(self.preview.size() - QSize(8, 8), Qt.KeepAspectRatio,
                                                 Qt.SmoothTransformation))
            else:
                self.preview.setPixmap(QPixmap())
                self.preview.setText("Nincs előnézet")
            self.btn_open.setEnabled(bool(res.output))
            self.btn_reveal.setEnabled(bool(res.output))
        self._refresh_buttons()

    def resizeEvent(self, e):
        super().resizeEvent(e)
        self._on_select_preview_only()

    def _on_select_preview_only(self):
        r = self._current_row()
        if 0 <= r < len(self.jobs) and self.jobs[r].result:
            prev = self.jobs[r].result.preview or self.jobs[r].result.details.get("preview")
            if prev and os.path.exists(prev):
                self.preview.setPixmap(QPixmap(prev).scaled(self.preview.size() - QSize(8, 8), Qt.KeepAspectRatio,
                                                            Qt.SmoothTransformation))

    def _open_result(self):
        r = self._current_row()
        if r >= 0 and self.jobs[r].result and self.jobs[r].result.output:
            open_path(self.jobs[r].result.output)

    def _reveal_result(self):
        r = self._current_row()
        if r >= 0 and self.jobs[r].result and self.jobs[r].result.output:
            reveal_in_folder(self.jobs[r].result.output)

    def _refresh_buttons(self):
        busy = self.thread is not None
        has = bool(self.jobs)
        sel = bool(self._selected_rows()) if hasattr(self, "table") else False
        self.btn_start.setEnabled(has and not busy)
        self.btn_cancel.setEnabled(busy)
        self.btn_add.setEnabled(not busy)
        self.btn_remove.setEnabled(sel and not busy)
        self.btn_ref.setEnabled(sel and not busy)
        self.btn_auto.setEnabled(has and not busy)
        self.btn_out.setEnabled(not busy)

    def closeEvent(self, e):
        if getattr(self, "disk_page", None) is not None and self.disk_page.busy():
            ans = QMessageBox.question(self, "Kilépés", "A lemezfeladat a háttérben tovább fut, akkor is, ha "
                                       "bezárod a programot; újranyitás után a Formázott lemez oldalon látod "
                                       "az eredményét. Bezárod?", QMessageBox.Yes | QMessageBox.No)
            if ans != QMessageBox.Yes:
                e.ignore()
                return
        if self.thread is not None:
            ans = QMessageBox.question(self, "Kilépés", "Még fut egy javítás. Megszakítod és kilépsz?",
                                       QMessageBox.Yes | QMessageBox.No)
            if ans != QMessageBox.Yes:
                e.ignore()
                return
            self.worker.cancel()
            self.thread.quit()
            self.thread.wait(5000)
        e.accept()


def main(argv=None):
    from . import hotreload
    hotreload.enable()          # long-running: pick up updates made on disk
    argv = argv if argv is not None else sys.argv
    if sys.platform.startswith("win"):
        try:  # own taskbar icon/grouping instead of python's
            import ctypes
            ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("TheFutureVisuals.FutureRepair")
        except Exception:  # noqa: BLE001
            pass
    app = QApplication(argv)
    app.setApplicationName("Future Repair")
    app.setOrganizationName("The Future Visuals")
    app.setStyle("Fusion")
    theme.setup(app)            # the studio's look (CRM / delivery site), light or dark
    try:
        from . import knowledge
        knowledge.start_background()        # the shared knowledge: fetch what the other machines learnt
    except Exception:  # noqa: BLE001
        pass
    w = MainWindow()
    files = [a for a in argv[1:] if os.path.isfile(a)]
    if files:
        w.add_files(files)
    w.show()
    return app.exec()


if __name__ == "__main__":
    sys.exit(main())
