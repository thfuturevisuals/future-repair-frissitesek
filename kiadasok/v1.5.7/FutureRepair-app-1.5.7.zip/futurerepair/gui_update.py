"""Version button and update dialog of the desktop window."""
from __future__ import annotations

import subprocess
import sys
from typing import Callable, Optional

from PySide6.QtCore import QObject, Qt, QThread, QTimer, QUrl, Signal, Slot
from PySide6.QtGui import QDesktopServices, QIcon
from PySide6.QtWidgets import (QCheckBox, QDialog, QHBoxLayout, QLabel, QMessageBox, QPlainTextEdit, QPushButton,
                               QVBoxLayout)

from . import __version__, theme, updater
from .paths import app_command


class _Task(QObject):
    done = Signal(object)

    def __init__(self, fn: Callable):
        super().__init__()
        self.fn = fn

    @Slot()
    def run(self):
        try:
            r = self.fn()
        except Exception as e:  # noqa: BLE001
            r = {"ok": False, "error": str(e)}
        self.done.emit(r)


class Background(QObject):
    """Runs one function at a time in a worker thread; the callback gets the result in the UI thread."""
    finished = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.thread: Optional[QThread] = None
        self.task: Optional[_Task] = None
        self.callback: Optional[Callable] = None

    def busy(self) -> bool:
        return self.thread is not None

    def start(self, fn: Callable, callback: Callable) -> bool:
        if self.thread is not None:
            return False
        self.callback = callback
        self.thread = QThread()
        self.task = _Task(fn)
        self.task.moveToThread(self.thread)
        self.thread.started.connect(self.task.run)
        self.task.done.connect(self._done)
        self.thread.start()
        return True

    @Slot(object)
    def _done(self, r):
        cb = self.callback
        self.thread.quit()
        self.thread.wait()
        self.thread, self.task, self.callback = None, None, None
        if cb:
            cb(r)
        self.finished.emit()


def _when(ts) -> str:
    import time
    try:
        return time.strftime("%Y.%m.%d. %H:%M", time.localtime(float(ts)))
    except (TypeError, ValueError):
        return "még nem"


class UpdateButton(QPushButton):
    """Shows the version; turns into a notice when a new version is available or installed."""

    def __init__(self, window):
        super().__init__("v" + __version__)
        self.window = window
        self.dialog: Optional[UpdateDialog] = None
        self.bg = Background(self)
        self.setObjectName("chip")
        self.setFont(theme.font(12.5, 500))
        self.setCursor(Qt.PointingHandCursor)
        theme.notifier.changed.connect(self.refresh)
        self.clicked.connect(self.open_dialog)
        self.refresh()
        QTimer.singleShot(4000, self.auto)
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.auto)
        self.timer.start(int(updater.CHECK_EVERY * 1000))
        QTimer.singleShot(1500, self._whats_new)

    # -- background work ------------------------------------------------------
    def auto(self):
        def job():
            updater.cleanup()
            return updater.auto_update()
        self.bg.start(job, self._done)

    def check_now(self):
        def job():
            r = updater.check()
            r.pop("manifest", None)
            return r
        return self.bg.start(job, self._done)

    def install_now(self):
        return self.bg.start(lambda: updater.install(), self._installed)

    def _installed(self, r):
        self._done(r)
        if r.get("ok") and not r.get("already"):
            ans = QMessageBox.question(
                self.window, "Frissítés",
                "A Future Repair %s telepítve.\n\nÚjraindítod most? (A futó lemezfeladatok nem állnak le.)"
                % r.get("version"), QMessageBox.Yes | QMessageBox.No, QMessageBox.Yes)
            if ans == QMessageBox.Yes:
                self.window.restart_app()
        elif not r.get("ok"):
            QMessageBox.warning(self.window, "Frissítés", "A frissítés nem sikerült: %s" % r.get("error"))

    def _done(self, r):
        self.refresh()
        if self.dialog is not None:
            self.dialog.refresh()

    # -- display --------------------------------------------------------------
    def refresh(self):
        st = updater.status()
        if st["restart_needed"]:
            text, accent = "Új verzió kész: %s – újraindítás" % st["installed"], True
            tip = "A %s már telepítve van; a program következő indításakor ez fut." % st["installed"]
        elif st["available"]:
            text, accent = "Új verzió: %s" % st["latest"], True
            tip = "Elérhető a Future Repair %s. Kattints a részletekért." % st["latest"]
        else:
            text, accent = "v" + __version__, False
            tip = "Future Repair %s – frissítések: kattints ide." % __version__
            if st.get("error"):
                tip += "\nUtolsó ellenőrzés: %s" % st["error"]
        self.setText(text)
        self.setToolTip(tip)
        self.setIcon(theme.dot_icon(theme.P["acc_hi"]) if accent else QIcon())
        if bool(self.property("accent")) != accent:
            self.setProperty("accent", accent)
            self.style().unpolish(self)
            self.style().polish(self)

    def open_dialog(self):
        if self.dialog is None:
            self.dialog = UpdateDialog(self)
        self.dialog.refresh()
        self.dialog.show()
        self.dialog.raise_()
        self.dialog.activateWindow()

    def _whats_new(self):
        st = updater.state()
        seen = st.get("seen")
        updater._update_state(seen=__version__)
        if not seen or updater.vtuple(__version__) <= updater.vtuple(seen):
            return
        notes = ""
        if updater.active_version() == __version__:
            notes = str(updater._read_json(updater.ACTIVE_FILE).get("notes") or "")
        QMessageBox.information(self.window, "Future Repair %s" % __version__,
                                "A program frissült: %s → %s.%s" % (seen, __version__,
                                                                   ("\n\nÚjdonságok:\n" + notes) if notes else ""))


class UpdateDialog(QDialog):
    def __init__(self, button: UpdateButton):
        super().__init__(button.window)
        self.button = button
        self.setWindowTitle("Future Repair – frissítések")
        self.setMinimumWidth(560)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(28, 24, 28, 22)
        lay.setSpacing(12)
        lay.addWidget(theme.title("Frissítések"))
        self.info = QLabel()
        self.info.setWordWrap(True)
        self.info.setTextFormat(Qt.RichText)
        lay.addWidget(self.info)
        lay.addSpacing(4)
        self.notes_title = theme.heading("Újdonságok")
        lay.addWidget(self.notes_title)
        self.notes = QPlainTextEdit()
        self.notes.setReadOnly(True)
        self.notes.setMinimumHeight(140)
        self.notes.setPlaceholderText("Még nincs leírás.")
        lay.addWidget(self.notes, 1)
        self.auto_cb = QCheckBox("Automatikus frissítés")
        self.auto_cb.toggled.connect(self._auto_toggled)
        lay.addWidget(self.auto_cb)
        hint = QLabel("A program magától letölti és kipróbálja az új verziót, és a következő indításkor azt "
                      "használja. A futó javítások és lemezfeladatok sosem váltanak verziót menet közben.")
        hint.setWordWrap(True)
        hint.setObjectName("muted")
        lay.addWidget(hint)
        lay.addSpacing(6)
        row = QHBoxLayout()
        row.setSpacing(8)
        self.btn_check = QPushButton("Keresés most")
        self.btn_install = theme.PrimaryButton("Telepítés")
        self.btn_restart = theme.PrimaryButton("Újraindítás")
        self.btn_rollback = QPushButton("Vissza az előző verzióra")
        self.btn_close = QPushButton("Bezárás")
        for b in (self.btn_check, self.btn_install, self.btn_restart, self.btn_rollback):
            row.addWidget(b)
        row.addStretch(1)
        row.addWidget(self.btn_close)
        lay.addLayout(row)
        self.btn_check.clicked.connect(self._check)
        self.btn_install.clicked.connect(self._install)
        self.btn_restart.clicked.connect(lambda: self.button.window.restart_app())
        self.btn_rollback.clicked.connect(self._rollback)
        self.btn_close.clicked.connect(self.close)
        self.button.bg.finished.connect(self.refresh)
        theme.notifier.changed.connect(self.refresh)

    def refresh(self):
        st = updater.status()
        busy = self.button.bg.busy()
        ok, accent, warn, sub = theme.tone("ok"), theme.tone("accent"), theme.tone("warn"), theme.tone("sub")
        rows = ["<span style='color:%s'>Futó verzió:</span> <b>%s</b>" % (sub, st["running"])]
        if st["restart_needed"]:
            rows.append("<span style='color:%s'>Telepítve:</span> <b style='color:%s'>%s</b> – a program következő "
                        "indításakor ez fut" % (sub, ok, st["installed"]))
        if st.get("latest"):
            rows.append("<span style='color:%s'>Legújabb kiadás:</span> <b>%s</b>" % (sub, st["latest"]))
        rows.append("<span style='color:%s'>Utolsó ellenőrzés:</span> %s" % (sub, _when(st.get("last_check"))))
        if busy:
            rows.append("<span style='color:%s'>Folyamatban…</span>" % accent)
        if st.get("error"):
            rows.append("<span style='color:%s'>%s</span>" % (warn, st["error"]))
        elif st.get("unpublished") and not st.get("latest"):
            rows.append("<span style='color:%s'>A frissítési csatornán még nincs kiadott verzió, így nincs mit "
                        "letölteni.</span>" % sub)
        if st.get("needs_installer"):
            rows.append("<span style='color:%s'>Ehhez a verzióhoz új telepítő kell.</span>" % warn)
        if not st.get("writable"):
            rows.append("<span style='color:%s'>A program mappája nem írható, ezért magától nem tud "
                        "frissülni.</span>" % warn)
        self.info.setText("<br>".join(rows))
        self.notes_title.setText(("Újdonságok – %s" % st["latest"] if st.get("latest") else "Újdonságok").upper())
        self.notes.setPlainText(st.get("notes") or "")
        self.auto_cb.blockSignals(True)
        self.auto_cb.setChecked(bool(st.get("auto", True)))
        self.auto_cb.blockSignals(False)
        self.btn_check.setEnabled(not busy)
        self.btn_install.setVisible(bool(st.get("available")))
        self.btn_install.setEnabled(not busy)
        self.btn_install.setText("Telepítő letöltése" if st.get("needs_installer") else "Telepítés most")
        self.btn_restart.setVisible(bool(st["restart_needed"]))
        self.btn_rollback.setVisible(bool(st.get("active_update")))
        self.btn_rollback.setEnabled(not busy)

    def _auto_toggled(self, on: bool):
        try:
            updater.set_auto(on)
        except OSError as e:
            QMessageBox.warning(self, "Frissítés", "Nem tudom elmenteni: %s" % e)

    def _check(self):
        self.button.check_now()
        self.refresh()

    def _install(self):
        st = updater.status()
        if st.get("needs_installer"):
            QDesktopServices.openUrl(QUrl(st.get("installer_url") or updater.RELEASES_PAGE))
            return
        self.button.install_now()
        self.refresh()

    def _rollback(self):
        st = updater.status()
        ans = QMessageBox.question(self, "Visszaállás",
                                   "Visszaállsz a(z) %s előtti verzióra? A program következő indításakor az "
                                   "előző verzió fut, és ezt a kiadást nem telepíti újra magától."
                                   % st.get("active_update"), QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
        if ans != QMessageBox.Yes:
            return
        r = updater.rollback()
        if r.get("ok"):
            QMessageBox.information(self, "Visszaállás", "Kész: a következő indításkor a %s fut." % r["version"])
        else:
            QMessageBox.warning(self, "Visszaállás", r.get("error") or "Nem sikerült.")
        self.button.refresh()
        self.refresh()


def restart_command():
    return app_command()


def start_detached(cmd) -> None:
    flags = 0
    if sys.platform.startswith("win"):
        flags = getattr(subprocess, "DETACHED_PROCESS", 0) | getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
    subprocess.Popen(cmd, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                     close_fds=True, creationflags=flags)
