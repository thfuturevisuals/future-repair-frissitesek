"""Shared result / reporting types used by all repair engines and the UI."""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Callable, List, Optional


@dataclass
class RepairResult:
    status: str                      # 'ok' | 'partial' | 'failed' | 'intact' | 'cancelled'
    output: Optional[str]
    message: str = ""
    details: dict = field(default_factory=dict)
    log: List[str] = field(default_factory=list)
    notes: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    preview: Optional[str] = None    # path of a JPEG preview image

    @classmethod
    def success(cls, output: str, details: dict) -> "RepairResult":
        return cls(status="ok", output=output, details=dict(details))

    @property
    def ok(self) -> bool:
        return self.status in ("ok", "partial")


class Reporter:
    """Collects log lines; optionally forwards step names to the UI."""

    def __init__(self, on_step: Optional[Callable[[str], None]] = None,
                 on_log: Optional[Callable[[str], None]] = None):
        self.lines: List[str] = []
        self.notes: List[str] = []
        self.warnings: List[str] = []
        self.on_step = on_step
        self.on_log = on_log
        self.t0 = time.time()

    def _add(self, s: str) -> None:
        line = "[%6.1fs] %s" % (time.time() - self.t0, s)
        self.lines.append(line)
        if self.on_log:
            self.on_log(line)

    def step(self, s: str) -> None:
        self._add(s)
        if self.on_step:
            self.on_step(s)

    def log(self, s: str) -> None:
        self._add(s)

    def note(self, s: str) -> None:
        self.notes.append(s)
        self._add("Megjegyzés: " + s)

    def warn(self, s: str) -> None:
        self.warnings.append(s)
        self._add("Figyelem: " + s)
