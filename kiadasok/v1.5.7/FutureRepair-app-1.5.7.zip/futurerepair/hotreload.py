"""Keeps a long-running process (the MCP server, an open window) on the current code.

The program can be updated on disk while Claude's MCP connection keeps the server process
running. Before each repair the engine modules are compared with the files on disk and the
changed ones (and everything that imports from them) are reloaded, so the next repair runs
the new code without restarting anything. Nothing is reloaded while a repair is running.
"""
from __future__ import annotations

import hashlib
import importlib
import os
import sys
import threading

# dependency order: a module is listed after the modules it imports names from
ORDER = [
    "futurerepair.video.bits",
    "futurerepair.video.h264",
    "futurerepair.video.hevc",
    "futurerepair.video.mp4",
    "futurerepair.video.entries",
    "futurerepair.video.models",
    "futurerepair.video.scanner",
    "futurerepair.video.analyze",
    "futurerepair.video.fragments",
    "futurerepair.video.writer",
    "futurerepair.video.verify",
    "futurerepair.photo.repair",
    "futurerepair.audio.repair",
    "futurerepair.suggest",
    "futurerepair.video.repair",
    "futurerepair.engine",
]

_lock = threading.RLock()
_state = {"active": 0, "reloading": False}

# Only long-running processes (the MCP server, the window) switch it on; a one-off process
# (command line, disk worker) always runs the code it started with.
ENABLED = False


def enable() -> None:
    global ENABLED
    ENABLED = True


def _digest(path: str) -> str:
    with open(path, "rb") as f:
        return hashlib.sha1(f.read()).hexdigest()


def refresh(importing: str = "") -> bool:
    """Reload engine modules whose source changed. `importing` is a module that is being
    imported right now (it is only stamped). Returns True if anything was reloaded."""
    with _lock:
        if _state["active"] > 0 or _state["reloading"]:
            return False
        _state["reloading"] = True
        try:
            importlib.invalidate_caches()
            pkg = sys.modules.get("futurerepair")
            loaded_at = getattr(pkg, "_LOADED_AT", None)
            changed = False
            for name in ORDER:
                mod = sys.modules.get(name)
                if mod is None:
                    continue
                path = getattr(mod, "__file__", None)
                if not path or not os.path.isfile(path):
                    continue
                try:
                    h = _digest(path)
                except OSError:
                    continue
                if not changed and getattr(mod, "__fr_digest__", None) is None and loaded_at is not None:
                    # first look at a module this process loaded itself: it is current unless its
                    # file was replaced after the process started
                    try:
                        newer = os.path.getmtime(path) > loaded_at + 1
                    except OSError:
                        newer = False
                    if not newer and (not ENABLED or name != importing):
                        mod.__fr_digest__ = h
                        continue
                if not changed and getattr(mod, "__fr_digest__", None) == h:
                    continue
                if not ENABLED and name != importing:
                    mod.__fr_digest__ = h
                    continue
                if name != importing:
                    try:
                        importlib.reload(mod)
                    except Exception as e:  # noqa: BLE001 - keep the old code if the new one fails
                        sys.stderr.write("hotreload: %s: %s\n" % (name, e))
                        continue
                mod.__fr_digest__ = h
                changed = True
            return changed
        finally:
            _state["reloading"] = False


def enter() -> None:
    """Called when a repair starts: bring the code up to date, then keep it fixed."""
    with _lock:
        if _state["active"] == 0:
            refresh()
        _state["active"] += 1


def leave() -> None:
    with _lock:
        _state["active"] = max(0, _state["active"] - 1)
