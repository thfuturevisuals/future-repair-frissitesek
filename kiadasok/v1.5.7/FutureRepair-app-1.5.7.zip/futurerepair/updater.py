"""Automatic updates.

Where updates come from
  A release is a signed manifest.json plus a zip of the program code (FutureRepair.py and the
  futurerepair package), published as a GitHub release (thfuturevisuals/future-repair-frissitesek).
  The manifest is signed with The Future Visuals' Ed25519 key and names the SHA-256 of the zip;
  anything that is not signed with that key, or does not match, is refused.

How an update is installed (see paths.py)
  Every version gets its own folder:  app/frissitesek/<version>/  and app/frissitesek/aktiv.json
  says which one is in use. A new version is unpacked into a temporary folder, test-started (all
  modules import, Claude's connection answers), and only then made active. Programs that are already
  running - the window, Claude's connection, a disk recovery working for hours - keep their own
  version untouched; the next start uses the new one. A version folder is deleted only when no
  running program uses it any more. The code that came with the installer is never modified, and
  "rollback" switches back to the previous version.
"""
from __future__ import annotations

import base64
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import threading
import time
import zipfile
from typing import Dict, List, Optional, Tuple

from . import __version__, ed25519
from .paths import BASE_DIR, CODE_DIR, ROOT, UPDATES, console_python, is_update, windows_exe

NAME = "future-repair"
# Where releases are looked for, in order; the newest valid one wins. The public repository's own files
# (manifest.json on main, published with a git push by packaging/kiadas.py --tarolo), then its GitHub
# releases (what 1.5.0 and 1.5.1 look at).
CHANNEL = "https://raw.githubusercontent.com/thfuturevisuals/future-repair-frissitesek/main/manifest.json"
CHANNELS = [CHANNEL,
            "https://github.com/thfuturevisuals/future-repair-frissitesek/releases/latest/download/manifest.json"]
RELEASES_PAGE = "https://github.com/thfuturevisuals/future-repair-frissitesek"
# Ed25519 public keys whose signature is accepted (key id -> hex)
PUBLIC_KEYS = {
    "tfv-2026-11": "09b541e0c041e88910875d63df73d1c617d1630ca187b1d1175b480333fb8fdf",
}
CHECK_EVERY = 6 * 3600              # automatic check at most this often (seconds)
MAX_MANIFEST = 256 * 1024
MAX_APP_ZIP = 64 * 1024 * 1024

UPD_DIR = os.path.join(BASE_DIR, UPDATES)
ACTIVE_FILE = os.path.join(UPD_DIR, "aktiv.json")
SETTINGS_FILE = os.path.join(UPD_DIR, "beallitas.json")
STATE_FILE = os.path.join(UPD_DIR, "allapot.json")
INSTALL_LOCK = os.path.join(UPD_DIR, "telepites.lock")
INUSE_PREFIX = ".hasznalatban-"
_VERSION_RE = re.compile(r"^\d+(\.\d+){1,3}$")


class UpdateError(Exception):
    pass


class NotPublished(UpdateError):
    """The channel answers 404: nothing has been released there yet (or the release has no manifest)."""


def _log(msg: str) -> None:
    try:
        sys.stderr.write("[frissites] %s\n" % msg)
        sys.stderr.flush()
    except Exception:  # noqa: BLE001 (no console under pythonw)
        pass


# ---------------------------------------------------------------------------
# versions
# ---------------------------------------------------------------------------

def vtuple(v) -> Tuple[int, ...]:
    nums = re.findall(r"\d+", str(v or ""))
    return tuple(int(x) for x in nums[:4]) or (0,)


def _read_version(code_dir: str) -> Optional[str]:
    try:
        with open(os.path.join(code_dir, "futurerepair", "__init__.py"), encoding="utf-8") as f:
            m = re.search(r'^__version__\s*=\s*"([^"]+)"', f.read(), re.M)
        return m.group(1) if m else None
    except OSError:
        return None


def base_version() -> str:
    return _read_version(BASE_DIR) or "0"


def _read_json(path: str) -> Dict:
    try:
        with open(path, encoding="utf-8") as f:
            d = json.load(f)
        return d if isinstance(d, dict) else {}
    except (OSError, ValueError):
        return {}


def _write_json(path: str, data: Dict) -> None:
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp = "%s.%d.tmp" % (path, os.getpid())
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=1)
    os.replace(tmp, path)


def active_version() -> Optional[str]:
    """The installed update in use, if any (and if it is newer than the installer's own code)."""
    v = str(_read_json(ACTIVE_FILE).get("version") or "")
    if not _VERSION_RE.match(v):
        return None
    if _read_version(os.path.join(UPD_DIR, v)) != v:
        return None
    return v if vtuple(v) > vtuple(base_version()) else None


def installed_version() -> str:
    """The version the next start of the program will run."""
    return active_version() or base_version()


def settings() -> Dict:
    s = {"auto": True}
    s.update(_read_json(SETTINGS_FILE))
    return s


def set_auto(on: bool) -> None:
    s = _read_json(SETTINGS_FILE)
    s["auto"] = bool(on)
    _write_json(SETTINGS_FILE, s)


def state() -> Dict:
    return _read_json(STATE_FILE)


def _update_state(**kw) -> Dict:
    st = state()
    st.update(kw)
    try:
        _write_json(STATE_FILE, st)
    except OSError:
        pass
    return st


def writable() -> bool:
    try:
        os.makedirs(UPD_DIR, exist_ok=True)
        probe = os.path.join(UPD_DIR, ".iras-proba-%d" % os.getpid())
        with open(probe, "w") as f:
            f.write("x")
        os.remove(probe)
        return True
    except OSError:
        return False


# ---------------------------------------------------------------------------
# locks: "this version folder is in use", "an installation is running"
# ---------------------------------------------------------------------------

def _lock(path: str, mode: str = "a+b"):
    try:
        f = open(path, mode)
    except OSError:
        return None
    try:
        if os.name == "nt":
            import msvcrt
            f.seek(0)
            msvcrt.locking(f.fileno(), msvcrt.LK_NBLCK, 1)
        else:
            import fcntl
            fcntl.flock(f.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        return f
    except OSError:
        f.close()
        return None


def _unlock(f) -> None:
    try:
        if os.name == "nt":
            import msvcrt
            f.seek(0)
            msvcrt.locking(f.fileno(), msvcrt.LK_UNLCK, 1)
        else:
            import fcntl
            fcntl.flock(f.fileno(), fcntl.LOCK_UN)
    except OSError:
        pass
    try:
        f.close()
    except OSError:
        pass


_held = []
RUN_DIR = "futas"          # Windows install folder: <kind>-<pid>.lock for every running copy of the program


def _kind(argv: List[str]) -> str:
    if "--disk-worker" in argv or "--disk-readonly" in argv:
        return "munka"                        # disk recovery, runs as administrator
    if "--mcp" in argv:
        return "claude"                       # Claude's connection
    if any(a.startswith("--") for a in argv):
        return "parancs"
    return "ablak"


def run_dir() -> Optional[str]:
    """<install folder>/futas of an installed Windows copy, else None."""
    if os.name != "nt" or not windows_exe():
        return None
    return os.path.join(ROOT, RUN_DIR)


def hold(kind: Optional[str] = None) -> None:
    """Mark this process as running, for its lifetime.

    Started from an update folder: <folder>/.hasznalatban-<pid>.lock, so cleanup() leaves the folder
    alone. In an installed Windows copy also <install folder>/futas/<kind>-<pid>.lock, so the
    installer can tell what runs: a disk recovery runs as administrator, and the installer can neither
    stop it nor replace the files it uses (and must not break it). An open file cannot be deleted on
    Windows, so the marks of programs that have ended are simply deleted (here and by the installer)."""
    if _held:
        return
    marks = []
    if is_update():
        marks.append(os.path.join(CODE_DIR, "%s%d.lock" % (INUSE_PREFIX, os.getpid())))
    rd = run_dir()
    if rd:
        try:
            os.makedirs(rd, exist_ok=True)
            for n in os.listdir(rd):
                if n.endswith(".lock"):
                    try:
                        os.remove(os.path.join(rd, n))
                    except OSError:
                        pass                  # a running program holds it
            marks.append(os.path.join(rd, "%s-%d.lock" % (kind or _kind(sys.argv[1:]), os.getpid())))
        except OSError:
            pass
    for path in marks:
        f = _lock(path)
        if f is not None:
            _held.append((f, path))
    if not _held:
        return

    import atexit

    def _release():
        for fh, p in _held:
            _unlock(fh)
            try:
                os.remove(p)
            except OSError:
                pass
        del _held[:]
    atexit.register(_release)


def in_use(version_dir: str) -> bool:
    try:
        names = os.listdir(version_dir)
    except OSError:
        return False
    for n in names:
        if not (n.startswith(INUSE_PREFIX) and n.endswith(".lock")):
            continue
        p = os.path.join(version_dir, n)
        if _held and any(p == hp for _f, hp in _held):
            return True
        f = _lock(p, "rb")
        if f is None:
            return True                       # a running program holds it
        _unlock(f)                            # left behind by a program that has ended
        try:
            os.remove(p)
        except OSError:
            pass
    return False


# ---------------------------------------------------------------------------
# downloading
# ---------------------------------------------------------------------------

def _is_local(url: str) -> bool:
    return not re.match(r"^https?://", url, re.I)


def _local_path(url: str) -> str:
    if url.lower().startswith("file://"):
        from urllib.parse import unquote, urlparse
        p = unquote(urlparse(url).path)
        if os.name == "nt" and re.match(r"^/[A-Za-z]:", p):
            p = p[1:]
        return p
    return url


def _curl() -> Optional[str]:
    for c in ("/usr/bin/curl", os.path.join(os.environ.get("SystemRoot", r"C:\Windows"), "System32", "curl.exe")):
        if os.path.exists(c):
            return c
    return None


def _fetch_curl(url: str, dest: str, limit: int, timeout: int) -> None:
    curl = _curl()
    if not curl:
        raise UpdateError("nincs curl a letöltéshez")
    flags = 0x08000000 if os.name == "nt" else 0          # CREATE_NO_WINDOW
    r = subprocess.run([curl, "-fsSL", "--max-time", str(timeout), "--max-filesize", str(limit),
                        "-A", "FutureRepair/%s" % __version__, "-o", dest, url],
                       stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                       creationflags=flags)
    if r.returncode != 0:
        msg = r.stderr.decode("utf-8", "replace").strip().splitlines()
        if any("returned error: 404" in m for m in msg):
            raise NotPublished("még nincs kiadott verzió")
        raise UpdateError("letöltés sikertelen (%s)" % (msg[-1] if msg else "curl %d" % r.returncode))


def _fetch_urllib(url: str, dest: str, limit: int, timeout: int, progress=None) -> None:
    import urllib.error
    import urllib.request
    req = urllib.request.Request(url, headers={"User-Agent": "FutureRepair/%s" % __version__})
    total = 0
    try:
        resp = urllib.request.urlopen(req, timeout=timeout)
    except urllib.error.HTTPError as e:
        if e.code == 404:
            raise NotPublished("még nincs kiadott verzió")
        raise
    with resp, open(dest, "wb") as out:
        size = int(resp.headers.get("Content-Length") or 0)
        while True:
            chunk = resp.read(1 << 16)
            if not chunk:
                break
            total += len(chunk)
            if total > limit:
                raise UpdateError("a letöltött fájl nagyobb a vártnál")
            out.write(chunk)
            if progress and size:
                progress(total / size)


def fetch(url: str, dest: str, limit: int, timeout: int = 120, progress=None) -> None:
    """Download url (https, file:// or a plain path, e.g. a NAS share) to dest."""
    if _is_local(url):
        src = _local_path(url)
        if os.path.getsize(src) > limit:
            raise UpdateError("a fájl nagyobb a vártnál")
        shutil.copyfile(src, dest)
        return
    if sys.platform == "darwin":
        # the system curl trusts the certificates of macOS itself (the bundled Python has none)
        _fetch_curl(url, dest, limit, timeout)
        return
    try:
        _fetch_urllib(url, dest, limit, timeout, progress)
    except UpdateError:
        raise
    except Exception as e:  # noqa: BLE001
        import ssl
        if isinstance(e, ssl.SSLError) or "CERTIFICATE" in str(e).upper():
            _fetch_curl(url, dest, limit, timeout)       # Windows: curl.exe uses the system's TLS
            return
        raise UpdateError("letöltés sikertelen (%s)" % e)


# ---------------------------------------------------------------------------
# manifest
# ---------------------------------------------------------------------------

def canonical(manifest: Dict) -> bytes:
    """The bytes that are signed: the manifest without its signature, keys sorted, compact."""
    body = {k: v for k, v in manifest.items() if k != "signature"}
    return json.dumps(body, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


def verify_manifest(raw: bytes) -> Dict:
    try:
        m = json.loads(raw.decode("utf-8"))
    except (ValueError, UnicodeDecodeError):
        raise UpdateError("a frissítési leírás hibás")
    if not isinstance(m, dict):
        raise UpdateError("a frissítési leírás hibás")
    key = PUBLIC_KEYS.get(str(m.get("key") or ""))
    try:
        sig = base64.b64decode(str(m.get("signature") or ""), validate=True)
    except ValueError:
        sig = b""
    if not key or not ed25519.verify(bytes.fromhex(key), canonical(m), sig):
        raise UpdateError("a frissítés aláírása nem érvényes – nem telepítem")
    if m.get("name") != NAME or not _VERSION_RE.match(str(m.get("version") or "")):
        raise UpdateError("a frissítési leírás nem a Future Repairhez tartozik")
    app = m.get("app")
    if not isinstance(app, dict) or not re.match(r"^[0-9a-f]{64}$", str(app.get("sha256") or "")) \
            or not isinstance(app.get("size"), int):
        raise UpdateError("a frissítési leírás hiányos")
    return m


def _resolve(manifest_url: str, entry: Dict) -> str:
    url = entry.get("url") or entry.get("file") or ""
    if re.match(r"^https?://", url, re.I) or not url:
        return url
    if _is_local(manifest_url):
        return os.path.join(os.path.dirname(_local_path(manifest_url)), url)
    from urllib.parse import urljoin
    return urljoin(manifest_url, url)


def _channel() -> str:
    return _channels()[0]


def _channels() -> List[str]:
    own = os.environ.get("FUTUREREPAIR_UPDATE_URL") or settings().get("channel")
    return [own] if own else list(CHANNELS)


def _requirements(m: Dict) -> Tuple[bool, str]:
    req = m.get("requires") or {}
    py = req.get("python")
    if py and sys.version_info[:2] < vtuple(py)[:2]:
        return False, "Python %s" % py
    plats = req.get("platforms")
    if plats and not any(sys.platform.startswith(p) for p in plats):
        return False, "ez a rendszer (%s)" % sys.platform
    for pkg, minv in (req.get("packages") or {}).items():
        have = None
        try:
            from importlib import metadata
            for name in (pkg, pkg.replace("-", "_"), pkg + "_Essentials", pkg.lower() + "-essentials"):
                try:
                    have = metadata.version(name)
                    break
                except metadata.PackageNotFoundError:
                    continue
        except Exception:  # noqa: BLE001
            have = None
        if have is None or vtuple(have) < vtuple(minv):
            return False, "%s %s" % (pkg, minv)
    return True, ""


def _installer_for(m: Dict, url: str) -> Optional[str]:
    inst = m.get("installers") or {}
    key = "windows" if sys.platform.startswith("win") else "mac" if sys.platform == "darwin" else None
    e = inst.get(key) if key else None
    return _resolve(url, e) if isinstance(e, dict) else None


def check(timeout: int = 30) -> Dict:
    """Look for a newer version. Never raises: problems are in r["error"]."""
    urls = _channels()
    r = {"ok": False, "running": __version__, "installed": installed_version(), "channel": urls[0],
         "available": False, "time": int(time.time())}
    best, best_url, errors, unpublished = None, None, [], 0
    tmpdir = tempfile.mkdtemp(prefix="futurerepair-upd-")
    try:
        for i, url in enumerate(urls):
            try:
                path = os.path.join(tmpdir, "manifest-%d.json" % i)
                fetch(url, path, MAX_MANIFEST, timeout)
                with open(path, "rb") as f:
                    m = verify_manifest(f.read())
            except NotPublished:
                unpublished += 1            # nothing released there yet: not an error, just nothing new
                continue
            except UpdateError as e:
                errors.append(str(e))
                continue
            except Exception as e:  # noqa: BLE001
                errors.append("nem sikerült ellenőrizni (%s)" % e)
                continue
            if best is None or vtuple(m["version"]) > vtuple(best["version"]):
                best, best_url = m, url
        if best is not None:
            latest = best["version"]
            r.update(ok=True, latest=latest, notes=best.get("notes") or "", date=best.get("date") or "",
                     manifest=best, manifest_url=best_url, channel=best_url)
            newer = vtuple(latest) > vtuple(installed_version())
            good, missing = _requirements(best)
            r["available"] = newer
            if newer and not good:
                r["needs_installer"] = True
                r["reason"] = "Ehhez a verzióhoz új telepítő kell (%s)." % missing
                r["installer_url"] = _installer_for(best, best_url) or RELEASES_PAGE
            if newer and str(state().get("skip") or "") == latest:
                r["skipped"] = True
        elif errors:
            r["error"] = errors[0]
        else:
            r.update(ok=True, unpublished=bool(unpublished))
    finally:
        shutil.rmtree(tmpdir, ignore_errors=True)
    saved = {k: v for k, v in r.items() if k not in ("manifest",)}
    _update_state(last_check=r["time"], last=saved)
    return r


# ---------------------------------------------------------------------------
# installing
# ---------------------------------------------------------------------------

def _sha256(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def _extract(zpath: str, dest: str) -> None:
    with zipfile.ZipFile(zpath) as z:
        for info in z.infolist():
            name = info.filename.replace("\\", "/")
            if name.startswith("/") or ".." in name.split("/") or ":" in name:
                raise UpdateError("hibás frissítőcsomag (%s)" % name)
            if not (name == "FutureRepair.py" or name.startswith("futurerepair/")):
                raise UpdateError("váratlan fájl a frissítőcsomagban (%s)" % name)
            if (info.external_attr >> 16) & 0o170000 == 0o120000:
                raise UpdateError("hibás frissítőcsomag (link: %s)" % name)
            target = os.path.join(dest, *name.split("/"))
            if name.endswith("/"):
                os.makedirs(target, exist_ok=True)
                continue
            os.makedirs(os.path.dirname(target), exist_ok=True)
            with z.open(info) as src, open(target, "wb") as out:
                shutil.copyfileobj(src, out)


def _run_probe(cmd: List[str], data: bytes = b"", timeout: int = 180) -> Tuple[int, bytes, bytes]:
    env = dict(os.environ)
    env["FUTUREREPAIR_NO_AUTOUPDATE"] = "1"
    env["QT_QPA_PLATFORM"] = "offscreen"
    flags = 0x08000000 if os.name == "nt" else 0
    p = subprocess.run(cmd, input=data, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=timeout,
                       env=env, creationflags=flags)
    return p.returncode, p.stdout, p.stderr


def _last_line(b: bytes) -> str:
    lines = [x for x in b.decode("utf-8", "replace").strip().splitlines() if x.strip()]
    return lines[-1][:300] if lines else ""


def selftest_dir(code_dir: str, expect: str) -> None:
    """Start the unpacked version the way the program will: all modules import, the version is
    right, and Claude's connection answers with its tools."""
    script = os.path.join(code_dir, "FutureRepair.py")
    py = console_python()
    rc, out, err = _run_probe([py, "-E", "-s", script, "--update-selftest"])
    try:
        info = json.loads(_last_line(out))
    except ValueError:
        info = {}
    if rc != 0 or info.get("version") != expect or info.get("errors"):
        detail = "; ".join(info.get("errors") or []) or _last_line(err) or "kód %d" % rc
        raise UpdateError("az új verzió próbaindítása nem sikerült (%s)" % detail)
    msgs = [{"jsonrpc": "2.0", "id": 1, "method": "initialize",
             "params": {"protocolVersion": "2025-06-18", "capabilities": {},
                        "clientInfo": {"name": "futurerepair-update", "version": "1"}}},
            {"jsonrpc": "2.0", "method": "notifications/initialized"},
            {"jsonrpc": "2.0", "id": 2, "method": "tools/list"}]
    data = "".join(json.dumps(m) + "\n" for m in msgs).encode("utf-8")
    rc, out, err = _run_probe([py, "-E", "-s", script, "--mcp"], data)
    tools, version = 0, None
    for line in out.splitlines():
        try:
            m = json.loads(line)
        except ValueError:
            continue
        if isinstance(m, dict) and m.get("id") == 1:
            version = ((m.get("result") or {}).get("serverInfo") or {}).get("version")
        if isinstance(m, dict) and m.get("id") == 2:
            tools = len((m.get("result") or {}).get("tools") or [])
    if version != expect or tools <= 0:
        raise UpdateError("az új verzió Claude-kapcsolata nem indult (%s)" % (_last_line(err) or "nincs válasz"))


def module_selftest() -> Dict:
    """Run inside the version being tested (FutureRepair.py --update-selftest)."""
    import importlib
    mods = ["futurerepair.engine", "futurerepair.mcp_server", "futurerepair.gui", "futurerepair.gui_disk",
            "futurerepair.updater", "futurerepair.claude_connect", "futurerepair.disk.launch",
            "futurerepair.disk.reassemble", "futurerepair.disk.entryrecover", "futurerepair.disk.survey",
            "futurerepair.video.repair", "futurerepair.photo.repair", "futurerepair.audio.repair"]
    errors = []
    for name in mods:
        try:
            importlib.import_module(name)
        except Exception as e:  # noqa: BLE001
            errors.append("%s: %s" % (name, e))
    return {"version": __version__, "code": CODE_DIR, "errors": errors}


def _remove_tree(path: str) -> bool:
    """Delete a folder; on Windows a folder some program still works in cannot even be renamed."""
    trash = "%s.torles-%d" % (path, os.getpid())
    try:
        os.rename(path, trash)
    except OSError:
        return False
    shutil.rmtree(trash, ignore_errors=True)
    return True


def install(m: Optional[Dict] = None, manifest_url: Optional[str] = None, progress=None) -> Dict:
    """Download, check and activate the version in manifest m (or the newest one)."""
    if m is None:
        c = check()
        if not c.get("ok"):
            return {"ok": False, "error": c.get("error") or "nem sikerült ellenőrizni"}
        if not c.get("available"):
            return {"ok": True, "already": True, "version": installed_version()}
        if c.get("needs_installer"):
            return {"ok": False, "needs_installer": True, "error": c.get("reason"),
                    "installer_url": c.get("installer_url")}
        m, manifest_url = c["manifest"], c["manifest_url"]
    ver = m["version"]
    if vtuple(ver) <= vtuple(installed_version()):
        return {"ok": True, "already": True, "version": installed_version()}
    good, missing = _requirements(m)
    if not good:
        return {"ok": False, "needs_installer": True, "error": "Ehhez a verzióhoz új telepítő kell (%s)." % missing}
    if not writable():
        return {"ok": False, "error": "A program mappájába nem tudok írni (%s); az új verziót a telepítővel "
                                      "lehet feltenni." % UPD_DIR}
    lock = _lock(INSTALL_LOCK)
    if lock is None:
        return {"ok": False, "busy": True, "error": "Egy másik frissítés éppen települ."}
    tmp = os.path.join(UPD_DIR, ver + ".tmp")
    zpath = os.path.join(UPD_DIR, "FutureRepair-app-%s.zip" % ver)
    try:
        if vtuple(ver) <= vtuple(installed_version()):     # installed meanwhile by another program
            return {"ok": True, "already": True, "version": installed_version()}
        app = m["app"]
        url = _resolve(manifest_url or _channel(), app)
        _log("letöltés: %s" % url)
        fetch(url, zpath + ".part", min(MAX_APP_ZIP, app["size"]) + 1, progress=progress)
        if os.path.getsize(zpath + ".part") != app["size"] or _sha256(zpath + ".part") != app["sha256"]:
            raise UpdateError("a letöltött frissítés sérült (ellenőrzőösszeg)")
        os.replace(zpath + ".part", zpath)
        if os.path.exists(tmp):
            shutil.rmtree(tmp, ignore_errors=True)
        os.makedirs(tmp)
        _extract(zpath, tmp)
        if _read_version(tmp) != ver:
            raise UpdateError("a csomag verziója nem egyezik (%s)" % _read_version(tmp))
        selftest_dir(tmp, ver)
        final = os.path.join(UPD_DIR, ver)
        if os.path.exists(final) and not _remove_tree(final):
            raise UpdateError("a(z) %s mappát egy futó program használja" % final)
        os.rename(tmp, final)
        prev = installed_version()
        _write_json(ACTIVE_FILE, {"version": ver, "previous": prev, "installed": int(time.time()),
                                  "notes": m.get("notes") or ""})
        _update_state(skip=None, installed=ver)
        _log("telepítve: %s (előző: %s)" % (ver, prev))
        cleanup()
        return {"ok": True, "version": ver, "previous": prev, "notes": m.get("notes") or ""}
    except UpdateError as e:
        return {"ok": False, "error": str(e)}
    except Exception as e:  # noqa: BLE001
        return {"ok": False, "error": "a telepítés nem sikerült (%s)" % e}
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
        for p in (zpath, zpath + ".part"):
            try:
                os.remove(p)
            except OSError:
                pass
        _unlock(lock)


def rollback() -> Dict:
    """Go back to the version used before the current update (or to the installer's own code)."""
    a = _read_json(ACTIVE_FILE)
    cur = active_version()
    if not cur:
        return {"ok": False, "error": "Nincs telepített frissítés, a telepítővel kapott %s fut." % base_version()}
    prev = str(a.get("previous") or "")
    if prev and _VERSION_RE.match(prev) and _read_version(os.path.join(UPD_DIR, prev)) == prev \
            and vtuple(prev) > vtuple(base_version()):
        _write_json(ACTIVE_FILE, {"version": prev, "previous": None, "installed": int(time.time()),
                                  "notes": "visszaállítva %s helyett" % cur})
    else:
        os.remove(ACTIVE_FILE)
        prev = base_version()
    _update_state(skip=cur)            # do not install the same version again automatically
    return {"ok": True, "version": prev, "removed": cur}


def cleanup() -> None:
    """Delete version folders that are neither active, nor the previous one, nor used by a program."""
    try:
        names = os.listdir(UPD_DIR)
    except OSError:
        return
    a = _read_json(ACTIVE_FILE)
    keep = {str(a.get("version") or ""), str(a.get("previous") or "")}
    if is_update():
        keep.add(os.path.basename(CODE_DIR))
    now = time.time()
    for n in names:
        p = os.path.join(UPD_DIR, n)
        if not os.path.isdir(p):
            if n.endswith((".part", ".zip")) and now - os.path.getmtime(p) > 86400:
                try:
                    os.remove(p)
                except OSError:
                    pass
            continue
        if _VERSION_RE.match(n):
            if n in keep or in_use(p):
                continue
            _remove_tree(p)
        elif ".torles-" in n or (n.endswith(".tmp") and now - os.path.getmtime(p) > 86400):
            shutil.rmtree(p, ignore_errors=True)


# ---------------------------------------------------------------------------
# automatic mode
# ---------------------------------------------------------------------------

def auto_update(force: bool = False) -> Dict:
    """Check now and then; with automatic updates on, install what was found."""
    if os.environ.get("FUTUREREPAIR_NO_AUTOUPDATE") == "1":
        return {"ok": False, "disabled": True}
    st = state()
    if not force and time.time() - float(st.get("last_check") or 0) < CHECK_EVERY:
        r = dict(st.get("last") or {})
        r["cached"] = True
        r["installed"] = installed_version()
        r["running"] = __version__
        r["available"] = vtuple(r.get("latest")) > vtuple(r["installed"])
        return r
    r = check()
    if r.get("available") and settings().get("auto", True) and not r.get("needs_installer") \
            and not r.get("skipped"):
        r["install"] = install(r["manifest"], r["manifest_url"])
        r["installed"] = installed_version()
    r.pop("manifest", None)
    return r


def start_background(interval: float = CHECK_EVERY, first_delay: float = 20.0, on_result=None) -> None:
    """Automatic check in a background thread (for the long-running Claude connection)."""
    if os.environ.get("FUTUREREPAIR_NO_AUTOUPDATE") == "1":
        return

    def loop():
        time.sleep(first_delay)
        while True:
            try:
                r = auto_update()
                if on_result:
                    on_result(r)
            except Exception as e:  # noqa: BLE001
                _log("automatikus ellenőrzés hiba: %s" % e)
            time.sleep(max(600.0, interval))
    threading.Thread(target=loop, name="frissites", daemon=True).start()


def status() -> Dict:
    st = state()
    last = st.get("last") or {}
    inst = installed_version()
    return {"running": __version__, "installed": inst, "base": base_version(), "active_update": active_version(),
            "restart_needed": vtuple(inst) != vtuple(__version__),
            "auto": settings().get("auto", True), "last_check": st.get("last_check"),
            "latest": last.get("latest"), "available": vtuple(last.get("latest")) > vtuple(inst),
            "notes": last.get("notes"), "error": last.get("error"), "needs_installer": last.get("needs_installer"),
            "unpublished": bool(last.get("unpublished")),
            "installer_url": last.get("installer_url"), "writable": writable(), "folder": UPD_DIR}


def main(argv: List[str]) -> int:
    """--update-status | --update-check | --update-install | --update-rollback | --update-selftest"""
    if "--update-selftest" in argv:
        r = module_selftest()
        ok = not r["errors"]
    elif "--update-check" in argv:
        r = check()
        r.pop("manifest", None)
        ok = r.get("ok", False)
    elif "--update-install" in argv:
        r = install()
        ok = r.get("ok", False)
    elif "--update-rollback" in argv:
        r = rollback()
        ok = r.get("ok", False)
    else:
        r = status()
        ok = True
    try:
        sys.stdout.write(json.dumps(r) + "\n")   # ASCII: any console code page
        sys.stdout.flush()
    except Exception:  # noqa: BLE001
        pass
    return 0 if ok else 1
