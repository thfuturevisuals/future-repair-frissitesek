"""Közös tudásbázis: felvétel-minták, amelyekkel minta nélkül is megjavítható egy már látott kamera vagy
beállítás sérült felvétele - bármelyik gépen, ha egyszer valamelyiken már sikerült.

A minta (template) egy ép felvétel váza: a fejléce, a kodek beállításai és az indexe (moov) az első pár
másodpercre, a kép és a hang helyén nullákkal; a képkockákból csak a fejlécük első bájtjai maradnak
(ebből kiderül a szerkezet, de a képből semmi). A javító motor ezt ugyanúgy használja, mint egy
mintafájlt.

Tanulás: amikor egy javítás sikerül mintafájllal (vagy minta nélkül, a kijavított fájlból), vagy a
lemez-visszaállítás egy ép felvételt hoz vissza, és ilyen beállítású felvételről még nincs minta, a program
készít egyet. Ami egy javításban bevált, felkerül a közös tudásbázisba (a Delivery szerverére, a stúdió
kulcsával, amit a telepítő ad), és onnan minden gép letölti. Minden használat eredménye (bevált / nem)
visszamegy, így a megbízhatóbb minták kerülnek előre.

Nem kerül fel: a fájl neve, helye, a kép, a hang, a metaadatok (GPS, felhasználói adatok).
"""
from __future__ import annotations

import base64
import hashlib
import json
import os
import re
import secrets
import shutil
import struct
import subprocess
import sys
import tempfile
import threading
import time
import zlib
from typing import Dict, List, Optional, Tuple

from . import __version__
from .paths import ROOT

SERVER = "https://delivery.thefuturevisuals.com/api/repair-kb"
SYNC_EVERY = 6 * 3600
MAX_TEMPLATE = 1_400_000             # compressed bytes
MAX_RAW = 64 << 20                   # the skeleton's recording area at most this big (zeros, compresses away)
KEEP_SLICE = 32                      # bytes kept of a picture NAL (its header): no picture in it
_lock = threading.RLock()


# ---------------------------------------------------------------------------------------------
# where things are
# ---------------------------------------------------------------------------------------------

def data_dir() -> str:
    if os.environ.get("FUTUREREPAIR_KB_DIR"):
        d = os.environ["FUTUREREPAIR_KB_DIR"]
    elif sys.platform.startswith("win"):
        d = os.path.join(os.environ.get("LOCALAPPDATA") or os.path.expanduser("~"), "FutureRepair", "tudasbazis")
    elif sys.platform == "darwin":
        d = os.path.join(os.path.expanduser("~"), "Library", "Application Support", "FutureRepair", "tudasbazis")
    else:
        d = os.path.join(os.path.expanduser("~"), ".local", "share", "FutureRepair", "tudasbazis")
    os.makedirs(os.path.join(d, "mintak"), exist_ok=True)
    return d


def _server() -> str:
    return (os.environ.get("FUTUREREPAIR_KB_URL") or SERVER).rstrip("/")


def key() -> Optional[str]:
    """The studio key: from the installer (next to the program), or saved by hand."""
    k = os.environ.get("FUTUREREPAIR_KB_KEY")
    if k:
        return k.strip()
    for p in (os.path.join(ROOT, "tudasbazis_kulcs.txt"), os.path.join(data_dir(), "kulcs.txt")):
        try:
            with open(p, encoding="utf-8") as f:
                k = f.read().strip()
            if k:
                return k
        except OSError:
            pass
    return None


def save_key(k: str) -> None:
    with open(os.path.join(data_dir(), "kulcs.txt"), "w", encoding="utf-8") as f:
        f.write(k.strip() + "\n")


def machine() -> str:
    p = os.path.join(data_dir(), "gep.txt")
    try:
        with open(p, encoding="utf-8") as f:
            m = f.read().strip()
        if m:
            return m
    except OSError:
        pass
    m = "fr-" + secrets.token_hex(6)
    with open(p, "w", encoding="utf-8") as f:
        f.write(m)
    return m


def _index_path() -> str:
    return os.path.join(data_dir(), "index.json")


def _load() -> Dict:
    try:
        with open(_index_path(), encoding="utf-8") as f:
            d = json.load(f)
        if isinstance(d, dict):
            d.setdefault("templates", {})
            d.setdefault("pending", [])
            d.setdefault("results", [])
            return d
    except (OSError, ValueError):
        pass
    return {"templates": {}, "pending": [], "results": [], "share": True}


def _save(d: Dict) -> None:
    p = _index_path()
    tmp = p + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(d, f, ensure_ascii=False, indent=1)
    os.replace(tmp, p)


def sharing() -> bool:
    return bool(_load().get("share", True))


def set_sharing(on: bool) -> None:
    with _lock:
        d = _load()
        d["share"] = bool(on)
        _save(d)


# ---------------------------------------------------------------------------------------------
# what a recording is: the things a broken file and a template can be matched by
# ---------------------------------------------------------------------------------------------

def _sidecar(path: str) -> Dict:
    """Sony / XAVC sidecar XML next to the recording (C0001.MP4 -> C0001M01.XML)."""
    base, _ext = os.path.splitext(path)
    out: Dict = {}
    for cand in (base + "M01.XML", base + "M01.xml", base + ".XML", base + ".xml"):
        try:
            with open(cand, "rb") as f:
                x = f.read(65536).decode("utf-8", "replace")
        except OSError:
            continue
        m = re.search(r'<Device\b[^>]*manufacturer="([^"]*)"[^>]*modelName="([^"]*)"', x)
        if m:
            out["maker"], out["device"] = m.group(1)[:60], m.group(2)[:60]
        m = re.search(r'<VideoFrame\b[^>]*videoCodec="([^"]*)"', x)
        if m:
            out["xml_codec"] = m.group(1)[:80]
        m = re.search(r'captureFps="([^"]*)"', x)
        if m:
            out["xml_fps"] = m.group(1)[:20]
        break
    return out


def _head(lay) -> Tuple[str, str]:
    """The top-level boxes before the recording area, and the ftyp brands."""
    names = []
    for b in lay.top:
        if b.type == b"mdat":
            break
        if b.type in (b"moov", b"free", b"skip", b"wide"):
            continue
        names.append(b.type.decode("latin-1"))
    brand = ""
    if len(lay.ftyp) >= 16:
        brand = lay.ftyp[8:12].decode("latin-1", "replace").strip()
    return ",".join(names[:12]), brand


def _sps_of_config(cfg_type: bytes, cfg: bytes) -> Optional[bytes]:
    try:
        if cfg_type == b"avcC" and len(cfg) > 8:
            n = cfg[5] & 0x1F
            if n:
                ln = struct.unpack(">H", cfg[6:8])[0]
                return cfg[8:8 + ln]
        if cfg_type == b"hvcC" and len(cfg) > 23:
            o = 23
            for _ in range(cfg[22]):
                typ = cfg[o] & 0x3F
                cnt = struct.unpack(">H", cfg[o + 1:o + 3])[0]
                o += 3
                for _j in range(cnt):
                    ln = struct.unpack(">H", cfg[o:o + 2])[0]
                    if typ == 33:
                        return cfg[o + 2:o + 2 + ln]
                    o += 2 + ln
    except (IndexError, struct.error):
        pass
    return None


def _h(b: Optional[bytes]) -> str:
    return hashlib.sha1(b).hexdigest()[:12] if b else ""


def info_of_healthy(path: str) -> Optional[Dict]:
    """Matching facts of a playable recording (one with its index)."""
    from .video import entries as E
    from .video.analyze import read_layout
    lay = read_layout(path)
    mv = lay.moov
    if mv is None:
        return None
    vt = next((t for t in mv.tracks if t.is_video and t.sizes), None)
    if vt is None:
        return None
    w, h = E.video_dims(vt.sample_entry)
    durs = vt.durations[:2000]
    dur = max(set(durs), key=durs.count) if durs else 0
    fps = round(vt.timescale / dur, 3) if dur else 0
    cfg_type, cfg = E.video_config(vt.sample_entry)
    head, brand = _head(lay)
    audio = ""
    at = next((t for t in mv.tracks if t.is_audio and t.sizes), None)
    if at is not None:
        ai = E.audio_info(at.sample_entry)
        audio = "%s/%dch/%d/%d" % (at.codec.decode("latin-1", "replace"), ai.channels, ai.sample_rate, ai.bits)
    out = {"codec": vt.codec.decode("latin-1", "replace"), "width": w, "height": h, "fps": fps,
           "brand": brand, "head": head, "audio": audio,
           "tracks": ",".join(t.handler.decode("latin-1", "replace") for t in mv.tracks if t.sizes),
           "sps": _h(_sps_of_config(cfg_type, cfg) if cfg_type else None)}
    out.update(_sidecar(path))
    return out


def fingerprint(info: Dict) -> str:
    return "|".join(str(info.get(k, "")) for k in ("codec", "width", "height", "fps", "brand", "head", "audio",
                                                   "sps", "device", "xml_codec"))


def info_of_broken(path: str, lay) -> Dict:
    """What can be told of a recording without its index: header boxes, the parameter sets in the
    recording itself, the sidecar XML."""
    import mmap
    head, brand = _head(lay)
    out: Dict = {"head": head, "brand": brand}
    out.update(_sidecar(path))
    try:
        from .video.repair import _data_range, _find_param_sets
        start, end = _data_range(lay)
        with open(path, "rb") as f:
            mm = mmap.mmap(f.fileno(), 0, access=mmap.ACCESS_READ)
            try:
                codec, nals, _pos = _find_param_sets(mm, start, end)
            finally:
                mm.close()
        if codec is not None:
            sps = next((n for n in nals if (n[0] & 0x1F) == 7 or ((n[0] >> 1) & 0x3F) == 33), None)
            out["sps"] = _h(sps)
            s = next(iter(codec.sps.values()), None)
            if s is not None and getattr(s, "width", 0):
                out["width"], out["height"] = s.width, s.height
            out["nal_codec"] = type(codec).__name__.lower()
    except Exception:  # noqa: BLE001 - matching is best effort
        pass
    return out


def _score(t: Dict, b: Dict) -> int:
    """How well template meta t fits broken-file facts b (0: does not fit)."""
    if b.get("width") and t.get("width") and (b["width"], b.get("height")) != (t["width"], t.get("height")):
        return 0
    nc = b.get("nal_codec")
    if nc and t.get("codec"):
        avc = t["codec"] in ("avc1", "avc3")
        hevc = t["codec"] in ("hvc1", "hev1")
        if (nc == "h264" and not avc) or (nc == "hevc" and not hevc):
            return 0
    s = 0
    if b.get("sps") and b["sps"] == t.get("sps"):
        s += 50
    if b.get("xml_codec") and b["xml_codec"] == t.get("xml_codec"):
        s += 25
    if b.get("device") and b["device"] == t.get("device"):
        s += 15
    if b.get("xml_fps") and b["xml_fps"] == t.get("xml_fps"):
        s += 5
    if b.get("brand") and b["brand"] == t.get("brand"):
        s += 10
    if b.get("head") and b["head"] == t.get("head"):
        s += 10
    if b.get("width") and t.get("width"):
        s += 10
    return s if s >= 20 else 0


def candidates(path: str, lay, limit: int = 3) -> List[Tuple[int, str, Dict]]:
    """Templates that may fit a broken recording, best first: (score, id, meta)."""
    with _lock:
        d = _load()
    b = info_of_broken(path, lay)
    out = []
    for tid, t in d["templates"].items():
        if not os.path.exists(os.path.join(data_dir(), "mintak", tid + ".frt")):
            continue
        meta = t.get("meta") or {}
        sc = _score(meta, b)
        if sc:
            rel = int(t.get("successes", 0)) - 2 * int(t.get("failures", 0))
            out.append((sc * 100 + max(-99, min(99, rel)), tid, meta))
    out.sort(key=lambda x: -x[0])
    return out[:limit]


def label(meta: Dict) -> str:
    parts = [meta.get("device") or "", "%sx%s" % (meta.get("width"), meta.get("height")) if meta.get("width") else "",
             ("%gp" % meta["fps"]) if meta.get("fps") else "", meta.get("xml_codec") or meta.get("codec") or ""]
    return ", ".join(p for p in parts if p)


# ---------------------------------------------------------------------------------------------
# making a template
# ---------------------------------------------------------------------------------------------

_KEEP_H264 = {6: 4, 7: -1, 8: -1, 9: -1, 13: -1, 15: -1}           # -1: the whole NAL
_KEEP_HEVC = {32: -1, 33: -1, 34: -1, 35: -1, 39: 4, 40: 4}


def _sanitize_nal_sample(data: bytes, nls: int, hevc: bool) -> bytes:
    out = bytearray(len(data))
    p = 0
    n = len(data)
    while p + nls <= n:
        ln = int.from_bytes(data[p:p + nls], "big")
        if ln <= 0 or p + nls + ln > n:
            break
        out[p:p + nls] = data[p:p + nls]
        s = p + nls
        b0 = data[s]
        t = ((b0 >> 1) & 0x3F) if hevc else (b0 & 0x1F)
        keep = (_KEEP_HEVC if hevc else _KEEP_H264).get(t, KEEP_SLICE)
        k = ln if keep < 0 else min(ln, keep)
        out[s:s + k] = data[s:s + k]
        p = s + ln
    return bytes(out)


def _sanitize(track, data: bytes) -> bytes:
    if not track.is_video:
        return bytes(len(data))                    # sound and metadata (GPS, user data): nothing kept
    c = track.codec
    if c in (b"avc1", b"avc3", b"hvc1", b"hev1"):
        from .video import entries as E
        cfg_type, cfg = E.video_config(track.sample_entry)
        nls = ((cfg[4] & 3) + 1) if cfg_type == b"avcC" and cfg and len(cfg) > 4 else \
            ((cfg[21] & 3) + 1) if cfg_type == b"hvcC" and cfg and len(cfg) > 21 else 4
        return _sanitize_nal_sample(data, nls, c in (b"hvc1", b"hev1"))
    keep = 512 if c.startswith(b"ap") else 64        # ProRes frame header / other: the first bytes only
    return data[:keep] + bytes(max(0, len(data) - keep))


def make_template(path: str, max_frames: int = 120) -> Tuple[bytes, Dict]:
    """(compressed skeleton MP4, meta) of a playable recording."""
    from .video.analyze import build_profile, read_layout
    from .video.mp4 import runs
    from .video.writer import OutTrack, write_file
    info = info_of_healthy(path)
    if info is None:
        raise ValueError("nincs ép indexe")
    lay = read_layout(path)
    mv = lay.moov
    tracks = [t for t in mv.tracks if t.sizes and t.chunk_offsets]
    chunks = []                                    # (offset, track index, chunk index, first sample)
    for ti, t in enumerate(tracks):
        si = 0
        for ci, off in enumerate(t.chunk_offsets):
            chunks.append((off, ti, ci, si))
            si += t.chunk_samples[ci]
    chunks.sort()
    vi = next(i for i, t in enumerate(tracks) if t.is_video)
    took: Dict[int, List[Tuple[int, int, int]]] = {i: [] for i in range(len(tracks))}
    need = {i: min(2, len(t.chunk_offsets)) for i, t in enumerate(tracks)}
    vframes = 0
    region_end = 0
    region_start = chunks[0][0] if chunks else 0
    for off, ti, ci, si in chunks:
        t = tracks[ti]
        k = t.chunk_samples[ci]
        nbytes = sum(t.sizes[si:si + k])
        enough = vframes >= max_frames and all(len(v) >= need[i] for i, v in took.items())
        if enough or (off + nbytes - region_start > MAX_RAW and vframes >= 8):
            break
        took[ti].append((ci, si, k))
        region_end = max(region_end, off + nbytes)
        if ti == vi:
            vframes += k
    work = tempfile.mkdtemp(prefix="futurerepair-minta-")
    try:
        src = os.path.join(work, "forras.bin")
        with open(path, "rb") as f, open(src, "wb") as out:
            out.truncate(region_end - region_start)
            for ti, lst in took.items():
                t = tracks[ti]
                for ci, si, k in lst:
                    p = t.chunk_offsets[ci]
                    for j in range(si, si + k):
                        sz = t.sizes[j]
                        f.seek(p)
                        out.seek(p - region_start)
                        out.write(_sanitize(t, f.read(sz)))
                        p += sz
        outs = []
        for ti, lst in took.items():
            if not lst:
                continue
            t = tracks[ti]
            n = sum(k for _ci, _si, k in lst)
            sync = None
            if t.sync is not None:
                sync = sorted(i for i in t.sync if i < n)
            cts = t.cts[:n] if t.cts and any(t.cts[:n]) else None
            mt = next((m for _sd, m, _r in t.elst if m > 0), 0)
            outs.append(OutTrack(t.handler, t.timescale, t.sample_entry,
                                 [t.chunk_offsets[ci] - region_start for ci, _si, _k in lst],
                                 [k for _ci, _si, k in lst],
                                 [sum(t.sizes[si:si + k]) for _ci, si, k in lst],
                                 None if t.stsz_const else t.sizes[:n], stsz_const=t.stsz_const,
                                 durations=runs(t.durations[:n]), cts=cts, sync=sync, media_time=mt, ref=t,
                                 track_id=t.track_id, language=t.mdhd_language))
        head = lay.ftyp
        with open(path, "rb") as f:                # the camera's own header boxes (e.g. Sony's profile uuid)
            for b in lay.top:
                if b.type == b"mdat":
                    break
                if b.type == b"uuid" and b.size <= 65536:
                    f.seek(b.start)
                    head += f.read(b.size)
        mp4 = os.path.join(work, "minta.mp4")
        write_file(mp4, src, head, outs, movie_ts=mv.timescale or 1000)
        build_profile(mp4)                         # the repair engine must be able to use it
        with open(mp4, "rb") as f:
            blob = zlib.compress(f.read(), 9)
    finally:
        shutil.rmtree(work, ignore_errors=True)
    if len(blob) > MAX_TEMPLATE:
        if max_frames > 15:
            return make_template(path, max_frames // 2)
        raise ValueError("a minta túl nagy")
    info["frames"] = vframes
    info["app"] = __version__
    return blob, info


def template_id(blob: bytes) -> str:
    return hashlib.sha256(blob).hexdigest()[:32]


def template_file(tid: str) -> Optional[str]:
    """The template as a playable skeleton file (unpacked once into the temp folder)."""
    src = os.path.join(data_dir(), "mintak", tid + ".frt")
    if not os.path.exists(src):
        return None
    d = os.path.join(tempfile.gettempdir(), "futurerepair-mintak")
    os.makedirs(d, exist_ok=True)
    dst = os.path.join(d, tid + ".mp4")
    if not os.path.exists(dst):
        with open(src, "rb") as f:
            raw = zlib.decompress(f.read())
        with open(dst + ".tmp", "wb") as f:
            f.write(raw)
        os.replace(dst + ".tmp", dst)
    return dst


# ---------------------------------------------------------------------------------------------
# learning and reporting
# ---------------------------------------------------------------------------------------------

def known(info: Dict) -> Optional[str]:
    fp = fingerprint(info)
    with _lock:
        for tid, t in _load()["templates"].items():
            if t.get("fingerprint") == fp:
                return tid
    return None


def learn(path: str, origin: str, proven: bool = True) -> Optional[str]:
    """Make a template of this playable recording if its kind is not known yet. -> the new id."""
    try:
        info = info_of_healthy(path)
        if info is None or not info.get("width"):
            return None
        if known(info):
            return None
        blob, meta = make_template(path)
    except Exception as e:  # noqa: BLE001 - learning never breaks a repair
        _log("minta nem készült (%s): %s" % (os.path.basename(path), e))
        return None
    meta["origin"] = origin
    tid = template_id(blob)
    with _lock:
        d = _load()
        if tid in d["templates"]:
            return None
        with open(os.path.join(data_dir(), "mintak", tid + ".frt"), "wb") as f:
            f.write(blob)
        d["templates"][tid] = {"fingerprint": fingerprint(meta), "meta": meta, "successes": 1 if proven else 0,
                               "failures": 0, "local": True, "added": int(time.time())}
        if proven:
            d["pending"].append(tid)
        _save(d)
    _log("új minta: %s (%s)" % (label(meta), origin))
    _kick()
    return tid


def learn_async(path: str, origin: str) -> None:
    threading.Thread(target=learn, args=(path, origin), name="tudasbazis-tanul", daemon=True).start()


def report(tid: str, ok: bool, detail: str = "") -> None:
    with _lock:
        d = _load()
        t = d["templates"].get(tid)
        if t is not None:
            t["successes" if ok else "failures"] = int(t.get("successes" if ok else "failures", 0)) + 1
        d["results"].append({"id": tid, "ok": bool(ok), "detail": detail[:200]})
        d["results"] = d["results"][-500:]
        _save(d)
    _kick()


# ---------------------------------------------------------------------------------------------
# the shared database
# ---------------------------------------------------------------------------------------------

def _curl() -> Optional[str]:
    for c in ("/usr/bin/curl", os.path.join(os.environ.get("SystemRoot", r"C:\Windows"), "System32", "curl.exe")):
        if os.path.exists(c):
            return c
    return None


def _request(method: str, url: str, body: Optional[bytes] = None, timeout: int = 60) -> bytes:
    k = key() or ""
    headers = {"x-fr-kulcs": k, "User-Agent": "FutureRepair/%s" % __version__}
    if body is not None:
        headers["content-type"] = "application/json"
    if sys.platform != "darwin":
        import urllib.error
        import urllib.request
        try:
            req = urllib.request.Request(url, data=body, method=method, headers=headers)
            with urllib.request.urlopen(req, timeout=timeout) as r:
                return r.read()
        except urllib.error.HTTPError as e:
            raise IOError("HTTP %d: %s" % (e.code, e.read()[:200].decode("utf-8", "replace")))
        except Exception as e:  # noqa: BLE001
            import ssl
            if not (isinstance(e, ssl.SSLError) or "CERTIFICATE" in str(e).upper()):
                raise
    curl = _curl()
    if not curl:
        raise IOError("nincs curl")
    cmd = [curl, "-sS", "-f", "--max-time", str(timeout), "-X", method]
    for hk, hv in headers.items():
        cmd += ["-H", "%s: %s" % (hk, hv)]
    tmp = None
    if body is not None:
        fd, tmp = tempfile.mkstemp(prefix="futurerepair-kb-")
        with os.fdopen(fd, "wb") as f:
            f.write(body)
        cmd += ["--data-binary", "@" + tmp]
    cmd.append(url)
    try:
        r = subprocess.run(cmd, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                           creationflags=0x08000000 if os.name == "nt" else 0)
    finally:
        if tmp:
            os.remove(tmp)
    if r.returncode != 0:
        raise IOError(r.stderr.decode("utf-8", "replace").strip()[-200:] or "curl %d" % r.returncode)
    return r.stdout


def sync(timeout: int = 60) -> Dict:
    """Send what this machine learnt and what it found, fetch what the others learnt."""
    if not key():
        return {"ok": False, "error": "nincs kulcs (a telepítő adja)"}
    with _lock:
        d = _load()
    sent = got = 0
    base = _server()
    if d.get("share", True):
        for tid in list(d["pending"]):
            t = d["templates"].get(tid)
            p = os.path.join(data_dir(), "mintak", tid + ".frt")
            if t is None or not os.path.exists(p):
                continue
            with open(p, "rb") as f:
                blob = f.read()
            body = json.dumps({"id": tid, "fingerprint": t["fingerprint"], "meta": t["meta"], "proven": True,
                               "machine": machine(), "template": base64.b64encode(blob).decode("ascii")}).encode()
            _request("POST", base + "/minta", body, timeout)
            sent += 1
            with _lock:
                d2 = _load()
                if tid in d2["pending"]:
                    d2["pending"].remove(tid)
                _save(d2)
        with _lock:
            d2 = _load()
            res, d2["results"] = d2["results"], []
            _save(d2)
        if res:
            try:
                _request("POST", base + "/eredmeny", json.dumps({"machine": machine(), "results": res}).encode(),
                         timeout)
            except Exception:
                with _lock:
                    d2 = _load()
                    d2["results"] = res + d2["results"]
                    _save(d2)
                raise
    idx = json.loads(_request("GET", base + "/index", None, timeout).decode("utf-8"))
    for t in idx.get("templates") or []:
        tid = str(t.get("id") or "")
        if not re.match(r"^[0-9a-f]{32}$", tid):
            continue
        p = os.path.join(data_dir(), "mintak", tid + ".frt")
        if not os.path.exists(p):
            blob = _request("GET", base + "/minta/" + tid, None, timeout)
            if template_id(blob) != tid or len(blob) > MAX_TEMPLATE:
                continue
            with open(p, "wb") as f:
                f.write(blob)
            got += 1
        with _lock:
            d2 = _load()
            cur = d2["templates"].get(tid) or {}
            cur.update({"fingerprint": t.get("fingerprint") or cur.get("fingerprint"),
                        "meta": t.get("meta") or cur.get("meta") or {},
                        "successes": int(t.get("successes") or 0), "failures": int(t.get("failures") or 0)})
            d2["templates"][tid] = cur
            _save(d2)
    with _lock:
        d2 = _load()
        d2["last_sync"] = int(time.time())
        d2["last_error"] = ""
        _save(d2)
    return {"ok": True, "sent": sent, "got": got, "total": len(idx.get("templates") or [])}


def _sync_quiet() -> None:
    try:
        r = sync()
        if r.get("ok") and (r.get("sent") or r.get("got")):
            _log("tudásbázis: %d minta elküldve, %d új letöltve (%d a közösben)" % (r["sent"], r["got"], r["total"]))
    except Exception as e:  # noqa: BLE001
        with _lock:
            d = _load()
            d["last_error"] = str(e)[:200]
            _save(d)


_kick_timer: Optional[threading.Timer] = None


def _kick(delay: float = 20.0) -> None:
    """Sync a little later (several things learnt in a row go in one round)."""
    global _kick_timer
    if not key():
        return
    with _lock:
        if _kick_timer is not None:
            _kick_timer.cancel()
        _kick_timer = threading.Timer(delay, _sync_quiet)
        _kick_timer.daemon = True
        _kick_timer.start()


_started = False


def start_background() -> None:
    """Fetch the others' templates shortly after the start, then every 6 hours."""
    global _started
    if _started or os.environ.get("FUTUREREPAIR_NO_KB") == "1":
        return
    _started = True

    def loop():
        time.sleep(8)
        while True:
            _sync_quiet()
            time.sleep(SYNC_EVERY)
    threading.Thread(target=loop, name="tudasbazis", daemon=True).start()


def status() -> Dict:
    with _lock:
        d = _load()
    temps = d["templates"]
    return {"templates": len(temps), "local": sum(1 for t in temps.values() if t.get("local")),
            "pending": len(d["pending"]), "share": d.get("share", True), "key": bool(key()),
            "last_sync": d.get("last_sync"), "last_error": d.get("last_error") or "",
            "labels": sorted({label(t.get("meta") or {}) for t in temps.values()})[:50]}


def _log(line: str) -> None:
    try:
        with open(os.path.join(data_dir(), "naplo.txt"), "a", encoding="utf-8") as f:
            f.write("%s %s\n" % (time.strftime("%Y-%m-%d %H:%M:%S"), line))
    except OSError:
        pass
