"""Connecting Future Repair to the Claude desktop app (as a local MCP server).

Claude Desktop starts the local MCP servers listed under "mcpServers" in its config file:
  Windows: %APPDATA%\\Claude\\claude_desktop_config.json
           (the Microsoft Store / MSIX build reads its own copy instead:
            %LOCALAPPDATA%\\Packages\\Claude_<id>\\LocalCache\\Roaming\\Claude\\claude_desktop_config.json)
  macOS:   ~/Library/Application Support/Claude/claude_desktop_config.json
This adds (or removes) the "future-repair" entry in every copy that Claude may read; everything else in
the files is kept as it was, and the previous file is saved next to it. Claude has to be restarted
afterwards.
"""
from __future__ import annotations

import glob
import json
import os
import sys
import time
from typing import Dict, List, Tuple

NAME = "future-repair"
FILE = "claude_desktop_config.json"


def config_paths() -> List[str]:
    """Config files to keep in step (the first one is the one shown to the user)."""
    if sys.platform.startswith("win"):
        home = os.path.expanduser("~")
        roaming = os.environ.get("APPDATA") or os.path.join(home, "AppData", "Roaming")
        local = os.environ.get("LOCALAPPDATA") or os.path.join(home, "AppData", "Local")
        real = os.path.join(roaming, "Claude", FILE)
        out = []
        for pkg in sorted(glob.glob(os.path.join(local, "Packages", "Claude_*"))):
            d = os.path.join(pkg, "LocalCache", "Roaming", "Claude")
            if os.path.isdir(d):                   # the packaged app has run and keeps its own copy
                out.append(os.path.join(d, FILE))
        if os.path.isdir(os.path.dirname(real)) or not out:
            out.append(real)
        return out
    if sys.platform == "darwin":
        return [os.path.expanduser("~/Library/Application Support/Claude/" + FILE)]
    return [os.path.join(os.environ.get("XDG_CONFIG_HOME") or os.path.expanduser("~/.config"), "Claude", FILE)]


def config_path() -> str:
    return config_paths()[0]


def server_command() -> Tuple[str, List[str]]:
    """How Claude should start this installation's MCP server (stdio). It always goes through the
    starter that came with the installer, so Claude gets the newest installed update."""
    from .paths import BASE_DIR
    app_dir = BASE_DIR                                                          # .../app
    script = os.path.join(app_dir, "FutureRepair.py")
    root = os.path.dirname(app_dir)
    if sys.platform.startswith("win"):
        # console python.exe, not the FutureRepair.exe launcher: the launcher starts the windowed app and
        # returns at once, while Claude talks to the server through its standard input/output
        py = os.path.join(root, "runtime", "python.exe")
        if os.path.exists(py):
            return py, ["-E", "-s", script, "--mcp"]
    if sys.platform == "darwin":
        contents = os.path.dirname(os.path.dirname(app_dir))                     # .../X.app/Contents
        mcp = os.path.join(contents, "MacOS", "future-repair-mcp")
        if os.path.exists(mcp):
            return mcp, []
    exe = sys.executable
    if sys.platform.startswith("win") and exe.lower().endswith("pythonw.exe"):
        exe = exe[:-len("pythonw.exe")] + "python.exe"
    return exe, ["-E", "-s", script, "--mcp"]


def _load(path: str) -> Dict:
    if not os.path.exists(path):
        return {}
    with open(path, encoding="utf-8-sig") as f:
        text = f.read()
    if not text.strip():
        return {}
    data = json.loads(text)
    if not isinstance(data, dict):
        raise ValueError("a fájl nem JSON-objektum")
    return data


def _save(path: str, data: Dict) -> None:
    os.makedirs(os.path.dirname(path), exist_ok=True)
    if os.path.exists(path):                    # keep the previous version next to it
        with open(path, "rb") as f:
            old = f.read()
        with open(path + ".futurerepair-mentes", "wb") as f:
            f.write(old)
    tmp = path + ".tmp-%d" % os.getpid()
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
        f.write("\n")
    os.replace(tmp, path)


def _same(entry: Dict, cmd: str, args: List[str]) -> bool:
    return os.path.normcase(str(entry.get("command") or "")) == os.path.normcase(cmd) and \
        [str(a) for a in entry.get("args") or []] == args


def status() -> Dict:
    paths = config_paths()
    cmd, args = server_command()
    out = {"config": paths[0], "configs": paths, "connected": False, "current": False}
    found, current, errors = 0, 0, []
    for p in paths:
        try:
            data = _load(p)
        except (OSError, ValueError) as e:
            errors.append("%s: %s" % (p, e))
            continue
        entry = (data.get("mcpServers") or {}).get(NAME)
        if isinstance(entry, dict):
            found += 1
            current += _same(entry, cmd, args)
            out["entry"] = entry
    out["connected"] = found > 0
    out["current"] = found > 0 and current == found
    if errors:
        out["error"] = "A Claude beállításfájlja nem olvasható – " + "; ".join(errors)
    return out


def connect() -> Dict:
    cmd, args = server_command()
    paths = config_paths()
    done, errors = [], []
    for p in paths:
        try:
            src = p
            if not os.path.exists(p) and p != paths[-1] and os.path.exists(paths[-1]):
                # a packaged (MSIX) Claude without its own copy reads the normal file: start from that one,
                # so that the servers already set up there stay visible
                src = paths[-1]
            data = _load(src)
        except (OSError, ValueError) as e:
            errors.append("A Claude beállításfájlja hibás, nem írom felül: %s (%s). Javítsd ki, vagy töröld."
                          % (p, e))
            continue
        servers = data.get("mcpServers")
        if not isinstance(servers, dict):
            servers = {}
        servers[NAME] = {"command": cmd, "args": args}
        data["mcpServers"] = servers
        try:
            _save(p, data)
            done.append(p)
        except OSError as e:
            errors.append("%s: %s" % (p, e))
    r = {"ok": not errors and bool(done), "config": paths[0], "written": done, "command": cmd, "args": args}
    if errors:
        r["error"] = " | ".join(errors)
    return r


def disconnect() -> Dict:
    paths = config_paths()
    errors = []
    for p in paths:
        try:
            data = _load(p)
        except (OSError, ValueError) as e:
            errors.append("%s: %s" % (p, e))
            continue
        servers = data.get("mcpServers")
        if isinstance(servers, dict) and NAME in servers:
            del servers[NAME]
            try:
                _save(p, data)
            except OSError as e:
                errors.append("%s: %s" % (p, e))
    r = {"ok": not errors, "config": paths[0]}
    if errors:
        r["error"] = " | ".join(errors)
    return r


def selftest(timeout: float = 120.0) -> Dict:
    """Start the server the way Claude will, and ask it for its tool list."""
    import subprocess
    cmd, args = server_command()
    msgs = [{"jsonrpc": "2.0", "id": 1, "method": "initialize",
             "params": {"protocolVersion": "2025-06-18", "capabilities": {},
                        "clientInfo": {"name": "futurerepair-selftest", "version": "1"}}},
            {"jsonrpc": "2.0", "method": "notifications/initialized"},
            {"jsonrpc": "2.0", "id": 2, "method": "tools/list"}]
    data = "".join(json.dumps(m) + "\n" for m in msgs).encode("utf-8")
    flags = 0x08000000 if sys.platform.startswith("win") else 0         # CREATE_NO_WINDOW
    try:
        p = subprocess.run([cmd] + args, input=data, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                           timeout=timeout, creationflags=flags)
    except (OSError, subprocess.SubprocessError) as e:
        return {"ok": False, "error": str(e)}
    info, tools = None, 0
    for line in p.stdout.splitlines():
        try:
            m = json.loads(line)
        except ValueError:
            continue
        if not isinstance(m, dict):
            continue
        if m.get("id") == 1:
            info = (m.get("result") or {}).get("serverInfo")
        elif m.get("id") == 2:
            tools = len((m.get("result") or {}).get("tools") or [])
    r = {"ok": bool(info) and tools > 0, "tools": tools}
    if info:
        r["server"] = "%s %s" % (info.get("name", ""), info.get("version", ""))
    if not r["ok"]:
        err = p.stderr.decode("utf-8", "replace").strip().splitlines()
        r["error"] = (err[-1] if err else "a szerver nem válaszolt")[:400]
    return r


def main(argv: List[str]) -> int:
    """--claude-connect [--no-test] / --claude-disconnect / --claude-status / --claude-selftest [--result FILE]"""
    if "--claude-disconnect" in argv:
        r = disconnect()
    elif "--claude-selftest" in argv:
        r = selftest()
    elif "--claude-status" in argv:
        r = status()
        r["ok"] = True
    else:
        r = connect()
        if r.get("ok") and "--no-test" not in argv:
            r["selftest"] = selftest()
    r["time"] = time.strftime("%Y-%m-%d %H:%M:%S")
    if "--result" in argv:
        i = argv.index("--result")
        if i + 1 < len(argv):
            try:
                with open(argv[i + 1], "w", encoding="utf-8") as f:
                    json.dump(r, f, ensure_ascii=False, indent=1)
            except OSError:
                pass
    try:
        sys.stdout.write(json.dumps(r) + "\n")   # ASCII: any console code page
    except Exception:  # noqa: BLE001  (no console under pythonw)
        pass
    if not r.get("ok"):
        return 1
    return 2 if (r.get("selftest") or {}).get("ok") is False else 0


def restart_hint(connected: bool = True) -> str:
    if sys.platform == "darwin":
        how = "lépj ki teljesen a Claude alkalmazásból (Cmd+Q)"
    else:
        how = "lépj ki teljesen a Claude alkalmazásból (a tálca jobb alsó sarkában a Claude ikonon jobb klikk → Quit)"
    if connected:
        return "Ezután %s, majd indítsd újra – onnantól a Claude eléri a Future Repair eszközeit." % how
    return "A változás a Claude újraindítása után érvényes: %s, majd indítsd újra." % how
