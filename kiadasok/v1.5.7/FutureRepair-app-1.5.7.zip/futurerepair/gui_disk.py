"""Future Repair - 'Formázott lemez' page: bring files back from a formatted disk by their old folders.

1) pick the damaged disk and read it in (the old folders, sizes and places of the files),
2) tick folders/files in the tree,
3) pick where they go and restore them. The disk itself is only read (and set read-only).
"""
from __future__ import annotations

import json
import os
import re
import shutil
import sys
import time
from typing import Dict, List, Optional

from PySide6.QtCore import Qt, QTimer, QUrl
from PySide6.QtGui import QDesktopServices
from PySide6.QtWidgets import (QAbstractItemView, QCheckBox, QComboBox, QFileDialog, QFrame, QHBoxLayout,
                               QHeaderView, QLabel, QLineEdit, QMessageBox, QPlainTextEdit, QProgressBar,
                               QPushButton, QSplitter, QTreeWidget, QTreeWidgetItem, QVBoxLayout, QWidget)

from . import theme
from .disk import launch

VIDEO_INDEX = {".mp4", ".mov", ".m4v", ".3gp", ".insv", ".lrv", ".lrf"}
ROLE_ENTRY = Qt.UserRole
ROLE_PATH = Qt.UserRole + 1
ROLE_STAT = Qt.UserRole + 2


def human(n: float) -> str:
    n = float(n or 0)
    for unit, k in (("TB", 1e12), ("GB", 1e9), ("MB", 1e6), ("KB", 1e3)):
        if n >= k:
            return ("%.1f %s" % (n / k, unit)).replace(".", ",")
    return "%d B" % n


def file_status(e: Dict):
    """(text, colour tone, will it come back) of one old file."""
    ext = os.path.splitext(e["name"])[1].lower()
    if e.get("maybe_overwritten"):
        return "Felülíródhatott", "warn", True
    if e["contig"] or e["size"] <= 262144:
        return "Egy darabban", "ok", True
    if ext in VIDEO_INDEX:
        return "Összerakható (videóindex)", "accent", True
    if ext == ".mxf":
        return "Összerakható (MXF)", "accent", True
    if ext in (".wav", ".bwf"):
        return "Összerakható (hang)", "warn", True
    if ext == ".braw":
        return "Összerakható (BRAW, ellenőrizendő)", "warn", True
    return "Darabolt – nem támogatott", "bad", False


def display_name(name: str) -> str:
    m = re.fullmatch(r"_ismeretlen_mappa_(\d+)", name)
    return "Ismeretlen nevű mappa (%s)" % m.group(1) if m else name


def default_work_dir(d: Dict) -> str:
    base = os.path.join(os.path.expanduser("~"), "Documents", "FutureRepair")
    model = re.sub(r"[^A-Za-z0-9]+", "_", d.get("model") or "lemez").strip("_")
    return os.path.join(base, "lemez_%s_%dGB" % (model, int((d.get("size") or 0) / 1e9)))


class DiskPage(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.disks: List[Dict] = []
        self.entries: List[Dict] = []
        self.summary: Dict = {}
        self.work_dir: Optional[str] = None
        self.dest: Optional[str] = None
        self.job_out: Optional[str] = None
        self.job_kind: Optional[str] = None
        self.job_started = 0.0
        self.file_items: Dict[str, QTreeWidgetItem] = {}
        self._building = False
        self.timer = QTimer(self)
        self.timer.setInterval(1000)
        self.timer.timeout.connect(self._poll)
        self.sel_timer = QTimer(self)
        self.sel_timer.setSingleShot(True)
        self.sel_timer.setInterval(150)
        self.sel_timer.timeout.connect(self._update_selection)
        self.filter_timer = QTimer(self)
        self.filter_timer.setSingleShot(True)
        self.filter_timer.setInterval(300)
        self.filter_timer.timeout.connect(self._apply_filter)
        self._build()
        self.refresh_disks()

    # -- layout -----------------------------------------------------------------------------
    def _build(self):
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(14)
        lay.addWidget(theme.page_head("Visszahozás formázott lemezről",
                                      "A régi mappák alapján keresi meg a fájlokat. A sérült lemezt a program csak "
                                      "olvassa, és előtte írásvédetté teszi."))

        row = QHBoxLayout()
        row.setSpacing(8)
        disk_label = QLabel("Sérült lemez")
        disk_label.setObjectName("sub")
        row.addWidget(disk_label)
        self.disk_box = QComboBox()
        self.disk_box.setMinimumWidth(420)
        self.disk_box.currentIndexChanged.connect(self._disk_changed)
        row.addWidget(self.disk_box, 1)
        self.btn_refresh = QPushButton("Frissítés")
        self.btn_refresh.clicked.connect(self.refresh_disks)
        row.addWidget(self.btn_refresh)
        self.btn_open = QPushButton("Korábbi beolvasás…")
        self.btn_open.setToolTip("Egy korábban beolvasott lemez listájának megnyitása (munkamappa).")
        self.btn_open.clicked.connect(self._open_previous)
        row.addWidget(self.btn_open)
        self.btn_scan = theme.PrimaryButton("Beolvasás")
        self.btn_scan.setToolTip("Megkeresi a régi fájlrendszer mappáit: a fájlok nevét, méretét és helyét.\n"
                                 "Pár perc; a lemezre nem ír, előtte írásvédetté teszi.")
        self.btn_scan.clicked.connect(self.start_scan)
        row.addWidget(self.btn_scan)
        lay.addLayout(row)

        prog = QHBoxLayout()
        prog.setSpacing(16)
        texts = QVBoxLayout()
        texts.setSpacing(2)
        self.info = QLabel("Válaszd ki a formázott lemezt, és kattints a Beolvasásra. A program a lemezt csak "
                           "olvassa (rendszergazdai jóváhagyás kell hozzá).")
        self.info.setObjectName("sub")
        self.info.setWordWrap(True)
        texts.addWidget(self.info)
        self.phase = QLabel("")
        self.phase.setObjectName("muted")
        self.phase.setWordWrap(True)
        texts.addWidget(self.phase)
        prog.addLayout(texts, 1)
        self.bar = theme.ProgressLine()
        self.bar.setFixedWidth(340)
        prog.addWidget(self.bar, 0, Qt.AlignBottom)
        lay.addLayout(prog)

        split = QSplitter(Qt.Horizontal)
        split.setHandleWidth(14)
        split.setChildrenCollapsible(False)
        left = theme.Card("Régi mappák és fájlok", margins=(16, 14, 16, 8), spacing=8)
        tools = QHBoxLayout()
        tools.setSpacing(8)
        self.search = QLineEdit()
        self.search.setObjectName("search")
        self.search.setPlaceholderText("Keresés név szerint (pl. follow the flow)")
        self.search.setClearButtonEnabled(True)
        self.search.textChanged.connect(lambda _t: self.filter_timer.start())
        tools.addWidget(self.search, 1)
        self.only_video = QCheckBox("Csak videók")
        self.only_video.toggled.connect(lambda _b: self.filter_timer.start())
        tools.addWidget(self.only_video)
        self.btn_none = QPushButton("Kijelölés törlése")
        self.btn_none.clicked.connect(self._clear_checks)
        tools.addWidget(self.btn_none)
        left.lay.addLayout(tools)
        self.tree = QTreeWidget()
        self.tree.setColumnCount(5)
        self.tree.setHeaderLabels([t.upper() for t in ("Név", "Méret", "Fájlok", "Állapot", "Módosítva")])
        self.tree.setAlternatingRowColors(False)
        self.tree.setUniformRowHeights(True)
        self.tree.setFrameShape(QFrame.NoFrame)
        self.tree.setItemDelegate(theme.ToneDelegate(self.tree))
        self.tree.setSelectionMode(QAbstractItemView.SingleSelection)
        theme.header_font(self.tree)
        hh = self.tree.header()
        hh.setStretchLastSection(False)
        hh.setSectionResizeMode(0, QHeaderView.Stretch)
        for c, w in ((1, 90), (2, 70), (3, 210), (4, 140)):
            hh.setSectionResizeMode(c, QHeaderView.Interactive)
            self.tree.setColumnWidth(c, w)
        self.tree.itemChanged.connect(self._item_changed)
        self.tree.currentItemChanged.connect(self._show_item)
        left.lay.addWidget(self.tree, 1)
        split.addWidget(left)

        side = theme.Card("Összesítés")
        sl = side.lay
        self.sum_label = QLabel("Még nincs beolvasott lemez.")
        self.sum_label.setWordWrap(True)
        self.sum_label.setObjectName("msg")
        sl.addWidget(self.sum_label)
        self.sel_label = QLabel("")
        self.sel_label.setWordWrap(True)
        sl.addWidget(self.sel_label)
        self.item_label = QLabel("")
        self.item_label.setWordWrap(True)
        self.item_label.setObjectName("sub")
        self.item_label.setTextInteractionFlags(Qt.TextSelectableByMouse)
        sl.addWidget(self.item_label)
        sl.addWidget(theme.heading("Napló"))
        self.log = QPlainTextEdit()
        self.log.setReadOnly(True)
        self.log.setObjectName("log")
        self.log.setPlaceholderText("Még üres.")
        sl.addWidget(self.log, 1)
        split.addWidget(side)
        split.setStretchFactor(0, 3)
        split.setStretchFactor(1, 2)
        split.setSizes([760, 420])
        lay.addWidget(split, 1)

        bottom = QHBoxLayout()
        bottom.setSpacing(10)
        self.dest_label = QLabel("Cél: nincs kiválasztva")
        self.dest_label.setObjectName("sub")
        bottom.addWidget(self.dest_label)
        self.btn_dest = QPushButton("Cél mappa…")
        self.btn_dest.setToolTip("Hová kerüljenek a visszahozott fájlok (nem lehet a sérült lemezen).")
        self.btn_dest.clicked.connect(self._pick_dest)
        bottom.addWidget(self.btn_dest)
        bottom.addStretch(1)
        self.btn_ro = QPushButton("Írásvédelem feloldása")
        self.btn_ro.setToolTip("A beolvasás írásvédetté teszi a sérült lemezt. Ha végeztél vele, itt oldhatod fel.")
        self.btn_ro.clicked.connect(self._readonly_off)
        bottom.addWidget(self.btn_ro)
        self.btn_stop = QPushButton("Leállítás")
        self.btn_stop.clicked.connect(self.stop)
        bottom.addWidget(self.btn_stop)
        self.btn_restore = theme.PrimaryButton("Visszaállítás")
        self.btn_restore.clicked.connect(self.start_restore)
        bottom.addWidget(self.btn_restore)
        lay.addLayout(bottom)
        self._refresh_buttons()
        theme.notifier.changed.connect(self._retheme)

    def _retheme(self):
        """The look changed (light / dark): texts with colours of their own are made again."""
        if self.entries:
            self._render_summary()
        self._update_dest_label()
        self.tree.viewport().update()

    # -- disks --------------------------------------------------------------------------------
    def refresh_disks(self):
        try:
            self.disks = [d for d in launch.disks() if (d.get("size") or 0) > 0]
        except Exception as e:  # noqa: BLE001
            self.disks = []
            self._log("A lemezek listázása nem sikerült: %s" % e)
        self.disk_box.blockSignals(True)
        self.disk_box.clear()
        for d in self.disks:
            label = "%s – %s, %s%s" % (
                ("Lemez %d" % d["number"]) if d.get("number") is not None else d["path"], d.get("model") or "?",
                human(d.get("size")), (" (" + " ".join(x.rstrip(":") + ":" for x in d["letters"]) + ")")
                if d.get("letters") else "")
            if d.get("system"):
                label += " – rendszerlemez"
            self.disk_box.addItem(label)
            if d.get("system"):
                it = self.disk_box.model().item(self.disk_box.count() - 1)
                it.setEnabled(False)
        self.disk_box.setCurrentIndex(-1)
        self.disk_box.blockSignals(False)
        self._refresh_buttons()
        if getattr(self, "listing_st", None):
            self._match_listing_disk()

    def _listing_fits(self, d: Optional[Dict]) -> Optional[bool]:
        """Is disk d the one the loaded list was made on? None: cannot tell (an old list)."""
        st = getattr(self, "listing_st", None) or {}
        if d is None or not st.get("disk_size"):
            return None
        if st.get("disk_serial") and d.get("serial"):
            return st["disk_serial"] == d["serial"] and st["disk_size"] == d.get("size")
        return st["disk_size"] == d.get("size")

    def _match_listing_disk(self) -> None:
        """Select the disk the loaded list was made on. The disk numbers change when the computer starts
        again or a disk is plugged in, so it goes by size and serial number; a disk with the destination
        on it cannot be the damaged one."""
        cands = [i for i, d in enumerate(self.disks) if not d.get("system") and self._listing_fits(d)]
        dn = launch.disk_of_path(self.dest) if self.dest else None
        if dn is not None:
            cands = [i for i in cands if self.disks[i].get("number") != dn]
        cur = self.disk_box.currentIndex()
        size = human((getattr(self, "listing_st", None) or {}).get("disk_size"))
        if len(cands) == 1:
            if cur != cands[0]:
                self._keep_listing = True
                try:
                    self.disk_box.setCurrentIndex(cands[0])
                finally:
                    self._keep_listing = False
                self._log("A lista erről a lemezről készült, kiválasztottam: %s" % self.disk_box.currentText())
        elif not cands:
            self._log("A lista lemeze (%s) most nincs a gépen – csatlakoztasd, majd Frissítés." % size)
        elif cur not in cands:
            self.disk_box.setCurrentIndex(-1)
            self._log("Több %s-os lemez is van a gépen: válaszd ki fent, melyik a sérült (a cél meghajtó nem "
                      "lehet rajta)." % size)

    def current_disk(self) -> Optional[Dict]:
        i = self.disk_box.currentIndex()
        return self.disks[i] if 0 <= i < len(self.disks) else None

    def _disk_changed(self, _i):
        d = self.current_disk()
        if d is None:
            return
        ld = getattr(self, "listing_dir", None)
        if self.entries and ld and os.path.exists(os.path.join(ld, launch.ENTRIES)) and \
                (getattr(self, "_keep_listing", False) or self._listing_fits(d)):
            # the loaded list belongs to this disk (possibly under another number than when it was made)
            self.work_dir = ld
            self.info.setText("Beolvasott lista: %s – ehhez a lemezhez tartozik. Pipáld ki, mit hozzak vissza, "
                              "válaszd ki a célt, majd Visszaállítás." % self.work_dir)
            self._refresh_buttons()
            return
        wd = default_work_dir(d)
        if os.path.exists(os.path.join(wd, launch.ENTRIES)) and self._listing_done(wd):
            self.work_dir = wd
            self.load_listing(wd)
            self.info.setText("Ennek a lemeznek már van beolvasott listája (%s). Újra is beolvashatod." % wd)
        else:
            self.work_dir = wd
            self.info.setText("Kattints a Beolvasásra. A lista ide kerül: %s" % wd)
        self._refresh_buttons()

    def _listing_done(self, wd: str) -> bool:
        st = launch.read_status(wd)
        if st is None:
            return True
        return st.get("state") == "done" and bool(st.get("tree"))

    # -- scan ---------------------------------------------------------------------------------
    def start_scan(self):
        d = self.current_disk()
        if d is None:
            QMessageBox.information(self, "Beolvasás", "Előbb válaszd ki a sérült lemezt.")
            return
        if d.get("system"):
            QMessageBox.warning(self, "Beolvasás", "A rendszerlemezt nem lehet kiválasztani.")
            return
        ans = QMessageBox.question(
            self, "Beolvasás",
            "A program beolvassa ezt a lemezt:\n\n%s\n\nA lemezt írásvédetté teszi és csak olvassa. Ehhez "
            "rendszergazdai jóváhagyás kell – a megjelenő ablakban kattints az Igen gombra.\n\nIndulhat?"
            % self.disk_box.currentText(), QMessageBox.Yes | QMessageBox.No)
        if ans != QMessageBox.Yes:
            return
        self.work_dir = self.work_dir or default_work_dir(d)
        job = {"device": d["path"], "output": self.work_dir, "sources": [], "mode": "scan", "protect": True}
        self._start(job, "scan")

    def _open_previous(self):
        start = os.path.join(os.path.expanduser("~"), "Documents", "FutureRepair")
        p = QFileDialog.getExistingDirectory(self, "Munkamappa (benne a futurerepair_lemez_bejegyzesek.json)",
                                             start if os.path.isdir(start) else "")
        if not p:
            return
        if not os.path.exists(os.path.join(p, launch.ENTRIES)):
            QMessageBox.warning(self, "Korábbi beolvasás", "Ebben a mappában nincs beolvasott lista.")
            return
        self.work_dir = p
        self.load_listing(p)

    # -- the listing --------------------------------------------------------------------------
    def load_listing(self, wd: str):
        try:
            with open(os.path.join(wd, launch.ENTRIES), encoding="utf-8") as f:
                data = json.load(f)
        except (OSError, ValueError) as e:
            QMessageBox.warning(self, "Lista", "A lista nem olvasható: %s" % e)
            return
        self.entries = [e for e in data.get("entries", []) if not e.get("deleted")]
        self.summary = data.get("summary") or {}
        self._build_tree()
        st = launch.read_status(wd) or {}
        self.device_of_listing = (st.get("device") or (st.get("job") or {}).get("device"))
        self.listing_st = {k: st.get(k) for k in ("disk_size", "disk_serial", "disk_model", "partitions", "device")}
        self.listing_dir = wd
        self._render_summary()
        self._log("Lista betöltve: %s" % wd)
        self.info.setText("Beolvasott lista: %s – pipáld ki, mit hozzak vissza, válaszd ki a célt, majd "
                          "Visszaállítás." % wd)
        if not getattr(self, "_keep_listing", False):
            self._match_listing_disk()
        self._refresh_buttons()

    def _render_summary(self):
        files = [e for e in self.entries if not e["dir"] and e["size"] > 0]
        vids = [e for e in files if os.path.splitext(e["name"])[1].lower() in VIDEO_INDEX | {".mxf", ".braw"}]
        good = [e for e in files if file_status(e)[2]]
        self.sum_label.setText(
            "<b>%d fájl, %s</b> a régi mappákban<br>videó: %d db, %s<br>visszahozható: %d fájl, %s<br>"
            "<span style='color:%s'>%s</span>" % (
                len(files), human(sum(e["size"] for e in files)), len(vids), human(sum(e["size"] for e in vids)),
                len(good), human(sum(e["size"] for e in good)), theme.tone("muted"),
                "A régi felső mappa(k) neve elveszett: „Ismeretlen nevű mappa” néven szerepel(nek)."))

    def _build_tree(self):
        self._building = True
        self.tree.setUpdatesEnabled(False)
        self.tree.clear()
        self.file_items = {}
        folders: Dict[str, QTreeWidgetItem] = {}
        stats: Dict[str, List[int]] = {}
        flags = Qt.ItemIsEnabled | Qt.ItemIsSelectable | Qt.ItemIsUserCheckable
        files = sorted((e for e in self.entries if not e["dir"] and e["size"] > 0 and e.get("path")),
                       key=lambda e: e["path"].lower())

        def folder(path: str) -> QTreeWidgetItem:
            it = folders.get(path)
            if it is not None:
                return it
            parent_path, _, name = path.rpartition("/")
            parent = folder(parent_path) if parent_path else None
            it = QTreeWidgetItem([display_name(name), "", "", "", ""])
            it.setFlags(flags | Qt.ItemIsAutoTristate)
            it.setCheckState(0, Qt.Unchecked)
            it.setData(0, ROLE_PATH, path)
            it.setData(0, ROLE_ENTRY, None)
            stats[path] = [0, 0, 0, 0]          # files, bytes, will come back, will not
            (parent.addChild(it) if parent is not None else self.tree.addTopLevelItem(it))
            folders[path] = it
            return it
        for e in files:
            parent_path = e["path"].rpartition("/")[0]
            parent = folder(parent_path) if parent_path else None
            text, tone, ok = file_status(e)
            it = QTreeWidgetItem([e["name"], human(e["size"]), "", text, (e.get("mtime") or "")[:16]])
            it.setFlags(flags)
            it.setCheckState(0, Qt.Unchecked)
            it.setData(0, ROLE_ENTRY, e)
            it.setData(3, theme.ROLE_TONE, tone)
            it.setTextAlignment(1, Qt.AlignRight | Qt.AlignVCenter)
            (parent.addChild(it) if parent is not None else self.tree.addTopLevelItem(it))
            self.file_items[e["path"]] = it
            pp = parent_path
            while pp:
                st = stats[pp]
                st[0] += 1
                st[1] += e["size"]
                st[2 if ok else 3] += 1
                pp = pp.rpartition("/")[0]
        for path, it in folders.items():
            n, b, good, bad = stats[path]
            it.setData(0, ROLE_STAT, [n, b, good, bad])
            it.setText(1, human(b))
            it.setText(2, str(n))
            it.setText(3, "mind visszahozható" if not bad else "%d nem hozható vissza" % bad)
            it.setData(3, theme.ROLE_TONE, "ok" if not bad else "warn")
            it.setTextAlignment(1, Qt.AlignRight | Qt.AlignVCenter)
            it.setTextAlignment(2, Qt.AlignRight | Qt.AlignVCenter)
        self.tree.sortItems(0, Qt.AscendingOrder)
        for i in range(self.tree.topLevelItemCount()):
            self.tree.topLevelItem(i).setExpanded(True)
        self.tree.setUpdatesEnabled(True)
        self._building = False
        self._update_selection()

    def _iter_files(self, item: Optional[QTreeWidgetItem] = None):
        stack = [item] if item is not None else [self.tree.topLevelItem(i) for i in range(self.tree.topLevelItemCount())]
        while stack:
            it = stack.pop()
            e = it.data(0, ROLE_ENTRY)
            if e is not None:
                yield it, e
            for j in range(it.childCount()):
                stack.append(it.child(j))

    def checked(self) -> List[Dict]:
        return [e for it, e in self._iter_files() if it.checkState(0) == Qt.Checked]

    def _item_changed(self, _it, col):
        if col == 0 and not self._building:
            self.sel_timer.start()

    def _clear_checks(self):
        self._building = True
        for i in range(self.tree.topLevelItemCount()):
            self.tree.topLevelItem(i).setCheckState(0, Qt.Unchecked)
        self._building = False
        self._update_selection()

    def _update_selection(self):
        sel = self.checked()
        if not sel:
            self.sel_label.setText("Pipáld ki a visszahozandó mappákat vagy fájlokat.")
        else:
            kinds: Dict[str, List[int]] = {}
            for e in sel:
                t = file_status(e)[0]
                k = kinds.setdefault(t, [0, 0])
                k[0] += 1
                k[1] += e["size"]
            lines = ["<b>Kijelölve: %d fájl, %s</b>" % (len(sel), human(sum(e["size"] for e in sel)))]
            for t, (n, b) in sorted(kinds.items(), key=lambda kv: -kv[1][1]):
                lines.append("%s: %d db, %s" % (t, n, human(b)))
            self.sel_label.setText("<br>".join(lines))
        self._update_dest_label()
        self._refresh_buttons()

    def _show_item(self, it, _prev):
        if it is None:
            self.item_label.setText("")
            return
        e = it.data(0, ROLE_ENTRY)
        if e is None:
            n, b, good, bad = it.data(0, ROLE_STAT) or [0, 0, 0, 0]
            self.item_label.setText("%s<br>%d fájl, %s; visszahozható %d, nem %d" % (
                it.data(0, ROLE_PATH), n, human(b), good, bad))
            return
        text, _c, _ok = file_status(e)
        how = {"Egy darabban": "a fájl egyben van a lemezen, bájtra pontosan visszajön.",
               "Összerakható (videóindex)": "darabokban van; a saját tartalomjegyzéke alapján rakja össze, "
                                            "minden darabot ellenőrizve.",
               "Összerakható (MXF)": "darabokban van; az MXF csomagláncát követve rakja össze.",
               "Összerakható (hang)": "darabokban van; a hang folytonossága alapján rakja össze (meghallgatandó).",
               "Összerakható (BRAW, ellenőrizendő)": "darabokban van; a tartalomjegyzéke alapján rakja össze, "
                                                     "a képkockák fejlécét ellenőrizve – DaVinciben nézd meg.",
               "Felülíródhatott": "a lemez elején van, ahová a formázás után írtak – lehet, hogy sérült.",
               "Darabolt – nem támogatott": "darabokban van, és ezt a fajtát a program még nem rakja össze."
               }.get(text, "")
        self.item_label.setText("%s<br>%s, %s<br>%s" % (e["path"], human(e["size"]), text, how))

    def _apply_filter(self):
        q = self.search.text().strip().lower()
        vid = self.only_video.isChecked()
        vexts = VIDEO_INDEX | {".mxf", ".braw", ".r3d", ".mts", ".avi", ".mkv"}

        def visit(it, parent_match: bool) -> bool:
            e = it.data(0, ROLE_ENTRY)
            own = (not q) or (q in it.text(0).lower())
            if e is not None:
                show = (own or parent_match) and (not vid or os.path.splitext(e["name"])[1].lower() in vexts)
                it.setHidden(not show)
                return show
            any_child = False
            for j in range(it.childCount()):
                any_child |= visit(it.child(j), parent_match or (bool(q) and own))
            show = any_child or (own and bool(q) and not vid)
            it.setHidden(not show)
            if q and any_child:
                it.setExpanded(True)
            return show
        self.tree.setUpdatesEnabled(False)
        for i in range(self.tree.topLevelItemCount()):
            visit(self.tree.topLevelItem(i), False)
        self.tree.setUpdatesEnabled(True)

    # -- restore ------------------------------------------------------------------------------
    def _pick_dest(self):
        p = QFileDialog.getExistingDirectory(self, "Hová kerüljenek a visszahozott fájlok?", self.dest or "")
        if not p:
            return
        d = self.current_disk()
        dn = launch.disk_of_path(p)
        if d is not None and dn is not None and dn == d.get("number"):
            QMessageBox.warning(self, "Cél mappa", "Ez a sérült lemezen van – válassz másik meghajtót!")
            return
        self.dest = p
        self._update_dest_label()
        if getattr(self, "listing_st", None) and not self._listing_fits(self.current_disk()):
            self._match_listing_disk()
        self._refresh_buttons()

    def _update_dest_label(self):
        if not self.dest:
            self.dest_label.setText("Cél: nincs kiválasztva")
            return
        try:
            free = shutil.disk_usage(self.dest).free
        except OSError:
            free = 0
        need = sum(e["size"] for e in self.checked())
        warn = need > free
        self.dest_label.setText("Cél: %s – szabad: %s%s" % (
            self.dest, human(free), ("  <span style='color:%s'>(kevés a hely: %s kell)</span>"
                                     % (theme.tone("bad"), human(need)))
            if warn else ""))

    def start_restore(self):
        sel = self.checked()
        d = self.current_disk()
        if not sel:
            QMessageBox.information(self, "Visszaállítás", "Pipáld ki, mit hozzak vissza.")
            return
        if not self.dest:
            self._pick_dest()
            if not self.dest:
                return
        # always the disk selected above: the number the list was made with may belong to another disk by now
        if d is None:
            QMessageBox.information(self, "Visszaállítás", "Válaszd ki fent a sérült lemezt.")
            return
        if self._listing_fits(d) is False:
            st = getattr(self, "listing_st", None) or {}
            QMessageBox.warning(self, "Visszaállítás",
                                "A kiválasztott lemez (%s) nem az, amelyikről a lista készült (a lista lemeze %s%s).\n\n"
                                "Válaszd ki fent a sérült lemezt." % (
                                    self.disk_box.currentText(), human(st.get("disk_size")),
                                    (", " + st["disk_model"]) if st.get("disk_model") else ""))
            return
        dn = launch.disk_of_path(self.dest)
        if dn is not None and dn == d.get("number"):
            QMessageBox.warning(self, "Visszaállítás", "A cél a sérült lemezen van – válassz másik meghajtót!")
            return
        ld = getattr(self, "listing_dir", None) or self.work_dir
        if not ld or not os.path.exists(os.path.join(ld, launch.ENTRIES)):
            QMessageBox.warning(self, "Visszaállítás", "Nincs betöltve a lemez listája – Korábbi beolvasás… vagy "
                                                       "Beolvasás.")
            return
        device = d["path"]
        need = sum(e["size"] for e in sel)
        try:
            free = shutil.disk_usage(self.dest).free
        except OSError:
            free = 0
        txt = "%d fájl, %s kerül ide:\n%s\n\nSzabad hely: %s." % (len(sel), human(need), self.dest, human(free))
        if need > free:
            txt += "\n\nNincs elég hely! A program ott áll meg, ahol elfogy."
        txt += "\n\nA lemezt a program csak olvassa. Rendszergazdai jóváhagyás kell. Indulhat?"
        if QMessageBox.question(self, "Visszaállítás", txt, QMessageBox.Yes | QMessageBox.No) != QMessageBox.Yes:
            return
        job = {"device": device, "output": self.dest, "sources": [os.path.join(ld, launch.ENTRIES)],
               "mode": "entries", "paths": [e["path"] for e in sel], "protect": True}
        self._start(job, "restore")

    # -- running jobs -------------------------------------------------------------------------
    def _start(self, job: Dict, kind: str):
        try:
            launch.start_job(job)
        except Exception as e:  # noqa: BLE001
            QMessageBox.warning(self, "Indítás", str(e))
            return
        self.job_out = job["output"]
        self.job_kind = kind
        self.job_started = time.time()
        self._seen_log = 0
        self._marked = {}
        self._status_sig = None
        self.bar.setRange(0, 0)
        self.phase.setText("Várakozás a rendszergazdai jóváhagyásra…")
        self._log("Elindítva: %s → %s" % ({"scan": "beolvasás", "restore": "visszaállítás"}[kind], self.job_out))
        self.timer.start()
        self._refresh_buttons()

    def stop(self):
        if self.job_out:
            launch.stop_job(self.job_out)
            self.phase.setText("Leállítás kérve – a futó lépés végén áll meg.")

    def _poll(self):
        if not self.job_out:
            self.timer.stop()
            return
        # the state file holds every file's result (megabytes with thousands of files): read it only when it changed
        try:
            sp = os.stat(os.path.join(self.job_out, launch.STATUS))
            sig = (sp.st_mtime_ns, sp.st_size)
        except OSError:
            sig = None
        if sig is not None and sig == getattr(self, "_status_sig", None):
            return
        st = launch.read_status(self.job_out)
        self._status_sig = sig
        if st is None or (st.get("updated") or 0) < self.job_started - 5:
            if time.time() - self.job_started > 180:
                self.phase.setText("Nem indult el – a rendszergazdai jóváhagyás elmaradt? Indítsd újra.")
                self.bar.setRange(0, 1)
                self.bar.setValue(0)
                self.timer.stop()
                self.job_out = None
                self._refresh_buttons()
            return
        logs = st.get("log") or []
        seen = getattr(self, "_seen_log", 0)
        total = st.get("log_n")
        if total is None:                       # a worker from before 1.5.4: only the list's length
            total = len(logs)
        if total < seen:
            seen = 0
        new = total - seen
        if new > len(logs):
            self._log("… (%d korábbi sor kimaradt)" % (new - len(logs)))
            new = len(logs)
        for line in (logs[-new:] if new > 0 else []):
            self._log(line)
        self._seen_log = total
        state = st.get("state")
        p = float(st.get("progress") or 0)
        ov = st.get("overall")
        if self.job_kind == "restore" and ov and ov.get("bytes_total"):
            files = st.get("files") or []
            done = ov.get("bytes_done") or 0
            cur = st.get("current") or {}
            if state == "running" and len(files) < ov.get("files_total", 0):
                done += p * (cur.get("size") or 0)
            frac = min(1.0, done / float(ov["bytes_total"]))
            self.bar.setRange(0, 1000)
            self.bar.setValue(int(frac * 1000))
            self.bar.setFormat("%d / %d fájl  ·  %s / %s" % (ov.get("files_done", 0), ov.get("files_total", 0),
                                                             human(done), human(ov["bytes_total"])))
            self._mark_results(files)
            text = (st.get("phase") or "") + ("  (%d%%)" % int(p * 100) if state == "running" else "")
            if state == "running" and st.get("detail"):
                det = st["detail"]
                nm = (st.get("current") or {}).get("name") or ""
                if nm and det.startswith(nm + ": "):
                    det = det[len(nm) + 2:]
                text += "  –  " + det
            self.phase.setText(text)
        else:
            self.bar.setRange(0, 1000)
            self.bar.setValue(int(p * 1000))
            self.bar.setFormat("%d%%" % int(p * 100))
            self.phase.setText(st.get("phase") or "")
        if state in ("done", "error", "cancelled"):
            self.timer.stop()
            kind, out = self.job_kind, self.job_out
            self.job_out = None
            self._refresh_buttons()
            if state == "error":
                self.phase.setText("Hiba: %s" % st.get("error"))
                QMessageBox.warning(self, "Hiba", st.get("error") or "Ismeretlen hiba.")
            elif state == "cancelled":
                self.phase.setText("Leállítva. Újraindítva onnan folytatja, ahol abbahagyta.")
            elif kind == "scan":
                self.phase.setText("Beolvasás kész.")
                self.load_listing(out)
            else:
                self._restore_done(st, out)

    def _mark_results(self, files: List[Dict]):
        tones = {"complete": "ok", "check": "warn", "partial": "bad", "no_index": "bad", "failed": "bad",
                 "error": "bad", "skipped": "muted"}
        texts = {"complete": "Visszahozva", "check": "Visszahozva – ellenőrizd", "partial": "Nem sikerült",
                 "no_index": "Nem sikerült", "failed": "Nem sikerült", "error": "Hiba", "skipped": "Kihagyva"}
        marked = getattr(self, "_marked", None)
        if marked is None:
            marked = self._marked = {}
        for r in files:
            path = r.get("path") or ""
            stt = r.get("state")
            key = (stt, r.get("message"))
            if marked.get(path) == key:          # only what changed: thousands of rows every second freeze the window
                continue
            it = self.file_items.get(path)
            if it is None:
                continue
            marked[path] = key
            it.setText(3, texts.get(stt, stt or ""))
            it.setData(3, theme.ROLE_TONE, tones.get(stt))
            it.setToolTip(3, r.get("message") or "")

    def _restore_done(self, st: Dict, out: str):
        sm = st.get("summary") or {}
        self._mark_results(st.get("files") or [])
        self.phase.setText("Kész: %d rendben, %d ellenőrizendő, %d nem sikerült, %d kihagyva." % (
            sm.get("complete", 0), sm.get("check", 0), sm.get("partial", 0), sm.get("skipped", 0)))
        box = QMessageBox(self)
        box.setWindowTitle("Visszaállítás kész")
        box.setText(self.phase.text())
        open_btn = box.addButton("Mappa megnyitása", QMessageBox.AcceptRole)
        box.addButton("Bezárás", QMessageBox.RejectRole)
        box.exec()
        if box.clickedButton() is open_btn:
            QDesktopServices.openUrl(QUrl.fromLocalFile(out))

    def _readonly_off(self):
        d = self.current_disk()
        if d is None or d.get("number") is None:
            QMessageBox.information(self, "Írásvédelem", "Válaszd ki fent a lemezt.")
            return
        if QMessageBox.question(self, "Írásvédelem feloldása",
                                "Feloldod a(z) %s írásvédelmét?\n\nCsak akkor tedd, ha már minden fájlt "
                                "visszahoztál: ha bármi írni kezd rá, a még ott lévő régi adatok elveszhetnek."
                                % self.disk_box.currentText(), QMessageBox.Yes | QMessageBox.No) != QMessageBox.Yes:
            return
        try:
            r = launch.set_readonly(int(d["number"]), False)
        except Exception as e:  # noqa: BLE001
            r = {"ok": False, "error": str(e)}
        if r.get("ok"):
            QMessageBox.information(self, "Írásvédelem", "Az írásvédelem feloldva.")
        else:
            QMessageBox.warning(self, "Írásvédelem", r.get("error") or "Nem sikerült.")

    # -- helpers ------------------------------------------------------------------------------
    def _log(self, line: str):
        self.log.appendPlainText(line)

    def _refresh_buttons(self):
        busy = self.job_out is not None
        have_disk = self.current_disk() is not None
        self.btn_scan.setEnabled(not busy and have_disk)
        self.btn_refresh.setEnabled(not busy)
        self.btn_open.setEnabled(not busy)
        self.disk_box.setEnabled(not busy)
        self.btn_restore.setEnabled(not busy and bool(self.entries))
        self.btn_dest.setEnabled(not busy)
        self.btn_stop.setEnabled(busy)
        self.btn_ro.setEnabled(not busy and have_disk and sys.platform.startswith("win"))

    def busy(self) -> bool:
        return self.job_out is not None
