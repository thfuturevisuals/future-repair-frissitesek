"""Photo repair: JPEG (truncated / damaged header / leading garbage) and RAW preview rescue."""
from __future__ import annotations

import io
import os
from typing import List, Optional, Tuple

from ..result import RepairResult, Reporter

RAW_EXT = {".cr2", ".cr3", ".crw", ".nef", ".nrw", ".arw", ".srf", ".sr2", ".dng", ".raf", ".orf",
           ".rw2", ".pef", ".srw", ".3fr", ".iiq", ".erf", ".mrw", ".x3f", ".kdc", ".dcr", ".mos", ".rwl"}
JPEG_EXT = {".jpg", ".jpeg", ".jpe", ".jfif"}

SOI = b"\xff\xd8"
EOI = b"\xff\xd9"


def _pil():
    from PIL import Image, ImageFile
    return Image, ImageFile


# ---------------------------------------------------------------------------
# JPEG structure
# ---------------------------------------------------------------------------

def parse_jpeg(data: bytes, start: int = 0):
    """Walk JPEG marker segments from an SOI at `start`.

    Returns dict(header_end, scan_start, end, has_sof, has_dqt, has_dht, segments) where
    header_end is the end of the last SOS header, end is the position after EOI (or -1).
    """
    info = {"header_end": -1, "scan_start": -1, "end": -1, "has_sof": False, "has_dqt": False,
            "has_dht": False, "segments": [], "width": 0, "height": 0, "broken_at": -1}
    n = len(data)
    if data[start:start + 2] != SOI:
        return info
    p = start + 2
    while p + 2 <= n:
        if data[p] != 0xFF:
            info["broken_at"] = p
            return info
        m = data[p + 1]
        if m == 0xFF:        # fill byte
            p += 1
            continue
        if m in (0xD8, 0x01) or 0xD0 <= m <= 0xD7:
            p += 2
            continue
        if m == 0xD9:
            info["end"] = p + 2
            return info
        if p + 4 > n:
            info["broken_at"] = p
            return info
        ln = int.from_bytes(data[p + 2:p + 4], "big")
        if ln < 2 or p + 2 + ln > n:
            info["broken_at"] = p
            return info
        info["segments"].append((m, p, ln + 2))
        if m in (0xC0, 0xC1, 0xC2, 0xC3, 0xC5, 0xC6, 0xC7, 0xC9, 0xCA, 0xCB, 0xCD, 0xCE, 0xCF):
            info["has_sof"] = True
            if ln >= 7:
                info["height"] = int.from_bytes(data[p + 5:p + 7], "big")
                info["width"] = int.from_bytes(data[p + 7:p + 9], "big")
        elif m == 0xDB:
            info["has_dqt"] = True
        elif m == 0xC4:
            info["has_dht"] = True
        if m == 0xDA:
            info["header_end"] = p + 2 + ln
            info["scan_start"] = p + 2 + ln
            # skip entropy-coded data: stop at a marker that is not stuffing / RST
            q = p + 2 + ln
            while True:
                q = data.find(b"\xff", q)
                if q < 0 or q + 1 >= n:
                    return info          # truncated scan
                b = data[q + 1]
                if b == 0x00 or 0xD0 <= b <= 0xD7 or b == 0xFF:
                    q += 1 if b == 0xFF else 2
                    continue
                break
            p = q
            continue
        p += 2 + ln
    return info


def find_embedded_jpegs(data: bytes, min_size: int = 2048) -> List[Tuple[int, int, int, int]]:
    """All complete JPEG streams inside `data`: (start, end, width, height), largest first."""
    out = []
    i = data.find(b"\xff\xd8\xff")
    seen_end = -1
    while i != -1:
        info = parse_jpeg(data, i)
        if info["end"] > 0 and info["has_sof"] and info["end"] - i >= min_size:
            out.append((i, info["end"], info["width"], info["height"]))
            seen_end = max(seen_end, info["end"])
        i = data.find(b"\xff\xd8\xff", i + 3)
    # de-duplicate nested ones (thumbnails inside APP1 are separate valid streams - keep all)
    out.sort(key=lambda t: (t[2] * t[3], t[1] - t[0]), reverse=True)
    return out


def _decode_ok(blob: bytes, allow_truncated: bool = True):
    Image, ImageFile = _pil()
    old = ImageFile.LOAD_TRUNCATED_IMAGES
    ImageFile.LOAD_TRUNCATED_IMAGES = allow_truncated
    try:
        im = Image.open(io.BytesIO(blob))
        im.load()
        return im
    except Exception:  # noqa: BLE001
        return None
    finally:
        ImageFile.LOAD_TRUNCATED_IMAGES = old


def _gray_fraction(im) -> float:
    """Share of the bottom rows that are the flat gray libjpeg uses for missing data."""
    try:
        small = im.convert("L").resize((64, 64))
        px = list(small.getdata())
        rows = [px[r * 64:(r + 1) * 64] for r in range(64)]
        flat = 0
        for r in reversed(rows):
            if max(r) - min(r) <= 2 and 120 <= r[0] <= 136:
                flat += 1
            else:
                break
        return flat / 64.0
    except Exception:  # noqa: BLE001
        return 0.0


def _out_path(src: str, suffix: str, ext: Optional[str] = None) -> str:
    base, e = os.path.splitext(src)
    e = ext or e
    out = base + suffix + e
    i = 2
    while os.path.exists(out):
        out = "%s%s_%d%s" % (base, suffix, i, e)
        i += 1
    return out


def _save_preview(im) -> str:
    import tempfile
    d = os.path.join(tempfile.gettempdir(), "futurerepair_previews")
    os.makedirs(d, exist_ok=True)
    p = os.path.join(d, "kep_%d.jpg" % (abs(hash(id(im))) % 10 ** 8))
    th = im.copy()
    th.thumbnail((960, 960))
    th.convert("RGB").save(p, quality=85)
    return p


def repair_jpeg(path: str, reference: Optional[str], out_path: Optional[str], rep: Reporter) -> RepairResult:
    with open(path, "rb") as f:
        data = f.read()
    if not data.strip(b"\x00") or not data.strip(b"\xff"):
        return RepairResult("failed", None, "A fájl tartalma üres (csupa 00 vagy FF bájt) – nincs mit visszaállítani.")
    out_path = out_path or _out_path(path, "_javitott")
    start = data.find(b"\xff\xd8\xff")
    candidates: List[Tuple[str, bytes]] = []
    info = parse_jpeg(data, start) if start >= 0 else None

    if start > 0:
        rep.log("A JPEG eleje %d bájttal később kezdődik – a szemetet levágom." % start)
    if info and info["header_end"] > 0 and info["has_sof"] and info["has_dqt"]:
        body = data[start:info["end"]] if info["end"] > 0 else data[start:].rstrip(b"\x00") + EOI
        candidates.append(("own_header", body))
    if reference:
        with open(reference, "rb") as f:
            ref = f.read()
        rs = ref.find(b"\xff\xd8\xff")
        rinfo = parse_jpeg(ref, rs) if rs >= 0 else None
        if not rinfo or rinfo["header_end"] < 0:
            rep.warn("A mintafájl nem ép JPEG, nem tudom használni.")
        else:
            header = ref[rs:rinfo["header_end"]]
            # scan data of the broken file: after its own last SOS if present, else same offset as reference
            scan = -1
            k = data.rfind(b"\xff\xda")
            while k != -1:
                ln = int.from_bytes(data[k + 2:k + 4], "big")
                if 6 <= ln <= 20:
                    scan = k + 2 + ln
                    break
                k = data.rfind(b"\xff\xda", 0, k)
            offsets = [scan] if scan > 0 else []
            offsets.append(rinfo["header_end"] - rs)
            for off in offsets:
                if 0 < off < len(data):
                    tail = data[off:]
                    e = tail.rfind(EOI)
                    tail = tail[:e] if e > len(tail) // 2 else tail.rstrip(b"\x00")
                    candidates.append(("ref_header@%d" % off, header + tail + EOI))
    if not candidates and start >= 0:
        candidates.append(("raw", data[start:].rstrip(b"\x00") + EOI))

    best = None
    for name, blob in candidates:
        im = _decode_ok(blob)
        if im is None:
            rep.log("Próba (%s): nem dekódolható" % name)
            continue
        gray = _gray_fraction(im)
        rep.log("Próba (%s): %dx%d, hiányzó rész ~%d%%" % (name, im.width, im.height, gray * 100))
        score = (1 - gray) * im.width * im.height
        if best is None or score > best[0]:
            best = (score, name, blob, im, gray)

    if best is None:
        # last resort: embedded preview / thumbnail
        emb = find_embedded_jpegs(data)
        for s, e, w, h in emb:
            im = _decode_ok(data[s:e], allow_truncated=False)
            if im is not None:
                po = _out_path(path, "_elonezet", ".jpg")
                with open(po, "wb") as f:
                    f.write(data[s:e])
                res = RepairResult("partial", po, "A fő képet nem lehetett megmenteni, de a beágyazott "
                                   "%dx%d-es előnézetet kimentettem." % (im.width, im.height))
                res.preview = _save_preview(im)
                return res
        return RepairResult("failed", None, "A képet nem sikerült helyreállítani. "
                            "Próbáld meg egy ugyanazzal a géppel, ugyanabban a méretben készült ép JPEG mintával.")

    score, name, blob, im, gray = best
    if (name == "own_header" and start == 0 and info and info["end"] > 0 and gray < 0.02
            and _decode_ok(data[:info["end"]], allow_truncated=False) is not None):
        res = RepairResult("intact", None, "A kép ép, nem találtam benne hibát (%dx%d)." % (im.width, im.height))
        res.preview = _save_preview(im)
        return res
    with open(out_path, "wb") as f:
        f.write(blob)
    status = "ok" if gray < 0.02 else "partial"
    msg = "A kép helyreállítva (%dx%d)." % (im.width, im.height)
    if status == "partial":
        msg += " A kép alsó ~%d%%-a hiányzik a fájlból (szürke)." % round(gray * 100)
    if name.startswith("ref_header"):
        msg += " A fejlécet a mintafájlból pótoltam."
    res = RepairResult(status, out_path, msg, details={"width": im.width, "height": im.height,
                                                     "missing_fraction": round(gray, 3), "method": name})
    res.preview = _save_preview(im)
    return res


def repair_raw(path: str, out_path: Optional[str], rep: Reporter) -> RepairResult:
    with open(path, "rb") as f:
        data = f.read()
    emb = find_embedded_jpegs(data, min_size=16 * 1024)
    rep.log("Beágyazott JPEG-ek: %s" % [(w, h, e - s) for s, e, w, h in emb[:6]])
    for s, e, w, h in emb:
        im = _decode_ok(data[s:e], allow_truncated=False)
        if im is None:
            continue
        po = out_path or _out_path(path, "_elonezet", ".jpg")
        with open(po, "wb") as f:
            f.write(data[s:e])
        res = RepairResult("partial", po,
                           "A RAW fájlból kimentettem a beágyazott %dx%d-es JPEG képet. "
                           "(Maga a RAW adat nem javítható, de ez a kép a fényképezőgép által "
                           "készített teljes értékű előnézet.)" % (im.width, im.height),
                           details={"width": im.width, "height": im.height})
        res.preview = _save_preview(im)
        return res
    # truncated embedded JPEG: try to salvage the largest partial one
    i = data.find(b"\xff\xd8\xff")
    best = None
    while i != -1:
        info = parse_jpeg(data, i)
        if info["header_end"] > 0 and info["end"] < 0 and info["width"] * info["height"] > 0:
            im = _decode_ok(data[i:] + EOI)
            if im is not None and (best is None or im.width * im.height > best[1].width * best[1].height):
                best = (i, im)
        i = data.find(b"\xff\xd8\xff", i + 3)
    if best is not None:
        po = out_path or _out_path(path, "_elonezet", ".jpg")
        best[1].convert("RGB").save(po, quality=95)
        res = RepairResult("partial", po, "A RAW fájlból egy részleges előnézetet tudtam kimenteni.")
        res.preview = _save_preview(best[1])
        return res
    return RepairResult("failed", None, "Ebben a RAW fájlban nem találtam menthető képet.")


def repair_photo(path: str, reference: Optional[str] = None, out_path: Optional[str] = None,
                 reporter: Optional[Reporter] = None, **_kw) -> RepairResult:
    rep = reporter or Reporter()
    ext = os.path.splitext(path)[1].lower()
    try:
        if ext in RAW_EXT:
            res = repair_raw(path, out_path, rep)
        else:
            res = repair_jpeg(path, reference, out_path, rep)
    except MemoryError:
        res = RepairResult("failed", None, "A fájl túl nagy a memóriához.")
    res.log = rep.lines
    res.warnings = rep.warnings
    res.notes = rep.notes
    return res
