"""Where the program lives.

    BASE_DIR   the "app" folder that came with the installer: the starter FutureRepair.py, the code
               shipped with the installer (futurerepair/), and frissitesek/ with installed updates
    CODE_DIR   the folder whose code this process runs: BASE_DIR, or BASE_DIR/frissitesek/<version>
    ROOT       the folder above BASE_DIR (Windows: the install folder with FutureRepair.exe and the
               runtime; macOS: FutureRepair.app/Contents/Resources)

Anything that starts the program again (the window, Claude's connection) goes through the starter in
BASE_DIR, so it always gets the newest installed version. A disk recovery worker is started from
CODE_DIR instead, so it keeps the exact code of the version that planned the job.
"""
from __future__ import annotations

import os
import sys
from typing import List, Optional

CODE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
UPDATES = "frissitesek"


def _base() -> str:
    if os.path.basename(os.path.dirname(CODE_DIR)) == UPDATES:
        return os.path.dirname(os.path.dirname(CODE_DIR))
    return CODE_DIR


BASE_DIR = _base()
ROOT = os.path.dirname(BASE_DIR)
STARTER = os.path.join(BASE_DIR, "FutureRepair.py")


def is_update() -> bool:
    return CODE_DIR != BASE_DIR


def windows_exe() -> Optional[str]:
    exe = os.path.join(ROOT, "FutureRepair.exe")
    return exe if sys.platform.startswith("win") and os.path.exists(exe) else None


def mac_bundle() -> Optional[str]:
    if sys.platform != "darwin":
        return None
    b = os.path.dirname(os.path.dirname(ROOT))                 # .../FutureRepair.app
    return b if b.endswith(".app") and os.path.isdir(b) else None


def console_python() -> str:
    """A Python that has standard input/output (Windows: python.exe, not pythonw.exe)."""
    exe = sys.executable
    if sys.platform.startswith("win"):
        py = os.path.join(os.path.dirname(exe), "python.exe")
        if os.path.exists(py):
            return py
    return exe


def window_python() -> str:
    """The Python for a windowed start (Windows: pythonw.exe, no console window)."""
    if sys.platform.startswith("win"):
        pyw = os.path.join(os.path.dirname(sys.executable), "pythonw.exe")
        if os.path.exists(pyw):
            return pyw
    return sys.executable


def app_command(paths: Optional[List[str]] = None) -> List[str]:
    """Command that opens the desktop window with the newest installed version."""
    paths = list(paths or [])
    bundle = mac_bundle()
    if bundle:
        return ["open", "-n", bundle] + (["--args"] + paths if paths else [])
    exe = windows_exe()
    if exe:
        return [exe] + paths
    return [window_python(), "-E", "-s", STARTER] + paths
