"""Starting and watching disk jobs from the program (the disk is read with administrator rights,
in a separate process that writes its progress into the job's output folder)."""
from __future__ import annotations

import json
import os
import re
import shlex
import subprocess
import sys
import tempfile
import time
import uuid
from typing import Dict, List, Optional

STATUS = "futurerepair_lemez_allapot.json"
JOB = "futurerepair_lemez_feladat.json"
STOP = "futurerepair_lemez_STOP"
ENTRIES = "futurerepair_lemez_bejegyzesek.json"


def app_dir() -> str:
    return os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


def _python() -> str:
    if sys.platform.startswith("win"):
        pyw = os.path.join(os.path.dirname(sys.executable), "pythonw.exe")
        return pyw if os.path.exists(pyw) else sys.executable
    return sys.executable


def disks() -> List[Dict]:
    from .raw import list_disks
    out = list_disks()
    letters, sysd = {}, None
    if sys.platform.startswith("win"):
        from . import winsys
        try:
            letters = winsys.letters_by_disk()
            sysd = winsys.system_disk()
        except Exception:  # noqa: BLE001
            pass
    for d in out:
        d["letters"] = letters.get(d.get("number"), [])
        d["system"] = sysd is not None and d.get("number") == sysd
    return out


def disk_of_path(path: str) -> Optional[int]:
    """Physical disk number that holds `path` (Windows), or None."""
    if not sys.platform.startswith("win"):
        return None
    drv = os.path.splitdrive(os.path.abspath(path))[0]
    if not re.fullmatch(r"[A-Za-z]:", drv or ""):
        return None
    from . import winsys
    try:
        return winsys.disk_number_of_letter(drv[0])
    except Exception:  # noqa: BLE001
        return None


def _elevated(args: List[str]) -> None:
    """Run FutureRepair.py with `args` as administrator, in the background."""
    script = os.path.join(app_dir(), "FutureRepair.py")
    exe = _python()
    if sys.platform.startswith("win"):
        from . import winsys
        rc = winsys.launch_elevated(exe, ["-E", "-s", script] + args, cwd=app_dir())
        if rc <= 32:
            raise RuntimeError("A rendszergazdai indítást elutasították vagy nem sikerült (kód: %d)." % rc)
        return
    cmd = " ".join(shlex.quote(a) for a in [exe, "-E", "-s", script] + args) + " >/dev/null 2>&1 &"
    if sys.platform == "darwin":
        osa = 'do shell script "%s" with administrator privileges' % cmd.replace("\\", "\\\\").replace('"', '\\"')
        r = subprocess.run(["osascript", "-e", osa], capture_output=True, text=True)
        if r.returncode != 0:
            raise RuntimeError("A rendszergazdai indítást elutasították: %s" % (r.stderr or "").strip())
        return
    for tool in (["pkexec"], ["sudo", "-n"]):
        try:
            subprocess.Popen(tool + ["/bin/sh", "-c", cmd], stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                             stderr=subprocess.DEVNULL)
            return
        except OSError:
            continue
    raise RuntimeError("Nem tudom rendszergazdaként elindítani a feladatot.")


def start_job(job: Dict) -> str:
    out = job["output"]
    os.makedirs(out, exist_ok=True)
    stop = os.path.join(out, STOP)
    if os.path.exists(stop):
        os.remove(stop)
    job = dict(job)
    job.setdefault("protect", True)
    if hasattr(os, "getuid"):
        job["owner"] = [os.getuid(), os.getgid()]
    path = os.path.join(out, JOB)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(job, f, ensure_ascii=False, indent=1)
    st = os.path.join(out, STATUS)
    if os.path.exists(st):
        # an earlier job's state must not look like this one's
        try:
            os.replace(st, st + ".elozo")
        except OSError:
            pass
    _elevated(["--disk-worker", path])
    return path


def stop_job(out: str) -> None:
    with open(os.path.join(out, STOP), "w") as f:
        f.write("stop")


def read_status(out: str) -> Optional[Dict]:
    p = os.path.join(out, STATUS)
    for _ in range(3):
        try:
            with open(p, encoding="utf-8") as f:
                st = json.load(f)
            st["_mtime"] = os.path.getmtime(p)
            return st
        except FileNotFoundError:
            return None
        except (OSError, ValueError):
            time.sleep(0.05)
    return None


def set_readonly(number: int, on: bool, wait: float = 60.0) -> Dict:
    res = os.path.join(tempfile.gettempdir(), "futurerepair_readonly_%s.json" % uuid.uuid4().hex[:8])
    _elevated(["--disk-readonly", str(number), "on" if on else "off", res])
    t0 = time.time()
    while time.time() - t0 < wait:
        if os.path.exists(res):
            with open(res, encoding="utf-8") as f:
                return json.load(f)
        time.sleep(0.3)
    return {"ok": False, "error": "Nem jött válasz (a jóváhagyás elmaradt?)."}
