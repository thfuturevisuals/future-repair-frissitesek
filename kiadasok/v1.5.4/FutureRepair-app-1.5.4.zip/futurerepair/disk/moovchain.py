"""Putting a fragmented recording back together on the disk with the help of its own index (moov).

The old folder entry gives the file's first cluster and exact size. The file was written in
pieces of U bytes (e.g. 32 MB per write); each piece is contiguous and starts on the cluster grid,
but pieces of files that were copied at the same time alternate on the disk.

1) The first piece is at the first cluster. Its header says where the recording (mdat) ends, so
   the in-file position of the index (moov) is known - and with it the piece that holds the moov
   and the offset of the moov inside that piece. That piece is searched for (just before the
   file's sidecar file if there is one, else forward on the disk): the moov box must sit at
   exactly that offset and describe a recording that fits the file.
2) The moov lists every frame's position and size. Every other piece is then searched between
   its neighbours: a candidate is right only if the frames that fall into it have exactly the
   structure the index describes (NAL units adding up to the frame size, ProRes frame headers...).
   Wrong data passes this test practically never, so the result is the original file byte for byte.
"""
from __future__ import annotations

import bisect
import time
from typing import Callable, Dict, List, Optional, Tuple

import os

from ..video.fragments import BlockView
from ..video.mp4 import be32, be64, is_fourcc, parse_moov

NAL_CODECS = {b"avc1", b"avc3", b"hvc1", b"hev1", b"dvh1", b"dvhe"}
PRORES = {b"apch", b"apcn", b"apcs", b"apco", b"ap4h", b"ap4x"}
JPEG = {b"jpeg", b"mjpa", b"mjpb", b"AVdn"}


def nal_len_size(track) -> int:
    se = track.sample_entry or b""
    for tag, idx in ((b"avcC", 4), (b"hvcC", 21)):
        i = se.find(tag)
        if i != -1 and i + 4 + idx < len(se):
            return (se[i + 4 + idx] & 3) + 1
    return 4


def parse_head_boxes(read: Callable[[int, int], bytes], size: int) -> Dict:
    """Top-level boxes of a file whose bytes read(off, n) returns (only the first piece is needed)."""
    out: Dict = {"boxes": []}
    pos = 0
    while pos + 8 <= size and len(out["boxes"]) < 64:
        h = read(pos, 16)
        if len(h) < 8:
            break
        bsz = be32(h, 0)
        typ = h[4:8]
        hdr = 8
        if bsz == 1:
            if len(h) < 16:
                break
            bsz = be64(h, 8)
            hdr = 16
        elif bsz == 0:
            bsz = size - pos
        if not is_fourcc(typ) or bsz < hdr:
            break
        out["boxes"].append((typ.decode("latin-1"), pos, bsz))
        if typ == b"mdat":
            out["mdat_start"] = pos + hdr
            out["mdat_end"] = pos + bsz
            break
        if typ == b"moov":
            out["moov"] = (pos, bsz, hdr)
        pos += bsz
    return out


class _InFile:
    """Slices by in-file position over a BlockView whose first byte is in-file position `base`."""

    def __init__(self, view: BlockView, base: int):
        self.v = view
        self.base = base

    def __getitem__(self, key):
        return self.v[key.start - self.base:key.stop - self.base]


def _walk_nal(view, off: int, size: int, nls: int) -> bool:
    q = off
    end = off + size
    n = 0
    while q < end:
        h = view[q:q + nls + 1]
        if len(h) < nls + 1:
            return False
        ln = int.from_bytes(h[:nls], "big")
        if ln < 1 or q + nls + ln > end or h[nls] & 0x80:
            return False
        q += nls + ln
        n += 1
        if n > 8192:
            return False
    return q == end


# the folder entry's size can lack whole multiples of 4 GiB (seen: a 76 GB Sony clip listed as 3 GB, its
# sidecar XML 225 GB further on the disk): the header's recording size then shows the real one
SIZE_WRAP = int(os.environ.get("FR_SIZE_WRAP") or (1 << 32))


def _gb(n: int) -> str:
    return ("%.1f GB" % (n / 1e9)).replace(".", ",")


class MoovRebuild:
    def __init__(self, src, G: int, H: int, count: int, U: int, first: int, size: int, claimed: bytearray,
                 log: Callable[[str], None], cancel=None, progress=None, hint: Optional[int] = None,
                 name: str = "", window: int = 32 << 30, moov_at: Optional[int] = None,
                 owner: Optional[Callable[[int], Optional[str]]] = None,
                 beat: Optional[Callable[[str], None]] = None):
        self.beat = beat
        self._t0 = self._last_beat = __import__("time").time()
        self.src = src
        self.G, self.H, self.count, self.U = G, H, count, U
        self.first, self.size = first, size
        self.claimed = claimed
        self.log = log
        self.cancel = cancel
        self.progress = progress
        self.hint = hint
        self.name = name
        self.ucl = U // G
        self.K = -(-size // U)
        self.window_cl = window // G
        self.pieces: Dict[int, int] = {0: first}
        self.found_by: Dict[int, int] = {}
        self.samples: List[Tuple[int, int, str, int]] = []      # (offset, size, kind, nls), by offset
        self.starts: List[int] = []
        self.tried = 0
        self.claims: List[Tuple[int, int]] = []
        self.moov_at = moov_at              # disk position of the file's own index, if known already
        self.first_break: Optional[Tuple[int, int]] = None
        self.rejected_moovs = 0
        self._p0: Optional[bytes] = None
        self.padding: set = set()           # pieces that hold only the camera's padding (no frames, no sound)
        self.filled: set = set()            # pieces with sound only that could not be placed: written as silence
        self.data_end = 0
        self.mdat_end = size
        self.splits: Dict[int, List[Tuple[int, int, int]]] = {}   # piece -> [(cluster offset, cluster, clusters)]
        self.missing: List[int] = []        # pieces not on the disk any more: written as zeros
        self.owner = owner                  # which recovered file a claimed cluster went to (for the log)

    # geometry -----------------------------------------------------------------------
    def pos(self, c: int) -> int:
        return self.H + (c - 2) * self.G

    def plen(self, k: int) -> int:
        return min(self.size, (k + 1) * self.U) - k * self.U

    def plen_cl(self, k: int) -> int:
        return -(-self.plen(k) // self.G)

    def seg(self, k: int, c: int) -> Tuple[int, int]:
        p = self.pos(c)
        return p, p + self.plen(k)

    def segs(self, k: int) -> List[Tuple[int, int]]:
        """Disk ranges of found piece k in file order: two when the copy program's write was split."""
        sp = self.splits.get(k)
        if not sp:
            return [self.seg(k, self.pieces[k])]
        out = []
        for off_cl, c, n in sp:
            ln = min(n * self.G, self.plen(k) - off_cl * self.G)
            out.append((self.pos(c), self.pos(c) + ln))
        return out

    def end_cl(self, j: int) -> int:
        """The cluster right after found piece j (after its last part)."""
        sp = self.splits.get(j)
        if sp:
            return sp[-1][1] + sp[-1][2]
        return self.pieces[j] + self.plen_cl(j)

    def free(self, c: int, n: int) -> bool:
        if c < 2 or c + n > self.count + 2:
            return False
        return self.claimed.find(1, c, c + n) == -1

    def _cancelled(self):
        if self.cancel and self.cancel():
            raise InterruptedError
        if self.beat is not None:
            import time as _t
            now = _t.time()
            if now - self._last_beat >= 10:
                self._last_beat = now
                try:
                    self.beat("%s: darabok keresése a lemezen (%s hely átnézve, %d perce dolgozik rajta)" % (
                        self.name, "{:,}".format(self.tried).replace(",", " "), (now - self._t0) // 60))
                except Exception:  # noqa: BLE001
                    pass

    # 1) the header and the moov ---------------------------------------------------------
    def _read_infile(self, off: int, n: int) -> bytes:
        """In-file read where only piece 0 (and found pieces) are known."""
        k = off // self.U
        c = self.pieces.get(k)
        if c is None:
            return b""
        p = self.pos(c) + (off - k * self.U)
        n = min(n, (k + 1) * self.U - off, self.size - off)
        return self.src.read(p, n)

    def _moov_from(self, data: bytes, base: int):
        if len(data) < 16 or data[4:8] != b"moov":
            return None
        msz = be32(data, 0)
        hdr = 8
        if msz == 1:
            msz = be64(data, 8)
            hdr = 16
        if msz < hdr + 8 or msz > len(data):
            return None
        try:
            mv = parse_moov(data[hdr:msz], base + hdr)
        except Exception:  # noqa: BLE001
            return None
        return mv

    def _movie_fits(self, mv, mdat_start: int, mdat_end: int) -> bool:
        if mv is None or not mv.tracks:
            return False
        n = 0
        for t in mv.tracks:
            for off, sz in zip(t.offsets, t.sizes):
                if off < mdat_start or off + sz > mdat_end:
                    return False
                n += 1
        return n > 0

    def _learn(self, t) -> Optional[Tuple]:
        """Frame header bytes that are the same in every frame of the known pieces (e.g. a codec
        magic), and a size field if the header holds the frame size: used for codecs the
        program does not know (BRAW, DNxHD, CineForm...)."""
        heads = []
        for off, sz in zip(t.offsets, t.sizes):
            k = off // self.U
            if k not in self.pieces or (off + 16) // self.U != k or sz < 16:
                continue
            h = self._read_infile(off, 16)
            if len(h) == 16:
                heads.append((h, sz))
            if len(heads) >= 200:
                break
        if len(heads) < 8:
            return None
        sig = [(i, heads[0][0][i]) for i in range(16) if all(h[i] == heads[0][0][i] for h, _ in heads)]
        size_field = None
        for o in (0, 4, 8):
            for endian in ("big", "little"):
                ds = {sz - int.from_bytes(h[o:o + 4], endian) for h, sz in heads}
                if len(ds) == 1 and abs(next(iter(ds))) < 4096:
                    size_field = (o, endian, next(iter(ds)))
                    break
            if size_field:
                break
        if len(sig) < 3 and size_field is None:
            return None
        return tuple(sig), size_field

    def _decoder_of(self, t) -> Optional[Tuple[str, Optional[bytes]]]:
        name = {b"avc1": "h264", b"avc3": "h264", b"hvc1": "hevc", b"hev1": "hevc", b"jpeg": "mjpeg",
                b"mjpa": "mjpeg", b"AVdn": "dnxhd"}.get(t.codec)
        if name is None and t.codec in PRORES:
            name = "prores"
        if name is None:
            return None
        extra = None
        se = t.sample_entry or b""
        for tag in (b"avcC", b"hvcC"):
            i = se.find(tag)
            if i >= 4:
                bsz = be32(se, i - 4)
                if 8 < bsz <= len(se) - (i - 4):
                    extra = bytes(se[i + 4:i - 4 + bsz])
        return name, extra

    def _use_movie(self, mv) -> None:
        smp = []
        self.decoders = {}
        ends = [off + sz for t in mv.tracks for off, sz in zip(t.offsets, t.sizes) if sz > 0]
        self.data_end = max(ends) if ends else 0           # where the recorded data ends in the mdat
        for ti, t in enumerate(mv.tracks):
            if not t.is_video:
                continue
            self.decoders[ti] = self._decoder_of(t)
            if t.codec in NAL_CODECS:
                kind, nls = "nal", nal_len_size(t)
            elif t.codec in PRORES:
                kind, nls = "prores", 0
            elif t.codec in JPEG:
                kind, nls = "jpeg", 0
            else:
                learned = self._learn(t)
                if learned is None:
                    continue
                kind, nls = "learn", learned
            for off, sz in zip(t.offsets, t.sizes):
                if sz > 0:
                    smp.append((off, sz, kind, nls, ti))
        smp.sort(key=lambda s: s[0])
        # every frame the same size (intra codecs at constant bytes per frame): a second camera with
        # the same settings has pieces that pass the structure test just as well
        vs = [x[1] for x in smp[:400]]
        self.twin_prone = len(vs) >= 20 and len(set(vs)) == 1
        self.samples = smp
        self.starts = [s[0] for s in smp]

    def _moov_candidates(self, km: int):
        n = self.plen_cl(km)
        seen = set()
        if self.moov_at is not None:
            # found by an earlier attempt with another piece size: the same place on the disk
            rel = self._moov_rel
            if (self.moov_at - rel - self.H) % self.G == 0:
                c = (self.moov_at - rel - self.H) // self.G + 2
                seen.add(c)
                yield c
        if self.hint:
            for j in range(0, 4096):
                c = self.hint - n - j
                if c <= self.first:
                    break
                seen.add(c)
                yield c
        lo = self.first + self.ucl
        for c in range(lo, min(self.count + 2, lo + self.window_cl)):
            if c not in seen:
                yield c

    def _accept_moov(self, mv, km: int, c: int, i: int, t0: float) -> Optional[bool]:
        """Checks a fitting index (see _ours); True: taken, False: someone else's, None: ours, but
        the first piece is shorter than U (the attempt stops; first_break tells the piece size)."""
        verdict = self._ours(mv, km, c)
        if verdict is True:
            self.pieces[km] = c
            self.found_by[km] = i
            self.moov_at = self.pos(c) + self._moov_rel
            self.mdat_end = self._mdat_end_seen
            self._claim_piece(km, c)
            self.log("  %s: az index (moov) megvan a %d. klaszterben (%d. jelölt, %.0f mp%s)." % (
                self.name, c, i + 1, time.time() - t0,
                (", %d másik felvétel indexét kihagytam" % self.rejected_moovs) if self.rejected_moovs else ""))
            return True
        if verdict is False:
            self.rejected_moovs += 1
            return False
        _short, good_end, bad_end = verdict
        self.first_break = (good_end, bad_end)
        self.moov_at = self.pos(c) + self._moov_rel
        return None

    def find_moov(self, mdat_start: int, mdat_end: int):
        km = mdat_end // self.U
        self._moov_rel = mdat_end - km * self.U
        self._mdat_end_seen = mdat_end
        if km == 0:
            data = self._read_infile(mdat_end, self.size - mdat_end)
            mv = self._moov_from(data, mdat_end)
            return (mv, km) if self._movie_fits(mv, mdat_start, mdat_end) else (None, km)
        off = mdat_end - km * self.U
        n = self.plen_cl(km)
        t0 = time.time()
        for i, c in enumerate(self._moov_candidates(km)):
            if i % 256 == 0:
                self._cancelled()
            # only the index's own clusters have to be free here: with a wrong piece size the rest of
            # the assumed piece is someone else's (the first-piece check below tells that apart)
            mc = c + off // self.G
            if not self.free(mc, 1):
                continue
            h = self.src.read(self.pos(c) + off, 16)
            if len(h) < 8 or h[4:8] != b"moov":
                continue
            msz = be32(h, 0)
            if msz == 1:
                msz = be64(h, 8)
            if msz < 16 or mdat_end + msz > self.size:
                continue
            if not self.free(mc, -(-(off % self.G + min(msz, self.plen(km) - off)) // self.G)):
                continue
            if off + msz <= self.plen(km):
                data = self.src.read(self.pos(c) + off, msz)
                mv = self._moov_from(data, mdat_end)
                if self._movie_fits(mv, mdat_start, mdat_end):
                    got = self._accept_moov(mv, km, c, i, t0)
                    if got:
                        return mv, km
                    if got is None:
                        return None, km
            else:
                # the moov runs on into the next piece (rare)
                part1 = self.src.read(self.pos(c) + off, self.plen(km) - off)
                if self.K <= km + 1:
                    continue
                n2 = self.plen_cl(km + 1)
                end_c = c + n
                for d in [0] + [self.ucl * j for j in range(1, 5)] + list(range(1, 2048)):
                    c2 = end_c + d
                    if not self.free(c2, n2):
                        continue
                    part2 = self.src.read(self.pos(c2), msz - len(part1))
                    mv = self._moov_from(part1 + part2, mdat_end)
                    if self._movie_fits(mv, mdat_start, mdat_end):
                        self.pieces[km + 1] = c2
                        got = self._accept_moov(mv, km, c, i, t0)
                        if got:
                            self._claim(c2, n2)
                            return mv, km
                        del self.pieces[km + 1]
                        if got is None:
                            return None, km
                        break
        return None, km

    def _sample_ok(self, view, smp) -> bool:
        off, sz, kind, nls = smp[:4]
        if kind == "nal":
            return _walk_nal(view, off, sz, nls)
        if kind == "prores":
            h = view[off:off + 8]
            return len(h) == 8 and be32(h, 0) == sz and h[4:8] == b"icpf"
        if kind == "learn":
            sig, size_field = nls
            h = view[off:off + 16]
            ok = len(h) == 16 and all(h[i] == v for i, v in sig)
            if ok and size_field:
                o, endian, d = size_field
                ok = sz - int.from_bytes(h[o:o + 4], endian) == d
            return ok
        return view[off:off + 2] == b"\xff\xd8"

    def _piece0(self) -> bytes:
        if self._p0 is None:
            self._p0 = self.src.read(self.pos(self.first), self.plen(0))
        return self._p0

    def _ours(self, mv, km: int, c: int):
        """Is this index really the file's own? A recording of another length from the same camera
        has the same box layout (the camera grows the recording area in fixed steps), so its index
        "fits" too. The frames of the first piece - read for sure from the file's first cluster -
        must have exactly the structure the index gives them, and so must the recording's last
        frames in the index's own piece.
        Returns True, False, or ("short", good_end, bad_end) when the index matches the first
        frames but not the later ones of the first piece: the index is ours, the first piece is
        just shorter than U (the copy program wrote smaller pieces)."""
        self._use_movie(mv)
        if not self.samples:
            return True                                  # nothing to compare with (unknown codec)
        p0 = self._piece0()
        inside = [smp for smp in self.samples if smp[0] + smp[1] <= len(p0)]
        good_end = None
        bad = None
        for idx, smp in enumerate(inside):
            if idx > 48 and idx % 7 and idx < len(inside) - 8:
                continue                                 # the start, every 7th, and the end
            if self._sample_ok(p0, smp):
                good_end = smp[0] + smp[1]
            else:
                bad = (idx, smp)
                break
        if bad is not None:
            idx, smp = bad
            if good_end is None or idx < 6:
                return False
            # the first frames fit: find the exact frame where it stops fitting
            j0 = max(0, idx - 7)
            for smp2 in inside[j0:idx + 1]:
                if self._sample_ok(p0, smp2):
                    good_end = smp2[0] + smp2[1]
                else:
                    return ("short", good_end, smp2[0] + smp2[1])
            return ("short", good_end, smp[0] + smp[1])
        if km > 0 and self.size > km * self.U:
            had = self.pieces.get(km)
            self.pieces[km] = c
            try:
                chk = self._check_piece(km, c)
            finally:
                if had is None:
                    del self.pieces[km]
                else:
                    self.pieces[km] = had
            if chk is False:
                return False
        return True

    # 2) the other pieces ------------------------------------------------------------------
    def _check_piece(self, k: int, c: int) -> Optional[bool]:
        """Do the frames that fall into piece k look exactly as the index says, with the piece at c?"""
        lo = k * self.U
        hi = lo + self.plen(k)
        exts = []
        base = lo
        if (k - 1) in self.pieces:
            exts += self.segs(k - 1)
            base = (k - 1) * self.U
        exts.append(self.seg(k, c))
        view = _InFile(BlockView(self.src, exts), base)
        i = bisect.bisect_left(self.starts, lo)
        checks = []
        # the frame that runs across the start of the piece
        if i > 0 and base < lo:
            off, sz, kind, nls = self.samples[i - 1][:4]
            if off >= base and off < lo < off + sz and off + sz <= hi:
                checks.append(self.samples[i - 1])
        j = i
        while j < len(self.samples) and len(checks) < 4:
            off, sz, kind, nls = self.samples[j][:4]
            if off >= hi:
                break
            if off + sz <= hi:
                checks.append(self.samples[j])
            j += 1
        # and the last frames of the piece: a piece that is really two (the copy program's pieces are
        # smaller than U) fails there even when its first frames happen to be in the right place
        tail = []
        j = bisect.bisect_left(self.starts, hi) - 1
        while j >= i and len(tail) < 4:
            off, sz = self.samples[j][:2]
            if off >= lo and off + sz <= hi and self.samples[j] not in checks:
                tail.append(self.samples[j])
            j -= 1
        checks += tail
        if not checks:
            return None
        for smp in checks:
            if not self._sample_ok(view, smp):
                return False
        return True

    def _piece_candidates(self, k: int):
        j = max(kk for kk in self.pieces if kk < k)
        prev = self.pieces[j]
        start = self.end_cl(j) + sum(self.plen_cl(i) for i in range(j + 1, k))
        upper = None
        for kk in sorted(self.pieces):
            if kk > k:
                upper = self.pieces[kk]
                break
        gap = None
        if (k - 2) in self.pieces and j == k - 1:
            gap = prev - self.end_cl(k - 2)
        order = [start]
        if gap is not None and gap > 0:
            order.append(start + gap)
        order += [start + self.ucl * j for j in range(1, 7)]
        order += [start + d for d in range(1, 9)] + [start + self.ucl + d for d in range(1, 9)]
        seen = set()
        for c in order:
            if c not in seen:
                seen.add(c)
                yield c
        stop = upper if upper is not None and upper > start else start + self.window_cl
        for c in range(start + 1, min(self.count + 2, stop)):
            if c not in seen:
                yield c
        # after the next known piece / behind the previous one (space freed earlier, rare)
        if upper is not None:
            for c in range(upper + 1, min(self.count + 2, upper + self.window_cl // 4)):
                yield c
        for c in range(prev - 1, max(1, prev - self.window_cl // 8), -1):
            yield c

    def _checkable(self, k: int) -> bool:
        lo = k * self.U
        hi = lo + self.plen(k)
        i = bisect.bisect_left(self.starts, lo)
        if i > 0:
            off, sz = self.samples[i - 1][:2]
            if off < lo < off + sz <= hi:
                return True
        while i < len(self.samples) and self.samples[i][0] < hi:
            if self.samples[i][0] + self.samples[i][1] <= hi:
                return True
            i += 1
        return False

    def find_piece(self, k: int) -> Optional[int]:
        n = self.plen_cl(k)
        if not self._checkable(k):
            # no frame of the index falls into this piece: only the contiguous position is trusted
            j = max(kk for kk in self.pieces if kk < k)
            c = self.end_cl(j) + sum(self.plen_cl(i) for i in range(j + 1, k))
            return c if self._free_piece(k, c) else None
        passes = []
        first_i = None
        extra = (4 * self.ucl + 32) if getattr(self, "twin_prone", False) else 24
        for i, c in enumerate(self._piece_candidates(k)):
            if i % 256 == 0:
                self._cancelled()
            if first_i is not None and i > first_i + extra:
                break
            if not self._free_piece(k, c):
                continue
            self.tried += 1
            if self._check_piece(k, c):
                passes.append((i, c))
                if first_i is None:
                    first_i = i
        if not passes:
            sp = self._find_split(k)
            if sp:
                self.splits[k] = sp
                at = sp[1][0] * self.G
                self.log("  %s: a %d. darab két részben van (%s után folytatódik máshol)." % (
                    self.name, k + 1, ("%d MB" % (at >> 20)) if at >= (1 << 20) else ("%d KB" % (at >> 10))))
                return sp[0][1]
            start = None
            try:
                j = max(kk for kk in self.pieces if kk < k)
                start = self.end_cl(j) + sum(self.plen_cl(i) for i in range(j + 1, k))
            except ValueError:
                pass
            if start is None:
                nxt = "ismeretlen"
            elif self._free_piece(k, start):
                nxt = "szabad, de a képkockák nem stimmelnek"
            else:
                nxt = "foglalt"
                own = self._owner_near(start, self.plen_cl(k))
                if own:
                    nxt += " (%s)" % own
                if start >= 2 and self._check_piece(k, start):
                    nxt += ", és a képkockák szerint ez a darab az – egy másik fájl vette el"
            self.log("  %s: a %d. darab nincs meg (%d szabad jelölt ellenőrizve; a közvetlenül következő hely %s)." % (
                self.name, k + 1, self.tried, nxt))
            return None
        if len(passes) > 1:
            i, c = self._choose(k, passes)
        else:
            i, c = passes[0]
        self.found_by[k] = i
        return c

    def _frame_thumb(self, view, smp) -> Optional[bytes]:
        from .thumbs import thumb
        off, sz, _kind, _nls, ti = smp
        dec = (getattr(self, "decoders", {}) or {}).get(ti)
        if not dec:
            return None
        data = view[off:off + sz]
        if len(data) != sz:
            return None
        return thumb(data, dec[0], dec[1])

    def _choose(self, k: int, passes):
        """Several positions fit piece k (a recording with the same frame sizes, e.g. a second camera
        with constant bytes per frame): decide by the picture."""
        from .thumbs import mad
        if (k - 1) not in self.pieces:
            self.uncertain = getattr(self, "uncertain", 0) + 1
            return passes[0]
        lo = k * self.U
        i = bisect.bisect_left(self.starts, lo)
        base = (k - 1) * self.U
        prev_view = _InFile(BlockView(self.src, self.segs(k - 1)), base)
        left = None
        j = i - 1
        while j >= 0 and left is None and self.samples[j][0] >= base:
            if self.samples[j][0] + self.samples[j][1] <= lo:
                left = self._frame_thumb(prev_view, self.samples[j])
                if left is None:
                    break
            j -= 1
        if left is not None:
            scored = []
            for p in passes:
                view = _InFile(BlockView(self.src, self.segs(k - 1) + [self.seg(k, p[1])]), base)
                t = None
                jj = i - 1 if i > 0 and self.samples[i - 1][0] < lo < self.samples[i - 1][0] + self.samples[i - 1][1] \
                    else i
                while jj < len(self.samples) and t is None and self.samples[jj][0] < lo + self.plen(k):
                    t = self._frame_thumb(view, self.samples[jj])
                    jj += 1
                    if jj - i > 3:
                        break
                scored.append((mad(left, t) if t is not None else 1e9, p))
            scored.sort(key=lambda x: x[0])
            if scored[0][0] < 1e9 and (len(scored) == 1 or scored[0][0] < 0.75 * scored[1][0]):
                self.decided = getattr(self, "decided", 0) + 1
                return scored[0][1]
        self.uncertain = getattr(self, "uncertain", 0) + 1
        return passes[0]

    def _parts(self, k: int) -> List[Tuple[int, int]]:
        """In-file byte ranges of piece k that hold the file's data: everything except the padding
        the camera put between the end of the recording and the index (when it is known)."""
        a = k * self.U
        b = a + self.plen(k)
        if not (self.data_end and self.mdat_end > self.data_end):
            return [(a, b)]
        out = []
        if a < self.data_end:
            out.append((a, min(b, self.data_end)))
        if b > self.mdat_end:
            out.append((max(a, self.mdat_end), b))
        return out

    def _cl_ranges(self, k: int) -> List[Tuple[int, int]]:
        a = k * self.U
        out = []
        for x0, x1 in self._parts(k):
            c0 = (x0 - a) // self.G
            c1 = -(-(x1 - a) // self.G)
            out.append((c0, c1 - c0))
        return out

    def _free_piece(self, k: int, c: int) -> bool:
        return all(self.free(c + o, n) for o, n in self._cl_ranges(k))

    def _claim_piece(self, k: int, c: int) -> None:
        sp = self.splits.get(k)
        if sp:
            for _off, cc, n in sp:
                self._claim(cc, n)
            return
        for o, n in self._cl_ranges(k):
            self._claim(c + o, n)

    def _owner_near(self, c: int, n: int) -> Optional[str]:
        if not self.owner:
            return None
        for x in range(c, c + max(1, n)):
            o = self.owner(x)
            if o:
                return o
        return None

    def _sample_at(self, view, smp) -> bool:
        try:
            return self._sample_ok(view, smp)
        except Exception:  # noqa: BLE001
            return False

    def _find_split(self, k: int) -> Optional[List[Tuple[int, int, int]]]:
        """Piece k is nowhere in one block: the copy program's write may have been split in two (the
        free space was in pieces then). Its start is where the frames begin to fit, the rest is
        searched for from the first frame that does not fit."""
        lo = k * self.U
        hi = lo + self.plen(k)
        n = self.plen_cl(k)
        dbg = os.environ.get("FR_DEBUG_SPLIT")
        if self._parts(k) != [(lo, hi)] or n < 2:
            if dbg:
                self.log("    split %d: parts %s" % (k, self._parts(k)))
            return None
        i0 = bisect.bisect_left(self.starts, lo)
        inside = []
        j = i0
        while j < len(self.samples) and self.samples[j][0] < hi:
            if self.samples[j][0] + self.samples[j][1] <= hi:
                inside.append(self.samples[j])
            j += 1
        if len(inside) < 3:
            return None
        prev = self.segs(k - 1) if (k - 1) in self.pieces else []
        base = (k - 1) * self.U if prev else lo
        tried = 0
        for c in self._piece_candidates(k):
            tried += 1
            if tried > 64:
                break
            if not self.free(c, 1):
                continue
            view = _InFile(BlockView(self.src, prev + [self.seg(k, c)]), base)
            if not self._sample_at(view, inside[0]):
                continue
            if dbg:
                self.log("    split %d: head candidate %d" % (k, c))
            # the frames fit from the start up to the split: find the first one that does not
            a, b = 0, len(inside)               # inside[a] fits, inside[b] (if any) does not
            while b - a > 1:
                m = (a + b) // 2
                if self._sample_at(view, inside[m]):
                    a = m
                else:
                    b = m
            if b >= len(inside):
                continue                       # every frame fits: not a split (the check failed elsewhere)
            # a frame's structure (its NAL lengths) can fit even when the end of its last NAL is already
            # past the split, so the split lies anywhere from the last fitting frame to the first that fails
            first_cl = max(1, (inside[a][0] - lo) // self.G)
            last_cl = min(n - 1, (inside[b][0] + inside[b][1] - lo - 1) // self.G)
            if dbg:
                self.log("    split %d: fits up to sample %d/%d, split between clusters %d..%d of %d" % (
                    k, a, len(inside), first_cl, last_cl, n))
            found = []
            for m_cl in range(first_cl, last_cl + 1):
                if not self.free(c, m_cl):
                    break
                rest = n - m_cl
                tail = self._find_rest(k, c, m_cl, rest, prev, base, inside[a:])
                if tail is None:
                    continue
                ln = self.plen(k) - m_cl * self.G
                full = _InFile(BlockView(self.src, prev + [(self.pos(c), self.pos(c) + m_cl * self.G),
                                                           (self.pos(tail), self.pos(tail) + ln)]), base)
                if all(self._sample_at(full, smp) for smp in inside):
                    found.append((m_cl, tail))
            if found:
                if len(found) > 1:
                    self.uncertain = getattr(self, "uncertain", 0) + 1
                m_cl, tail = found[0]
                return [(0, c, m_cl), (m_cl, tail, n - m_cl)]
        return None

    def _find_rest(self, k, c, m_cl, rest, prev, base, after) -> Optional[int]:
        lo = k * self.U
        head = (self.pos(c), self.pos(c) + m_cl * self.G)
        checks = after[:3] + after[-3:]
        j = max(kk for kk in self.pieces if kk < k)
        start = self.end_cl(j)
        upper = next((self.pieces[kk] for kk in sorted(self.pieces) if kk > k), None)
        stop = upper if upper is not None and upper > start else start + self.window_cl
        order = [c + m_cl + d for d in range(1, 2 * self.ucl + 2)] + list(range(start, min(self.count + 2, stop)))
        seen = set()
        for i, c2 in enumerate(order):
            if c2 in seen:
                continue
            seen.add(c2)
            if i % 256 == 0:
                self._cancelled()
            if not self.free(c2, rest) or (c <= c2 < c + m_cl):
                continue
            ln = self.plen(k) - m_cl * self.G
            view = _InFile(BlockView(self.src, prev + [head, (self.pos(c2), self.pos(c2) + ln)]), base)
            self.tried += 1
            if all(self._sample_at(view, smp) for smp in checks):
                return c2
        return None

    def _claim(self, c: int, n: int) -> None:
        self.claimed[c:c + n] = b"\x01" * n
        self.claims.append((c, n))

    def release(self) -> None:
        for c, n in self.claims:
            self.claimed[c:c + n] = bytes(n)
        self.claims = []

    def wrapped_size(self, mdat_end: int) -> Optional[int]:
        """The real size when the entry lost multiples of 4 GiB: the one size + n * 4 GiB that leaves
        room for the index (moov) right after the recording, and no other."""
        fits = []
        room = min(256 << 20, SIZE_WRAP // 2)           # an index is a few MB; a 4 GB step is far more
        for n in range(1, 4096):
            s = self.size + n * SIZE_WRAP
            if s - mdat_end > room:
                break
            if s - mdat_end >= 8:
                fits.append(s)
        return fits[0] if len(fits) == 1 else None

    # main ------------------------------------------------------------------------------
    def run(self) -> Dict:
        res: Dict = {"pieces": self.K}
        hdr = parse_head_boxes(self._read_infile, min(self.size, self.U))
        if "mdat_start" not in hdr:
            res.update(state="failed", message="A fájl eleje nem MP4/MOV szerkezetű a lemezen.")
            return res
        mdat_start, mdat_end = hdr["mdat_start"], hdr["mdat_end"]
        res["structure"] = [b[0] for b in hdr["boxes"]]
        mv = None
        if "moov" in hdr:                                    # index in front of the recording
            mpos, msz, mh = hdr["moov"]
            mv = self._moov_from(self._read_infile(mpos, msz), mpos)
            if not self._movie_fits(mv, mdat_start, min(mdat_end, self.size)):
                mv = None
        if mv is None:
            if mdat_end > self.size:
                fix = self.wrapped_size(mdat_end)
                if fix:
                    res.update(state="resize", size=fix, mdat_end=mdat_end,
                               message="A mappabejegyzés szerinti méret (%s) %d × 4 GB-tal kevesebb a valódinál: "
                                       "a felvétel %s." % (_gb(self.size), (fix - self.size) // SIZE_WRAP, _gb(fix)))
                    return res
                res.update(state="failed", mdat_end=mdat_end,
                           message="A lemezen a fájlnak csak az eleje van meg (%s a %s-os felvételből): a másolás "
                                   "nem fejeződött be, a vége és az indexe nem került a lemezre."
                                   % (_gb(self.size), _gb(mdat_end)))
                return res
            if mdat_end <= mdat_start:
                res.update(state="failed", message="A fejléc szerinti felvételhossz nem illik a fájlmérethez.")
                return res
            mv, km = self.find_moov(mdat_start, mdat_end)
            if mv is None:
                if self.first_break:
                    res.update(state="partial", first_break=self.first_break, moov_at=self.moov_at,
                               message="Az index megvan, de a másolóprogram kisebb darabokban írt (%d MB-nál "
                                       "kisebbekben)." % (self.U >> 20))
                    return res
                res.update(state="no_index", message="A fájl indexét (moov) nem találtam meg a lemezen%s." % (
                    " (%d hasonló felvétel indexét megtaláltam, de egyik sem ezé)" % self.rejected_moovs
                    if self.rejected_moovs else ""))
                return res
            # the moov's piece must also hold the right end of the recording
            if km > 0 and mdat_end > km * self.U:
                self._use_movie(mv)
                chk = self._check_piece(km, self.pieces[km])
                if chk is False:
                    res.update(state="no_index", message="A megtalált index darabja nem illik a felvételhez.")
                    return res
        self._use_movie(mv)
        self.mdat_end = mdat_end
        if not self.samples:
            res.update(state="failed", message="A videósáv kódolása miatt a darabok nem ellenőrizhetők.")
            return res
        t0 = time.time()
        for k in range(1, self.K):
            if k in self.pieces:
                continue
            if self.progress:
                self.progress(k / float(self.K))
            if k * self.U >= self.data_end and k * self.U + self.plen(k) <= mdat_end:
                # only the padding the camera adds after the recording (nothing reads it): written as
                # zeros instead of guessing a place for it on the disk
                self.padding.add(k)
                continue
            c = self.find_piece(k)
            if c is None and not self._checkable(k):
                # no picture in this piece (only the end of the sound): it cannot be checked, and its
                # likely place is taken - written as silence instead of failing the whole recording
                self.filled.add(k)
                continue
            if c is None:
                found = sum(1 for kk in self.pieces if kk < k)
                if found < 20 or len(self.missing) + 1 > max(1, found // 20):
                    res.update(state="partial", found=sorted(self.pieces), missing_from=k,
                               missing=self.missing + [k],
                               message="A %d darabból a %d.-at nem találtam meg." % (self.K, k + 1))
                    return res
                self.missing.append(k)          # most of the recording is there: zeros in place of this one
                continue
            self.pieces[k] = c
            self._claim_piece(k, c)
        exts = []
        for k in range(self.K):
            a = k * self.U
            b = a + self.plen(k)
            if k in self.padding or k in self.filled or k in self.missing:
                exts.append(("zero", b - a))
                continue
            if k in self.splits:
                exts += self.segs(k)
                continue
            base = self.pos(self.pieces[k])
            cur = a
            for x0, x1 in self._parts(k):
                if x0 > cur:
                    exts.append(("zero", x0 - cur))
                exts.append((base + (x0 - a), base + (x1 - a)))
                cur = x1
            if cur < b:
                exts.append(("zero", b - cur))
        real = [k for k in range(self.K) if k in self.pieces]
        jumps = sum(1 for a, b in zip(real, real[1:])
                    if b == a + 1 and self.pieces[b] != self.end_cl(a))
        msg = "Teljes: %d darab, ebből %d helyen ugrik (%d jelölt kipróbálva)." % (self.K, jumps, self.tried)
        if self.padding:
            msg += " A felvétel utáni üres kitöltés (%d darab) nullákkal pótolva." % len(self.padding)
        if self.filled:
            msg += " A felvétel végén %d darabnyi hangot nem lehetett azonosítani, csenddel pótoltam." % len(
                self.filled)
        if getattr(self, "decided", 0):
            msg += " Egy hasonló felvétel darabjai közül %d helyen a kép döntött." % self.decided
        if getattr(self, "uncertain", 0):
            msg += " %d darabnál nem lehetett biztosan dönteni." % self.uncertain
        # the piece size is proven only by a jump between two pieces that both hold recorded data
        res.update(u_evidence=any(
            self.pieces.get(k) is not None and self.pieces.get(k - 1) is not None and
            (k * self.U) < self.data_end and self.pieces[k] != self.end_cl(k - 1)
            for k in range(1, self.K) if (k * self.U) < self.data_end))
        res.update(filled=sorted(self.filled))
        if self.splits:
            msg += " %d darab két részben volt a lemezen (a másolóprogram írása kettévált)." % len(self.splits)
        if self.missing:
            lost = sum(self.plen(k) for k in self.missing)
            span = max(1, (self.data_end or self.size) - mdat_start)
            where = ", ".join("%d%%" % min(100, max(0, round(100.0 * (k * self.U - mdat_start) / span)))
                              for k in self.missing[:6])
            res.update(state="gaps", missing=list(self.missing), lost=lost, extents=exts, jumps=jumps,
                       tried=self.tried, splits=len(self.splits),
                       message="A %d darabból %d nem volt meg a lemezen (%d MB, a felvétel %s-ánál): a helyükön "
                               "nullák vannak, ott a kép és a hang hibás; a felvétel többi része rendben."
                               % (self.K, len(self.missing), lost >> 20, where))
            return res
        res.update(state="complete", extents=exts, jumps=jumps, tried=self.tried,
                   seconds=round(time.time() - t0, 1), message=msg, uncertain=getattr(self, "uncertain", 0))
        return res
