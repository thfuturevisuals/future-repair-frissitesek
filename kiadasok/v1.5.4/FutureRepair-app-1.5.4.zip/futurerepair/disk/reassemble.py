"""Rebuilding fragmented recordings directly from the disk they were stored on.

A recovery tool that does not know a file's allocation chain copies `size` bytes starting at
the file's first cluster. On a disk where several files were written at the same time the
result contains the file's own clusters interleaved with clusters of other files.

Here the disk itself is read (never written): every recovered file is located on the disk by
the content of its clusters, then the recording is followed cluster by cluster across the whole
disk - a cluster continues the recording if the frame cut at the end of the previous cluster
continues correctly in it - until the file's full size is reached. When the whole chain is
found, the result is the original file byte for byte, including its own index (moov).
"""
from __future__ import annotations

import json
import os
from collections import Counter
import shutil
import time
import traceback
from typing import Callable, Dict, List, Optional, Tuple

from ..video.fragments import BlockView, ChainBuilder, max_unit_size
from ..video.mp4 import be32, be64, is_fourcc, parse_moov
from .raw import RawSource
from .survey import (F_MP4, F_READERR, F_START, F_ZERO, HEAD, DiskIndex, build_index, detect_grid, find_file_starts,
                     fs_info, head_hash, read_partitions, score_grid)

VIDEO_EXT = {".mp4", ".mov", ".m4v", ".mxf", ".3gp", ".insv", ".lrv"}


# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------

def parse_header(view, size: int) -> Dict:
    """Top-level boxes at the start of a file seen through `view` (no payload reads)."""
    out: Dict = {"boxes": []}
    pos = 0
    while pos + 8 <= size and len(out["boxes"]) < 64:
        h = view[pos:pos + 16]
        if len(h) < 8:
            break
        bsz = be32(h, 0)
        typ = h[4:8]
        hdr = 8
        if bsz == 1:
            if len(h) < 16:
                break
            bsz = be64(h, 8)
            hdr = 16
        elif bsz == 0:
            if typ == b"mdat":                      # size not written: the recording was interrupted
                out["boxes"].append(("mdat", pos, 0))
                out["mdat_start"] = pos + hdr
                out["mdat_end"] = None
                break
            bsz = size - pos
        if not is_fourcc(typ) or bsz < hdr:
            break
        out["boxes"].append((typ.decode("latin-1"), pos, bsz))
        if typ == b"mdat":
            out["mdat_start"] = pos + hdr
            out["mdat_end"] = pos + bsz if bsz > hdr else None
            break                                   # the payload is the recording itself
        if typ == b"moov":
            out["moov"] = (pos, bsz)
        pos += bsz
    return out


def locate_on_disk(ix: DiskIndex, path: str, max_probe: int = 6) -> Tuple[Optional[int], int, int]:
    """Disk cluster where a recovered file starts. Returns (cluster, matching blocks, probed)."""
    B = ix.B
    size = os.path.getsize(path)
    nblocks = max(1, -(-size // B))
    probes = [0] + [i for i in range(1, nblocks) if i < max_probe]
    heads = {}
    with open(path, "rb") as f:
        for i in probes:
            f.seek(i * B)
            heads[i] = head_hash(f.read(min(HEAD, size - i * B)))
    best, best_n = None, 0
    for k0 in ix.lookup(heads[0]):
        n = sum(1 for i in probes if k0 + i < ix.count and ix.hashes[k0 + i] == heads[i])
        if n > best_n:
            best, best_n = k0, n
    if best is None:
        # the first block may be damaged in the copy: try to anchor on a later block
        for i in probes[1:]:
            for k in ix.lookup(heads[i]):
                k0 = k - i
                if k0 < 0:
                    continue
                n = sum(1 for j in probes if k0 + j < ix.count and ix.hashes[k0 + j] == heads[j])
                if n > best_n:
                    best, best_n = k0, n
    return best, best_n, len(probes)


def copy_extents(src: RawSource, extents: List[Tuple[int, int]], out_path: str,
                 progress: Optional[Callable[[float], None]] = None, cancel=None) -> int:
    total = sum((e if s == "zero" else len(e) if s == "data" else e - s) for s, e in extents)
    tmp = out_path + ".part"
    done = 0
    with open(tmp, "wb") as out:
        for s, e in extents:
            if s == "data":                       # ("data", bytes): written as they are (e.g. a KLV fill header)
                out.write(e)
                done += len(e)
                continue
            if s == "zero":                       # ("zero", n): n zero bytes (padding that was never read)
                left = e
                while left > 0:
                    n = min(16 << 20, left)
                    out.write(bytes(n))
                    left -= n
                    done += n
                continue
            pos = s
            while pos < e:
                if cancel and cancel():
                    raise InterruptedError
                n = min(16 << 20, e - pos)
                data = src.read_direct(pos, n)
                if len(data) != n:
                    raise IOError("Rövid olvasás a lemezen (%d. bájt)" % pos)
                out.write(data)
                pos += n
                done += n
                if progress:
                    progress(done / float(max(1, total)))
    os.replace(tmp, out_path)
    return done


class DiskChain(ChainBuilder):
    """ChainBuilder over the clusters of a whole disk."""

    def __init__(self, src, ix: DiskIndex, k0: int, mdat_start: int, video_end: int, models, transitions,
                 max_unit: int, claimed: set, log=None, cancel=None, progress=None,
                 max_ahead: int = 2048, max_back: int = 256):
        origin = ix.origin
        super().__init__(src, origin + k0 * ix.B + mdat_start, src.size, ix.B, models, transitions, max_unit,
                         log=log, cancel=cancel, progress=progress, max_ahead=max_ahead)
        self.origin = origin
        self.extent_start = origin + k0 * ix.B
        self.restart0 = mdat_start
        self.limit = video_end
        self.trim_to_limit = False
        self.max_back = max_back
        self.slow_limit = 24
        # no "resync" on a disk: a cluster that merely looks like a recording is most likely
        # another file's - a partial file is better than mixed content
        self.resync_ahead = 0
        self.ix = ix
        self.claimed = claimed
        self.k0 = k0

        def skip(k):
            if k < 0 or k >= ix.count:
                return True
            if k in claimed:
                return True
            return bool(ix.flags[k] & (F_ZERO | F_START | F_READERR)) and k != k0
        self.skip = skip

        def pred_skip(k):
            return k < 0 or k >= ix.count or bool(ix.flags[k] & (F_ZERO | F_READERR))
        self.pred_skip = pred_skip


def _moov_ok(view, mdat_start: int, mdat_end: int, size: Optional[int]) -> int:
    """Size of the moov that follows the recording if it reads completely and points into the
    recording, else 0."""
    h = view[mdat_end:mdat_end + 16]
    if len(h) < 8 or h[4:8] != b"moov":
        return 0
    msz = be32(h, 0)
    hdr = 8
    if msz == 1:
        msz = be64(h, 8)
        hdr = 16
    if msz < hdr or (size is not None and mdat_end + msz > size) or mdat_end + msz > len(view):
        return 0
    if msz > (64 << 20):
        return 0
    try:
        movie = parse_moov(view[mdat_end + hdr:mdat_end + msz], mdat_end + hdr)
    except Exception:  # noqa: BLE001
        return 0
    if movie is None or not movie.tracks:
        return 0
    n = 0
    for t in movie.tracks:
        for off, sz in zip(t.offsets, t.sizes):
            if off < mdat_start or off + sz > mdat_end:
                return 0
            n += 1
    return msz if n > 0 else 0


def _creation_name(moov: bytes, k0: int, ext: str) -> str:
    """'20260717_213405_c123456.MP4' from the movie header (falls back to the cluster number)."""
    import datetime
    i = moov.find(b"mvhd")
    stamp = None
    if i >= 4 and i + 16 < len(moov):
        ver = moov[i + 4]
        try:
            secs = be64(moov, i + 8) if ver == 1 else be32(moov, i + 8)
            if secs > 0:
                t = datetime.datetime(1904, 1, 1) + datetime.timedelta(seconds=secs)
                if 2000 <= t.year <= 2100:
                    stamp = t.strftime("%Y%m%d_%H%M%S")
        except Exception:  # noqa: BLE001
            stamp = None
    return "%s_c%d%s" % (stamp or "lemez", k0, ext)


# ---------------------------------------------------------------------------
# One file
# ---------------------------------------------------------------------------

def recover_one(src: RawSource, ix: DiskIndex, entry: Dict, prof, claimed: set, out_dir: str,
                log: Callable[[str], None], cancel=None, progress=None) -> Dict:
    """Follow one recording on the disk and write it to out_dir. `entry`: {path, size, k0}."""
    B = ix.B
    k0 = entry["k0"]
    size = entry.get("size")                      # None: carved from the disk, size not known
    name = os.path.basename(entry.get("path") or "lemez_c%d.MP4" % k0)
    res: Dict = {"name": name, "path": entry.get("path"), "cluster": k0, "size": size}
    first = BlockView(src, [(ix.pos(k0), ix.pos(k0) + B)])
    hdr = parse_header(first, min(size or B, B))
    if "mdat_start" not in hdr:
        res.update(state="failed", message="A fájl eleje nem MP4/MOV szerkezetű a lemezen.")
        return res
    mdat_start = hdr["mdat_start"]
    mdat_end = hdr.get("mdat_end")
    if size is not None:
        mdat_end = min(mdat_end or size, size)
    res["structure"] = [b[0] for b in hdr["boxes"]]
    max_unit = max_unit_size(prof.models)
    if B < 2 * max_unit:
        res.update(state="failed", message="A lemez foglalási egysége túl kicsi ehhez a módszerhez.")
        return res
    t0 = time.time()
    chain = DiskChain(src, ix, k0, mdat_start, mdat_end, prof.models, prof.transitions, max_unit, claimed,
                      log=log, cancel=cancel, progress=progress)
    extents = chain.run()
    blocks = chain.blocks
    have = sum(e - s for s, e in extents)
    res["clusters"] = len(blocks)
    res["chain_seconds"] = round(time.time() - t0, 1)
    complete = False
    moov_size = 0
    if mdat_end is not None and have >= mdat_end:
        if size is not None and (mdat_end >= size or have >= size):
            complete = True
        else:
            # the index (moov) after the recording: find the cluster(s) that hold the rest of it
            v = BlockView(src, extents)
            moov_size = _moov_ok(v, mdat_start, mdat_end, size)
            if moov_size:
                complete = True
            else:
                found = None
                cur = blocks[-1]
                cands = [k for k in range(cur + 1, min(ix.count, cur + 2048)) if not chain.skip(k)]
                cands += [k for k in range(cur - 1, max(-1, cur - 257), -1) if not chain.skip(k)]
                for k in cands:
                    if cancel and cancel():
                        raise InterruptedError
                    v2 = BlockView(src, extents + [(ix.pos(k), ix.pos(k) + B)])
                    moov_size = _moov_ok(v2, mdat_start, mdat_end, size)
                    if moov_size:
                        found = k
                        break
                if found is not None:
                    extents = extents + [(ix.pos(found), ix.pos(found) + B)]
                    blocks.append(found)
                    complete = True
                else:
                    log("%s: a felvétel megvan, de az indexét (moov) nem találtam meg." % name)
    if size is None:
        # carved: the file ends after its moov, or where the recording stopped
        if complete:
            size = mdat_end + moov_size
            v = BlockView(src, extents)
            ext = ".MOV" if b"qt  " in bytes(first[8:12]) else ".MP4"
            name = _creation_name(v[mdat_end:mdat_end + min(moov_size, 1 << 20)], k0, ext)
        else:
            size = have if mdat_end is None else min(have, mdat_end)
        res["size"] = size
        res["name"] = name
    if mdat_end is None:
        mdat_end = size
    # trim to the file size
    out_ext = []
    total = 0
    for s, e in extents:
        if total >= size:
            break
        e = min(e, s + (size - total))
        out_ext.append((s, e))
        total += e - s
    for k in blocks:
        claimed.add(k)
    res["cluster_list"] = list(blocks)
    base, ext = os.path.splitext(name)
    if complete and total == size:
        out_path = os.path.join(out_dir, name)
        copy_extents(src, out_ext, out_path, cancel=cancel)
        res.update(state="complete", output=out_path, bytes=total,
                   message="Az eredeti fájl teljes egészében visszaállt (%d darabból)." % len(blocks))
    else:
        out_path = os.path.join(out_dir, base + "_resz" + ext)
        copy_extents(src, out_ext, out_path, cancel=cancel)
        res.update(state="partial", output=out_path, bytes=total,
                   message="A felvételnek %.0f%%-a került elő (%d darab); a hiányzó rész nincs meg a lemezen."
                           % (100.0 * min(total, mdat_end) / max(1, mdat_end), len(blocks)))
    res["blocks"] = _runs(blocks)
    return res


def _runs(blocks: List[int]) -> str:
    runs = []
    for b in blocks:
        if runs and runs[-1][1] == b - 1:
            runs[-1][1] = b
        else:
            runs.append([b, b])
    txt = ", ".join(("%d" % a) if a == b else ("%d-%d" % (a, b)) for a, b in runs)
    return txt if len(txt) < 2000 else txt[:2000] + " …"


# ---------------------------------------------------------------------------
# The whole job
# ---------------------------------------------------------------------------

class DiskRecovery:
    """Survey the disk, index it, locate the recovered files and rebuild them.

    job = {"device": path, "output": dir, "sources": [dirs or files], "references": [files],
           "block": optional cluster size, "origin": optional, "only": optional list of names}
    Progress and results are written to <output>/futurerepair_lemez_allapot.json.
    """

    STATUS = "futurerepair_lemez_allapot.json"
    INDEX = "futurerepair_lemez_index.bin"

    def __init__(self, job: Dict, cancel=None):
        self.job = job
        self.out = job["output"]
        os.makedirs(self.out, exist_ok=True)
        self.cancel = cancel
        self.status: Dict = {"state": "starting", "phase": "", "progress": 0.0, "started": time.time(),
                             "device": job.get("device"), "files": [], "log": []}
        self._last_write = 0.0

    # status ---------------------------------------------------------------
    def log(self, msg: str) -> None:
        line = "[%s] %s" % (time.strftime("%H:%M:%S"), msg)
        self.status["log"].append(line)
        self.status["log"] = self.status["log"][-400:]
        # lines ever written: the window above keeps only the last 400, a reader that counted the
        # list's length would stop seeing new lines once it is full
        self.status["log_n"] = int(self.status.get("log_n") or 0) + 1
        self.write_status(force=True)

    def phase(self, name: str, progress: float = 0.0) -> None:
        self.status["phase"] = name
        self.status["progress"] = progress
        self.status.pop("detail", None)
        self.write_status(force=True)

    def detail(self, text: str) -> None:
        """What a long step is doing right now (a search through the disk): shown under the phase,
        and keeps the status fresh so nobody thinks it stopped."""
        self.status["detail"] = text
        self.write_status()

    def set_progress(self, x: float) -> None:
        self.status["progress"] = round(float(x), 4)
        self.write_status()

    def write_status(self, force: bool = False) -> None:
        now = time.time()
        if not force and now - self._last_write < 2:
            return
        self._last_write = now
        self.status["updated"] = now
        tmp = os.path.join(self.out, self.STATUS + ".part")
        try:
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(self.status, f, ensure_ascii=False, indent=1)
            os.replace(tmp, os.path.join(self.out, self.STATUS))
            owner = self.job.get("owner")
            if owner and hasattr(os, "geteuid") and os.geteuid() == 0:
                os.chown(os.path.join(self.out, self.STATUS), int(owner[0]), int(owner[1]))
        except OSError:
            pass

    def _give_back(self) -> None:
        """On macOS/Linux the job runs as root: hand what it made back to the user who started it."""
        owner = self.job.get("owner")
        if not owner or not hasattr(os, "geteuid") or os.geteuid() != 0:
            return
        uid, gid = int(owner[0]), int(owner[1])
        for dp, dn, fn in os.walk(self.out):
            for n in [dp] + [os.path.join(dp, x) for x in fn]:
                try:
                    os.chown(n, uid, gid)
                except OSError:
                    pass

    # steps ------------------------------------------------------------------
    def run(self) -> Dict:
        try:
            self.status["state"] = "running"
            self._run()
            if self.status["state"] not in ("cancelled",):
                self.status["state"] = "done"
        except InterruptedError:
            self.status["state"] = "cancelled"
            self.log("Leállítva.")
        except Exception as e:  # noqa: BLE001
            self.status["state"] = "error"
            self.status["error"] = str(e)
            self.log("HIBA: %s" % e)
            self.status["traceback"] = traceback.format_exc()[-4000:]
        self.status["finished"] = time.time()
        self._give_back()
        self.write_status(force=True)
        return self.status

    def _protect(self) -> None:
        """Windows: mark the disk read-only before anything else (needs administrator rights)."""
        import re as _re
        import sys as _sys
        if not _sys.platform.startswith("win") or not self.job.get("protect", True):
            return
        m = _re.search(r"physicaldrive(\d+)", self.job["device"].lower())
        if not m:
            return
        from . import winsys
        n = int(m.group(1))
        sysd = winsys.system_disk()
        if sysd is not None and n == sysd:
            raise RuntimeError("Ez a rendszerlemez (C:) – ezt nem vizsgálom.")
        out = winsys.set_disk_readonly(n, True)
        state = winsys.disk_readonly_state(out)
        self.status["disk_readonly"] = state
        self.log("A %d. lemez írásvédett lett (Windows): %s" % (n, {True: "igen", False: "NEM", None: "?"}[state]))

    def _previous(self) -> Dict[str, Dict]:
        """Results of an earlier run of the same job (to continue where it stopped)."""
        p = os.path.join(self.out, self.STATUS)
        try:
            with open(p, encoding="utf-8") as f:
                old = json.load(f)
        except (OSError, ValueError):
            return {}
        done = {}
        for r in old.get("files", []):
            if r.get("state") in ("complete", "partial") and r.get("output") and os.path.exists(r["output"]):
                done[r.get("path") or "c%s" % r.get("cluster")] = r
        return done

    def _check_output(self) -> None:
        import re as _re
        import sys as _sys
        if not _sys.platform.startswith("win"):
            return
        m = _re.search(r"physicaldrive(\d+)", self.job["device"].lower())
        drive = os.path.splitdrive(os.path.abspath(self.out))[0]
        if m and _re.fullmatch(r"[A-Za-z]:", drive or ""):
            from . import winsys
            if winsys.disk_number_of_letter(drive[0]) == int(m.group(1)):
                raise RuntimeError("A célmappa ugyanazon a lemezen van, amit helyreállítunk – válassz másik meghajtót!")

    def _run(self) -> None:
        job = self.job
        self._check_output()
        previous = self._previous()
        # every file an earlier run of this job reported (state by path), before this run's status replaces it
        self.prev_files = {}
        self.prev_results = {}
        for name in (self.STATUS + ".elozo", self.STATUS):
            try:
                with open(os.path.join(self.out, name), encoding="utf-8") as f:
                    for x in json.load(f).get("files") or []:
                        if x.get("path"):
                            self.prev_files[x["path"]] = x.get("state")
                            self.prev_results[x["path"]] = x
            except (OSError, ValueError):
                pass
        self.phase("Lemez megnyitása (csak olvasás)")
        self._protect()
        src = RawSource(job["device"], cache_pages=512)
        self.src = src
        self.status["disk_size"] = src.size
        self.log("Lemez: %s, %.2f TB" % (job["device"], src.size / 1e12))
        parts = read_partitions(src)
        self.status["partitions"] = parts
        region = (0, src.size)
        if parts:
            big = max(parts, key=lambda p: p["size"])
            region = (big["start"], big["start"] + big["size"])
            fsi = fs_info(src, big["start"])
            self.status["filesystem_now"] = fsi
            self.log("Partíció: %d – %d, a mostani fájlrendszer: %s" % (region[0], region[1], fsi.get("type")))
        if job.get("mode") == "scan" or "#scan" in (job.get("only") or []):
            # survey + complete listing in one go (what the program's disk page starts with)
            from .diagnose import ENTRIES_FILE, run_survey
            from .entryrecover import run_tree
            sv = run_survey(self, src, region)
            if not sv.get("layout"):
                raise RuntimeError("A régi fájlrendszer nyomait nem találtam meg ezen a lemezen (a régi "
                                   "mappabejegyzések hiányoznak), így a fájlok név szerint nem hozhatók vissza.")
            job["entries_file"] = os.path.join(self.out, ENTRIES_FILE)
            run_tree(self, src, region)
            return
        if job.get("mode") == "survey" or "#survey" in (job.get("only") or []):
            from .diagnose import run_survey
            run_survey(self, src, region)
            return
        if job.get("mode") == "tree" or "#tree" in (job.get("only") or []):
            from .entryrecover import run_tree
            run_tree(self, src, region)
            if "#entries" not in (job.get("only") or []):
                return
            # listing first, then restore from the complete list
            from .diagnose import ENTRIES_FILE
            job["entries_file"] = os.path.join(self.out, ENTRIES_FILE)
        if job.get("mode") == "entries" or "#entries" in (job.get("only") or []):
            from .entryrecover import run_entries
            run_entries(self, src, region)
            return
        # grid ---------------------------------------------------------------
        index_path = os.path.join(self.out, self.INDEX)
        ix = None
        if os.path.exists(index_path):
            try:
                ix = DiskIndex.load(index_path)
                if ix.meta.get("device_size") != src.size:
                    ix = None
                else:
                    self.log("Korábbi index folytatása: %d / %d egység kész." % (ix.done, ix.count))
            except Exception:  # noqa: BLE001
                ix = None
        if ix is None:
            B, origin = job.get("block"), job.get("origin")
            if not B or origin is None:
                self.phase("Foglalási rács keresése")
                B, origin = self._detect_grid(src, region)
            first = (region[0] - origin + B - 1) // B if region[0] > origin else 0
            origin = origin + first * B
            count = (region[1] - origin) // B
            ix = DiskIndex(origin, B, count)
            self.log("Foglalási egység: %d MB, rács kezdete: %d, egységek: %d" % (B >> 20, origin, count))
        self.status["grid"] = {"block": ix.B, "origin": ix.origin, "count": ix.count}
        if job.get("mode") == "carve":
            self.ix = ix
            self._carve(src, ix, index_path, previous)
            return
        # index --------------------------------------------------------------
        if ix.done < ix.count:
            self.phase("A lemez átvizsgálása (minden %d MB-os egység eleje)" % (ix.B >> 20), ix.done / float(ix.count))
            t0 = time.time()
            build_index(src, ix, index_path, meta={"device_size": src.size}, progress=self.set_progress,
                        cancel=self.cancel, log=self.log, opener=lambda: RawSource(job["device"], cache_pages=4),
                        threads=4)
            self.log("A lemez átvizsgálása %.0f perc alatt kész." % ((time.time() - t0) / 60))
            if ix.done < ix.count:
                raise InterruptedError
        self.ix = ix
        nz = sum(1 for f in ix.flags if f & F_ZERO)
        ns = sum(1 for f in ix.flags if f & F_START)
        nm = sum(1 for f in ix.flags if f & F_MP4)
        self.log("Index kész: %d egység, ebből üres %d, fájl eleje %d (videó %d)." % (ix.count, nz, ns, nm))
        # files ----------------------------------------------------------------
        self.phase("A visszahozott fájlok átnézése")
        files = self._collect(job.get("sources") or [])
        only = set(n.lower() for n in (job.get("only") or []))
        if only:
            files = [p for p in files if os.path.basename(p).lower() in only]
        healthy, broken = self._classify(files)
        refs = list(job.get("references") or []) + healthy
        self.log("Videók: %d, ebből ép %d, sérült %d." % (len(files), len(healthy), len(broken)))
        entries = []
        for i, p in enumerate(broken):
            self.set_progress(i / float(max(1, len(broken))))
            k0, n, probed = locate_on_disk(ix, p)
            rec = {"name": os.path.basename(p), "path": p, "size": os.path.getsize(p)}
            if k0 is None:
                rec.update(state="not_found", message="Nem találtam meg a lemezen.")
                self.status["files"].append(rec)
                continue
            rec.update(k0=k0, matched=n, probed=probed)
            entries.append(rec)
        entries.sort(key=lambda r: r["k0"])
        self.log("Lemezen megtalálva: %d / %d sérült fájl." % (len(entries), len(broken)))
        # rebuild ---------------------------------------------------------------
        claimed: set = set()
        for r in previous.values():
            claimed.update(r.get("cluster_list") or [])
        for i, rec in enumerate(entries):
            if self.cancel and self.cancel():
                raise InterruptedError
            if rec["path"] in previous:
                rec = previous[rec["path"]]
                self.status["files"].append(rec)
                self.log("%s: már kész egy korábbi futásból." % rec["name"])
                continue
            need = rec["size"] + (64 << 20)
            try:
                free = shutil.disk_usage(self.out).free
            except OSError:
                free = need
            if free < need:
                raise RuntimeError("Elfogyott a hely a célmappában (%s) – szabadíts fel helyet, majd indítsd újra; "
                                   "a kész fájlokat nem kezdi újra." % self.out)
            self.phase("Összerakás: %s (%d / %d)" % (rec["name"], i + 1, len(entries)), 0.0)
            ref = self._pick_reference(rec["path"], refs)
            if ref is None:
                rec.update(state="no_reference", message="Nincs hozzá illő ép mintafájl (ugyanarról a kameráról).")
                self.status["files"].append(rec)
                continue
            prof = self._profile(ref)
            rec["reference"] = ref
            try:
                out_dir = self._out_dir_for(rec["path"])
                res = recover_one(src, ix, rec, prof, claimed, out_dir, self.log, cancel=self.cancel,
                                  progress=self.set_progress)
                rec.update(res)
                if res.get("state") == "complete":
                    refs.insert(0, res["output"])          # a rebuilt original is a good sample too
                if res.get("state") == "partial":
                    self._repair_partial(rec, ref)
            except InterruptedError:
                raise
            except Exception as e:  # noqa: BLE001
                rec.update(state="error", message=str(e))
            self.log("%s: %s" % (rec["name"], rec.get("message", rec.get("state"))))
            self.status["files"].append(rec)
            self.write_status(force=True)
        self.status["summary"] = {
            "complete": sum(1 for r in self.status["files"] if r.get("state") == "complete"),
            "partial": sum(1 for r in self.status["files"] if r.get("state") == "partial"),
            "other": sum(1 for r in self.status["files"] if r.get("state") not in ("complete", "partial")),
        }

    # carving: find the recordings on the disk itself -----------------------------
    def _score_view(self, view, start: int, end: int, prof) -> float:
        from ..video.scanner import Scanner
        if prof is None or end <= start:
            return 0.0
        sc = Scanner(view, start, end, prof.models, prof.transitions)
        sc.run()
        covered = sum(c.end - c.start for _mi, c in sc.order)
        return covered / float(end - start)

    def _carve(self, src, ix: DiskIndex, index_path: str, previous: Dict[str, Dict]) -> None:
        job = self.job
        limit = int(job.get("max_files") or 0)
        refs = list(job.get("references") or [])
        claimed: set = set()
        done_k0 = set()
        for r in previous.values():
            claimed.update(r.get("cluster_list") or [])
            if r.get("cluster") is not None:
                done_k0.add(r["cluster"])
                self.status["files"].append(r)
        refs = [r["output"] for r in previous.values() if r.get("state") == "complete"] + refs
        made = sum(1 for r in previous.values() if r.get("state") in ("complete", "partial"))
        skipped_profiles = 0
        chunk = max(1024, int((128 << 30) // ix.B))          # index 128 GB at a time
        scanned = 0
        B = ix.B
        while True:
            if self.cancel and self.cancel():
                raise InterruptedError
            if limit and made >= limit:
                break
            if ix.done < ix.count:
                self.phase("A lemez átvizsgálása: %.1f%% (%d / %d egység)"
                           % (100.0 * ix.done / ix.count, ix.done, ix.count), ix.done / float(ix.count))
                build_index(src, ix, index_path, meta={"device_size": src.size}, progress=self.set_progress,
                            cancel=self.cancel, log=self.log,
                            opener=lambda: RawSource(job["device"], cache_pages=4), threads=4,
                            stop_at=ix.done + chunk)
            starts = [k for k in range(scanned, ix.done) if ix.flags[k] & F_MP4]
            scanned = ix.done
            for k0 in starts:
                if self.cancel and self.cancel():
                    raise InterruptedError
                if limit and made >= limit:
                    break
                if k0 in claimed or k0 in done_k0:
                    continue
                first = BlockView(src, [(ix.pos(k0), ix.pos(k0) + B)])
                hdr = parse_header(first, B)
                if "mdat_start" not in hdr:
                    continue
                mend = hdr.get("mdat_end")
                if mend is not None and mend <= B:
                    continue                      # fits in one unit: nothing to put together
                # which camera/settings? score the start of the recording against the samples
                best, best_s = None, 0.0
                for ref in refs[:24]:
                    sc = self._score_view(first, hdr["mdat_start"], B, self._profile(ref))
                    if sc > best_s:
                        best, best_s = ref, sc
                    if sc >= 0.9:
                        break
                if best is None or best_s < 0.5:
                    skipped_profiles += 1
                    self.status["skipped_no_reference"] = skipped_profiles
                    continue
                self.phase("Összerakás: %d. egységnél kezdődő felvétel (%d. a próbából)" % (k0, made + 1), 0.0)
                rec = {"cluster": k0, "k0": k0, "path": None, "reference": best}
                out_dir = self.out
                try:
                    res = recover_one(src, ix, rec, self._profile(best), claimed, out_dir, self.log,
                                      cancel=self.cancel, progress=self.set_progress)
                    rec.update(res)
                    if res.get("state") == "complete":
                        refs.insert(0, res["output"])
                    elif res.get("state") == "partial":
                        self._repair_partial(rec, best)
                except InterruptedError:
                    raise
                except Exception as e:  # noqa: BLE001
                    rec.update(state="error", message=str(e), name="c%d" % k0)
                if rec.get("state") in ("complete", "partial"):
                    made += 1
                self.log("%s: %s" % (rec.get("name"), rec.get("message", rec.get("state"))))
                self.status["files"].append(rec)
                self.write_status(force=True)
            if ix.done >= ix.count:
                break
        self.status["summary"] = {
            "complete": sum(1 for r in self.status["files"] if r.get("state") == "complete"),
            "partial": sum(1 for r in self.status["files"] if r.get("state") == "partial"),
            "no_matching_sample": skipped_profiles,
            "indexed": "%d / %d" % (ix.done, ix.count),
        }
        self.log("Kész: %d teljes, %d részleges felvétel; %d videókezdethez nem volt illő minta. "
                 "Átvizsgálva a lemez %.1f%%-a." % (self.status["summary"]["complete"],
                                                    self.status["summary"]["partial"], skipped_profiles,
                                                    100.0 * ix.done / ix.count))

    def _repair_partial(self, rec: Dict, ref: str) -> None:
        """A partial original has no index: rebuild a playable file from it with the sample."""
        from ..video.repair import repair_video
        from ..result import Reporter
        src_path = rec["output"]
        base, ext = os.path.splitext(src_path)
        out = base + "_javitott" + ext
        r = repair_video(src_path, ref, out, reporter=Reporter())
        if r.output:
            d = r.details or {}
            rec["playable"] = r.output
            rec["message"] = rec.get("message", "") + " Lejátszható változat: %s (%.0f mp)." % (
                os.path.basename(r.output), d.get("video_seconds", 0))
        else:
            rec["message"] = rec.get("message", "") + " A lejátszható változat elkészítése nem sikerült: %s" % r.message

    def _detect_grid(self, src, region) -> Tuple[int, int]:
        """Allocation unit B and its alignment r: files start on the grid r + k*B.

        1) read sample regions spread over the disk and note where files start (headers);
        2) every candidate grid (from those starts, the file system data and common alignments)
           is scored by reading a sector at ~1500 grid points: on the right grid a share of
           them are file starts, on a wrong one almost none."""
        a, b = region
        span = b - a
        known_B = self.job.get("block")
        hits: List[int] = []
        kinds: Dict[int, str] = {}
        win = 256 << 20
        order = [0, 12, 6, 18, 3, 9, 15, 21, 1, 13, 7, 19, 4, 10, 16, 22, 2, 14, 8, 20, 5, 11, 17, 23]
        rounds = 0
        for rnd in range(4):                       # up to 96 regions (24 GB)
            regs = []
            for i in order:
                s = a + (span * (i * 4 + rnd)) // 96
                s -= s % 4096
                regs.append((s, min(b, s + win)))
            hits += find_file_starts(src, regs, progress=lambda x, r=rnd: self.set_progress((r + x) / 8.0),
                                     cancel=self.cancel, kinds=kinds)
            rounds += 1
            B0, r0, info = detect_grid(hits, [known_B] if known_B else None)
            if B0 and info.get("hits", 0) >= 12:
                break
        self.log("Fájlkezdetek a mintákban: %d (%d GB átolvasva)" % (len(hits), rounds * 24 * win >> 30))
        sizes = [known_B] if known_B else [1 << k for k in range(25, 16, -1)]
        mp4 = [p for p in hits if kinds.get(p) == "mp4"]
        # Every candidate costs a few hundred random reads: only the alignments that many file
        # starts share (and those of the file system) are tried.
        cands = set()
        fsi = self.status.get("filesystem_now") or {}
        for B in sizes:
            for group in (mp4, hits):
                for r, _n in Counter(p % B for p in group).most_common(6):
                    cands.add((B, r))
            for base in (a, fsi.get("heap") or a, 0, 1 << 20):
                cands.add((B, base % B))
        kc = Counter(kinds.values())
        self.log("Fájlkezdetek fajtái: %s; kipróbált rácsok: %d" % (
            ", ".join("%s %d" % kv for kv in kc.most_common()), len(cands)))
        dens: Dict[Tuple[int, int], Tuple[float, int]] = {}

        def density(B, r):
            key = (B, r % B)
            if key not in dens:
                h, n = score_grid(src, B, r % B, a, b, n=400)
                dens[key] = (h / float(n) if n else 0.0, h)
            return dens[key]
        for i, (B, r) in enumerate(sorted(cands, key=lambda c: (-c[0], c[1]))):
            if self.cancel and self.cancel():
                raise InterruptedError
            density(B, r)
            self.set_progress(0.5 + 0.5 * (i + 1) / max(1, len(cands)))
        # The allocation unit is the largest B whose best grid has file starts, while the grid
        # shifted by B/2 has (almost) none - if both halves have them, files start on a finer grid.
        chosen = None
        for B in sorted({c[0] for c in cands}, reverse=True):
            d, h, r = max((dens[(bb, rr)][0], dens[(bb, rr)][1], rr) for (bb, rr) in dens if bb == B)
            if h < 3:
                continue
            dh, _hh = density(B, r + B // 2)
            if dh < 0.25 * d:
                chosen = (B, r, h)
                break
        self.status["grid_detect"] = {"hits": len(hits),
                                      "scores": sorted(((v[1], k[0], k[1]) for k, v in dens.items()), reverse=True)[:8]}
        if chosen is None:
            raise RuntimeError("Nem sikerült megállapítani a lemez foglalási egységét (fájlkezdetek: %d)." % len(hits))
        B, r, h = chosen
        self.log("Foglalási rács: %d KB, eltolás %d (fájlkezdet a mintapontokon: %d)" % (B >> 10, r, h))
        return B, r

    def _collect(self, sources: List[str]) -> List[str]:
        out = []
        for s in sources:
            if os.path.isfile(s):
                out.append(s)
                continue
            if not os.path.isdir(s):
                raise RuntimeError("Nem érem el ezt a mappát: %s (a rendszergazdaként futó folyamat a hálózati "
                                   "meghajtóbetűjeleket nem látja – UNC útvonal kell, pl. \\\\192.168.0.21\\...)" % s)
            for dp, dn, fn in os.walk(s):
                dn.sort()
                for f in sorted(fn):
                    if os.path.splitext(f)[1].lower() in VIDEO_EXT and not f.startswith("."):
                        out.append(os.path.join(dp, f))
        return out

    def _classify(self, files: List[str]):
        from ..suggest import video_is_healthy
        healthy, broken = [], []
        for i, p in enumerate(files):
            self.set_progress(i / float(max(1, len(files))))
            try:
                ok = video_is_healthy(p)
            except Exception:  # noqa: BLE001
                ok = False
            if ok and os.path.getsize(p) > self.ix.B:
                ok = self._content_ok(p)
            (healthy if ok else broken).append(p)
        return healthy, broken

    def _content_ok(self, path: str) -> bool:
        """A file with an index can still contain other files' data in the middle."""
        try:
            from ..video.verify import deep_verify
            r = deep_verify(path, points=5, frames_per_point=2)
            return bool(r.get("ok"))
        except Exception:  # noqa: BLE001
            return False

    def _profile(self, ref: str):
        cache = self.__dict__.setdefault("_profiles", {})
        if ref not in cache:
            from ..video.analyze import build_profile
            try:
                cache[ref] = build_profile(ref)
            except Exception:  # noqa: BLE001
                cache[ref] = None
        return cache[ref]

    def _score(self, broken: str, ref: str, probe: int = 24 << 20) -> float:
        """Share of the start of the broken file's recording that the sample's model explains."""
        import mmap
        from ..video.analyze import read_layout
        from ..video.scanner import Scanner
        prof = self._profile(ref)
        if prof is None:
            return 0.0
        try:
            lay = read_layout(broken)
        except Exception:  # noqa: BLE001
            return 0.0
        start = max(0, lay.mdat_start)
        end = min(lay.mdat_end if lay.mdat_end > 0 else lay.size, start + probe)
        if end <= start:
            return 0.0
        with open(broken, "rb") as f:
            mm = mmap.mmap(f.fileno(), 0, access=mmap.ACCESS_READ)
            try:
                sc = Scanner(mm, start, end, prof.models, prof.transitions)
                sc.run()
                covered = sum(c.end - c.start for _mi, c in sc.order)
            finally:
                mm.close()
        return covered / float(end - start)

    def _pick_reference(self, broken: str, refs: List[str]) -> Optional[str]:
        if not refs:
            return None
        folder = os.path.dirname(broken)
        ordered = sorted(refs, key=lambda r: (os.path.dirname(r) != folder,))
        best, best_s = None, 0.0
        for r in ordered[:16]:
            s = self._score(broken, r)
            if s > best_s:
                best, best_s = r, s
            if s >= 0.9:
                break
        return best if best_s >= 0.5 else None

    def _out_dir_for(self, path: str) -> str:
        """Keep the folder structure below the source folder."""
        for s in self.job.get("sources") or []:
            s = os.path.abspath(s)
            ap = os.path.abspath(path)
            if os.path.isdir(s) and ap.startswith(s.rstrip("\\/") + os.sep):
                rel = os.path.relpath(os.path.dirname(ap), s)
                d = os.path.join(self.out, os.path.basename(s.rstrip("\\/")) or "forras", rel)
                os.makedirs(d, exist_ok=True)
                return d
        return self.out


def main_readonly(number: str, mode: str, result_path: str) -> int:
    """Elevated helper: set/clear the Windows read-only flag of a disk, write the result to a file."""
    from . import winsys
    try:
        out = winsys.set_disk_readonly(int(number), mode == "on")
        st = winsys.disk_readonly_state(out)
        txt = {"ok": True, "readonly": st, "output": out[-2000:]}
    except Exception as e:  # noqa: BLE001
        txt = {"ok": False, "error": str(e)}
    with open(result_path, "w", encoding="utf-8") as f:
        json.dump(txt, f, ensure_ascii=False)
    return 0 if txt.get("ok") else 1


def main_worker(job_path: str) -> int:
    with open(job_path, encoding="utf-8") as f:
        job = json.load(f)
    stop_file = os.path.join(job["output"], "futurerepair_lemez_STOP")

    def cancel():
        return os.path.exists(stop_file)
    st = DiskRecovery(job, cancel=cancel).run()
    return 0 if st.get("state") == "done" else 1
