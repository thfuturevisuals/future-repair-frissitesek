"""Disk survey: partitions, file system, allocation grid and a per-cluster index.

The index stores, for every allocation unit ("cluster") of the grid, a hash of its first 64 KB
and a few flags (all zero, looks like the start of a file). Matching the 32 MB pieces of the
files a recovery tool produced against this index tells where on the disk every piece came from.
"""
from __future__ import annotations

import array
import hashlib
import json
import os
import re
import struct
import time
from collections import Counter
from typing import Callable, Dict, List, Optional, Tuple

HEAD = 64 * 1024

F_ZERO = 1          # head is all zero
F_START = 2         # head looks like the start of a file (MP4/MOV, JPEG, ...)
F_MP4 = 4           # ... an MP4/MOV header in particular
F_READERR = 8       # could not be read

# file signatures searched at sector-aligned positions to find where files start
_SIG = re.compile(
    rb"(?s)(?:\x00\x00\x00[\x10-\xff]ftyp)"          # MP4 / MOV / CR3 / HEIC
    rb"|(?:\x00\x00\x00[\x08-\xff](?:moov|wide|mdat)[\x00-\xff]{4}(?:ftyp|mdat|moov|free|wide))"
    rb"|(?:\xff\xd8\xff[\xe0\xe1\xdb\xee])"           # JPEG
    rb"|(?:\x89PNG\r\n\x1a\n)"
    rb"|(?:%PDF-1\.)"
    rb"|(?:RIFF....(?:WAVE|AVI ))"
    rb"|(?:\x06\x0e\x2b\x34\x02\x05\x01\x01)"         # MXF
    rb"|(?:8BPS\x00[\x01\x02])"                        # PSD
    rb"|(?:PK\x03\x04)"
)


def head_flags(head: bytes) -> int:
    f = 0
    if not head.strip(b"\x00"):
        return F_ZERO
    if head[4:8] == b"ftyp" and 8 <= int.from_bytes(head[:4], "big") <= 512:
        f |= F_START | F_MP4
    elif head[4:8] in (b"wide", b"mdat", b"moov", b"free") and head[12:16] in (b"ftyp", b"mdat", b"moov", b"free", b"wide"):
        f |= F_START | F_MP4
    elif _SIG.match(head[:64]):
        f |= F_START
    return f


def head_hash(head: bytes) -> int:
    return int.from_bytes(hashlib.blake2b(head, digest_size=8).digest(), "little")


# ---------------------------------------------------------------------------
# Partitions and file systems
# ---------------------------------------------------------------------------

def read_partitions(src) -> List[Dict]:
    """GPT or MBR partitions: [{'start', 'size', 'type', 'name'}] (bytes)."""
    parts = []
    for ss in (512, 4096):
        hdr = src.read(ss, 92)
        if hdr[:8] == b"EFI PART":
            entries_lba, n, esz = struct.unpack_from("<QII", hdr, 72)
            tbl = src.read(entries_lba * ss, n * esz)
            for i in range(n):
                e = tbl[i * esz:(i + 1) * esz]
                if len(e) < 128 or not e[:16].strip(b"\x00"):
                    continue
                first, last = struct.unpack_from("<QQ", e, 32)
                name = e[56:128].decode("utf-16-le", "replace").rstrip("\x00")
                parts.append({"start": first * ss, "size": (last - first + 1) * ss,
                              "type": _guid(e[:16]), "name": name, "sector": ss})
            return parts
    mbr = src.read(0, 512)
    if mbr[510:512] == b"\x55\xaa":
        for i in range(4):
            e = mbr[446 + 16 * i:446 + 16 * (i + 1)]
            typ = e[4]
            lba, cnt = struct.unpack_from("<II", e, 8)
            if typ and cnt:
                parts.append({"start": lba * 512, "size": cnt * 512, "type": "0x%02x" % typ, "name": "", "sector": 512})
    return parts


def _guid(b: bytes) -> str:
    a, b1, c = struct.unpack_from("<IHH", b, 0)
    return "%08x-%04x-%04x-%s-%s" % (a, b1, c, b[8:10].hex(), b[10:16].hex())


def fs_info(src, start: int) -> Dict:
    bs = src.read(start, 4096)
    info: Dict = {"type": "unknown"}
    if bs[3:11] == b"EXFAT   ":
        (part_off, vol_len, fat_off, fat_len, heap_off, count, root) = struct.unpack_from("<QQIIIII", bs, 64)
        bps = 1 << bs[108]
        spc = 1 << bs[109]
        info.update(type="exFAT", cluster=bps * spc, heap=start + heap_off * bps, clusters=count,
                    sector=bps, root_cluster=root, fat=start + fat_off * bps, fat_len=fat_len * bps)
    elif bs[3:11] == b"NTFS    ":
        bps = struct.unpack_from("<H", bs, 11)[0]
        spc = bs[13]
        spc = 1 << (256 - spc) if spc > 0x80 else spc
        info.update(type="NTFS", cluster=bps * spc, heap=start, sector=bps)
    elif bs[82:90] == b"FAT32   ":
        info.update(type="FAT32")
    else:
        sb = src.read(start + 1024, 1024)
        if sb[56:58] == b"\x53\xef":
            info.update(type="ext4")
        elif sb[0:2] in (b"H+", b"HX"):
            info.update(type="HFS+")
        elif bs[32:36] == b"NXSB":
            info.update(type="APFS")
        elif src.read(start + 0x10040, 8) == b"_BHRfS_M":
            info.update(type="Btrfs")
    return info


# ---------------------------------------------------------------------------
# Allocation grid
# ---------------------------------------------------------------------------

# (literal searched for, its offset from the start of the file)
_QUICK = [(b"ftyp", 4, "mp4"), (b"\xff\xd8\xff", 0, "jpeg"), (b"\x89PNG\r\n\x1a\n", 0, "png"),
          (b"%PDF-", 0, "pdf"), (b"RIFF", 0, "riff"), (b"8BPS", 0, "psd"), (b"PK\x03\x04", 0, "zip"),
          (b"\x06\x0e\x2b\x34\x02\x05\x01\x01", 0, "mxf")]


def _starts_in(buf: bytes, base: int, align: int, kinds: Optional[Dict[int, str]] = None,
               limit: Optional[int] = None) -> List[int]:
    out = []
    limit = len(buf) if limit is None else limit
    for lit, back, kind in _QUICK:
        i = buf.find(lit)
        while i != -1:
            p = i - back
            if 0 <= p < limit and (base + p) % align == 0 and head_flags(buf[p:p + 64]) & F_START:
                out.append(base + p)
                if kinds is not None:
                    kinds[base + p] = kind
            i = buf.find(lit, i + 1)
    return out


def scan_regions(src, regions: List[Tuple[int, int]], visit: Callable[[bytes, int, int], None],
                 progress: Optional[Callable[[float], None]] = None, cancel=None,
                 step: int = 16 << 20, overlap: int = 4096) -> None:
    """Read the regions in big pieces and call visit(buf, base, n) for each; buf holds `overlap`
    extra bytes past n so that something starting near the end can still be parsed. The next
    piece is read while the current one is being looked at."""
    from concurrent.futures import ThreadPoolExecutor
    total = sum(b - a for a, b in regions) or 1
    pieces = []
    for a, b in regions:
        pos = a
        while pos < b:
            n = min(step, b - pos)
            pieces.append((pos, n))
            pos += n

    def rd(pn):
        pos, n = pn
        m = min(n + overlap, src.size - pos)
        try:
            return src.read_direct(pos, m)
        except OSError:
            return b""
    done = 0
    with ThreadPoolExecutor(max_workers=1) as pool:
        fut = pool.submit(rd, pieces[0]) if pieces else None
        for i, (pos, n) in enumerate(pieces):
            if cancel and cancel():
                raise InterruptedError
            buf = fut.result()
            fut = pool.submit(rd, pieces[i + 1]) if i + 1 < len(pieces) else None
            if buf:
                visit(buf, pos, min(n, len(buf)))
            done += n
            if progress:
                progress(done / total)


def find_file_starts(src, regions: List[Tuple[int, int]], align: int = 512,
                     progress: Optional[Callable[[float], None]] = None, cancel=None,
                     kinds: Optional[Dict[int, str]] = None) -> List[int]:
    """Positions (sector aligned) inside the given regions where a file seems to start."""
    hits: List[int] = []

    def visit(buf, base, n):
        hits.extend(_starts_in(buf, base, align, kinds, limit=n))
    scan_regions(src, regions, visit, progress=progress, cancel=cancel)
    return sorted(set(hits))


def residue_stats(hits: List[int], sizes: Optional[List[int]] = None) -> List[Tuple[int, int, int, int]]:
    """For every size B: (B, most common p % B, how many hits have it, all hits)."""
    sizes = sizes or [1 << k for k in range(12, 28)]
    out = []
    for B in sizes:
        if not hits:
            out.append((B, 0, 0, 0))
            continue
        r, n = Counter(p % B for p in hits).most_common(1)[0]
        out.append((B, r, n, len(hits)))
    return out


def detect_grid(hits: List[int], sizes=None) -> Tuple[Optional[int], Optional[int], Dict]:
    """Largest allocation size B (and its alignment) that most file starts sit on."""
    sizes = sizes or [1 << k for k in range(27, 15, -1)]      # 128 MiB ... 64 KiB
    info: Dict = {"hits": len(hits)}
    if len(hits) < 6:
        return None, None, info
    for B in sizes:
        c = Counter(p % B for p in hits)
        r, n = c.most_common(1)[0]
        if n >= max(6, 0.6 * len(hits)):
            info.update(share=round(n / len(hits), 3), residue=r)
            return B, r, info
    return None, None, info


# ---------------------------------------------------------------------------
# Cluster index
# ---------------------------------------------------------------------------

class DiskIndex:
    """hash + flags of the first 64 KB of every cluster k of the grid origin + k*B."""

    def __init__(self, origin: int, B: int, count: int):
        self.origin = origin
        self.B = B
        self.count = count
        self.hashes = array.array("Q", bytes(8 * count))
        self.flags = bytearray(count)
        self.done = 0               # clusters indexed so far (resumable)
        self._lookup: Optional[Dict[int, List[int]]] = None

    def pos(self, k: int) -> int:
        return self.origin + k * self.B

    def cluster_of(self, p: int) -> int:
        return (p - self.origin) // self.B

    def lookup(self, h: int) -> List[int]:
        if self._lookup is None or len(self._lookup_src) != self.done:
            d: Dict[int, List[int]] = {}
            for k in range(self.done):
                if not self.flags[k] & (F_ZERO | F_READERR):
                    d.setdefault(self.hashes[k], []).append(k)
            self._lookup = d
            self._lookup_src = range(self.done)
        return self._lookup.get(h, [])

    # persistence --------------------------------------------------------------
    def save(self, path: str, meta: Optional[Dict] = None) -> None:
        tmp = path + ".part"
        hdr = json.dumps({"origin": self.origin, "B": self.B, "count": self.count, "done": self.done,
                          "meta": meta or {}}).encode()
        with open(tmp, "wb") as f:
            f.write(b"FRIX" + struct.pack("<I", len(hdr)) + hdr)
            f.write(self.hashes.tobytes())
            f.write(bytes(self.flags))
        os.replace(tmp, path)

    @classmethod
    def load(cls, path: str) -> "DiskIndex":
        with open(path, "rb") as f:
            if f.read(4) != b"FRIX":
                raise ValueError("not an index file")
            n = struct.unpack("<I", f.read(4))[0]
            hdr = json.loads(f.read(n))
            ix = cls(hdr["origin"], hdr["B"], hdr["count"])
            ix.hashes = array.array("Q")
            ix.hashes.frombytes(f.read(8 * ix.count))
            ix.flags = bytearray(f.read(ix.count))
            ix.done = hdr["done"]
            ix.meta = hdr.get("meta", {})
        return ix


def score_grid(src, B: int, r: int, lo: int, hi: int, n: int = 1500) -> Tuple[int, int]:
    """(file starts, points read) among about n cluster heads of the grid r + k*B."""
    first = (lo - r + B - 1) // B
    last = (hi - r) // B - 1
    if last <= first:
        return 0, 0
    step = max(1, (last - first) // n)
    hits = 0
    pts = 0
    for k in range(first, last, step):
        p = r + k * B
        pts += 1
        try:
            if head_flags(src.read_direct(p, 512)) & F_START:
                hits += 1
        except OSError:
            pass
    return hits, pts


def build_index(src, ix: DiskIndex, save_path: Optional[str] = None, meta: Optional[Dict] = None,
                progress: Optional[Callable[[float], None]] = None, cancel=None,
                log: Optional[Callable[[str], None]] = None, opener: Optional[Callable[[], object]] = None,
                threads: int = 4, stop_at: Optional[int] = None) -> DiskIndex:
    """Read the head of every cluster (resumes where a previous run stopped).

    With `opener` (returns a new source) several reads run in parallel, each thread with its own
    handle - a hard disk can then reorder the requests."""
    import threading
    from concurrent.futures import ThreadPoolExecutor
    t0 = time.time()
    last_save = [t0]
    errors = [0]
    local = threading.local()

    def get_src():
        if opener is None:
            return src
        s = getattr(local, "src", None)
        if s is None:
            s = opener()
            local.src = s
        return s

    def work(k0: int, k1: int):
        s = get_src()
        out = []
        for k in range(k0, k1):
            p = ix.pos(k)
            try:
                head = s.read_direct(p, min(HEAD, s.size - p))
                out.append((k, head_hash(head), head_flags(head)))
            except OSError as e:
                out.append((k, 0, F_READERR))
                errors[0] += 1
                if log and errors[0] <= 20:
                    log("Olvasási hiba a %d. egységnél (%d. bájt): %s" % (k, p, e))
        return out

    step = 64
    nthreads = threads if opener is not None else 1
    limit = ix.count if stop_at is None else min(ix.count, stop_at)
    with ThreadPoolExecutor(max_workers=nthreads) as pool:
        k = ix.done
        while k < limit:
            if cancel and cancel():
                break
            batch = []
            for t in range(nthreads * 4):
                a = k + t * step
                if a >= limit:
                    break
                batch.append(pool.submit(work, a, min(limit, a + step)))
            res = []
            for fut in batch:
                res.extend(fut.result())
            for kk, h, f in res:
                ix.hashes[kk] = h
                ix.flags[kk] = f
            k = max(kk for kk, _h, _f in res) + 1 if res else limit
            ix.done = k
            if progress:
                progress(k / float(ix.count))
            if save_path and time.time() - last_save[0] > 60:
                ix.save(save_path, meta)
                last_save[0] = time.time()
    ix._lookup = None
    if save_path:
        ix.save(save_path, meta)
    if progress:
        progress(ix.done / float(ix.count))
    return ix
