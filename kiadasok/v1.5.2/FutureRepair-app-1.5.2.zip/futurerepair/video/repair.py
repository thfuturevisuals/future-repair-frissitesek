"""Video repair orchestration: picks a strategy and produces a playable file."""
from __future__ import annotations

import mmap
import os
import re
from collections import Counter
from typing import Callable, List, Optional

from .. import hotreload as _hotreload

# A long-running process may still hold older versions of the modules imported below.
_hotreload.refresh(importing=__name__)

from . import entries as E  # noqa: E402
from .analyze import FileLayout, Profile, RepairError, build_profile, read_layout  # noqa: E402
from .h264 import H264, build_avcc, poc_sequence as h264_poc  # noqa: E402
from .hevc import HEVC, IDR as HEVC_IDR, BLA as HEVC_BLA, IRAP as HEVC_IRAP, build_hvcc, poc_sequence as hevc_poc  # noqa: E402
from .models import AacModel, FixedModel, MJPEGModel, NalVideoModel, PcmModel, ProResModel  # noqa: E402
from .mp4 import make_box  # noqa: E402
from .fragments import BlockView, build_chain, detect_block_size, max_unit_size  # noqa: E402
from .scanner import Scanner  # noqa: E402
from .writer import OutTrack, write_file  # noqa: E402
from ..result import RepairResult, Reporter  # noqa: E402

PRORES_RATES = {1: (24000, 1001), 2: (24, 1), 3: (25, 1), 4: (30000, 1001), 5: (30, 1), 6: (50, 1),
                7: (60000, 1001), 8: (60, 1), 9: (100, 1), 10: (120000, 1001), 11: (120, 1)}


def _mode(values, default):
    if not values:
        return default
    return Counter(values).most_common(1)[0][0]


def default_output_path(broken: str, suffix: str = "_javitott") -> str:
    base, ext = os.path.splitext(broken)
    out = base + suffix + (ext or ".mp4")
    i = 2
    while os.path.exists(out):
        out = "%s%s_%d%s" % (base, suffix, i, ext or ".mp4")
        i += 1
    return out


# ---------------------------------------------------------------------------
# Timeline construction
# ---------------------------------------------------------------------------

def _presentation(pocs: List[int], epoch_start: List[bool]):
    n = len(pocs)
    slots = [0] * n
    i = 0
    while i < n:
        j = i + 1
        while j < n and not epoch_start[j]:
            j += 1
        order = sorted(range(i, j), key=lambda k: (pocs[k], k))
        for rank, k in enumerate(order):
            slots[k] = i + rank
        i = j
    delay = max((k - slots[k] for k in range(n)), default=0)
    delay = max(0, delay)
    return [slots[k] - k + delay for k in range(n)], delay


def video_track(model, sample_entry: bytes, timescale: int, frame_dur: int, ref=None,
                sync_i_frames: bool = False, rep: Optional[Reporter] = None) -> OutTrack:
    sizes, chunk_src, chunk_counts, chunk_bytes, infos = [], [], [], [], []
    for c in model.chunks:
        chunk_src.append(c.start)
        chunk_counts.append(len(c.sizes))
        chunk_bytes.append(c.end - c.start)
        sizes.extend(c.sizes)
        infos.extend(c.infos)
    n = len(sizes)
    cts = None
    media_time = 0
    sync = None
    if isinstance(model, NalVideoModel):
        codec = model.codec
        if isinstance(codec, H264):
            pocs = h264_poc(infos, codec)
            epochs = [a.idr for a in infos]
            keys = [i for i, a in enumerate(infos) if a.idr or
                    (sync_i_frames and a.slice is not None and a.slice.slice_type % 5 in (2, 4))]
        else:
            pocs = hevc_poc(infos, codec)
            epochs = [a.vcl_type in HEVC_IDR or a.vcl_type in HEVC_BLA for a in infos]
            keys = [i for i, a in enumerate(infos) if a.vcl_type in HEVC_IRAP]
        if n:
            epochs[0] = True
        if pocs is not None and n:
            offs, delay = _presentation(pocs, epochs)
            if any(o != offs[0] for o in offs) or delay:
                cts = [o * frame_dur for o in offs]
                media_time = delay * frame_dur
        elif rep:
            rep.note("A képkockák megjelenítési sorrendjét nem sikerült kiolvasni; a videó dekódolási sorrendben lesz.")
        if len(keys) < n:
            sync = keys
    return OutTrack(b"vide", timescale, sample_entry, chunk_src, chunk_counts, chunk_bytes, sizes,
                    durations=[(n, frame_dur)] if n else [], cts=cts, sync=sync, media_time=media_time, ref=ref,
                    track_id=ref.track_id if ref else 1,
                    language=ref.mdhd_language if ref else 0x55C4)


def aac_track(model: AacModel, sample_entry: bytes, timescale: int, frame_dur: int, ref=None,
              media_time: int = 0, track_id: int = 2) -> OutTrack:
    sizes, chunk_src, chunk_counts, chunk_bytes = [], [], [], []
    for c in model.chunks:
        chunk_src.append(c.start)
        chunk_counts.append(len(c.sizes))
        chunk_bytes.append(c.end - c.start)
        sizes.extend(c.sizes)
    n = len(sizes)
    return OutTrack(b"soun", timescale, sample_entry, chunk_src, chunk_counts, chunk_bytes, sizes,
                    durations=[(n, frame_dur)] if n else [], media_time=media_time, ref=ref,
                    track_id=ref.track_id if ref else track_id,
                    language=ref.mdhd_language if ref else 0x55C4)


def pcm_track(model: PcmModel, ref) -> OutTrack:
    chunk_src, chunk_counts, chunk_bytes = [], [], []
    for c in model.chunks:
        chunk_src.append(c.start)
        chunk_counts.append(c.units)
        chunk_bytes.append(c.end - c.start)
    total = sum(chunk_counts)
    dur = _mode(ref.durations[:5000], 1)
    sizes = None
    const = ref.stsz_const
    if not const:
        sizes = [model.unit] * total
    media_time = 0
    for sd, mt, _r in ref.elst:
        if mt > 0:
            media_time = mt
            break
    return OutTrack(b"soun", ref.timescale, ref.sample_entry, chunk_src, chunk_counts, chunk_bytes, sizes,
                    stsz_const=const, durations=[(total, dur)] if total else [], media_time=media_time,
                    ref=ref, track_id=ref.track_id, language=ref.mdhd_language)


# ---------------------------------------------------------------------------
# Parameter-set handling
# ---------------------------------------------------------------------------

def _patched_video_entry(model: NalVideoModel, ref_entry: bytes, rep: Reporter) -> bytes:
    """If the broken stream carries different in-band SPS/PPS, put those in the sample entry."""
    found = []
    for c in model.chunks[:2000]:
        for a in c.infos:
            if a.param_sets:
                found.extend(a.param_sets)
        if found:
            break
    if not found:
        return ref_entry
    codec = model.codec
    typ, cfg = E.video_config(ref_entry)
    if typ is None:
        return ref_entry
    cfg_nals = set()
    if typ == b"avcC":
        from .h264 import parse_avcc
        nls, sps, pps = parse_avcc(cfg)
        cfg_nals = set(sps) | set(pps)
    else:
        from .hevc import parse_hvcc
        nls, nals = parse_hvcc(cfg)
        cfg_nals = set(nals)
    if all(n in cfg_nals for n in found):
        return ref_entry
    try:
        if isinstance(codec, H264):
            sps = [n for n in found if n[0] & 0x1F == 7][:1]
            pps = [n for n in found if n[0] & 0x1F == 8]
            if not sps or not pps:
                return ref_entry
            new = build_avcc(sps, list(dict.fromkeys(pps)), codec.nls)
            s = codec.sps.get(next(iter(codec.sps)))
            w, h = (s.width, s.height) if s else (0, 0)
        else:
            vps = [n for n in found if (n[0] >> 1) & 0x3F == 32][:1]
            sps = [n for n in found if (n[0] >> 1) & 0x3F == 33][:1]
            pps = [n for n in found if (n[0] >> 1) & 0x3F == 34]
            if not sps or not pps:
                return ref_entry
            new = build_hvcc(vps, sps, list(dict.fromkeys(pps)), codec.nls)
            from .hevc import parse_sps as hp
            s = hp(sps[0])
            w, h = (s.width, s.height) if s else (0, 0)
    except Exception:  # noqa: BLE001
        return ref_entry
    rep.note("A sérült fájl saját kódolási paramétereit használtam (eltérnek a mintáétól).")
    rw, rh = E.video_dims(ref_entry)
    if w and h and (w, h) != (rw, rh):
        rep.warn("A minta felbontása (%dx%d) eltér a sérült fájlétól (%dx%d)." % (rw, rh, w, h))
    return E.replace_video_config(ref_entry, typ, new, w, h)


# ---------------------------------------------------------------------------
# Strategies
# ---------------------------------------------------------------------------

def _data_range(lay: FileLayout):
    start = lay.mdat_start if lay.mdat_start >= 0 else 0
    end = lay.mdat_end if lay.mdat_end > 0 else lay.size
    if end <= start:
        end = lay.size
    return start, end


def rebuild_with_reference(broken: str, reference: str, out_path: str, rep: Reporter,
                           progress=None, cancel=None, lay: Optional[FileLayout] = None) -> RepairResult:
    rep.step("Mintafájl elemzése…")
    prof: Profile = build_profile(reference)
    vmodels = [m for m in prof.models if m.kind == "video"]
    if not vmodels and not any(m.output for m in prof.models):
        raise RepairError("A mintafájl sávjai közül egyiket sem tudom feldolgozni (%s)." % ", ".join(prof.notes))
    for n in prof.notes:
        if n.startswith("audio_codec_unsupported"):
            rep.warn("A minta hangformátumát (%s) nem tudom visszaállítani, csak a képet." % n.split(":", 1)[1])
        if n.startswith("video_codec_unsupported"):
            raise RepairError("Ezt a videókodeket (%s) még nem támogatja a program." % n.split(":", 1)[1])
        if n == "extra_video_track":
            rep.warn("A mintában több videósáv van (pl. kétlencsés 360°-os kamera) – csak az elsőt tudom visszaállítani.")
        if n == "video_au_mismatch":
            rep.warn("A minta képkockáinak szerkezete szokatlan, a javítás pontatlan lehet.")
    lay = lay or read_layout(broken)
    start, end = _data_range(lay)
    rep.log("Adatterület: %d – %d (%.1f MB)" % (start, end, (end - start) / 1e6))
    rep.step("Sérült fájl átvizsgálása…")
    view = None
    frag = None
    max_unit = max_unit_size(prof.models)
    found_B: List[int] = []

    def on_skip(scn) -> bool:
        # Many breaks that all sit on block boundaries: the file is fragmented. Stop the plain
        # scan early (it would have to search through all the foreign data) and reassemble.
        k = len(scn.skips)
        if k >= 4 and (k <= 16 or k % 8 == 0):
            B = detect_block_size(scn.skips, scn.skip_units, start, max_unit)
            if B:
                found_B.append(B)
                return True
        return False

    def plain_scan(prog=None, callback=None) -> Scanner:
        s1 = Scanner(mm, start, end, prof.models, prof.transitions, progress=prog, cancel=cancel,
                     on_skip=callback)
        s1.run()
        return s1

    def view_scan(v, prog=None) -> Scanner:
        s2 = Scanner(v, 0, len(v), prof.models, prof.transitions, progress=prog, cancel=cancel)
        s2.run()
        return s2

    with open(broken, "rb") as f:
        mm = mmap.mmap(f.fileno(), 0, access=mmap.ACCESS_READ)
        try:
            sc = plain_scan((lambda x: progress(0.05 + 0.40 * x)) if progress else None, on_skip)
            rep.log("Átvizsgálás: %s%s" % (sc.summary(), " (megszakítva: darabolt fájl)" if sc.aborted else ""))
            B = found_B[0] if found_B else None
            if B is None and _fragment_suspect(sc, start, end):
                B = detect_block_size(sc.skips, sc.skip_units, start, max_unit)
            if sc.skips:
                rep.log("Első töréspontok: " + ", ".join(
                    "%d->%d" % (p_, q_) for p_, q_ in sc.skips[:12]))
            if B:
                rep.log("Töréspontok: %d, blokkméret: %d KB, legnagyobb egység: %d B" % (len(sc.skips), B >> 10, max_unit))
                rep.step("A fájl darabokban van – a felvétel darabjainak összerakása…")
                before = None if sc.aborted else _covered(prof.models)
                # the recording may continue past the declared end of 'mdat' (the declared size
                # counts only the recording's own bytes), so follow it up to the end of the file
                frag_end = lay.size
                if lay.moov_box is not None and lay.moov_box.start > start:
                    frag_end = lay.moov_box.start
                extents, stats = build_chain(mm, start, frag_end, B, prof.models, prof.transitions, max_unit,
                                             log=rep.log, cancel=cancel,
                                             progress=(lambda x: progress(0.10 + 0.40 * x)) if progress else None)
                v = BlockView(mm, extents)
                sc2 = view_scan(v, (lambda x: progress(0.50 + 0.10 * x)) if progress else None)
                after = _covered(prof.models)
                rep.log("Összerakás után: %s, lefedett: %s -> %d bájt (felvétel %d bájt)"
                        % (sc2.summary(), before, after, len(v)))
                use_view = False
                if before is None:
                    if after >= 0.5 * len(v):
                        use_view = True
                    else:
                        # the reassembly does not look right: compare with a full plain scan
                        sc_full = plain_scan()
                        before = _covered(prof.models)
                        if after > before:
                            sc2 = view_scan(v)
                            use_view = True
                        else:
                            sc = sc_full
                elif after > before:
                    use_view = True
                else:
                    sc = plain_scan()      # restore the chunks of the plain scan
                if use_view:
                    sc, view = sc2, v
                    frag = {"block_size": B, "extents": len(extents), "recording_bytes": len(v),
                            "file_bytes": end - start, "gaps": len(stats["gaps"]),
                            "resync": len(stats["resync"]), "blocks": len(stats["blocks"])}
            elif sc.aborted:
                sc = plain_scan()
        finally:
            mm.close()
    if cancel and cancel():
        raise InterruptedError
    summ = sc.summary()
    if frag:
        rep.note("A felvétel %s-os darabokban, más adatokkal keverve volt a fájlban; a %d saját darabot "
                 "sorrendbe raktam." % (_human_size(frag["block_size"]), frag["blocks"]))
        if frag["resync"]:
            rep.warn("%d helyen a darabok nem illeszkedtek pontosan – ott néhány képkocka hiányozhat." % frag["resync"])

    tracks: List[OutTrack] = []
    movie_ts = prof.movie.timescale or 1000
    vframes = 0
    vdur_s = 0.0
    adur_s = 0.0
    for m, ref in zip(prof.models, prof.track_of_model):
        if not m.output or not m.chunks:
            continue
        if m.kind == "video":
            frame_dur = _mode(ref.durations[:5000], 1)
            entry = ref.sample_entry
            if isinstance(m, NalVideoModel):
                entry = _patched_video_entry(m, entry, rep)
            t = video_track(m, entry, ref.timescale, frame_dur, ref, prof.sync_i_frames, rep)
            vframes = t.nsamples
            vdur_s = t.media_duration / ref.timescale
        elif m.kind == "audio_aac":
            frame_dur = _mode(ref.durations[:5000], 1024)
            mt = next((mt for sd, mt, r in ref.elst if mt > 0), 0)
            t = aac_track(m, ref.sample_entry, ref.timescale, frame_dur, ref, mt)
            adur_s = t.media_duration / ref.timescale
        elif m.kind == "audio_pcm":
            t = pcm_track(m, ref)
            adur_s = t.media_duration / ref.timescale
        else:
            continue
        tracks.append(t)
    if not tracks or vframes == 0 and adur_s == 0:
        raise RepairError("Nem találtam a mintának megfelelő kép- vagy hangadatot a sérült fájlban. "
                          "Biztos, hogy ugyanazzal a kamerával és beállításokkal készült a minta?")
    if vframes == 0 and vmodels:
        rep.warn("Képkockát nem találtam, csak hangot.")
    ftyp = lay.ftyp or prof.layout.ftyp
    rep.step("Javított fájl írása…")
    write_file(out_path, broken, ftyp, tracks, movie_ts,
               progress=(lambda x: progress(0.6 + 0.38 * x)) if progress else None, cancel=cancel,
               view=view)
    total_payload = len(view) if view is not None else end - start
    covered = sum(sum(t.chunk_bytes) for t in tracks)
    details = {
        "video_frames": vframes,
        "video_seconds": round(vdur_s, 2),
        "audio_seconds": round(adur_s, 2),
        "skipped_bytes": summ["skipped_bytes"],
        "tail_bytes": summ["tail_bytes"],
        "coverage": round(covered / max(1, total_payload), 4),
    }
    if frag:
        details["fragmented"] = frag
    return RepairResult.success(out_path, details)


def _fragment_suspect(sc, start: int, end: int) -> bool:
    return len(sc.skips) >= 2 and sc.skipped_bytes > 0.02 * max(1, end - start)


def _covered(models) -> int:
    return sum(c.end - c.start for m in models if m.output for c in m.chunks)


def _human_size(n: int) -> str:
    if n >= 1 << 20:
        return "%d MB" % (n >> 20)
    return "%d KB" % (n >> 10)


def _find_param_sets(mm, start: int, end: int):
    """Look for length-prefixed SPS/PPS in the first part of the data."""
    region_end = min(end, start + 96 * 1024 * 1024)
    h264 = re.compile(rb"\x00\x00\x00[\x04-\xff][\x27\x47\x67]", re.DOTALL)
    hevc = re.compile(rb"\x00\x00\x00[\x04-\xff]\x42\x01", re.DOTALL)
    m = h264.search(mm, start, region_end)
    m2 = hevc.search(mm, start, region_end)
    cands = []
    if m:
        cands.append((m.start(), "h264"))
    if m2:
        cands.append((m2.start(), "hevc"))
    for pos, kind in sorted(cands):
        codec = H264(4) if kind == "h264" else HEVC(4)
        # read consecutive NALs from here, collecting parameter sets
        p = pos
        nals = []
        for _ in range(16):
            ln = int.from_bytes(mm[p:p + 4], "big")
            if ln < 2 or ln > 4096 * 16 or p + 4 + ln > end:
                break
            nal = bytes(mm[p + 4:p + 4 + ln])
            if codec.is_param_set(nal):
                nals.append(nal)
                codec.add_param_set(nal)
            p += 4 + ln
        if codec.sps and codec.pps:
            return codec, nals, pos
    return None, [], -1


def _bootstrap_video(mm, start: int, end: int, model: NalVideoModel, rep: Reporter):
    """Learn the frame structure from the beginning of the stream itself (no reference file)."""
    codec = model.codec
    if isinstance(codec, H264):
        codec.allowed_first = {9, 7, 6, 5, 1}
    else:
        from .hevc import VCL_TYPES
        codec.allowed_first = {35, 32, 33, 34, 39} | VCL_TYPES
    boot_end = min(end, start + 48 * 1024 * 1024)
    sc = Scanner(mm, start, boot_end, [model], confirm=False)
    sc.run()
    aus = [a for c in model.chunks for a in c.infos]
    if len(aus) >= 8:
        codec.learn(aus)
        lengths = sorted(a.length for a in aus)
        p98 = lengths[min(len(lengths) - 1, int(len(lengths) * 0.98))]
        model.min_au = max(1, lengths[0] // 16)
        model.max_au = codec.max_au = max(p98 * 4, 1024 * 1024)
        if all(a.nal_types and a.nal_types[0] in (9, 35) for a in aus[:200]):
            c0 = model.chunks[0]
            model.aud_len = int.from_bytes(mm[c0.start:c0.start + codec.nls], "big")
        spc = Counter(len(c.sizes) for c in model.chunks[:-1]) or Counter([1])
        top, cnt = spc.most_common(1)[0]
        model.max_per_chunk = max(spc) if cnt >= 0.98 * sum(spc.values()) else max(spc) * 2 + 2
    gaps = []
    prev_end = None
    for _mi, c in sc.order:
        if prev_end is not None and c.start > prev_end:
            gaps.append((prev_end, c.start))
        prev_end = c.end
    nframes = len(aus)
    model.chunks = []
    return gaps, nframes


def _guess_aac(mm, gaps, video_seconds: float, rep: Reporter):
    """Try to read the gaps between video chunks as raw AAC with a guessed configuration."""
    if len(gaps) < 3:
        return None
    from .models import AacProber
    sample = gaps[:60]
    for ch in (2, 1):
        try:
            prober = AacProber(E.make_asc(48000, ch))
        except Exception:  # noqa: BLE001
            return None
        good = 0
        frames = 0
        per_gap = []
        for a, b in sample:
            q, n = a, 0
            while q < b:
                ln = prober.frame_len(mm, q, b)
                if ln is None:
                    break
                q += ln
                n += 1
            if q == b and n:
                good += 1
                frames += n
                per_gap.append(n)
        if good >= 0.8 * len(sample):
            total_frames = frames * len(gaps) / float(len(sample))
            rate = 48000
            if video_seconds > 0:
                best = None
                for r in (48000, 44100, 32000, 24000, 22050, 16000, 96000):
                    err = abs(total_frames * 1024.0 / r - video_seconds)
                    if best is None or err < best[0]:
                        best = (err, r)
                rate = best[1]
            rep.log("AAC hangot találtam mintafájl nélkül: %d csatorna, ~%d Hz" % (ch, rate))
            return ch, rate, Counter(per_gap)
    return None


def rebuild_without_reference(broken: str, out_path: str, rep: Reporter, fps: Optional[float] = None,
                              progress=None, cancel=None, lay: Optional[FileLayout] = None) -> RepairResult:
    lay = lay or read_layout(broken)
    start, end = _data_range(lay)
    rep.step("Kódolás felismerése mintafájl nélkül…")
    audio_model = None
    a_rate = 0
    a_ch = 0
    with open(broken, "rb") as f:
        mm = mmap.mmap(f.fileno(), 0, access=mmap.ACCESS_READ)
        try:
            codec, nals, pos = _find_param_sets(mm, start, end)
            model = None
            entry = b""
            timescale = 0
            frame_dur = 0
            if codec is not None:
                model = NalVideoModel(codec)
                if isinstance(codec, H264):
                    s = next(iter(codec.sps.values()))
                    sps = [n for n in nals if n[0] & 0x1F == 7][:1]
                    pps = list(dict.fromkeys(n for n in nals if n[0] & 0x1F == 8))
                    cfg = build_avcc(sps, pps, 4)
                    entry = E.make_video_entry(b"avc1", s.width, s.height, b"avcC", cfg)
                    detected = (s.fps_num / s.fps_den) if s.fps_den else 0
                    rep.log("H.264 %dx%d, SPS szerinti fps: %s" % (s.width, s.height, detected or "nincs"))
                else:
                    from .hevc import parse_sps as hp
                    sps = [n for n in nals if (n[0] >> 1) & 0x3F == 33][:1]
                    vps = [n for n in nals if (n[0] >> 1) & 0x3F == 32][:1]
                    pps = list(dict.fromkeys(n for n in nals if (n[0] >> 1) & 0x3F == 34))
                    s = hp(sps[0])
                    cfg = build_hvcc(vps, sps, pps, 4)
                    entry = E.make_video_entry(b"hvc1", s.width, s.height, b"hvcC", cfg)
                    detected = 0
                    rep.log("HEVC %dx%d" % (s.width, s.height))
                if detected and detected > 200:
                    detected = 0     # field rate or bogus timing info
                rate = fps or detected or 25.0
                if not fps and not detected:
                    rep.warn("A képkockaszám nem derül ki a fájlból, 25 fps-t feltételeztem. "
                             "Ha gyorsított vagy lassított a videó, válaszd ki a helyes értéket és futtasd újra.")
                timescale, frame_dur = _rate_to_timescale(rate)
                rep.step("Képkocka-szerkezet tanulása…")
                gaps, nboot = _bootstrap_video(mm, start, end, model, rep)
                guess = _guess_aac(mm, gaps, nboot * frame_dur / float(timescale), rep)
                if guess:
                    a_ch, a_rate, per_gap = guess
                    asc = E.make_asc(a_rate, a_ch)
                    audio_model = AacModel("audio", asc)
                    audio_model.frames_per_chunk = per_gap
                    audio_model.finalize()
            else:
                i = mm.find(b"icpf", start, min(end, start + 96 * 1024 * 1024))
                if i >= 4:
                    model = ProResModel()
                    # frame: size(4) 'icpf'(4) hdr_size(2) res(1) ver(1) creator(4) w(2) h(2) flags(1) ar|fr(1)
                    hdr = mm[i - 4:i + 40]
                    w = int.from_bytes(hdr[16:18], "big")
                    h = int.from_bytes(hdr[18:20], "big")
                    chroma = hdr[20] >> 6
                    rcode = hdr[21] & 0x0F
                    fourcc = b"ap4h" if chroma == 3 else b"apcn"
                    entry = _prores_entry(fourcc, w, h)
                    if fps:
                        timescale, frame_dur = _rate_to_timescale(fps)
                    elif rcode in PRORES_RATES:
                        num, den = PRORES_RATES[rcode]
                        timescale, frame_dur = (num, den) if den != 1 else (num * 100, 100)
                    else:
                        timescale, frame_dur = _rate_to_timescale(25.0)
                    rep.log("ProRes %dx%d" % (w, h))
            if model is None:
                raise RepairError("Mintafájl nélkül nem ismerem fel a videó kódolását (a kamera nem írta bele a "
                                  "kódolási adatokat a felvételbe). Adj meg egy ép mintafájlt ugyanarról a kameráról.")
            models = [model] + ([audio_model] if audio_model else [])
            trans = Counter({(0, 1): 10, (1, 0): 10, ("any", 1): 10}) if audio_model else None
            rep.step("Sérült fájl átvizsgálása…")
            sc = Scanner(mm, start, end, models, trans,
                         progress=(lambda x: progress(0.05 + 0.55 * x)) if progress else None, cancel=cancel,
                         confirm=audio_model is not None or not isinstance(model, NalVideoModel))
            sc.run()
        finally:
            mm.close()
    if cancel and cancel():
        raise InterruptedError
    if not model.chunks:
        raise RepairError("Nem találtam visszaállítható képkockát.")
    t = video_track(model, entry, timescale, frame_dur, None, False, rep)
    tracks = [t]
    adur = 0.0
    if audio_model is not None and audio_model.chunks:
        a_entry = E.make_mp4a_entry(a_rate, a_ch, E.make_asc(a_rate, a_ch))
        # typical AAC encoder delay (priming) is 1024 samples
        at = aac_track(audio_model, a_entry, a_rate, 1024, None, 1024, track_id=2)
        tracks.append(at)
        adur = at.media_duration / float(a_rate)
    rep.step("Javított fájl írása…")
    write_file(out_path, broken, lay.ftyp, tracks, 1000,
               progress=(lambda x: progress(0.6 + 0.38 * x)) if progress else None, cancel=cancel)
    if not adur:
        rep.warn("Mintafájl nélkül a hangot nem tudtam visszaállítani, csak a képet.")
    else:
        rep.note("A hangot mintafájl nélkül, becsült beállításokkal állítottam vissza (AAC, %d Hz)." % a_rate)
    return RepairResult.success(out_path, {
        "video_frames": t.nsamples,
        "video_seconds": round(t.media_duration / float(timescale), 2),
        "audio_seconds": round(adur, 2),
        "skipped_bytes": sc.skipped_bytes,
    })


def _rate_to_timescale(rate: float):
    known = {23.976: (24000, 1001), 29.97: (30000, 1001), 59.94: (60000, 1001), 119.88: (120000, 1001)}
    for k, v in known.items():
        if abs(rate - k) < 0.01:
            return v
    r = int(round(rate))
    return r * 100, 100


def _prores_entry(fourcc: bytes, w: int, h: int) -> bytes:
    import struct
    body = b"\x00" * 6 + struct.pack(">H", 1) + b"\x00" * 16
    body += struct.pack(">HHIIIH", w, h, 0x00480000, 0x00480000, 0, 1)
    name = b"Apple ProRes"
    body += bytes([len(name)]) + name + b"\x00" * (31 - len(name))
    body += struct.pack(">Hh", 0x18, -1)
    return make_box(fourcc, body)


def trim_with_own_index(broken: str, out_path: str, lay: FileLayout, rep: Reporter,
                        progress=None, cancel=None) -> Optional[RepairResult]:
    """The file has a moov but part of the data is missing: keep the samples that exist."""
    movie = lay.moov
    tracks = []
    any_cut = False
    total_kept = 0
    for t in movie.tracks:
        if not t.sizes:
            continue
        keep = 0
        for o, s in zip(t.offsets, t.sizes):
            if o + s > lay.size:
                any_cut = True
                break
            keep += 1
        if keep == 0:
            continue
        total_kept += keep
        # rebuild chunk lists for the kept samples
        chunk_src, chunk_counts, chunk_bytes = [], [], []
        si = 0
        for co, k in zip(t.chunk_offsets, t.chunk_samples):
            if si >= keep:
                break
            k2 = min(k, keep - si)
            chunk_src.append(co)
            chunk_counts.append(k2)
            chunk_bytes.append(sum(t.sizes[si:si + k2]))
            si += k2
        sizes = None if t.stsz_const else t.sizes[:keep]
        dur_runs = []
        for d in t.durations[:keep]:
            if dur_runs and dur_runs[-1][1] == d:
                dur_runs[-1] = (dur_runs[-1][0] + 1, d)
            else:
                dur_runs.append((1, d))
        cts = t.cts[:keep] if any(t.cts[:keep]) else None
        sync = sorted(i for i in t.sync if i < keep) if t.sync is not None else None
        mt = next((mt for sd, mt, r in t.elst if mt > 0), 0)
        tracks.append(OutTrack(t.handler, t.timescale, t.sample_entry, chunk_src, chunk_counts, chunk_bytes,
                               sizes, stsz_const=t.stsz_const, durations=dur_runs, cts=cts, sync=sync,
                               media_time=mt, ref=t, track_id=t.track_id, language=t.mdhd_language))
    if not any_cut:
        return None
    if not tracks:
        raise RepairError("A fájl indexe megvan, de egyetlen hozzá tartozó adat sincs a fájlban.")
    rep.step("Javított fájl írása (a meglévő index alapján)…")
    write_file(out_path, broken, lay.ftyp, tracks, movie.timescale,
               progress=(lambda x: progress(0.1 + 0.88 * x)) if progress else None, cancel=cancel)
    v = next((t for t in tracks if t.handler == b"vide"), None)
    return RepairResult.success(out_path, {
        "video_frames": v.nsamples if v else 0,
        "video_seconds": round(v.media_duration / v.timescale, 2) if v else 0,
        "audio_seconds": 0,
        "skipped_bytes": 0,
    })


def remux(broken: str, out_path: str, rep: Reporter, progress=None, cancel=None) -> RepairResult:
    """Container rewrite through FFmpeg (fragmented / slightly damaged files)."""
    import av
    av.logging.set_level(None)
    rep.step("Újracsomagolás…")
    with av.open(broken, options={"err_detect": "ignore_err"}) as src:
        streams = [s for s in src.streams if s.type in ("video", "audio")]
        if not streams:
            raise RepairError("Nincs kép- vagy hangsáv a fájlban.")
        dur = float(src.duration or 0) / 1e6
        with av.open(out_path + ".part", "w", format="mp4" if out_path.lower().endswith(".mp4") else "mov") as dst:
            omap = {}
            for s in streams:
                try:
                    omap[s.index] = dst.add_stream_from_template(s)
                except Exception:  # noqa: BLE001
                    continue
            n = 0
            for pkt in src.demux(list(s for s in streams if s.index in omap)):
                if pkt.dts is None:
                    continue
                if cancel and cancel():
                    raise InterruptedError
                pkt.stream = omap[pkt.stream.index]
                try:
                    dst.mux(pkt)
                except Exception:  # noqa: BLE001
                    continue
                n += 1
                if progress and dur and n % 200 == 0 and pkt.time is not None:
                    progress(min(0.98, float(pkt.time) / dur))
    os.replace(out_path + ".part", out_path)
    return RepairResult.success(out_path, {})


def repair_video(broken: str, reference: Optional[str] = None, out_path: Optional[str] = None,
                 fps: Optional[float] = None, progress: Optional[Callable[[float], None]] = None,
                 cancel: Optional[Callable[[], bool]] = None, reporter: Optional[Reporter] = None) -> RepairResult:
    _hotreload.enter()          # may reload this module: the call below then runs the new code
    try:
        return _repair_video(broken, reference, out_path, fps, progress, cancel, reporter)
    finally:
        _hotreload.leave()


def _repair_video(broken, reference, out_path, fps, progress, cancel, reporter) -> RepairResult:
    rep = reporter or Reporter()
    out_path = out_path or default_output_path(broken)
    try:
        rep.step("Fájlszerkezet olvasása…")
        lay = read_layout(broken)
        if lay.size == 0:
            raise RepairError("A fájl üres (0 bájt).")
        if _is_all_zero(broken, lay):
            raise RepairError("A fájl tartalma csupa nulla bájt – az adat nem került rá a kártyára, "
                              "ebből nem lehet visszaállítani semmit.")
        if lay.moov is not None and not any(t.sizes for t in lay.moov.tracks):
            rep.log("A fájlban van index (moov), de üres – figyelmen kívül hagyom.")
            lay.moov = None
        if lay.moov is not None and not lay.fragmented:
            res = trim_with_own_index(broken, out_path, lay, rep, progress, cancel)
            if res is not None:
                res.message = "A fájl saját indexe alapján helyreállítva (a hiányzó végét levágtam)."
                return _finish(res, rep)
            from .verify import verify_output
            v = verify_output(broken)
            if v.get("playable") or not reference:
                res = RepairResult(status="intact", output=None,
                                   message="A fájl szerkezete ép, nem találtam benne hibát. "
                                           "Ha mégsem játszik le egy programban, az valószínűleg a "
                                           "kodek támogatásán múlik, nem a fájlon.")
                res.preview = v.get("preview")
                res.details.update(v)
                return _finish(res, rep)
            rep.note("A fájlnak van indexe, de nem dekódolható rendesen – mintafájl alapján újraépítem.")
        if lay.fragmented and not reference:
            res = remux(broken, out_path, rep, progress, cancel)
            res.message = "Töredékes (fragmented) MP4 újracsomagolva."
            return _finish(res, rep)
        if reference:
            res = rebuild_with_reference(broken, reference, out_path, rep, progress, cancel, lay)
        else:
            res = rebuild_without_reference(broken, out_path, rep, fps, progress, cancel, lay)
        return _finish(res, rep)
    except InterruptedError:
        _cleanup(out_path)
        return RepairResult(status="cancelled", output=None, message="Megszakítva.", log=rep.lines)
    except RepairError as e:
        _cleanup(out_path)
        return RepairResult(status="failed", output=None, message=str(e), log=rep.lines)


def _cleanup(out_path: str) -> None:
    for p in (out_path + ".part", ):
        try:
            if os.path.exists(p):
                os.remove(p)
        except OSError:
            pass


def _is_all_zero(path: str, lay: FileLayout) -> bool:
    start, end = _data_range(lay)
    with open(path, "rb") as f:
        for frac in (0.0, 0.25, 0.5, 0.75):
            f.seek(start + int((end - start) * frac))
            b = f.read(1 << 20)
            if b.strip(b"\x00"):
                return False
    return True


def _finish(res: RepairResult, rep: Reporter) -> RepairResult:
    from .verify import verify_output
    res.log = rep.lines
    res.notes = rep.notes
    res.warnings = rep.warnings
    if res.output and os.path.exists(res.output):
        v = verify_output(res.output)
        res.details.update(v)
        if not v.get("playable"):
            res.status = "partial"
            res.warnings.append("A kimeneti fájl dekódolása hibát jelzett, lehet, hogy csak részben játszható le.")
        if not res.message:
            sec = res.details.get("video_seconds") or res.details.get("duration") or 0
            res.message = "Kész: %s visszaállítva." % _fmt_dur(sec)
    return res


def _fmt_dur(sec: float) -> str:
    sec = int(round(sec or 0))
    h, r = divmod(sec, 3600)
    m, s = divmod(r, 60)
    if h:
        return "%d:%02d:%02d" % (h, m, s)
    return "%d:%02d" % (m, s)
