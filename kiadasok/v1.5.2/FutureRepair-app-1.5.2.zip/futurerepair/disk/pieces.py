"""Common ground for putting files back together from 'pieces' on a formatted exFAT disk.

The old folder entry gives a file's first cluster and exact size. The copy program wrote the
file in pieces of U bytes (32 MB); each piece is contiguous and starts on the cluster grid, but
the pieces of files copied at the same time alternate on the disk. Piece k holds the in-file
bytes [k*U, (k+1)*U). The subclasses decide whether a candidate position can hold piece k by
looking at the file's own structure across the piece boundary.
"""
from __future__ import annotations

import time
from typing import Callable, Dict, Iterator, List, Optional, Tuple


class PieceRebuild:
    kind = "?"

    def __init__(self, src, G: int, H: int, count: int, U: int, first: int, size: int, claimed: bytearray,
                 log: Callable[[str], None], cancel=None, progress=None, hint: Optional[int] = None,
                 name: str = "", window: int = 32 << 30):
        self.src = src
        self.G, self.H, self.count, self.U = G, H, count, U
        self.first, self.size = first, size
        self.claimed = claimed
        self.log = log
        self.cancel = cancel
        self.progress = progress
        self.hint = hint
        self.name = name
        self.ucl = U // G
        self.K = max(1, -(-size // U))
        self.window_cl = window // G
        self.pieces: Dict[int, int] = {0: first}
        self.found_by: Dict[int, int] = {}
        self.tried = 0
        self.claims: List[Tuple[int, int]] = []
        self.t0 = time.time()

    # geometry ---------------------------------------------------------------------------
    def pos(self, c: int) -> int:
        return self.H + (c - 2) * self.G

    def plen(self, k: int) -> int:
        return min(self.size, (k + 1) * self.U) - k * self.U

    def plen_cl(self, k: int) -> int:
        return -(-self.plen(k) // self.G)

    def seg(self, k: int, c: int) -> Tuple[int, int]:
        p = self.pos(c)
        return p, p + self.plen(k)

    def free(self, c: int, n: int) -> bool:
        if c < 2 or c + n > self.count + 2:
            return False
        return self.claimed.find(1, c, c + n) == -1

    def claim(self, c: int, n: int) -> None:
        self.claimed[c:c + n] = b"\x01" * n
        self.claims.append((c, n))

    def release(self) -> None:
        """Give back what this attempt took (when it did not succeed)."""
        for c, n in self.claims:
            self.claimed[c:c + n] = bytes(n)
        self.claims = []

    def cancelled(self) -> None:
        if self.cancel and self.cancel():
            raise InterruptedError

    def extents(self) -> List[Tuple[int, int]]:
        return [self.seg(k, self.pieces[k]) for k in range(self.K)]

    def jumps(self) -> int:
        return sum(1 for k in range(1, self.K) if self.pieces[k] != self.pieces[k - 1] + self.plen_cl(k - 1))

    # reading by in-file position ----------------------------------------------------------
    def reader(self, extra: Optional[Dict[int, int]] = None) -> Callable[[int, int], bytes]:
        """read(off, n) over the known pieces (plus `extra` {k: cluster}); stops at an unknown piece."""
        pieces = dict(self.pieces)
        if extra:
            pieces.update(extra)
        src, U, size = self.src, self.U, self.size

        def read(off: int, n: int) -> bytes:
            out = []
            while n > 0 and off < size:
                k = off // U
                c = pieces.get(k)
                if c is None:
                    break
                inner = off - k * U
                m = min(n, U - inner, size - off)
                b = src.read(self.pos(c) + inner, m)
                out.append(b)
                if len(b) < m:
                    break
                off += m
                n -= m
            return b"".join(out)
        return read

    # where to look for a piece ------------------------------------------------------------
    def candidates(self, k: int) -> Iterator[int]:
        """Positions for piece k, most likely first: right after piece k-1, the same gap as last
        time, after 1..6 foreign pieces, then everything up to the next known piece."""
        prev = self.pieces[k - 1]
        start = prev + self.plen_cl(k - 1)
        upper = None
        for kk in sorted(self.pieces):
            if kk > k:
                upper = self.pieces[kk]
                break
        gap = None
        if (k - 2) in self.pieces:
            gap = prev - (self.pieces[k - 2] + self.plen_cl(k - 2))
        order = [start]
        if gap is not None and gap > 0:
            order.append(start + gap)
        order += [start + self.ucl * j for j in range(1, 7)]
        order += [start + d for d in range(1, 9)] + [start + self.ucl + d for d in range(1, 9)]
        seen = set()
        for c in order:
            if c not in seen:
                seen.add(c)
                yield c
        stop = upper if upper is not None and upper > start else start + self.window_cl
        for c in range(start + 1, min(self.count + 2, stop)):
            if c not in seen:
                yield c
        if upper is not None:
            for c in range(upper + 1, min(self.count + 2, upper + self.window_cl // 4)):
                yield c
        for c in range(prev - 1, max(1, prev - self.window_cl // 8), -1):
            yield c

    def last_candidates(self) -> Iterator[int]:
        """Positions for the last piece: just before the file's sidecar (written right after it),
        then forward from the first piece."""
        k = self.K - 1
        n = self.plen_cl(k)
        seen = set()
        if self.hint:
            for j in range(0, 4096):
                c = self.hint - n - j
                if c <= self.first:
                    break
                seen.add(c)
                yield c
        lo = self.first + self.ucl
        for c in range(lo, min(self.count + 2, lo + self.window_cl)):
            if c not in seen:
                yield c

    def search(self, k: int, check: Callable[[int], Optional[bool]], cands: Optional[Iterator[int]] = None,
               limit: Optional[int] = None) -> Optional[int]:
        n = self.plen_cl(k)
        for i, c in enumerate(cands if cands is not None else self.candidates(k)):
            if i % 256 == 0:
                self.cancelled()
            if limit is not None and i >= limit:
                break
            if not self.free(c, n):
                continue
            self.tried += 1
            if check(c):
                self.found_by[k] = i
                return c
        return None

    def result(self, state: str, message: str, **kw) -> Dict:
        r = {"state": state, "message": message, "pieces": self.K, "tried": self.tried,
             "seconds": round(time.time() - self.t0, 1)}
        r.update(kw)
        if state == "complete":
            r["extents"] = self.extents()
            r["jumps"] = self.jumps()
        return r
