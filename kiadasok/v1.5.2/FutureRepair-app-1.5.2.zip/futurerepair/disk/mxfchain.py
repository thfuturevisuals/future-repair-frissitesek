"""Putting a fragmented MXF recording (e.g. Sony FX6 / FX9, Canon XF-AVC) back together.

An MXF file is one long chain of KLV packets (16-byte key that starts with 06 0E 2B 34, a BER
length, the value). Walking the chain tells exactly where the next packet must start after a
piece boundary, so a candidate piece is right only if a valid packet starts at exactly that
offset and the chain runs on through the whole piece. Frame-wrapped recordings also carry a
system item in every frame whose continuity count goes up by one, which tells two cameras with
the same settings apart. The Random Index Pack at the very end lists where every partition
starts; it is looked for first (just before the sidecar XML) and bounds the search.
"""
from __future__ import annotations

from typing import Dict, List, Optional, Set, Tuple

from .pieces import PieceRebuild

PREFIX = b"\x06\x0e\x2b\x34"
PARTITION = b"\x06\x0e\x2b\x34\x02\x05\x01\x01\x0d\x01\x02\x01\x01"      # + kind (2/3/4) + status + 00
RIP_KEY = b"\x06\x0e\x2b\x34\x02\x05\x01\x01\x0d\x01\x02\x01\x01\x11\x01\x00"
SYSTEM_PACK = b"\x06\x0e\x2b\x34\x02\x05\x01\x01\x0d\x01\x03\x01\x04\x01\x01\x00"


def klv_header(b: bytes, i: int = 0) -> Optional[Tuple[bytes, int, int]]:
    """(key, header length, value length) of the packet at b[i], or None."""
    if len(b) < i + 17:
        return None
    if b[i:i + 4] != PREFIX or b[i + 4] not in (1, 2, 3, 4):
        return None
    L = b[i + 16]
    if L < 0x80:
        return bytes(b[i:i + 16]), 17, L
    n = L & 0x7F
    if n == 0 or n > 8 or len(b) < i + 17 + n:
        return None
    return bytes(b[i:i + 16]), 17 + n, int.from_bytes(b[i + 17:i + 17 + n], "big")


def is_mxf_start(head: bytes) -> bool:
    return head[:13] == PARTITION and len(head) > 13 and head[13] == 2


FPS = [0, 24, 25, 30, 48, 50, 60, 72, 75, 90, 96, 100, 120]


def tc_frames(tc: bytes, fps: int) -> Optional[int]:
    """Frame number of an SMPTE 12M time code (4 BCD bytes: frames, seconds, minutes, hours)."""
    if len(tc) < 4 or not fps:
        return None
    def bcd(v, tens_mask):
        return ((v >> 4) & tens_mask) * 10 + (v & 0x0F)
    f, sec, m, h = bcd(tc[0], 0x3), bcd(tc[1], 0x7), bcd(tc[2], 0x7), bcd(tc[3], 0x3)
    if f >= fps or sec > 59 or m > 59 or h > 23:
        return None
    return ((h * 60 + m) * 60 + sec) * fps + f


class Walk:
    """State of the packet chain at a point: where the next packet starts, the last continuity
    count, time code and picture element seen."""
    __slots__ = ("next", "cc", "n", "tc", "fps", "pic", "last")

    def __init__(self, nxt: int, cc: Optional[int] = None, n: int = 0, tc: Optional[int] = None,
                 fps: int = 0, pic: Optional[Tuple[int, int]] = None, last=None):
        self.next, self.cc, self.n, self.tc, self.fps, self.pic, self.last = nxt, cc, n, tc, fps, pic, last

    def copy(self, nxt=None):
        return Walk(self.next if nxt is None else nxt, self.cc, self.n, self.tc, self.fps, self.pic, self.last)


class MxfRebuild(PieceRebuild):
    kind = "mxf"

    def __init__(self, *a, **kw):
        super().__init__(*a, **kw)
        self.rip: List[int] = []                # partition offsets from the Random Index Pack
        self.rip_set: Set[int] = set()
        self.uncertain: List[int] = []
        self.decided: Dict[str, int] = {}
        self.twin_prone = False
        self.why: Dict[str, int] = {}        # why candidates were turned down (for the log when a piece is missing)
        self.rip_dropped = False

    # chain walking ------------------------------------------------------------------------
    def walk(self, read, w: Walk, stop: int, need_cc: bool = False, max_packets: Optional[int] = None,
             starts: Optional[Set[int]] = None, info: Optional[Dict] = None,
             pic_sizes: Optional[List[int]] = None) -> Tuple[bool, Walk, Optional[int]]:
        """Follow the chain from w.next while packets start before `stop`.
        Returns (ok, new state, first continuity count seen); `info` gets the first time code and
        the first whole picture element after the start."""
        st = w.copy()
        off = st.next
        first_cc = None
        count = 0
        while off < stop:
            h = read(off, 32)
            if len(h) < 17 and off + 17 <= self.size:
                st.next = off
                return True, st, first_cc
            r = klv_header(h, 0)
            if r is None:
                if len(h) < 32 and off + 32 <= self.size and h[:4] == PREFIX[:len(h[:4])]:
                    st.next = off
                    return True, st, first_cc
                st.next = off
                return False, st, first_cc
            key, hl, vl = r
            end = off + hl + vl
            if end > self.size:
                st.next = off
                return False, st, first_cc
            if starts is not None:
                starts.add(off)
            if key == SYSTEM_PACK and vl >= 7:
                v = read(off + hl, min(vl, 57))
                if len(v) >= 7:
                    c = int.from_bytes(v[5:7], "big")
                    if first_cc is None:
                        first_cc = c
                        if need_cc and st.cc is not None and c != (st.cc + 1) & 0xFFFF:
                            st.next = off
                            return False, st, first_cc
                    st.cc = c
                if len(v) >= 57:
                    st.fps = FPS[(v[1] >> 1) & 0x1F] if ((v[1] >> 1) & 0x1F) < len(FPS) else 0
                    tcb = v[41:45] if v[40] == 0x81 else (v[24:28] if v[23] == 0x81 else b"")
                    t = tc_frames(tcb, st.fps) if tcb else None
                    if info is not None and "tc" not in info and t is not None:
                        info["tc"] = t
                    st.tc = t
            elif key[12] in (0x05, 0x15) and key[4] == 0x01 and end <= stop:
                if pic_sizes is not None:
                    pic_sizes.append(vl)
                if info is not None and "pic" not in info:
                    info["pic"] = (off + hl, vl)
                st.pic = (off + hl, vl)
            st.last = ("pic" if key[12] in (0x05, 0x15) and key[4] == 0x01 else
                       "snd" if key[12] in (0x06, 0x16) and key[4] == 0x01 else "other", off + hl, vl)
            off = end
            st.n += 1
            count += 1
            if max_packets is not None and count >= max_packets and (first_cc is not None or not need_cc):
                break
        st.next = off
        return True, st, first_cc

    def _piece_ok(self, k: int, c: int, w: Walk, info: Optional[Dict] = None) -> Optional[Walk]:
        """Does piece k fit at cluster c, coming after chain state w? Returns the state at its end."""
        read = self.reader({k: c})
        lo = k * self.U
        hi = lo + self.plen(k)

        def no(reason):
            self.why[reason] = self.why.get(reason, 0) + 1
            return None
        # quick test: a packet must start exactly where the chain says
        h = read(w.next, 32)
        if klv_header(h, 0) is None and len(h) >= 32:
            return no("nincs csomag a helyén")
        ok, w2, first_cc = self.walk(read, w, hi, need_cc=w.cc is not None, max_packets=6)
        if not ok:
            if w.cc is not None and first_cc is not None and first_cc != (w.cc + 1) & 0xFFFF:
                return no("más a képkockaszámláló")
            return no("a lánc az elején megszakad")
        # the whole piece: every packet valid, the partitions where the index says
        starts: Set[int] = set()
        ok, w3, _ = self.walk(read, w, hi, need_cc=w.cc is not None, starts=starts, info=info)
        if not ok:
            return no("a lánc a darab közepén megszakad")
        for p in self.rip:
            if lo <= p < hi and p not in starts:
                return no("a partíció nem ott van, ahol a fájl vége szerint kell")
        if k == self.K - 1 and w3.next != self.size:
            return no("a lánc nem a fájl végén ér véget")
        return w3

    def _choose(self, k: int, w: Walk, passes: List[Tuple[int, int, Walk, Dict]]):
        """Several positions fit piece k structurally (two cameras with the same settings): decide
        by the time code, then by the picture."""
        if w.tc is not None:
            nxt = [p for p in passes if p[3].get("tc") is not None and p[3]["tc"] - w.tc == 1]
            if len(nxt) == 1:
                self.decided["time code"] = self.decided.get("time code", 0) + 1
                return nxt[0]
            if nxt:
                passes = nxt
        if w.pic is not None:
            from .thumbs import mad, thumb
            left = thumb(self.reader()(w.pic[0], w.pic[1]))
            # the picture that runs across the boundary, put together with each candidate
            lt = w.last
            if left is not None and lt is not None and lt[0] == "pic" and lt[1] < k * self.U < lt[1] + lt[2]:
                scored = []
                for p in passes:
                    t = thumb(self.reader({k: p[1]})(lt[1], lt[2]))
                    scored.append((mad(left, t) if t is not None else 1e9, p))
                scored.sort(key=lambda x: x[0])
                if scored[0][0] < 1e9 and (len(scored) == 1 or scored[0][0] < 0.75 * scored[1][0]):
                    self.decided["picture"] = self.decided.get("picture", 0) + 1
                    return scored[0][1]
            if left is not None:
                scored = []
                for p in passes:
                    pic = p[3].get("pic")
                    if pic is None:
                        continue
                    t = thumb(self.reader({k: p[1]})(pic[0], pic[1]))
                    if t is not None:
                        scored.append((mad(left, t), p))
                scored.sort(key=lambda x: x[0])
                if scored and (len(scored) == 1 or scored[0][0] < 0.75 * scored[1][0]):
                    self.decided["picture"] = self.decided.get("picture", 0) + 1
                    return scored[0][1]
        self.uncertain.append(k)
        if getattr(self, "debug", False):
            self.log("    bizonytalan %d. darab: %s; bal kép: %s; jelöltek: %s" % (
                k, [(p[0], p[1], p[3].get("tc"), p[3].get("pic")) for p in passes], w.pic, w.tc))
        return passes[0]

    def _find_piece(self, k: int, w: Walk, first: Optional[int] = None):
        n = self.plen_cl(k)
        passes = []
        first_i = None
        cands = self.candidates(k)
        if first is not None:
            import itertools
            cands = itertools.chain([first], (c for c in cands if c != first))
        # recordings with the same size for every frame (XAVC Intra, DNxHD...) from a second camera
        # look the same piece by piece: then look further for a look-alike before deciding
        extra = (4 * self.ucl + 32) if self.twin_prone else 24
        for i, c in enumerate(cands):
            if i % 256 == 0:
                self.cancelled()
            if first_i is not None and i > first_i + extra:
                break
            if not self.free(c, n):
                continue
            self.tried += 1
            info: Dict = {}
            r = self._piece_ok(k, c, w, info)
            if r is not None:
                passes.append((i, c, r, info))
                if first_i is None:
                    first_i = i
        if getattr(self, "debug", False):
            self.log("    %s darab %d: megfelel %s" % (self.name, k, [(p[0], p[1]) for p in passes]))
        if not passes:
            return None
        if len(passes) == 1:
            return passes[0]
        got = self._choose(k, w, passes)
        if getattr(self, "debug", False):
            self.log("      -> %d" % got[1])
        return got

    # the Random Index Pack at the end ------------------------------------------------------------
    def _rip_at(self, c: int) -> Optional[List[int]]:
        k = self.K - 1
        lo = k * self.U
        read = self.reader({k: c})
        tail = read(self.size - 4, 4)
        if len(tail) < 4:
            return None
        L = int.from_bytes(tail, "big")
        start = self.size - L
        if L < 16 + 1 + 4 + 12 or L > (8 << 20) or start < lo:
            return None
        h = read(start, 32)
        r = klv_header(h, 0)
        if r is None or r[0] != RIP_KEY:
            return None
        hl, vl = r[1], r[2]
        if hl + vl != L or (vl - 4) % 12:
            return None
        body = read(start + hl, vl - 4)
        offs = []
        for i in range(0, len(body), 12):
            offs.append(int.from_bytes(body[i + 4:i + 12], "big"))
        if not offs or offs[0] != 0 or any(b <= a for a, b in zip(offs, offs[1:])) or offs[-1] >= self.size:
            return None
        foot = offs[-1]
        if foot >= lo:
            fh = read(foot, 16)
            if fh[:13] != PARTITION or fh[13] != 4:
                return None
        return offs

    def find_end(self) -> bool:
        if self.K < 2:
            return False
        k = self.K - 1
        for i, c in enumerate(self.last_candidates()):
            if i % 256 == 0:
                self.cancelled()
            if not self.free(c, self.plen_cl(k)):
                continue
            offs = self._rip_at(c)
            if offs:
                self.pieces[k] = c
                self.found_by[k] = i
                self.rip = offs
                self.rip_set = set(offs)
                self.log("  %s: a fájl vége (partíciólista) megvan a %d. klaszterben (%d. jelölt)." % (
                    self.name, c, i + 1))
                return True
        return False

    # main --------------------------------------------------------------------------------------
    def run(self) -> Dict:
        read0 = self.reader()
        head = read0(0, 64)
        if not is_mxf_start(head):
            return self.result("failed", "A fájl eleje nem MXF a lemezen.")
        if self.K == 1:
            return self.result("complete", "Egy darabban.")
        self.find_end()
        w = Walk(0)
        sizes: List[int] = []
        ok, w, _ = self.walk(read0, w, self.plen(0), pic_sizes=sizes)
        if not ok:
            # the chain breaks inside the first piece: the copy program wrote smaller pieces, and the
            # first one ends between the last good packet and the broken one
            last = w.last
            lo = max(1, (last[1] - 64) if last else 1)
            return self.result("partial", "Az első darab rövidebb %d MB-nál (a másolóprogram kisebb darabokban írt), "
                                          "vagy felülíródott." % (self.U >> 20), first_break=(lo, w.next))
        self.twin_prone = len(sizes) >= 5 and len(set(sizes)) == 1
        last_known = self.pieces.get(self.K - 1)
        for k in range(1, self.K):
            if self.progress:
                self.progress(k / float(self.K))
            first = None
            if k == self.K - 1 and last_known is not None:
                # the end found first only bounded the search; it is checked like any other
                # candidate (a camera with the same settings has an end that looks the same)
                del self.pieces[k]
                first = last_known
            self.why = {}
            got = self._find_piece(k, w, first=first)
            if got is None and self.rip and not self.rip_dropped:
                # the partition list found at the end may belong to a look-alike recording: try without it
                why = dict(self.why)
                saved, self.rip, self.rip_set = self.rip, [], set()
                got = self._find_piece(k, w, first=first)
                if got is None:
                    self.rip, self.rip_set = saved, set(saved)
                    self.why = why
                else:
                    self.rip_dropped = True
                    self.log("  %s: a fájl végén talált partíciólista nem ehhez a felvételhez tartozik, "
                             "nélküle folytatom." % self.name)
            if got is None:
                why = ", ".join("%s: %d" % kv for kv in sorted(self.why.items(), key=lambda x: -x[1])[:4])
                self.log("  %s: a %d. darab nincs meg (%d jelölt; %s)." % (self.name, k + 1, self.tried,
                                                                         why or "nem volt szabad jelölt"))
                return self.result("partial", "A %d darabból a %d.-at nem találtam meg." % (self.K, k + 1),
                                   missing_from=k, found=sorted(self.pieces), why=self.why)
            i, c, w, _info = got
            self.found_by[k] = i
            self.pieces[k] = c
            self.claim(c, self.plen_cl(k))
        if w.next != self.size:
            return self.result("partial", "A csomagok lánca nem a fájl végén ér véget.")
        msg = "Teljes: %d darab, %d csomag végigellenőrizve." % (self.K, w.n)
        if self.decided:
            msg += " Hasonló felvétel darabjai közül %s döntött." % ", ".join(
                "%d helyen %s" % (v, {"time code": "az időkód", "picture": "a kép"}[k]) for k, v in self.decided.items())
        if self.uncertain:
            msg += " %d darabnál nem lehetett biztosan dönteni két hasonló felvétel között." % len(self.uncertain)
        return self.result("complete", msg, packets=w.n, partitions=len(self.rip), uncertain=len(self.uncertain),
                           uncertain_pieces=self.uncertain[:50])
